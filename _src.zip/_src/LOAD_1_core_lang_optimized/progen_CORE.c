// NEEDS TO HAVE grid IMPORTED, OR THIS WON'T RUN!!!
#if defined(DUK_VERSION)	
void progen_CORE_duktape_port_settup(duk_context *ctx);
#endif

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
/////////////// Ducktape Port //////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

#if defined(DUK_VERSION)


// can keep counting up index... indefinitely
int progen_NOROLL_indefinite_shuffled_d_roll( 
	int max_roll, int index, int number_of_decks){ //rolls AS IF this # of decks
	
	index = abs(index ); max_roll = max_roll* number_of_decks; 
	int random_deckdraw_number = abs( (int)floor(
				(float)index /(float)max_roll));	    
	int strt_index = (int) abs( floor( 
	   sin( (float)random_deckdraw_number ) * ((float)max_roll-1.0)));
	
	//more randomness, going reverse order if divisible by 3
	int i_draw= 0;
	if( random_deckdraw_number % 2 != 0){ i_draw = index % max_roll;
	}else{ i_draw = max_roll-1 - (index % max_roll); }		

	int shuffles = 3+(random_deckdraw_number % 3);	
	for(int j=0; j< shuffles; j+=1){
	  //cutting deck, gives * max_roll to randomization multiplier
	  i_draw = i_draw + (random_deckdraw_number % max_roll );
	  if( i_draw >= max_roll){ i_draw -= max_roll;}	

	 i_draw +=1; //shuffling deck, counts up if %2, or down
	 if( i_draw % 2 ==0 ){ i_draw = strt_index + 
			(int)floor( (float)i_draw /2.0);
	 }else{  i_draw = strt_index - (int)floor( (float)i_draw /2.0); }

	 if( i_draw < 0){ i_draw += max_roll;} 
	 if( i_draw >= max_roll){ i_draw -= max_roll;}
	}
	return (int) ceil(((float)i_draw+1.0)/(float)number_of_decks); 
}
static duk_ret_t duk_progen_CORE_NOROLL_indefShuf_d_roll(
		duk_context *ctx) {
    // Get the first argument (obj1)
    int max_roll = (int)duk_get_number(ctx, 0);
    int index = (int)duk_get_number(ctx, 1);
    int number_of_decks = (int)duk_get_number(ctx, 2);
	
    int ret_index = (int)progen_NOROLL_indefinite_shuffled_d_roll( 
	max_roll, index, number_of_decks);
    
    duk_push_int(ctx, ret_index); 
    return 1; //1 return value
}


/////////////////////////////
///// _update_os_obj_join (I had perplexity translate js code)
//		EDIT: perplexity gave non-functional code, had to 
//			rewrite it.  (was helpful, though)
//	THIS IS FOR PROGEN_OBJ_JOIN,
//	It's here because I don't have a c file for progen at this point
//		(may move it in future)
/////////////////
static duk_ret_t duk_progen_CORE_obj_join(duk_context *ctx) {
    // Get the first argument (obj1)
    duk_idx_t obj1_idx = 0;

    // Get the second argument (obj2)
    duk_idx_t obj2_idx = 1;

    // Get the keys of obj2
    duk_idx_t enum_id = 2;
    duk_enum(ctx, obj2_idx, DUK_ENUM_OWN_PROPERTIES_ONLY);
    while (duk_next(ctx, enum_id, 1)) {
        //duk_get_string(ctx, -2),//key 
	//duk_get_string(ctx, -1)  //val
	
	//if(0==duk_has_prop_string(ctx, obj1_idx, duk_get_string(ctx, -2))){
	  duk_put_prop_string(ctx, obj1_idx, duk_get_string(ctx, -2));
	//}else{ duk_pop(ctx);}
 	
	// val has already been removed...
	duk_pop(ctx);
    }

    // Clean up the stack
    //  remove enum_id (duplicate
    duk_pop(ctx);

    duk_dup(ctx, obj1_idx);
    // Return obj1
    return 1;
}


static duk_ret_t duk_progen_OBJ_ASSIGN(duk_context *ctx) {
    // Getting number of arguments
    duk_idx_t nargs = duk_get_top(ctx); 

    // Get the first argument (obj1)
    duk_idx_t obj1_idx = 0;

    duk_idx_t obj2_idx;
    duk_idx_t enum_id;
    
    for(int i=1; i< nargs; i+=1){
	    // Get the second argument (obj2)
	    obj2_idx = i;

	    // Get the keys of obj2
	    duk_idx_t enum_id = -1;
	    duk_enum(ctx, obj2_idx, DUK_ENUM_OWN_PROPERTIES_ONLY);
	    while (duk_next(ctx, enum_id, 1)) {
		//duk_get_string(ctx, -2),//key 
		//duk_get_string(ctx, -1)  //val
		
		//if(0==duk_has_prop_string(ctx, obj1_idx, duk_get_string(ctx, -2))){
		  duk_put_prop_string(ctx, obj1_idx, duk_get_string(ctx, -2));
		//}else{ duk_pop(ctx);}
		
		// val has already been removed...
		duk_pop(ctx);
	    }

	    // Clean up the stack
	    //  remove enum_id (duplicate
	    duk_pop(ctx);
    }
    duk_dup(ctx, obj1_idx);
    // Return obj1
    return 1;
}


void progen_CORE_duktape_port_settup(duk_context *ctx){

	duk_push_c_function(ctx, duk_progen_CORE_obj_join, 2);
	duk_put_global_string(ctx, "progen_CORE_obj_join");
	
	duk_push_c_function(ctx, duk_progen_OBJ_ASSIGN, DUK_VARARGS);
	duk_put_global_string(ctx, "progen_CORE_obj_ASSIGN");
	

	duk_push_c_function(ctx, 
		duk_progen_CORE_NOROLL_indefShuf_d_roll, 3);
	duk_put_global_string(ctx, 
		"progen_CORE_NOROLL_indefinite_shuffled_d_roll");
	//duk_push_string( ctx, "Object.assign = _object_assign;");
	//duk_eval_noresult(ctx);
		
}

#endif
