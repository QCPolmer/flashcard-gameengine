//draw_canvas is 2d list in js
var draw_canvas = []; var draw_canvas_width = 0; var draw_canvas_height = 0;
// declaired at runtime
var _draw_canvas_div = document.getElementById("_draw_canvas_div");
// function draw_settup_canvas_custom( width, height)
function draw_canvas_get(){ return _gridstr__from_2darr(draw_canvas); }
// below will depend on 'draw_grid' function!!!
function draw_canvas_set( str ){ draw_grid( str, 0, 0); }
function draw_settup_canvas_custom( width, height){
	draw_canvas = _gridstr__2darr_txt_to_2darr(
			gridstr_make( width, height ));
	draw_canvas_width = width;
	draw_canvas_height = height;}
var DRAW_CANVAS_DFLT_WIDTH = 72; var DRAW_CANVAS_DFLT_HEIGHT = 24;
function draw_settup_canvas(){
	draw_settup_canvas_custom(
		DRAW_CANVAS_DFLT_WIDTH, DRAW_CANVAS_DFLT_HEIGHT );  }
function draw_clear_canvas(){ _gridstr__2darr_fill(draw_canvas, " "); }
// need to do:
function draw( str, x, y, transp_char_or_0){
	_gridstr__2darr_overlay( 
		draw_canvas, _gridstr__2darr_auto_buffer_get(str),
		Math.floor(x), Math.floor(y), 	transp_char_or_0);
}
function draw_grid( str, x, y, transp_char_or_0){
	//document.body.innerHTML = str;
	//console.log(str);
	// console.log( _gridstr__2darr_auto_buffer_get(str));
	_gridstr__2darr_overlay( 
		draw_canvas, _gridstr__2darr_auto_buffer_get(str),
		x,y, 	transp_char_or_0);
}
function draw_canvas_get_width(){ return draw_canvas_width;}
function draw_canvas_get_height(){ return draw_canvas_height;}

