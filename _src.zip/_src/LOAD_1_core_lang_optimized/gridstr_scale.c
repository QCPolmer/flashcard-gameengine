// UNCOMMENT NEXT TO LINES FOR STAND ALONE FUNCTION!!!
//#include <stdio.h>
//#include <string.h>
#if defined(DUK_VERSION)
void gridstr_scale_duktape_port_settup(duk_context *ctx);
#endif

// This function is FUBAR... 
// edit:
// It mostly works...  but is in BAD need of refactors

/*
OK... can use:
https://stackoverflow.com/questions/14598730/reverse-order-of-lines-wihout-reversing-words-in-c
For lines, replaces puts with sprintf, and gets with sscanf
(probably...) 
CONVERSION: https://stackoverflow.com/questions/26602608/whats-the-difference-between-gets-and-scanf#26602739

and for reversing otherwise ( not changing line order itself):
https://stackoverflow.com/questions/60291347/how-to-reverse-multiple-lines-of-input-c

stackoverflow is creative commons:
https://meta.stackexchange.com/questions/12527/do-i-have-to-worry-about-copyright-issues-for-code-posted-on-stack-overflow
*/


// Ch'en Meng and Diego Giagio wrote these functions:
void _gridstr_scale__gridstr_scale_reverse_lines_helper_funct(char *str, int len)
{
    char *p = str;
    char *e = str + len - 1;

    while (p < e) {
        *p ^= *e ^= *p ^= *e;
        p++;
        e--;
    }
}

void _gridstr_scale_reverse_lines(char *str)
{
    char *p;

    // First, reverse the entire string
    _gridstr_scale__gridstr_scale_reverse_lines_helper_funct(str, strlen(str));

    // Then, reverse each word
    p = str;
    while (*p) {
        char *e = p;
        while (*e != '\n' && *e != '\0') {
            e++;
        }

        _gridstr_scale__gridstr_scale_reverse_lines_helper_funct(p, e - p);
        //printf("%.*s%c", e - p, p, *e);

        if (*e == '\0')
            break;
        else
            p = e + 1;
    }
}

//////////////////////////////////////////
////////////////////////////////////////////


//from stackoverflow:
// https://stackoverflow.com/questions/60291347/how-to-reverse-multiple-lines-of-input-c
//
void _gridstr_scale_reverse_lineswords_srilakshmikanthanp(char *str)
{
   int i,j,length;
   char ch;

   for(length=0;str[length]!='\n'&&str[length]!='\0';length++); //for length of string litrel between '\n' or '\0' not for full length of the string

   for(i=0,j=length-1;i<length/2;i++,j--)   //to reverse string 
   {
        ch=str[i];
        str[i]=str[j];
        str[j]=ch;
   }

   if(str[length]=='\n')             //if the string literal is present  
        _gridstr_scale_reverse_lineswords_srilakshmikanthanp(&str[length+1]);     //then goes to recursion 
   else
        return;                      //if no more string is present then return
}

int _gridstr_scale__increase_char_itterator_this_many_lines(
		char* text_grid, int offset, int numb_lines){
	
	int i =offset;

	if(numb_lines ==0){ return offset; }

	int count = 0; 
	while( numb_lines > count){
		if( text_grid[i] == '\0'){ return i-1;}
		if( text_grid[i] == '\n' || text_grid[i] == '\r'){
			count+=1;	} i++;	}
	return i; 
}	

int _gridstr_scale_line_get_length( char* str_in, int offset){
	char * line_end = str_in;
	int line_len =0;

	while(line_end[offset] != '\n' && line_end[offset] != '\0'){
		line_end +=1; line_len +=1; }
	return line_len;
}
int _gridstr_scale_get_height( char * text_grid ){
	int i=0; int count = 0;
	while(text_grid[i] != '\0'){
		if( text_grid[i] == '\n' || text_grid[i] == '\r'){
			count +=1;	}
		i+=1;	}
	//if( text_grid[i-1] == '\n' || text_grid[i-1] == '\r'){ count -=1;}

	return count +1;
}

void _gridstr_scale_line( char * str_in, int in_offset, 
		char * str_out, int out_offset, int target_width){
	int line_in_len = _gridstr_scale_line_get_length( str_in, in_offset);
	int line_out_len = target_width; 
	int dist_to_end = 0;
	
	//rewriting str_resize 
	for( int i=0; i< target_width; i+=1){
		// THE LINE_in_len here is messed up,
		// count is -1+len, because I fubared something
		if( line_in_len == 0){ 
			str_out[i+ out_offset] = ' '; continue; }
		if(line_in_len == 1){ 
			str_out[i + out_offset] = 
				str_in[in_offset + 0]; continue; }
		if(line_in_len == 2){
			if(i < (target_width )/2){
				str_out[i + out_offset] = 
				str_in[in_offset + 0];
			}else{ 
				str_out[i + out_offset] = 
				str_in[in_offset + 1];
			}continue;
		}	
		if(i < line_out_len/2 && i < line_in_len/2){
			str_out[i + out_offset] = 
				str_in[in_offset+ i];
		}else{
			//below is what it SHOULD be
			dist_to_end =   (line_out_len- i );
			//dist_to_end = line_out_len;
			//dist_to_end=i;

			if(i >= line_out_len/2 && 
			  dist_to_end <= line_in_len/2 ){
				str_out[i+out_offset]= str_in[ in_offset + 
				  (int)( line_in_len - dist_to_end)];
			//pull from center of str_in	
			}else{ 	str_out[i +out_offset] = str_in[ in_offset+
				(int)(line_in_len/2)]; }
		}
	}
}
void gridstr_scale(
  char * str_in, 
  	// define with char[_gridstr_scale__sizeof_gen_gridstr(width, height];
  char * str_out_USE_GEN_SIZE_GIRDSTIR,   
  int target_height, int target_width){

  	char * str_out = str_out_USE_GEN_SIZE_GIRDSTIR;
	////////////////////////////////////////
	////REVERSE LINES
	int _gridstr_scale_reverse_lines_var =0;
	if(target_height <0){ 
		_gridstr_scale_reverse_lines_var =1; target_height = target_height * -1;}
	int reverse_words_in_lines =0;
	if(target_width < 0){ 
		reverse_words_in_lines = 1;
		target_width = target_width*-1; }
	//continues at end
	//printf("i% i%\n ", target_height, target_width);

	if(target_height*target_width ==0){ str_out[0] ='\0'; return;}

	int str_in_height = _gridstr_scale_get_height( str_in );
	int str_out_height = target_height;
	int dist_to_end = 0;
	
	int target_j = 0;
	int str_in_j = 0;

	int saved_n = 0;

	for( int i=0; i<= target_height; i+=1){
		//odd case... initial line is spaced different
		if( i ==0){ str_out[target_width] = '\n';
		}else{ str_out[target_width +(i*(target_width+1))] = '\n';
		};
		//str_out[i*(target_width+1)+1] = '\n';
		
		// THE LINE_in_len here is messed up,
		// count is -1+len, because I fubared something
		if(str_in_height == 0){
		   _gridstr_scale_line(  str_in, 0, str_out, i*(target_width+ 1),
				  target_width); continue; }
		if(str_in_height == 1){
		   _gridstr_scale_line( str_in, 0, str_out, 
		      i*(target_width+ 1), target_width); continue; }
		if(str_in_height == 2){
			if( i < (str_out_height )/2){
				_gridstr_scale_line( str_in, 0, str_out, 
		      		i*(target_width+ 1), target_width);
			}else{ 
			  if(saved_n == 0){
			    saved_n =
				  _gridstr_scale__increase_char_itterator_this_many_lines(
				   str_in, 1, 1 );}
			   _gridstr_scale_line( str_in, saved_n+2, str_out, 
		      		i*(target_width+ 1), target_width);
			}continue;
		}	

		if(i < str_out_height/2 && i < str_in_height/2){
			// second line here is optimizing.
			target_j = i; 
		}else{  //needs rewriting
			dist_to_end =  (str_out_height- i );
			if(i >= str_out_height/2 && 
			  dist_to_end <= str_in_height/2 ){
				target_j = str_in_height - dist_to_end; 
			//pull from center of str_in	
			}else{ 	target_j = (int)(str_in_height/2); }
		}
		// gottit	
		saved_n =_gridstr_scale__increase_char_itterator_this_many_lines(
			str_in, saved_n, target_j -str_in_j );
		//printf("%i %c %i %i \n", saved_n, str_in[saved_n],  str_in_j, i*(target_width+ 1) );	
		str_in_j = target_j;
		//offset is for the newline character
		if(i ==0){_gridstr_scale_line( str_in, saved_n, str_out, 
				i*(target_width), target_width); 
		}else{ _gridstr_scale_line( str_in, saved_n, str_out, 
				i*(target_width+1), target_width); 
		}
		
	}
	str_out[(target_height)*(target_width+1)-1] = '\0';
	////////////////////////////////////////
	////REVERSE LINES
	if(_gridstr_scale_reverse_lines_var){ _gridstr_scale_reverse_lines( str_out); }
	if(reverse_words_in_lines ){
		_gridstr_scale_reverse_lineswords_srilakshmikanthanp(
				str_out); }
}



void _gridstr_scale_line_nearest_neighbor( 
  char * str_in, int in_offset,
  char * str_out, int out_offset, int target_width){

	int line_in_len = _gridstr_scale_line_get_length( str_in, in_offset);
	
	//rewriting str_resize 
	float i_to_j_ratio = (float)(line_in_len)/
				(float)target_width;
	for( int i=0; i< target_width; i+=1){ 
	   if( line_in_len == 0){ 
			str_out[i+ out_offset] = ' '; continue; }
		// REPLACE THIS WITH GET 'j'
	    str_out[i+out_offset] 
		    = str_in[ in_offset+(int )((i)*i_to_j_ratio) ];
	}	 }


void gridstr_scale_nearest_neighbor( 
  char * str_in_USE_GEN_SIZE_GIRDSTIR, 
  	// define with char[_gridstr_scale__sizeof_gen_gridstr(width, height];
  char * str_out,   
  int target_height, int target_width){
	
	if(target_height*target_width ==0){ str_out[0] ='\0'; return;}
	
	target_height = target_height;
  	////////////////////////////////////////
	////REVERSE LINES
  	int _gridstr_scale_reverse_lines_var =0;
	if(target_height <0){ 
	   _gridstr_scale_reverse_lines_var =1; target_height = target_height * -1;}
	int reverse_words_in_lines =0;
	if(target_width < 0){ 
		reverse_words_in_lines = 1;
		target_width = target_width*-1; }

  	if(target_height*target_width ==0){ str_out[0] == '\0';}

	char * str_in = str_in_USE_GEN_SIZE_GIRDSTIR;
  	//rewriting str_resize 
	float i_to_j_ratio = (float)(_gridstr_scale_get_height( str_in ))/
		(float)target_height;
	int target_j = 0;
	int str_in_j =0;
	int saved_n = 0;

	for( int i=0; i<= target_height; i+=1){
		if( i ==0){ str_out[target_width] = '\n';
		}else{ 
		   str_out[target_width +(i*(target_width+1))] = '\n';
		};
		// second line here is optimizing.
		target_j = (int)((float)i*i_to_j_ratio);

		saved_n =_gridstr_scale__increase_char_itterator_this_many_lines(
			str_in, saved_n, target_j -str_in_j );
		str_in_j = target_j;

		_gridstr_scale_line_nearest_neighbor( 
		     str_in, saved_n, 
		     str_out, i*(target_width+1), 
		     target_width);
	}
	str_out[target_height*(target_width+1)-1] = '\0';
	////////////////////////////////////////
	////REVERSE LINES
	if(_gridstr_scale_reverse_lines_var){ _gridstr_scale_reverse_lines( str_out); }
	if(reverse_words_in_lines ){
	   _gridstr_scale_reverse_lineswords_srilakshmikanthanp(
				str_out); }
}

int _gridstr_scale__sizeof_gen_gridstr(int width, int height){ 
	if(width*height ==0){return 1;}
	if(width<0){ width = width*-1;}
	
	if(height<0){ height = height*-1;}
	return (int)( (width+1)*(height+1)+2); }
	//return (int)( (width+1)*(height)+2); }
/*
void main(){
	int height =8; int width = 3;
	char test[ _gridstr_scale__sizeof_gen_gridstr(width, height)];
	
	//gridstr_scale_nearest_neighbor( "@)",
	//	      test, height, width  );
	//gridstr_scale_nearest_neighbor( "1\n\n67q890\n124",
	
	//	      test, height, width  );

	gridstr_scale( "1\n2asd",
  		test, height, width  );

	//need to incorperate this.
	//_gridstr_scale_reverse_lineswords_srilakshmikanthanp( test);
	//_gridstr_scale_reverse_lines( test);
	
	
	//	gridstr_scale_nearest_neighbor( "+-+\n[ ]\n?=;",
//		      test, height, width  );

	printf("it worked! \n%s \n", test );
}
*/
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
/////////  Duktape Port ///////////////////////////////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
#if defined(DUK_VERSION)

//gridstr_scale =function(textblock, size_x, size_y){return scaled_gridstr}
static duk_ret_t js_port_duktape_gridstr_scale(duk_context *ctx){
	char *c = (char*) malloc( _gridstr_scale__sizeof_gen_gridstr(
			(int)duk_to_number(ctx,1), 
			(int)duk_to_number(ctx,2))* sizeof(char));	

	//char c[ _gridstr_scale__sizeof_gen_gridstr(
	//		(int)duk_to_number(ctx,1), 
	//		(int)duk_to_number(ctx,2))];
	
	//printf("  %s ",c );
	gridstr_scale(
		 (char*)duk_to_string(ctx,0),  
		 c,
	       	(int)duk_to_number(ctx,2),
		(int)duk_to_number(ctx,1)
		);
	duk_push_string(ctx, c);  
	
	free(c);
	return 1;
}
//gridstr_scale_nearest_neighbor = 
//	function(textblock, size_x, size_y){ return gristr_resized; }
static duk_ret_t js_port_duktape_gridstr_scale_nearest_neighbor(duk_context *ctx){
	//char c[ _gridstr_scale__sizeof_gen_gridstr(
	//		(int)duk_to_number(ctx,1), 
	//		(int)duk_to_number(ctx,2))];
	
	char *c = (char*) malloc(
		_gridstr_scale__sizeof_gen_gridstr(
			(int)duk_to_number(ctx,1), 
			(int)duk_to_number(ctx,2))
		* sizeof(char));		

	//printf("  %s ",c );
	gridstr_scale_nearest_neighbor(
		 (char*)duk_to_string(ctx,0),  
		 c,
	       	(int)duk_to_number(ctx,2),
		(int)duk_to_number(ctx,1)
		);
	duk_push_string(ctx, c);  
	
	free(c);
	return 1;
}
	
	
	
void gridstr_scale_duktape_port_settup(duk_context *ctx){
	duk_push_c_function(ctx, js_port_duktape_gridstr_scale, 3);
	duk_put_global_string(ctx, "gridstr_scale");
	duk_push_c_function(ctx, 
			js_port_duktape_gridstr_scale_nearest_neighbor, 3);
	duk_put_global_string(ctx, "gridstr_scale_nearest_neighbor");
}
#endif
