#include <string.h>
#include <stddef.h>

#if defined(DUK_VERSION)
void gridstr_duktape_port_settup(duk_context *ctx);
#endif

int gridstr_width( char* string, int str_len);
int gridstr_height( char* string, int str_len);
///////////// Index of functions: ////////////////
//Basic string operations, could be used in other projects.
void gridstr_fill( char* string, char to_to_fill_with,
		char*  ignore_chars_or_Empty_str);

// js version: gridstr_overlay(  s_to, s_from, x, y ){ return str;}
// THIS IS A BASE FUNCTION TO OPTIMIZE DRAW, AS LEN AND STUFF IS PRE CAUGHT
//API_TAG//
int gridstr_0_under_50_or_width(char* str, int length_or_0);
// THIS IS USED INTERALLY TO OPTIMIZE C CODE!!!
// FOR USE WITH C-DRAW FUNCTIONS, AND SUCH
// 	(Basically, low level stuff... Documented here because I
// 		previously named it gridstr_width, causing confusion!)
//API_TAG//

void gridstr_make( char* str, int x, int y); // for canvas mostly/
void _gridstr_overlay_base(  //one size fits-all draw
	char* s_to, char* s_from,  	int x, int y,
	char overlayChar_or_null,
	int s_to_width_or_0_NOT_IN_JS_VERSION,
	int s_from_width_or_0_NOT_IN_JS_VERSION,
	int s_to_len_or_zero_NOT_IN_JS_VERSION,
	int s_from_len_or_zero_NOT_IN_JS_VERSION); //to avoid strlen());
void gridstr_overlay(
	char* s_to, char* s_from,  	int x, int y,
	char overlayChar_or_null,
	int s_to_len_or_zero_NOT_IN_JS_VERSION);
void gridstr_overlay_grid(
	char* s_to, char* s_from,  	int x, int y,
	char overlayChar_or_null,
	int s_to_len_or_zero_NOT_IN_JS_VERSION,
	int s_from_len_or_zero_NOT_IN_JS_VERSION );
void gridstr_replaceall( char* string_to_change,
		int string_to_change_len,
		char *char_to_replace, char *char_to_replace_with){
	char a = char_to_replace[0];
	char b = char_to_replace_with[0];
	int i;
	for(i=0; i<string_to_change_len && string_to_change[i]!='\0'; i+=1){
		if(string_to_change[i] == a){
			string_to_change[i] = b; }
	} }


// update is in 'ports/curses', so I can change platform if need-be.
///////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
///////////////////////////////////////////////
///////////////////////////////
// the underscore is because the js binding uses it,
// as are the inputs (which are easy to get via javascript)
// will find first linebreak, and 'project' from there!
// NOTE: GRID NEEDS TO HAVE EQUAL LINE LENGTHS!!!
//
// str_to_return MUST BE SAME LENGTH AS STRING!!!
void _gridstr_rotate( char* string, char*str_to_return,
		float angle, int str_len, char* trasparent_char){
	//find character, use a loop (why not?)
	//printf("%i %f \n",(int)angle, angle);
       //printf("\n%s",string);

	gridstr_fill( str_to_return, trasparent_char[0], "	");

	int line_len;
	line_len = 0;
	int q;
	int i;
	for(i=0;(line_len< (float)str_len
				&& str_to_return[i] != '\n');i+=1){
		line_len+=1;}

	if(line_len== str_len){ line_len = str_len-1;
	}else{ line_len = line_len+1;}

	int y_line_count = floor( str_len / line_len );
	//int y_line_count = gridstr_height( string, str_len);

	// NOT sure why this works... but it does seem to work...
	// Used here to replicate JS code
	int len_x = line_len-1; int len_y = y_line_count-1;
	float x_off;
	float y_off;
	if( fmod(len_x, 2.0) <1.0){x_off= (float)(len_x)/2.0;
	}else{ x_off= (float)(len_x-1.0 )/2.0; }
	if( fmod(len_y, 2.0) <1.0){y_off= (float)(len_y)/2.0;
	}else{ y_off= (float)(len_y-1.0 )/2.0; }
	//printf("\n %i %i", len_x, len_y);
	float x_prime=0.0;
	float y_prime=0.0;

	//printf("\n%f %f %i %i",x_off, y_off, len_x, len_y);
	//float x_off = ((float)gridstr_width(string, str_len )-1.0)/2.0;
	//float y_off = ((float)gridstr_height(string, str_len )-1.0)/2.0;

	//reversing angle, as I'm scanning all points in the arr2d_out
	//grid, verses drawing directly (some points are skipped that way)
	float tmp_cos = .001*roundf(cos(-angle)*1000);
	float tmp_sin = .001*roundf(sin(-angle)*1000);
	//ABOVE IS ROUNDED OFF BECAUSE OTHERWISE IT DOESN'T WORK!!!

	float x=0.0; float y=0.0;

	//tmp_cos = -1.0; tmp_sin = -0.0;

	// loc = ((line_len) * y) + x;
	for( float i=0.0; (i*(line_len+1)) < str_len; i+=1){
	 for( float j=0.0; j< line_len-1; j+=1){
		
		x = j - x_off; y = i-y_off; //offset
		//x=j; y=i;	
		//tmp_cos = -1; tmp_sin =0;
		//tmp_cos = 1; tmp_sin =0;
		
	//printf("\n C/S %f %f %f %f", x_off, y_off, tmp_cos, tmp_sin);

		x_prime = ( x * tmp_cos + y * tmp_sin);
		y_prime = (-x * tmp_sin + y *tmp_cos);
		
		y_prime = floor(y_prime+y_off);
	        x_prime = floor(x_prime+x_off);
		
		//printf("%f %f \n", tmp_cos, tmp_sin);
		//printf("%i %i %f %i ll %i\n", x_prime, y_prime, 
		//		angle, str_len, line_len );
		//printf("%i %i\n", ((y+line_len) < str_len), y);
		if(x_prime >=0 && y_prime >=0){
		 if( y_prime < len_y   //y_line_count 
			&& x_prime < len_x ){  //(line_len-1)){
				//printf("%i %f \n",(int)angle, angle);
				//printf("%f %f \n", x,y);
			 	str_to_return[	((int)i*line_len)+(int)j]= 
				   string[(int)(
					(y_prime*line_len)+ x_prime)];
				
		}	}//string[y_prime+1] = '\n';//ALREADY IN ORIG. STR
	} 	}
	//printf("%s", string);
       str_to_return[str_len] = '\0';	
	return;
}
void _gridstr_transpose( char* string, char*str_to_return, int str_len){
	//find character, use a loop (why not?) 
	//printf("%i %f \n",(int)angle, angle);
	
	int line_len = 0; 
	for(int i=0;(line_len< (float)str_len
				&& string[i] != '\n');i+=1){
		line_len+=1;}
	//NOTE: had to change below because 1d transpose (no new lines)
	// 	did NOT work. (changed the commented out -1 to a +1 below! 
	if(line_len== str_len){ line_len = str_len+1; //-1;
	}else{ line_len = line_len+1;}
	
	int y_line_count = floor( str_len / line_len );
	//printf( "%f %f asdsdf\n", 
	//	(float)floor(str_len / line_len ), 
	//	((float)str_len / (float)line_len));
	
	// (str_len+1) because as a 'box' it needs a new line 
	// character at end.
	if((float)floor((str_len+1) / line_len ) ==
			((float)(str_len+1) / (float)line_len)){
		y_line_count+=1; }
	
	//printf("%i %i aa\n", y_line_count, line_len);
	// loc = ((line_len) * y) + x;
	for( int y=0; (y*(line_len)) < str_len; y+=1){
	 for( int x=0; x< line_len-1; x+=1){
		//printf("%i %i\n", x,y);
		str_to_return[	(x*(y_line_count+1))+y]= 
			string[(y*line_len)+ x];
	}	}	
	for( int i=0; i< (line_len); i+=1){
		//printf("%i mm\n",(i*(y_line_count+1)));
		str_to_return[	y_line_count+(i*(y_line_count+1))]= '\n';}
	//printf("%i --\n", (y_line_count+1)* (line_len-1));
       str_to_return[ -1 +(y_line_count+1)* (line_len-1) ] = '\0';
 	
	return;
}
void _gridstr_reverse_text( char* string, char*str_to_return, int str_len){
	for(int i=0;i<str_len; i+=1){ 
		str_to_return[(str_len-1)-i] = string[i];}
	str_to_return[str_len] = '\0';	
	return;
}

void gridstr_fill( char* string, char to_to_fill_with, 
		char*  ignore_chars_or_Empty_str){
	int i=0;
	if( strlen(ignore_chars_or_Empty_str) ==0){
		while(string[i] != '\0' ){
		       if(string[i] != '\n'){ string[i] = to_to_fill_with; }
			i+=1;
		}
		//printf("### %i ###", i );
	}else{
		while(string[i] != '\0' ){
		       if(string[i] != '\n'){ 
			 if( strchr(ignore_chars_or_Empty_str, string[i]) 
					 == NULL){
				 string[i] = to_to_fill_with; }  
		       
		       }
			i+=1;
		}
		//printf("### %i ###", i );
	}
	return;
}

/////////////////////////////////////////////
/////////////////////////////////////////////
/////////////////////////////////////////////
/////////////////////////////////////////////
////////////////////////////////////
///// MAIN thing here is: str_overlay_by_char_GRID_OPTIM
//	The Main Draw function,
//	And the wrappers for it.

/////////////////////////////////////////////
//////////////////
	char* _go_nxt_line( char* s_to_in){
		if(s_to_in == NULL ){ return s_to_in; } 
		s_to_in = strchr(s_to_in, '\n');
		if(s_to_in == NULL ){ return s_to_in; } 
		s_to_in +=1;
		return s_to_in; }
	void _copy_line( char* s_to_in, char* s_from_in, int x,
			char overlayChar_or_null){ //x offset
		//shifting focus 
		while( x > 0){ x--; 
			if( s_to_in[0] == '\n' || s_to_in[0] == '\0' ){
				return;}
			s_to_in++; }
		while( x < 0){ x++; 
			if( s_from_in[0] == '\n' || s_from_in[0] == '\0' ){
				return;}
			s_from_in++; }
		
		while( s_from_in[0] != '\n' && s_from_in[0] != '\0' &&
				s_to_in[0] != '\n' && s_to_in[0] != '\0'){
			//printf("%c", *s_to_in );
			if( overlayChar_or_null != *s_from_in){
				*s_to_in = *s_from_in; }
			  s_to_in++; s_from_in++;	}	}
	
	#define GRID_LEN_OFFSET 1
	#define GRID_OPTIMIZE_Y( Y__, s_TO_OR_FROM, \
			s_TO_OR_FROM_width_or_0, s_TO_OR_FROM_LEN ) \
		if( s_TO_OR_FROM_width_or_0 > 0 && Y__ > 0){ \
			if(s_TO_OR_FROM_LEN ==0){ \
			   s_TO_OR_FROM_LEN = strlen( s_TO_OR_FROM );} \
			if( s_TO_OR_FROM_LEN > \
			(Y__*(s_TO_OR_FROM_width_or_0 +GRID_LEN_OFFSET))){ \
				s_TO_OR_FROM += (Y__ * \
				((s_TO_OR_FROM_width_or_0-1) +  \
				 GRID_LEN_OFFSET+ GRID_LEN_OFFSET)) ;  \
				y=0; }else{ return;}	}
	// check if grid is too small
	#define GRID_OPTIMIZE_X_A( X__,  s_TO_OR_FROM_width_or_0) \
		if( s_TO_OR_FROM_width_or_0 > 0 && X__ > 0){ \
			if( X__ > s_TO_OR_FROM_width_or_0){ return;} }
	// the above checks to see if grid is to small for this to work
	#define GRID_OPTIMIZE_X_B( X__, s_TO_OR_FROM, \
			s_TO_OR_FROM_width_or_0) \
		if( s_TO_OR_FROM_width_or_0 > 0 && X__ > 0){ \
			if( s_TO_OR_FROM[0] == '\n' || \
				s_TO_OR_FROM[0] == '\0' ){ return;} \
			tmpOptimized = 1; \
			s_TO_OR_FROM += X__;  \
			_copy_line( s_to, s_from, 0,  overlayChar_or_null);}
			// the above line is needed
	//////////////////////////////////////////////////////
	///////////// str_overlay_by_char_GRID_OPTIM /////////
	//////////////////////////////////////////////////////
	void _gridstr_overlay_base(  //one size fits-all draw
		char* s_to, char* s_from,  	int x, int y, 
		char overlayChar_or_null,
		int s_to_width_or_0_NOT_IN_JS_VERSION, 
		int s_from_width_or_0_NOT_IN_JS_VERSION, // 0 =don't calc
		int s_to_len_or_zero_NOT_IN_JS_VERSION, 
		int s_from_len_or_zero_NOT_IN_JS_VERSION){ // 0 = don't use
		//////////////////////////////
		// GRID_OPTIMIZES can be removed/ are JUST optimizations
		GRID_OPTIMIZE_Y( y, s_to, 
				s_to_width_or_0_NOT_IN_JS_VERSION, 
				s_to_len_or_zero_NOT_IN_JS_VERSION );
		GRID_OPTIMIZE_Y( -y, s_from, 
				s_from_width_or_0_NOT_IN_JS_VERSION, 
				s_from_len_or_zero_NOT_IN_JS_VERSION);
		while(y > 0){ y--; s_to = _go_nxt_line( s_to); 
			if(s_to == NULL){ return;} }
		while(y < 0){ y++;  s_from = _go_nxt_line( s_from); 
			if(s_from == NULL){ return;}; }
		
		GRID_OPTIMIZE_X_A( x,  s_to_width_or_0_NOT_IN_JS_VERSION );
		GRID_OPTIMIZE_X_A(-x, s_from_width_or_0_NOT_IN_JS_VERSION );
		int tmpOptimized = 0;
		while(1){ tmpOptimized = 0;
			GRID_OPTIMIZE_X_B( x, s_to, 
				s_to_width_or_0_NOT_IN_JS_VERSION );
			GRID_OPTIMIZE_X_B( -x, s_from, 
				s_from_width_or_0_NOT_IN_JS_VERSION );

			if( !tmpOptimized){ _copy_line( 
				s_to, s_from, x, overlayChar_or_null);}
			s_from = _go_nxt_line( s_from); 
				if(s_from == NULL){ return;};
			s_to = _go_nxt_line( s_to); 
				if(s_to == NULL){ return;};  }
	}
#undef GRID_OPTIMIZE_X_B
// this is ONLY for below... and below is ONLY for _sketch
#define GRID_OPTIMIZE_X_B( X__, s_TO_OR_FROM, \
			s_TO_OR_FROM_width_or_0) \
		if( s_TO_OR_FROM_width_or_0 > 0 && X__ > 0){ \
			if( s_TO_OR_FROM[0] == '\n' || \
				s_TO_OR_FROM[0] == '\0' ){ return;} \
			tmpOptimized = 1; \
			s_TO_OR_FROM += X__;  \
			_copy_line_under_overlayChar( s_to, s_from, 0,  overlayChar_or_null);}
void _copy_line_under_overlayChar( 
			char* s_to_in, char* s_from_in, int x,
			char overlayChar_or_null){ //x offset
		//shifting focus 
		while( x > 0){ x--; 
			if( s_to_in[0] == '\n' || s_to_in[0] == '\0' ){
				return;}
			s_to_in++; }
		while( x < 0){ x++; 
			if( s_from_in[0] == '\n' || s_from_in[0] == '\0' ){
				return;}
			s_from_in++; }
		
		while( s_from_in[0] != '\n' && s_from_in[0] != '\0' &&
				s_to_in[0] != '\n' && s_to_in[0] != '\0'){
			//printf("%c", *s_to_in );
			if( overlayChar_or_null == *s_to_in){
				*s_to_in = *s_from_in; }
			  s_to_in++; s_from_in++;	}	}
// below (and the helper function) is pretty much just for 
// sketch_grid_DRAW_UNDER_TRANSPCHAR, as otherwise drawing one image 
// over another can use typical gridstr
void _gridstr_overlay_base_UNDER_OVERLAYCHAR(  
		char* s_to, char* s_from,  	int x, int y, 
		char overlayChar_or_null,
		int s_to_width_or_0_NOT_IN_JS_VERSION, 
		int s_from_width_or_0_NOT_IN_JS_VERSION, // 0 =don't calc
		int s_to_len_or_zero_NOT_IN_JS_VERSION, 
		int s_from_len_or_zero_NOT_IN_JS_VERSION){ // 0 = don't use
		//////////////////////////////
		// GRID_OPTIMIZES can be removed/ are JUST optimizations
		GRID_OPTIMIZE_Y( y, s_to, 
				s_to_width_or_0_NOT_IN_JS_VERSION, 
				s_to_len_or_zero_NOT_IN_JS_VERSION );
		GRID_OPTIMIZE_Y( -y, s_from, 
				s_from_width_or_0_NOT_IN_JS_VERSION, 
				s_from_len_or_zero_NOT_IN_JS_VERSION);
		while(y > 0){ y--; s_to = _go_nxt_line( s_to); 
			if(s_to == NULL){ return;} }
		while(y < 0){ y++;  s_from = _go_nxt_line( s_from); 
			if(s_from == NULL){ return;}; }
		
		GRID_OPTIMIZE_X_A( x,  s_to_width_or_0_NOT_IN_JS_VERSION );
		GRID_OPTIMIZE_X_A(-x, s_from_width_or_0_NOT_IN_JS_VERSION );
		int tmpOptimized = 0;
		while(1){ tmpOptimized = 0;
			GRID_OPTIMIZE_X_B( x, s_to, 
				s_to_width_or_0_NOT_IN_JS_VERSION );
			GRID_OPTIMIZE_X_B( -x, s_from, 
				s_from_width_or_0_NOT_IN_JS_VERSION );

			if( !tmpOptimized){ _copy_line_under_overlayChar( 
				s_to, s_from, x, overlayChar_or_null);}
			s_from = _go_nxt_line( s_from); 
				if(s_from == NULL){ return;};
			s_to = _go_nxt_line( s_to); 
				if(s_to == NULL){ return;};  }
	}
void gridstr_overlay(
	char* s_to, char* s_from,  	int x, int y, 
	char overlayChar_or_null,	
	int s_to_len_or_zero_NOT_IN_JS_VERSION){
		//printf("%s  as2222dfa", s_to );
	    _gridstr_overlay_base(  //one size fits-all draw
		s_to, s_from,  		x, y,  	overlayChar_or_null, 
		gridstr_0_under_50_or_width(s_to, 
			s_to_len_or_zero_NOT_IN_JS_VERSION), 
	       			0,	
	      //gridstr_0_under_50_or_width(s_from,
	      // 	s_from_len_or_zero_NOT_IN_JS_VERSION), 
		0, 	0);
	}
void gridstr_overlay_grid(
	char* s_to, char* s_from,  	int x, int y, 
	char overlayChar_or_null,	
	int s_to_len_or_zero_NOT_IN_JS_VERSION, 
	int s_from_len_or_zero_NOT_IN_JS_VERSION ){
		//printf("%s  as2222dfa", s_to );
	    _gridstr_overlay_base(  //one size fits-all draw
		s_to, s_from,  		x, y,  	overlayChar_or_null, 
		gridstr_0_under_50_or_width(s_to, s_to_len_or_zero_NOT_IN_JS_VERSION), 
	       	gridstr_0_under_50_or_width(s_from,s_from_len_or_zero_NOT_IN_JS_VERSION), 
		s_to_len_or_zero_NOT_IN_JS_VERSION, 
		s_from_len_or_zero_NOT_IN_JS_VERSION);
	}

// the grid len is large because I forsee giant grids causing problems
// ANd this is a dodgy method... IT WILL BREAKDOWN WITH '\n' MIDLINES,
// IF IT REPLACES A 'TXT' CHARACTER IN THE GRID!!! BEWARE!!!
//  ( I MADE IT LIKE THIS FOR SPEED, NOT TO BE PERFECT...) 
#define MIN_STR_GRID_LEN 50
#define FOR_THIS_FUNCT_GRID_LEN_OFFSET 1
int gridstr_0_under_50_or_width(char* str, int length_or_0){ // returns 0 if no viable grid
	int str_len;
	if( length_or_0 == 0 ){  str_len = strlen( str); 
	}else{ str_len = length_or_0;}
       		if(str_len < MIN_STR_GRID_LEN){ return 0;} 
	char * str_moving;
	
	str_moving = strchr(str, '\n');
		if( str_moving == NULL){ return 0;}
	int col_len; 
	col_len = (str_len - strlen( str_moving));
	///////////TESTS TO SEE IF ACTUALLY A GRID///////////	 
	//allowing trailing \n, getting if divides evenly OR 
	// evenly -1 for last line, and has a \n at the end.
	int tmpRem; //temp remainder
	tmpRem =(int)((str_len-col_len ) % 
			(col_len +FOR_THIS_FUNCT_GRID_LEN_OFFSET));
	if(  ( str[str_len-1] == '\n' && 
			( tmpRem == FOR_THIS_FUNCT_GRID_LEN_OFFSET ) )  
		||   ( tmpRem ==0 )
	){}else{ return 0;}
	// testing all lines but the last end with '\n'
	for( int i =col_len;  
			str_len > ( i + col_len ) ; 
			i+=(col_len+FOR_THIS_FUNCT_GRID_LEN_OFFSET)){
		if( str[i] != '\n'){ return 0; } }
	
	return col_len;  }


#undef MIN_STR_GRID_LEN
#undef FOR_THIS_FUNCT_GRID_LEN_OFFSET

int gridstr_width( char * str, int len){
	if(len == 0 ){ return 0; }
	if( str[0] =='\0' ||  str[0] =='\n' ){ return 0; }
	int i = 1; 
	while( str[i] !='\0' &&  str[i] !='\n' && i < len){ i+=1; }
	return i; 
}
int gridstr_height( char * str, int len){
	if(len == 0 ){ return 1; }
	if( str[0] =='\0' ){ return 1; }
	int i = 0; int line_cnt=1; 
	while( str[i] !='\0' && i < len){ 
		if(str[i] == '\n'){ line_cnt+=1;}
		i+=1; }
	return line_cnt; 
}

void _gridstr_replace_allchars_EXCEPT(
	char * getStr, int getStr_len, 
	char getChar_dont_replace, char getChar_replaceWith){
		for(int i=0; i< getStr_len; i+=1){
			if(getStr[i] != '\n' && 
				getStr[i] != getChar_dont_replace){
					getStr[i] = getChar_replaceWith; 
}	}	}


//need to make this accessible via JS and in HTML!
//(should NOT take long!!!
void gridstr_char_get( char* str, char* str_1_char_return, //2 chars: 'C\0'
		int str_len, 
		int x, int y, int str_width_FOR_OPTIMIZING_or_0){ 
	//should try again including width. 
	strcpy(str_1_char_return, "\t"); // because tabs shouldn't show up
	if( str_width_FOR_OPTIMIZING_or_0 == 0){
		gridstr_overlay(  
			str_1_char_return,	str, 
			  	//graphic
				-x, //x
				-y, //y
				0,str_len); //length of char to get
	}else{
	   _gridstr_overlay_base(  //one size fits-all draw
		str_1_char_return, str,  
		-x, -y,  0, 
		0, str_width_FOR_OPTIMIZING_or_0,
	      //gridstr_0_under_50_or_width(s_from,s_from_len_or_zero_NOT_IN_JS_VERSION), 
		0, 	str_len);
	}
	if(str_1_char_return[0] == '\t'){str_1_char_return[0] = '\0';}
}
	
///////////////////////////////////////
void gridstr_make( char* str, int x, int y){ 
	// this function ( and the base c ones that use it )
	// have given me nothing but trouble. 
	// (I think x and y are reversed... )
	
	// REWROTE THIS 9/4/2023: SHOULDN'T HAVE ALL OLD PROBLEMS
	// 	(the other version was janky, this one is NOT complex)
	int max_place = (y)*(x+1)+1;
	for(int i=0; i< max_place; i+=1){ str[i] = '-'; }
	for(int i=(x+1); i< max_place; i+=(x+1)){str[i-1] = '\n';}
	str[max_place] = '\0';
	
	//OLD
	//int line_char_index;
	//for( int i=0; i< y; i+=1){
	//	line_char_index = i*(x+1);
	//	for( int j=0; j<x; j+=1){
	//		str[line_char_index+j] = '-';	}
	//	str[(i+1)*(x+1)-1] = '\n';	}
	// str[(y+1)*(x+1)] = '\0';



	
/*	
	int ADDED_FOR_NEWLINE_CHAR = 1;
	x= x+ADDED_FOR_NEWLINE_CHAR; // for the new line '\n'
	
	int i=0; int j =0;
	int full_grid_size = (y+1)*(x+ADDED_FOR_NEWLINE_CHAR);
	while( full_grid_size > i){
		//printf("  %s  %i   \n", str, full_grid_size);
		j=0;
		while(x > j){
			str[i+j] = '-';
			j+=1;	}
		str[i+j] = '\n';
		i+=x+ADDED_FOR_NEWLINE_CHAR;}
	str[i- (x+ADDED_FOR_NEWLINE_CHAR)] = '\0';
*/
}

///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
//////////  Duktape port //////////////////////////////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
#if defined(DUK_VERSION)
void gridstr_duktape_port_loader(duk_context *ctx);

static duk_ret_t js_port_duktape__gridstr_replace_allchars_EXCEPT(
		duk_context *ctx){
		// char * getStr, 
		// char getChar_dont_replace, char getChar_replaceWith
	//char c[ duk_get_length(ctx,0) +1]; //str len 
	char *c = (char*) malloc( (duk_get_length(ctx,0) +1)* sizeof(char));

	strcpy(c, (char*)duk_to_string(ctx,0));
	_gridstr_replace_allchars_EXCEPT(
	    (char*) c, 		duk_get_length(ctx,0), 
	    (char) duk_to_string(ctx,1)[0],(char)duk_to_string(ctx,2)[0]);
	duk_push_string(ctx,c);

	free(c);
	return 1; // 1 return 
}
///////////////////////////////
// in js: function load(filename)... return string
// "gridstr_reverse_text
// string,  str_len
static duk_ret_t js_port_duktape__gridstr_reverse_text(duk_context *ctx){
	//I should be overkilling the size of the str. 
	//char c[ duk_to_int(ctx,1)  +1]; //caught str length
	char *c = (char*) malloc( (duk_to_int(ctx,1)  +1)* sizeof(char));
	

	//char c[ strlen((char*)duk_to_string(ctx,0)) +1 ];
	_gridstr_reverse_text( (char *)duk_to_string(ctx,0), 
			(char *)c,  duk_to_int(ctx,1));
	
	duk_push_string(ctx, c);  
	
	free(c);
	return 1;
}

///////////////////////////////
// in js: function load(filename)... return string
// "gridstr_char_get
// string,  str_len, x, y, str_width_for_optimizing_or_0
static duk_ret_t js_port_duktape__gridstr_char_get(duk_context *ctx){
// will need a js wrapper
	char str_out[2];
	gridstr_char_get( (char*)duk_to_string(ctx,0), (char *)str_out,
		       duk_get_length(ctx,0), // str_len
	       		duk_to_int(ctx,1), duk_to_int(ctx,2),// x,y 
			duk_to_int(ctx, 3));
	duk_push_string(ctx, str_out);
	return 1; // number of out
 }

	
///////////////////////////////
// in js: function load(filename)... return string
// "gridstr_transpose
// string,  str_len
static duk_ret_t js_port_duktape__gridstr_transpose(duk_context *ctx){
	//I should be overkilling the size of the str. 
	 int str_len = duk_to_int(ctx,1);
	char* str = (char*)duk_to_string(ctx,0);
	
	int numb_of_newgrid_lines=0;
	while(numb_of_newgrid_lines< str_len){	
		if(str[numb_of_newgrid_lines] == '\n'){break;} 
		numb_of_newgrid_lines+=1; }
		// this is for string size allocation,
				// so not 100% accurate
				// (y_line_count+1)* (line_len-1)
	//char c[ str_len  + numb_of_newgrid_lines + 1 +10]; 
	char *c = (char*) malloc( (str_len  + numb_of_newgrid_lines + 1 +10)* 
		sizeof(char));
		

			//caught str length
	//char c[ strlen((char*)duk_to_string(ctx,0)) +1 ];
	//printf("%i %i %i  ------\n", str_len,  numb_of_newgrid_lines,
	//		str_len  + numb_of_newgrid_lines + 1);
	_gridstr_transpose( (char *)duk_to_string(ctx,0), 
			(char *)c,  str_len);
	duk_push_string(ctx, c);  
	
	free(c);
	return 1;
}
///////////////////////////////
// in js: function load(filename)... return string
// "_gridstr_rotate
// string, angle, str_len
static duk_ret_t js_port_duktape__gridstr_rotate(duk_context *ctx){
	//I should be overkilling the size of the str. 
	//char c[ (int)duk_get_length(ctx,0) +1]; //caught str length
	char *c = (char*) malloc( ((int)duk_get_length(ctx,0) +1)* sizeof(char));
	
	
	//char c[ strlen((char*)duk_to_string(ctx,0)) +1 ];
	strcpy(c, (char*)duk_to_string(ctx,0));
	_gridstr_rotate( (char *)duk_to_string(ctx,0), 
			(char *)c,  (float)duk_to_number(ctx,1), 
		       (int)duk_get_length(ctx,0),
		       (char *)duk_to_string(ctx,2));	
	duk_push_string(ctx, c);  
	
	free(c);
	return 1;
}
///////////////////////////////
// in js: function load(filename)... return string
// "_gridstr_fill
// " gridstr, fill_char, gridstr_chars_to_ignore
static duk_ret_t js_port_duktape_gridstr_fill(duk_context *ctx){
	//I should be overkilling the size of the str. 
	// char c[ duk_get_length(ctx,0) +1 ];
	char *c = (char*) malloc( (duk_get_length(ctx,0) +1)* sizeof(char));
	

	strcpy(c, (char*)duk_to_string(ctx,0));
	gridstr_fill(c, duk_to_string(ctx,1)[0], 
			(char*)duk_to_string(ctx,2));
	
	duk_push_string(ctx, c);  
	
	free(c);
	return 1;
}
///////////////////////////////
// in js: function load(filename)... return string
// "_gridstr_make
// " x, y 
//
// ////////////////////////////////////
//  THIS FUNCTION HAS GIVEN ME ENDLESS PROBLEMS
//		ONE OTHER PLACE THAT TENDS TO MESS THINGS UP IS
//		gristr_rotate_MAKE_ROTATABLE_BORDER
//		(I used it for 3d crap too)
//  /////////////////////////////////////
duk_context *_sketch_line_col_CAUGHT_CONTEXT;
static duk_ret_t js_port_duktape_gridstr_make(duk_context *ctx){
	//I should be overkilling the size of the str. 
	//char c[ duk_to_int(ctx,0) *
	 //      	(duk_to_int(ctx,1)+2) +1];
	 //
	// BELOW IS OVERKILL, HOPEFULLY
	int x = duk_to_int(ctx,0);
	int y = duk_to_int(ctx,1);
	int max_len = (y)*(x+1) +2; //+1 should be enough... +2 is overkill 

	//int X_MODIFIER_TO_DEAL_WITH_GLITCHED_FUNCT=-1;
	//x = x + X_MODIFIER_TO_DEAL_WITH_GLITCHED_FUNCT;
		

	char *c = (char*) malloc( max_len  * sizeof(char));
			
	
	gridstr_make(c, x, y );	
		
	duk_push_string(ctx, c);	

	free(c);
	return 1;

	//char *c = (char*) malloc( 10*((duk_to_int(ctx,0)+1) *
	 //     	(duk_to_int(ctx,1)+2) +1)* sizeof(char));
		
	 // THIS IS HEAFTY OVERKILL FOR STR SIZE!!!
	//char *c = (char*) malloc( ((duk_to_int(ctx,0) +2) *
	//		(duk_to_int(ctx,1)+2) +20)* sizeof(char));
		

	//int X_MODIFIER_TO_DEAL_WITH_GLITCHED_FUNCT=-1;
	//gridstr_make(c, 
	//	duk_to_int(ctx,0) + X_MODIFIER_TO_DEAL_WITH_GLITCHED_FUNCT, 
	//	duk_to_int(ctx,1));
	
	//int X_MODIFIER_TO_DEAL_WITH_GLITCHED_FUNCT=-1;
	//gridstr_make(c, 
	//	duk_to_int(ctx,0) + X_MODIFIER_TO_DEAL_WITH_GLITCHED_FUNCT, 
	//	duk_to_int(ctx,1));
	


	 // THIS IS HEAFTY OVERKILL FOR STR SIZE!!!
	//char *c = (char*) malloc( ((duk_to_int(ctx,0) +2) *
	//		(duk_to_int(ctx,1)+2) +20)* sizeof(char));
		

	
	//duk_push_string(ctx, (const char*)c);  

	//printf("\n%s\n", c);
	//duk_push_sprintf(ctx, "-", c);
	  
	
	
}
///////////////////////////////
// in js: function load(filename)... return string
// "_gridstr_0_under_50_or_width
// " str, str_len
static duk_ret_t js_port_duktape_gridstr_0_under_50_or_width(duk_context *ctx){
	//I should be overkilling the size of the str. 
	// EDIT: THIS FUNCTION IS BROKEN FOR THE JS VERSION!
	// 	IT IS BASED ON A 
	duk_push_int(ctx, 
		gridstr_0_under_50_or_width( (char*)duk_to_string(ctx,0), 
		       		(int)duk_get_length(ctx,0)));  
	return 1;
}
///////////////////////////////
// in js: function load(filename)... return string
// "gridsr_width
// " str
static duk_ret_t js_port_duktape_gridstr_width(duk_context *ctx){
	//I should be overkilling the size of the str. 
	// EDIT: THIS FUNCTION IS BROKEN FOR THE JS VERSION!
	// 	IT IS BASED ON A 
	duk_push_int(ctx, 
		gridstr_width( (char*)duk_to_string(ctx,0), 
		       		(int)duk_get_length(ctx,0)));  
	return 1;
}

///////////////////////////////
// in js: function load(filename)... return string
// "gridstr_charCountPriorToIndex( 
// 	getStr, getChar, getIndex,getQuardant_or_UNDEF)
// " str
static duk_ret_t js_port_duktape_gridstr_gridstr_charCPI(duk_context *ctx){
	char * getStr = (char*)duk_to_string(ctx,0);
	int getStr_length = (int)duk_get_length(ctx,0);
	char * getChar = (char*)duk_to_string(ctx,1);
	int getIndex = (int)duk_to_int(ctx,2);
	int getQuardant_or_UNDEF =0;
	if( !duk_is_undefined(ctx, 3)){
		getQuardant_or_UNDEF = (int)duk_get_int(ctx, 3); }

	if(getIndex >= getStr_length ){ getIndex = getStr_length-1;}
	int count = 0; char code = getChar[0]; //js it's a charCode
	int halfWidth= floor(gridstr_width(getStr, getStr_length)/2);
	int tmpOverHlfway = 0;
	//below newLine_'code' cause JS version uses 'charCode'
	int i_frm_nwLine =0; char newLine_code = '\n';
	
	for( int i =0; i<= getIndex; i++){
	    if( getStr[i] == newLine_code ){ i_frm_nwLine=0;
		   if((halfWidth+ i)*2 > getStr_length){tmpOverHlfway =1;}
		}else{ i_frm_nwLine += 1; }

	    if( getStr[i] == code){ //code is getChar[0], js needs charCode
		if(getQuardant_or_UNDEF == 0){count += 1;continue;}

		if(getQuardant_or_UNDEF==1 || getQuardant_or_UNDEF==3 ){
			if(i_frm_nwLine > halfWidth){continue;} 
		}else{ if(i_frm_nwLine <= halfWidth){continue;} }
		if(getQuardant_or_UNDEF > 2 && tmpOverHlfway==0){continue;}
		if(getQuardant_or_UNDEF <= 2 && tmpOverHlfway==1){continue;}
		count += 1;  } } 

	duk_push_int(ctx, count);  
	return 1;
} 

///////////////////////////////
// in js: function load(filename)... return string
// "gridstr_height
// " str
static duk_ret_t js_port_duktape_gridstr_height(duk_context *ctx){
	//I should be overkilling the size of the str. 
	// EDIT: THIS FUNCTION IS BROKEN FOR THE JS VERSION!
	// 	IT IS BASED ON A 
	duk_push_int(ctx, 
		gridstr_height( (char*)duk_to_string(ctx,0), 
		       		(int)duk_get_length(ctx,0)));  
	return 1;
}
///////////////////////////////
// in js: function load(filename)... return string
// "_gridstr_overlay(
// "s_to, s_from, x, y, overlayChar_or_null,""s_to.length"
static duk_ret_t js_port_duktape_gridstr_overlay(duk_context *ctx){
	// char c[ duk_get_length(ctx,0) +1];
	char *c = (char*) malloc( (duk_get_length(ctx,0) +1)* sizeof(char));
	
	strcpy(c, duk_to_string(ctx,0) );
	
	char transp_char = 0;
	if(strlen((char*)duk_to_string(ctx,4)) > 0){ 
		transp_char = duk_to_string(ctx,4)[0];}
	//printf("  %s ",c );
	gridstr_overlay(
		c, (char*)duk_to_string(ctx,1),  	
		duk_to_int(ctx,2), duk_to_int(ctx,3), 
		transp_char,	
		duk_get_length(ctx,0) );
	duk_push_string(ctx, c);

	free(c);  
	return 1;
}
///////////////////////////////
// in js: function load(filename)... return string
// "gridstr_replaceall(
// "s_to, s_from, x, y, overlayChar_or_null,""s_to.length"
static duk_ret_t js_port_duktape_gridstr_replaceall(duk_context *ctx){
	int len = duk_get_length(ctx,0);
	
	//char c[ len +1];
	char *c = (char*) malloc( (len +1)* sizeof(char));
	
	strcpy(c, duk_to_string(ctx,0) );
	
	//printf("  %s ",c );
	gridstr_replaceall( (char*) c, 
		len,
		(char *)duk_to_string(ctx, 1), 
		(char *)duk_to_string(ctx, 2));
	duk_push_string(ctx, c);  

	free(c);
	return 1;
}


//"s_to, s_from, x, y, overlayChar_or_null,""s_to.length, s_from.length"
static duk_ret_t js_port_duktape_gridstr_overlay_grid(duk_context *ctx){
	//char c[ duk_get_length(ctx,0) +1];
	char *c = (char*) malloc( (duk_get_length(ctx,0) +1)* sizeof(char));
	
	strcpy(c, duk_to_string(ctx,0) );
	
	char transp_char = 0;
	if(strlen((char*)duk_to_string(ctx,4)) > 0){ 
		transp_char = duk_to_string(ctx,4)[0];}
	//printf("  %s ",c );
	gridstr_overlay_grid(
		c, (char*)duk_to_string(ctx,1),  	
		duk_to_int(ctx,2), duk_to_int(ctx,3), 
		transp_char,	
		duk_get_length(ctx,0), 
		duk_get_length(ctx,1) );
	duk_push_string(ctx, c);  

	free(c);
	return 1;
}
//gridstr_indexOf_char_getXY
const char * js_port_duktape_gridstr_i_char_XYfunct(){ 
	return "function gridstr_indexOf_char_getXY( getGridstr, getChar){ "
    " var tmpIndex = getGridstr.indexOf(getChar );"
    " if(tmpIndex == -1 ){ return null;}; "
    "var tmpLines = getGridstr.substr(0,tmpIndex + 1).split('\\n'); "
    "return [tmpLines[tmpLines.length-1].length-1, tmpLines.length-1];}";}

void gridstr_duktape_port_settup(duk_context *ctx){
	duk_push_c_function( ctx, //_gridstr_replace_allchars_EXCEPT
		  js_port_duktape__gridstr_replace_allchars_EXCEPT, 3);
		duk_put_global_string( ctx, "gridstr_replace_allchars_EXCEPT");		
	duk_push_c_function( ctx, // gridstr_overlay_grid
			js_port_duktape_gridstr_overlay_grid, 5);
		duk_put_global_string( ctx, "gridstr_overlay_grid");
	duk_push_c_function( ctx, // _gridstr_rotate
			js_port_duktape__gridstr_rotate, 3);
		duk_put_global_string( ctx, "_gridstr_rotate");
	duk_push_c_function( ctx, // _gridstr_reverse
			js_port_duktape__gridstr_reverse_text, 2);
		duk_put_global_string( ctx, "gridstr_reverse_text");
	duk_push_c_function( ctx, // _gridstr_transpose
			js_port_duktape__gridstr_transpose, 2);
		duk_put_global_string( ctx, "gridstr_transpose");
	duk_push_c_function( ctx, js_port_duktape_gridstr_overlay, 5);
		duk_put_global_string( ctx, "gridstr_overlay");
	//duk_push_string(ctx,// gridstr_replaceall
	//	gridstr_replaceall_js_func());
	//	duk_eval_noresult(ctx);
	duk_push_c_function( ctx, // gridstr_make
			js_port_duktape_gridstr_replaceall, 3);
		duk_put_global_string( ctx, "gridstr_replaceall");
	duk_push_c_function( ctx, // gridstr_make
			js_port_duktape_gridstr_make, 2);
		duk_put_global_string( ctx, "gridstr_make");
	duk_push_c_function( ctx, // gridstr_fill
			js_port_duktape_gridstr_fill, 3);
		duk_put_global_string( ctx, "gridstr_fill");
	duk_push_c_function( ctx,// _gridstr_0_under_50_or_width
			js_port_duktape_gridstr_0_under_50_or_width, 1);
		duk_put_global_string( ctx, "gridstr_0_under_50_or_width");
	duk_push_c_function( ctx,// _gridstr_0_under_50_or_width
			js_port_duktape_gridstr_gridstr_charCPI, 4);
		duk_put_global_string(ctx,"gridstr_charCountPriorToIndex");
	duk_push_c_function( ctx,// _gridstr_0_under_50_or_width
			js_port_duktape_gridstr_width, 1);
		duk_put_global_string( ctx, "gridstr_width");
	duk_push_c_function( ctx,// _gridstr_0_under_50_or_width
			js_port_duktape_gridstr_height, 1);
		duk_put_global_string( ctx, "gridstr_height");
	
	duk_push_c_function( ctx,// _gridstr_char_get
			js_port_duktape__gridstr_char_get, 4);
		duk_put_global_string( ctx, "gridstr_char_get");

	duk_push_string( ctx, //gridstr_indexOf_char_getXY
		js_port_duktape_gridstr_i_char_XYfunct());
	duk_eval_noresult(ctx); 
}
#endif
