#include <stdlib.h> /* malloc, free */
#include <string.h> /* strcmp, strdup */

// from https://github.com/ccxvii/minilibs
// (SLIGHTLY modified) 
//#include "tree.h"
//
//NOTE: Er... I think all 'tree' functions below are not used... yeah...

struct tree *tree_insert(struct tree *node, const char *key, void *value);
void *tree_lookup(struct tree *node, const char *key);
void tree_free(struct tree *node);

//


/* This is an AA-tree implementation. */

struct tree
{
	char *key;
	void *value;
	struct tree *left, *right;
	int level;
};

static struct tree sentinel = { "", NULL, &sentinel, &sentinel, 0 };

static struct tree *tree_make(const char *key, void *value)
{
	struct tree *node = malloc(sizeof(struct tree));
	node->key = strdup(key);
	node->value = value;
	node->left = node->right = &sentinel;
	node->level = 1;
	return node;
}

void *tree_lookup(struct tree *node, const char *key)
{
	if (node) {
		while (node != &sentinel) {
			int c = strcmp(key, node->key);
			if (c == 0)
				return node->value;
			else if (c < 0)
				node = node->left;
			else
				node = node->right;
		}
	}
	return NULL;
}

static struct tree *tree_skew(struct tree *node)
{
	if (node->left->level == node->level) {
		struct tree *save = node;
		node = node->left;
		save->left = node->right;
		node->right = save;
	}
	return node;
}

static struct tree *tree_split(struct tree *node)
{
	if (node->right->right->level == node->level) {
		struct tree *save = node;
		node = node->right;
		save->right = node->left;
		node->left = save;
		node->level++;
	}
	return node;
}

struct tree *tree_insert(struct tree *node, const char *key, void *value)
{
	if (node && node != &sentinel) {
		int c = strcmp(key, node->key);
		if (c < 0)
			node->left = tree_insert(node->left, key, value);
		else
			node->right = tree_insert(node->right, key, value);
		node = tree_skew(node);
		node = tree_split(node);
		return node;
	}
	return tree_make(key, value);
}

void tree_free(struct tree *node)
{
	if (node && node != &sentinel) {
		tree_free(node->left);
		tree_free(node->right);
		free(node->key);
		free(node);
	}
}

/////////////////////// TEST
//#ifdef TEST
/*
#include <stdio.h>
static void tree_print(struct tree *node, int level)
{
	int i;
	if (node->left != &sentinel)
		tree_print(node->left, level + 1);
	for (i = 0; i < level; ++i)
		putchar(' ');
	printf("%s = %s (%d)\n", node->key, (const char*)node->value, node->level);
	if (node->right != &sentinel)
		tree_print(node->right, level + 1);
}

int main(int argc, char **argv)
{
	struct tree *args = NULL;
	int i;
	for (i = 0; i < argc; ++i) {
		char buf[10];
		sprintf(buf, "%d", i);
		args = tree_insert(args, argv[i], strdup(buf));
		args = tree_insert(args, "scrotum", "head");
		args = tree_insert(args, "face", "elbow");
		args = tree_insert(args, "butt", "head ");
	}
	// freeing data
	tree_free( args);
	args = NULL;
	args = tree_insert(args, "scrotum", "head");
	args = tree_insert(args, "scrotum2", "head2");
	args = tree_insert(args, "scrotum3", "head3");

	printf("\n\n===%s====\n\n", (const char*)tree_lookup(args, "scrotum") );
	tree_print(args, 1);
	return 0;
}
endif
*/

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
/////////////// Ducktape Port //////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

#if defined(DUK_VERSION)

// below will make a preprocessor directive that generates tree(n)
#define _MAKEDATA(n) tree##n

#undef _MAKEDATA

//
struct tree *_tree_col_handler;
char * _tree_col_holder[20000];
int _tree_col_holder_lastUsed = 0;


static duk_ret_t js_port_duktape_tree_colhandler_clear(
		duk_context *ctx ){
	if( _tree_col_handler != NULL){
		tree_free(_tree_col_handler ); }
	_tree_col_handler = NULL;
	while(_tree_col_holder_lastUsed > 0){
		_tree_col_holder_lastUsed -=1;
		free(_tree_col_holder[_tree_col_holder_lastUsed]);}

	_tree_col_holder_lastUsed=0;
	// below is to avoid errors, and this should run first!
	tree_insert( _tree_col_handler, "-", "-");
	return 0;  /* one return value */
}

// js: _tree_col_handler( obj_i, x,y);  
static duk_ret_t js_port_duktape_tree_colhandler_insert(
		duk_context *ctx ){
	int rtrn = -1; 
	char * tmp_val; tmp_val = (char *)malloc(20);
	char * tmp_key; tmp_key = (char *)malloc(30);

	//storing for clearing memory
	_tree_col_holder[_tree_col_holder_lastUsed] = tmp_val;
	_tree_col_holder_lastUsed+=1;
	_tree_col_holder[_tree_col_holder_lastUsed] = tmp_key;
	_tree_col_holder_lastUsed+=1;

	int obj_id =duk_to_int(ctx, 0);
        int x = floor((float)duk_to_number(ctx, 1));
	int y = floor((float)duk_to_number(ctx, 2));

	int i=0;
	snprintf(tmp_val, 20, "%i",  obj_id);

	snprintf(tmp_key, 30, "%i,%i,%i", x, y, i );
	while( tree_lookup( _tree_col_handler, tmp_val ) != NULL){ i+=1;
	   snprintf(tmp_key, 30, "%i,%i,%i", x, y, i );
	}
	_tree_col_handler = 
		tree_insert( _tree_col_handler, tmp_key, tmp_val);

	return 0;  /* one return value */
}



/*
void *ptr;
ptr = duk_get_pointer()
	duk_get_pointer()
struct mystruct *p = /* ... */;
//duk_push_pointer(ctx, (void *) p);
// js: lookup_objxy, lookup_objlarge (catching them from global vars)
// get pointers to 'lookup small obj. loc' and 'lookup large_obj pool'
//
// REMOVED AFTER COLLISION HANDER (the preprocessor stuff)





// ABOVE CAN PROBABLY BE OMITTED!!!

/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////

// EDIT: having a hard time describing below
//BELOW WORKS by removing all the x and y values except a grid (%)
// THEN, storing the length seperately, and 'posting' them to 
// the grid without removing them. (the grid is basically a 3d arary, 
// 	stored in 1d, as a certain length WILL give the second dimention 
// --- only the 'lengths' of the arrays are saved, so I can 
// 	zero the lengths alone out without modifying the actual values. 
// --- stored values are indexes
#define MX_DEPTH_MINUS_1 9
#define X_MDL(x) abs( x % 160 )
#define Y_MDL(y) abs( y % 50 )
#define MX_DEPTH 10
#ifdef __DOS__
int __huge lookupbyxy__rmloaded_launch_game_objs__list[161][51][MX_DEPTH];
#else
int lookupbyxy__rmloaded_launch_game_objs__list[161][51][MX_DEPTH];
#endif
// it's a 160*50 grid, times depth (10)
int lookupbyxy__rmloaded_launch_game_objs__list_lens[161][51]; // it's a 160*50 grid
int lookupbyxy__rmloaded_launch_game_objs__objx_catch[5000];
int lookupbyxy__rmloaded_launch_game_objs__objy_catch[5000];
static int lookupbyxy__rmloaded_launch_game_objs__at_listlength(int x, int y){
	return lookupbyxy__rmloaded_launch_game_objs__list_lens[X_MDL(x)][ Y_MDL(y)];}
// returns -1 for no results (AS 0 = place 0 in array) 
static int lookupbyxy__rmloaded_launch_game_objs__at(int x, int y, int i){ 
	// i is xy index(# at loc)
	// 2000 is 80 * 25, a full length
	int obj_ID= lookupbyxy__rmloaded_launch_game_objs__list[X_MDL(x)][Y_MDL(y)][i];
	if( lookupbyxy__rmloaded_launch_game_objs__objx_catch[obj_ID] == x && 
	       lookupbyxy__rmloaded_launch_game_objs__objy_catch[obj_ID] == y	){
			return obj_ID; 
	}return -1; }
static void lookupbyxy__rmloaded_launch_game_objs__list_reset(){
	for(int j=0; j< 161; j+=1){
		for(int i=0; i< 51; i+=1){ 
		  lookupbyxy__rmloaded_launch_game_objs__list_lens[j][i] =0;	}}	}
static void lookupbyxy__rmloaded_launch_game_objs__add_xy( int x, int y, int obj_ID){
	int x_m = X_MDL(x); int y_m = Y_MDL(y);
	int i = lookupbyxy__rmloaded_launch_game_objs__list_lens[x_m][y_m]; 
	
	lookupbyxy__rmloaded_launch_game_objs__objx_catch[obj_ID] = x; 
	lookupbyxy__rmloaded_launch_game_objs__objy_catch[obj_ID] = y;

	lookupbyxy__rmloaded_launch_game_objs__list[x_m][y_m][i] = obj_ID;
	if( i < MX_DEPTH_MINUS_1){ 
		lookupbyxy__rmloaded_launch_game_objs__list_lens[x_m][y_m] +=1; }
}
#undef MX_DEPTH
#undef MX_DEPTH_PLUS_1
#undef X_MDL
#undef Y_MDL


/*
int lookupbyxy__rmloaded_launch_game_objs__list[800100]; // it's a 160*50 grid, times depth (10)
int lookupbyxy__rmloaded_launch_game_objs__list_lens[8010]; // it's a 160*50 grid
static int lookupbyxy__rmloaded_launch_game_objs__at_key(int x, int y){
	int ret_xykey = abs((x % 160)+ ((y%50)*160) );
	return ret_xykey;}
	
static int lookupbyxy__rmloaded_launch_game_objs__at_listlength(int x, int y){
	return lookupbyxy__rmloaded_launch_game_objs__list_lens[lookupbyxy__rmloaded_launch_game_objs__at_key(x, y)];}
static int lookupbyxy__rmloaded_launch_game_objs__at(int x, int y, int i){ // i is xy index(# at loc)
	// 2000 is 80 * 25, a full length
	return lookupbyxy__rmloaded_launch_game_objs__list[
		lookupbyxy__rmloaded_launch_game_objs__at_key( x, y) +(i* LOOKUPXY_SINGLE_DEPTH_LEN)]; }
static void lookupbyxy__rmloaded_launch_game_objs__list_reset(){
	for(int i=0; i< 8010; i+=1){ 
		lookupbyxy__rmloaded_launch_game_objs__list_lens[i] =0;	}	}
static void lookupbyxy__rmloaded_launch_game_objs__add_xy( int x, int y, int obj_ID){
	int i = lookupbyxy__rmloaded_launch_game_objs__at_listlength( x, y); 
	int key = lookupbyxy__rmloaded_launch_game_objs__at_key( x, y);
	lookupbyxy__rmloaded_launch_game_objs__list[key +(i* LOOKUPXY_SINGLE_DEPTH_LEN)]
		= obj_ID;
	if( i+1 < LOOKUPXY_MAX_DEPTH){ 
		lookupbyxy__rmloaded_launch_game_objs__list_lens[key] +=1; }
}
*/

/*
int lookupbyxy__rmloaded_launch_game_objs__list[800100]; // it's a 160*50 grid, times depth (10)
int lookupbyxy__rmloaded_launch_game_objs__list_lens[8010]; // it's a 160*50 grid
static int lookupbyxy__rmloaded_launch_game_objs__at_key(int x, int y){
	int ret_xykey = abs((x % 160)+ ((y%50)*160) );
	return ret_xykey;}
	
static int lookupbyxy__rmloaded_launch_game_objs__at_listlength(int x, int y){
	return lookupbyxy__rmloaded_launch_game_objs__list_lens[lookupbyxy__rmloaded_launch_game_objs__at_key(x, y)];}
static int lookupbyxy__rmloaded_launch_game_objs__at(int x, int y, int i){ // i is xy index(# at loc)
	// 2000 is 80 * 25, a full length
	return lookupbyxy__rmloaded_launch_game_objs__list[
		lookupbyxy__rmloaded_launch_game_objs__at_key( x, y) +(i* LOOKUPXY_SINGLE_DEPTH_LEN)]; }
static void lookupbyxy__rmloaded_launch_game_objs__list_reset(){
	for(int i=0; i< 8010; i+=1){ 
		lookupbyxy__rmloaded_launch_game_objs__list_lens[i] =0;	}	}
static void lookupbyxy__rmloaded_launch_game_objs__add_xy( int x, int y, int obj_ID){
	int i = lookupbyxy__rmloaded_launch_game_objs__at_listlength( x, y); 
	int key = lookupbyxy__rmloaded_launch_game_objs__at_key( x, y);
	lookupbyxy__rmloaded_launch_game_objs__list[key +(i* LOOKUPXY_SINGLE_DEPTH_LEN)]
		= obj_ID;
	if( i+1 < LOOKUPXY_MAX_DEPTH){ 
		lookupbyxy__rmloaded_launch_game_objs__list_lens[key] +=1; }
}*/
#undef LOOKUPXY_MAX_DEPTH
#undef LOOKUPXY_SINGLE_DEPTH_LEN

#define LOOKUPPROP_MAX_DEPTH 200
#define LOOKUPPROP_SINGLE_DEPTH_LEN 80
int lookupbyprop__rmloaded_launch_game_objs_large__list[82][202]; // 80 props *200 list depth (plus some extra)
int lookupbyprop__rmloaded_launch_game_objs_large__list_lens[82];// 80 props ( numbers 0-9, chars a-z & A-Z)
int lookup_lrg_objx_catch[5000];
int lookup_lrg_objy_catch[5000];	

const char * LOOKUPPROPS = { "0123456789"
			"abcdefghijklmnopqrstuvwxyz"
			"ABCDEFGHIJKLMNOPQRSTUVWXYZ"};
static int lookupbyprop__rmloaded_launch_game_objs_large__char_to_int(char c){
	char* retnumb;
	retnumb = strchr( LOOKUPPROPS, c );
	if(retnumb == NULL){ return 79;} // an unused loc
	//printf(" %i ", (int)(retnumb- lookup));
	//printf(" %i ", (int)(retnumb-LOOKUPPROPS)); 
	return (int)(retnumb-LOOKUPPROPS);
}
static int lookupbyprop__rmloaded_launch_game_objs_large__get_listlength(
		char prop_c){
	return lookupbyprop__rmloaded_launch_game_objs_large__list_lens[
	  lookupbyprop__rmloaded_launch_game_objs_large__char_to_int(prop_c) ];}
static int lookupbyprop__rmloaded_launch_game_objs_large__get_list_i(
		char prop_c, int i){//i is index # with prop
	// 2000 is 80 * 25, a full length
	return lookupbyprop__rmloaded_launch_game_objs_large__list[
		lookupbyprop__rmloaded_launch_game_objs_large__char_to_int(prop_c)][i]; }
static void lookupbyprop__rmloaded_launch_game_objs_large__list_reset(){
	for(int i=0; i< LOOKUPPROP_SINGLE_DEPTH_LEN +1; i+=1){ 
		lookupbyprop__rmloaded_launch_game_objs_large__list_lens[i] =0;	}	}
static void lookupbyprop__rmloaded_launch_game_objs_large__add_obj( 
		char prop_c, int obj_ID){
	int prop = lookupbyprop__rmloaded_launch_game_objs_large__char_to_int(
			prop_c);
	int i = lookupbyprop__rmloaded_launch_game_objs_large__list_lens[prop]; 
	lookupbyprop__rmloaded_launch_game_objs_large__list[prop][i] = obj_ID;
	if( i+1 < LOOKUPPROP_MAX_DEPTH){ 
		lookupbyprop__rmloaded_launch_game_objs_large__list_lens[prop] +=1; }
}
#undef LOOKUPPROP_MAX_DEPTH
#undef LOOKUPPROP_SINGLE_DEPTH_LEN

static duk_ret_t js_port_duktape_rmloaded_settup_lookup_lrg(duk_context *ctx ){
	// indexing inputs (location on duktape stack)
	int OBJLIST_I = 0;  int OBJ_I = 1;
	int COLGRP_I = 2;

	duk_get_prop_string(ctx, OBJLIST_I, "length");
	int len = duk_to_int(ctx, -1); //negetive for reverse index
	duk_pop(ctx);
	
	int i=0;
	// BELOW IS FOR STRESS TESTING, REMOVE NEXT LINE!!!
	//for(int j=0; j<3; j+=1){
	for( i =0;  i< len; i+=1){
		
		
		//duk_enum() --- might be able to use for 'loops'
		duk_get_prop_index(ctx, OBJLIST_I, i);
		// OBJ_I NOW WORKS!
		
		//catch x, y --- based on lrg_obj_list index
		duk_get_prop_string(ctx, OBJ_I, "x");
		duk_get_prop_string(ctx, OBJ_I, "y");
		lookup_lrg_objx_catch[i]= 
			floor((float)duk_to_number(ctx, -2));
		lookup_lrg_objy_catch[i]= 
			floor((float)duk_to_number(ctx, -1));
		duk_pop(ctx); duk_pop(ctx);

		duk_get_prop_string(ctx, OBJ_I, "colgroup");
		
		int j=0;
		char tmpProp = duk_char_code_at(ctx,COLGRP_I, j);
		// adding it 1x per prop
		while(tmpProp !=0){
			lookupbyprop__rmloaded_launch_game_objs_large__add_obj( 
					tmpProp, i);
			j+=1;
			tmpProp = duk_char_code_at(ctx,COLGRP_I, j);
			//tmpProp = 0;
	       		}		
		
		duk_pop_n(ctx,2);   //colgroup, objList
		
	}
	return 0;
}
static duk_ret_t js_port_duktape_rmloaded_col_test_settup_vars( duk_context *ctx){
	lookupbyxy__rmloaded_launch_game_objs__list_reset();
	lookupbyprop__rmloaded_launch_game_objs_large__list_reset();
	return 0;
}

#define DUKSTASH_XYLOCS_INDEX 0
#define DUKSTASH_LRGOBJ_INDEX 1


#define X_MULITPLIER 5000
#define RETURN_LIST 3
#define LOOKUP_XY_I 4
#define LOOKUP_LRG_I 5
#define RETURN_LIST_OBJS_I 6
#define COLLIDABLE_OBJS_I 7
#define OBJ_I 8

#define RETURN_LIST_MAX_LEN 10

// RETURNS BY ADDING COLLISON TO DUK_CONTEXT AS "" OR "(COLGFX)"!!!
void _rmloaded_col_SIMPLE( duk_context * ctx, 
		int x, int y, char prop){
	
	int len = lookupbyxy__rmloaded_launch_game_objs__at_listlength(x,y);
	if(len > 0){ 
		duk_get_global_string(ctx, "_rmloaded_launch_game_objs");
		for(int i=len-1; i>= 0; i-=1){
			if( lookupbyxy__rmloaded_launch_game_objs__at( x,y,i) 
					==-1){ continue; }
			//getting OBJ
			duk_get_prop_index(ctx, -1, 
			   lookupbyxy__rmloaded_launch_game_objs__at( x,y,i));
			duk_get_prop_string(ctx, -1, "colgroup");
			if( strchr((const char*)duk_to_string(ctx, -1), 
					prop ) != NULL){ 
				duk_get_prop_string(ctx, -2, "graphic");
				duk_insert(ctx,-4);
				duk_pop_n(ctx,3);
				 return;
			}duk_pop(ctx); duk_pop(ctx);//prop  obj
		}duk_pop(ctx); // _for__rmloaded_launch_game_objs
	}

	char tmpC[2]; 
	len = lookupbyprop__rmloaded_launch_game_objs_large__get_listlength(prop);
	if(len > 0){ 
		duk_get_global_string(ctx, "_rmloaded_launch_game_objs_large");
		for(int i=0; i< len; i+=1){
			duk_get_prop_index(ctx, -1, 
			  lookupbyprop__rmloaded_launch_game_objs_large__get_list_i(
				       	prop,i));
			duk_get_prop_string(ctx, -1, "graphic");
			
			strcpy(tmpC, " ");
			gridstr_overlay(  
			  (char*)tmpC,	(char*)duk_to_string(ctx, -1), 
			  	//graphic
				-(x- lookup_lrg_objx_catch[
			             lookupbyprop__rmloaded_launch_game_objs_large__get_list_i( 
				 	prop,i)]), //x
				-(y- lookup_lrg_objy_catch[
		 	               lookupbyprop__rmloaded_launch_game_objs_large__get_list_i(
					prop,i)]), //y
				0,0); //length of char to get
			
			if( 0 != strcmp(tmpC, " ")){ // not the same
				//duk_pop_n(ctx, 3);
				duk_push_string(ctx, tmpC); 
				return;}
			duk_pop_n(ctx, 2);
	} duk_pop(ctx);  }

	duk_push_string(ctx, ""); 
	return;

}

// js rmloaded_col_test( x, y, prop (string) );
static duk_ret_t js_port_duktape_rmloaded_col_SIMPLE( duk_context *ctx){
	int x = floor((float)duk_to_number(ctx, 0));
	int y = floor((float)duk_to_number(ctx, 1));
	char prop= duk_char_code_at(ctx, 2, 0);
	
	_rmloaded_col_SIMPLE( ctx, x, y, prop);
	return 1;
} 
static duk_ret_t js_port_duktape_rmloaded_col_GET_OBJ( duk_context *ctx){
	int x = floor((float)duk_to_number(ctx, 0));
	int y = floor((float)duk_to_number(ctx, 1));
	char prop= duk_char_code_at(ctx, 2, 0);

	int len = lookupbyxy__rmloaded_launch_game_objs__at_listlength(x,y);
	if(len > 0){ 
		duk_get_global_string(ctx, "_rmloaded_launch_game_objs");
		for(int i=len-1; i>= 0; i-=1){
			if( lookupbyxy__rmloaded_launch_game_objs__at( x,y,i) 
					== -1){ 
				continue; }
			//getting OBJ
			duk_get_prop_index(ctx, -1, 
				lookupbyxy__rmloaded_launch_game_objs__at(x,y,i));
			duk_get_prop_string(ctx, -1, "colgroup");
			if( strchr((const char*)duk_to_string(ctx, -1), 
					prop ) != NULL){ 
				duk_dup(ctx, -2);
				duk_insert(ctx,-4);
				duk_pop_n(ctx,3);
				 return 1;
			}duk_pop(ctx); duk_pop(ctx);//prop  obj
		}duk_pop(ctx); // _for__rmloaded_launch_game_objs
	}

	char tmpC[2]; 
	len = lookupbyprop__rmloaded_launch_game_objs_large__get_listlength(prop);
	if(len > 0){ 
		duk_get_global_string(ctx, "_rmloaded_launch_game_objs_large");
		for(int i=0; i< len; i+=1){
			duk_get_prop_index(ctx, -1, 
			   lookupbyprop__rmloaded_launch_game_objs_large__get_list_i( 
					prop,i));
			duk_get_prop_string(ctx, -1, "graphic");
			duk_get_prop_string(ctx, -2, "x");
			duk_get_prop_string(ctx, -3, "y");

			strcpy(tmpC, " ");
			gridstr_overlay(  
			  (char*)tmpC,	(char*)duk_to_string(ctx, -3), 
			  	//graphic
				-(x- 
				  floor((float)duk_to_number(ctx,-2))),//x
				-(y- 
				  floor((float)duk_to_number(ctx, -1))),//y
				0,0); //length of char to get
			
			if( 0 != strcmp(tmpC, " ")){ // not the same
				//duk_dup(ctx, -4); //obj
				//duk_insert(ctx, 4); //inputs +1
				duk_pop_n(ctx, 3);
				//duk_pop_n(ctx, 5);
				//duk_push_string(ctx, tmpC); 
				return 1;}
			duk_pop_n(ctx, 4);
	} duk_pop(ctx);  }

	duk_push_null(ctx); 
	return 1;
} 

// RIGHT NOW UNUSED!!!
static duk_ret_t js_port_duktape_rmloaded_col( duk_context *ctx){

	int x = floor((float)duk_to_number(ctx, 0));
	int y = floor((float)duk_to_number(ctx, 1));
	
	char * props = (char *)duk_to_string(ctx, 2);
	
	

	
	//int RETURN_LIST = 3; // this one actually gets returned
		duk_push_array(ctx);
       	//int LOOKUP_XY_I = 5;
	// 	duk_push_global_stash(ctx); 
		duk_get_global_string(ctx, "_rmloaded_lookup_xlocs");


		
	//return 1; 
	//int LOOKUP_LRG_I = 6;
		duk_get_global_string(ctx, "_rmloaded_lookup_lrg_colgroups");

		//int RETURN_LIST_OBJS_I = 7;
		duk_push_array(ctx);
	int return_list_length = 0;
	//int RETURN_LIST_MAX_LEN = 10;
	char return_graphic_chars[RETURN_LIST_MAX_LEN];
	// below will go up as items are added to 'return list'
	// 'return list' [[objs], "chars"] will be generated at end.
	//int COLLIDABLE_OBJS_I =8;
		duk_get_prop_index(ctx, LOOKUP_XY_I, x*X_MULITPLIER +y );
			duk_pop(ctx); 

	//int OBJ_I =9;

	// search xy's (for 1 char objects)
	if( duk_is_null_or_undefined(ctx, COLLIDABLE_OBJS_I) != 1){
		int len = duk_get_length( ctx, COLLIDABLE_OBJS_I);
		for(int i=0; i< len; i+=1){
			// setting OBJ_I
			duk_get_prop_index(ctx, COLLIDABLE_OBJS_I, i );
			
			duk_get_prop_string(ctx, OBJ_I, "x");
			duk_get_prop_string(ctx, OBJ_I, "y");
			duk_get_prop_string(ctx, OBJ_I, "colgroup");
			
			if( strchr((const char*)duk_to_string(ctx, -1), props[0] ) 
				!= NULL && 
				y == floor((float)duk_to_number(ctx, -2))&&
				x == floor((float)duk_to_number(ctx, -3))){
				
				duk_put_prop_index(ctx, RETURN_LIST_OBJS_I, 
						return_list_length);
				duk_get_prop_string(ctx, OBJ_I, "graphic");
				return_graphic_chars[return_list_length] =
					duk_to_string(ctx, -1)[0];
				if( return_list_length < 
					RETURN_LIST_MAX_LEN){//max len
					return_list_length +=1;}
			}
			duk_pop_n(ctx, 4);   //obj, x,y,colgroup

	}	}


	return_graphic_chars[return_list_length] = '\0';
	//generating returned list
	duk_dup(ctx, RETURN_LIST_OBJS_I);
	duk_put_prop_index(ctx, RETURN_LIST,  0);
	//printf("%s", return_graphic_chars);
	duk_push_string(ctx, return_graphic_chars); //return_graphic_chars); 
	duk_put_prop_index(ctx, RETURN_LIST,  1);
	// removing non-returned values in stack (should be 4)
	duk_pop_n(ctx, 4);  
	//duk_push_array(ctx);
	return 1; /* the return, in this case, a array */
}
/*
static duk_ret_t js_port_duktape_rmloaded_col( duk_context *ctx){
	int x = duk_to_int(ctx, 0);
	int y = duk_to_int(ctx, 1);
	char * props = (char * )duk_to_string(ctx, 2);
	
	

	//int RETURN_LIST = 3; // this one actually gets returned
		duk_push_array(ctx);
       	//int LOOKUP_XY_I = 5;
	// 	duk_push_global_stash(ctx); 
		duk_get_global_string(ctx, "_rmloaded_lookup_xlocs");

	//return 1; 
	//int LOOKUP_LRG_I = 6;
		duk_get_global_string(ctx, "_rmloaded_lookup_lrg_colgroups");
	//int RETURN_LIST_OBJS_I = 7;
		duk_push_array(ctx);
	int return_list_length = 0;
	//int RETURN_LIST_MAX_LEN = 10;
	char return_graphic_chars[RETURN_LIST_MAX_LEN];
	// below will go up as items are added to 'return list'
	// 'return list' [[objs], "chars"] will be generated at end.
	//int COLLIDABLE_OBJS_I =8;
		duk_get_prop_index(ctx, LOOKUP_XY_I, x*X_MULITPLIER +y );

	//int OBJ_I =9;

	// search xy's (for 1 char objects)
	if( duk_is_null_or_undefined(ctx, COLLIDABLE_OBJS_I) != 1){
		int len = duk_get_length( ctx, COLLIDABLE_OBJS_I);
		for(int i=0; i< len; i+=1){
			// setting OBJ_I
			duk_get_prop_index(ctx, COLLIDABLE_OBJS_I, i );
			
			duk_get_prop_string(ctx, OBJ_I, "x");
			duk_get_prop_string(ctx, OBJ_I, "y");
			duk_get_prop_string(ctx, OBJ_I, "colgroup");
			
			if( strchr((const char*)duk_to_string(ctx, -1), props[0] ) 
				!= NULL && 
				y == duk_to_int(ctx, -2) &&
				x == duk_to_int(ctx, -3) ){
				
				duk_put_prop_index(ctx, RETURN_LIST_OBJS_I, 
						return_list_length);
				duk_get_prop_string(ctx, OBJ_I, "graphic");
				return_graphic_chars[return_list_length] =
					duk_to_string(ctx, -1)[0];
				if( return_list_length < 
					RETURN_LIST_MAX_LEN){//max len
					return_list_length +=1;}
			}
			duk_pop(ctx); duk_pop(ctx); 
			duk_pop(ctx); duk_pop(ctx); //obj, x,y,colgroup

	}	}


	return_graphic_chars[return_list_length] = '\0';
	//generating returned list
	duk_dup(ctx, RETURN_LIST_OBJS_I);
	duk_put_prop_index(ctx, RETURN_LIST,  0);
	//printf("%s", return_graphic_chars);
	duk_push_string(ctx, return_graphic_chars); //return_graphic_chars); 
	duk_put_prop_index(ctx, RETURN_LIST,  1);
	// removing non-returned values in stack (should be 4)
	duk_pop(ctx); duk_pop(ctx);duk_pop(ctx);duk_pop(ctx); 
	//duk_push_array(ctx);
	return 1; // the return, in this case, a array 
}

*/
#undef X_MULITPLIER
#undef RETURN_LIST 
#undef LOOKUP_XY_I 
#undef LOOKUP_LRG_I 
#undef RETURN_LIST_OBJS_I 
#undef COLLIDABLE_OBJS_I 
#undef OBJ_I 
#undef RETURN_LIST_MAX_LEN 

#undef DUKSTASH_XYLOCS_INDEX
#undef DUKSTASH_LRGOBJ_INDEX
//inputs:  duk context, duk col_list_index,  x, y 
// '_I' Represents 'stack value
#define X_MULITPLIER 5000



#undef X_MULITPLIER

// js: ( objlist, dict_to_update, behaviors, cam_x, cam_y, dont_draw_any_objs)
static duk_ret_t js_port_duktape_batch_draw_n_run_behave_n_updateloc_obj_list(
		duk_context *ctx ){
	// indexing inputs (location on duktape stack)
	int OBJLIST_I = 0; int BEHAVIORS= 1;
       	int CAM_X =2; int CAM_Y =3; 
	int DONT_DRAW_OBJS_I = 4;
	int DRAW_LATE_I = 5; int DRAW_LAST_I =6;
	int OBJ_I = 7;
	int GRAPH_I=8; int X_I=9; int Y_I=10; int BEHAV_I=11;
	int cam_x = floor((float)duk_to_number(ctx, CAM_X)); 
	int cam_y = floor((float)duk_to_number(ctx, CAM_Y));

	duk_get_prop_string(ctx, DRAW_LATE_I, "length");
	int len_draw_late = duk_to_int(ctx, -1); 
	duk_get_prop_string(ctx, DRAW_LAST_I, "length");
	int len_draw_last = duk_to_int(ctx, -1); 
	duk_pop(ctx); duk_pop(ctx);

	int x =0;
	int y =0;
	
	//boolean
	int dont_draw_any_objs = duk_get_boolean(ctx, DONT_DRAW_OBJS_I);
/////////
////////////////////////// MARKER FOR MODIFYING STUFF	
	duk_get_prop_string(ctx, OBJLIST_I, "length");
	int len = duk_to_int(ctx, -1); //negetive for reverse index
	duk_pop(ctx);

	duk_get_global_string(ctx, "rmloaded_paused");
	int tmp_rmloaded_paused = duk_to_boolean(ctx,-1);
	duk_pop(ctx);

	duk_int_t rc=0; // error catching
	char garbage_char_for_error_scanf[10];

		//(int)duk_get_top(ctx) pulls last index
	int i=0; int tmpX = 0; int tmpY=0; int tmp_draw_late_or_hide=0;
	for( i =0;  i< len; i+=1){
		//duk_enum() --- might be able to use for 'loops'
		duk_get_prop_index(ctx, OBJLIST_I, i);
		// OBJ_I NOW WORKS!
		
		duk_get_prop_string(ctx, OBJ_I, "graphic");
		duk_get_prop_string(ctx, OBJ_I, "x");
		tmpX = floor((float)duk_to_number(ctx, X_I));
		duk_get_prop_string(ctx, OBJ_I, "y");
		tmpY= floor((float)duk_to_number(ctx, Y_I));
		duk_get_prop_string(ctx, OBJ_I, "behavior");

		// excuting obj. behavior, pulling it from behave list
		duk_get_prop_string(ctx, BEHAVIORS, 
				(const char*)duk_to_string(ctx, BEHAV_I));
		
		duk_dup(ctx, OBJ_I);
		if( tmp_rmloaded_paused == 0){
			rc = duk_pcall(ctx, 1); 
				// THE '1' HERE IS FOR # of args!
		}else{
			duk_get_prop_string(ctx, OBJ_I, "ignore_pause");
			if(duk_to_boolean(ctx,-1)){
				duk_pop(ctx); // ignore_pause
				rc = duk_pcall(ctx, 1); 
			}else{ duk_pop_n(ctx,2); }
		}

		if (rc != DUK_EXEC_SUCCESS) {
			//does behavior exist?
		   if(duk_has_prop_string(ctx, BEHAVIORS, 
				duk_to_string(ctx, -2)) == 0){
			printf("Error:: BEHAVIOR '%s'\n DOES NOT EXIST! "
					"with object at x-%i y-%i: %s\n",
				duk_to_string(ctx, BEHAV_I), 
				tmpX, 
				tmpY, 
				duk_to_string(ctx, -1)); //error
		   }else{ //problem with object running behavior
			if (duk_is_error(ctx, -1)) {
			   	duk_get_prop_string(ctx, -1, "stack");
			   printf("error (stack info)\n ""(see trace for line number in top function):\n%s\n", 
					   duk_to_string(ctx, -1));
		       		duk_pop(ctx);
			}
    			printf("(For line number/function, see top trace )"
					"\n"
					" Error in behavior '%s' "
					"with object at x-%i y-%i: %s\n", 
				duk_to_string(ctx, BEHAV_I), 
				floor((float)duk_to_number(ctx, X_I)), 
				floor((float)duk_to_number(ctx, Y_I)), 
				duk_to_string(ctx, -1)); // error
		   }
		   fgets(garbage_char_for_error_scanf, 3, stdin);
		}

		duk_pop(ctx); // return val
			
		
		duk_get_prop_string(ctx, OBJ_I, "x");
		tmpX = floor((float)duk_to_number(ctx, -1));
		duk_get_prop_string(ctx, OBJ_I, "y");
		tmpY= floor((float)duk_to_number(ctx, -1));
		duk_pop(ctx); duk_pop(ctx); //x, y

		lookupbyxy__rmloaded_launch_game_objs__add_xy( tmpX, tmpY, i);

		duk_get_prop_string(ctx, OBJ_I, "draw_1late_2last");
		tmp_draw_late_or_hide = duk_to_int(ctx,-1);
		duk_pop(ctx);
		if(dont_draw_any_objs == 0){
		 if(tmp_draw_late_or_hide == 0){
			draw( ( char*)duk_to_string(ctx, GRAPH_I),  
				cam_x + 
				  floor((float)duk_to_number(ctx, X_I)), 
	       			cam_y + 
				  floor((float)duk_to_number(ctx, Y_I)), 
				' ');
		 }else{if(tmp_draw_late_or_hide == 1){
			duk_dup(ctx, OBJ_I);	
			duk_put_prop_index(ctx, DRAW_LATE_I,len_draw_late);
			len_draw_late +=1 ;}
		 if(tmp_draw_late_or_hide == 2){
			duk_dup(ctx, OBJ_I);	
			duk_put_prop_index(ctx, DRAW_LAST_I,len_draw_last);
			len_draw_last +=1;} } 
		}
		duk_pop_n(ctx, 5);   //graph // x // y // behavior //obj
	}
	return 0;  /* one return value */
}

// js: ( objlist, behaviors, cam_x, cam_y, dont_draw_any_objs)
static duk_ret_t js_port_duktape_batch_draw_run_behaveupdateloc_objLRG_list(
		duk_context *ctx ){
	
	// indexing inputs (location on duktape stack)
	int OBJLIST_I = 0; int BEHAVIORS= 1;
       	int CAM_X =2; int CAM_Y =3; 
	int DONT_DRAW_OBJS_I = 4;
	int DRAW_LATE_I = 5; int DRAW_LAST_I =6;
	int OBJ_I = 7;
	int GRAPH_I=8; int X_I=9; int Y_I=10; int BEHAV_I=11;
	
	duk_get_prop_string(ctx, DRAW_LATE_I, "length");
	int len_draw_late = duk_to_int(ctx, -1); 
	duk_get_prop_string(ctx, DRAW_LAST_I, "length");
	int len_draw_last = duk_to_int(ctx, -1); 
	duk_pop(ctx); duk_pop(ctx);

	int cam_x = floor((float)duk_to_number(ctx, CAM_X)); 
	int cam_y = floor((float)duk_to_number(ctx, CAM_Y));

	//boolean
	int dont_draw_any_objs = duk_get_boolean(ctx, DONT_DRAW_OBJS_I);

	int x =0;
	int y =0;

	duk_get_prop_string(ctx, OBJLIST_I, "length");
	int len = duk_to_int(ctx, -1); //negetive for reverse index
	duk_pop(ctx);

	duk_int_t rc=0; // error catching
	char garbage_char_for_error_scanf[10];

	duk_get_global_string(ctx, "rmloaded_paused");
	int tmp_rmloaded_paused = duk_to_boolean(ctx,-1);
	duk_pop(ctx);
		//(int)duk_get_top(ctx) pulls last index
	int i=0; int tmp_draw_late_or_hide=0;
	for( i =0;  i< len; i+=1){
		//duk_enum() --- might be able to use for 'loops'
		duk_get_prop_index(ctx, OBJLIST_I, i);
		// OBJ_I NOW WORKS!	
		
		duk_get_prop_string(ctx, OBJ_I, "graphic");
		duk_get_prop_string(ctx, OBJ_I, "x");
		duk_get_prop_string(ctx, OBJ_I, "y");
		duk_get_prop_string(ctx, OBJ_I, "behavior");

		// excuting obj. behavior, pulling it from behave list
		duk_get_prop_string(ctx, BEHAVIORS, 
				(const char*)duk_to_string(ctx, BEHAV_I));
		duk_dup(ctx, OBJ_I);
		if( tmp_rmloaded_paused == 0){
			rc = duk_pcall(ctx, 1); 
				// THE '1' HERE IS FOR # of args!
		}else{
			duk_get_prop_string(ctx, OBJ_I, "ignore_pause");
			if(duk_to_boolean(ctx,-1)){
				duk_pop(ctx); // ignore_pause
				rc = duk_pcall(ctx, 1); 
			}else{ duk_pop_n(ctx,2);}
		}

		if (rc != DUK_EXEC_SUCCESS) {
			//does behavior exist?
		   if(duk_has_prop_string(ctx, BEHAVIORS, 
				duk_to_string(ctx, -2)) == 0){
			printf("Error:: BEHAVIOR '%s'\n DOES NOT EXIST! "
					"with object at x-%i y-%i: %s\n",
				duk_to_string(ctx, BEHAV_I), 
				floor((float)duk_to_number(ctx, X_I)), 
				floor((float)duk_to_number(ctx, Y_I)), 
				duk_to_string(ctx, -1)); //error
		   }else{ //problem with object running behavior
			if (duk_is_error(ctx, -1)) {
			   	duk_get_prop_string(ctx, -1, "stack");
			   printf("error (stack info)\n ""(see trace below for line number failures in functions):\n%s\n", 
					   duk_to_string(ctx, -1));
		       		duk_pop(ctx);
			}
    			printf("(For line number/function, see topmost traces (look above this text) )"
					"\n"
					" Error in behavior '%s' "
					"with object at x-%i y-%i: %s\n",
				duk_to_string(ctx, BEHAV_I), 
				floor((float)duk_to_number(ctx, X_I)), 
				floor((float)duk_to_number(ctx, Y_I)), 
				duk_to_string(ctx, -1)); // error
		   }
		   fgets(garbage_char_for_error_scanf, 3, stdin);
		}

		duk_pop(ctx); // return val
		
		duk_get_prop_string(ctx, OBJ_I, "draw_1late_2last");
		tmp_draw_late_or_hide = duk_to_int(ctx,-1);
		duk_pop(ctx);
		if(dont_draw_any_objs ==0){
		 if(tmp_draw_late_or_hide == 0){
			draw( ( char*)duk_to_string(ctx, GRAPH_I),  
				cam_x + 
				 floor((float)duk_to_number(ctx, X_I)), 
	       			cam_y + 
				  floor((float)duk_to_number(ctx, Y_I)), 
				' ');
		 }else{if(tmp_draw_late_or_hide == 1){
			duk_dup(ctx, OBJ_I);	
			duk_put_prop_index(ctx, DRAW_LATE_I,len_draw_late);
			len_draw_late +=1 ;}
		 if(tmp_draw_late_or_hide == 2){
			duk_dup(ctx, OBJ_I);	
			duk_put_prop_index(ctx, DRAW_LAST_I,len_draw_last);
			len_draw_last +=1;} }
		}

		//catch x, y--- based on lrg_obj_list index
		lookup_lrg_objx_catch[i]= 
			floor((float)duk_to_number(ctx, X_I));
		lookup_lrg_objy_catch[i]= 
			floor((float)duk_to_number(ctx, Y_I));

		duk_pop_n(ctx, 5);   //graph // x // y // behavior //obj
	}
	return 0;  /* one return value */
}

///////////////////////////////////////////////////
///////////  FOR SKETCHING OBJ_LISTS, see rmloaded_sketch_all_objs
////////////////////////////////////////////////
// js: ( objlist, dict_to_update, behaviors, cam_x, cam_y, dont_draw_any_objs)
static duk_ret_t js_port_duktape_batch_SKETCH_n_run_behave_n_updateloc_obj_list(
		duk_context *ctx ){
	// indexing inputs (location on duktape stack)
	int OBJLIST_I = 0; int BEHAVIORS= 1;
       	int CAM_X =2; int CAM_Y =3; 
	int DONT_UPDATE_OBJS_I = 4;
	int DRAW_LATE_I = 5; int DRAW_LAST_I =6;
	int OBJ_I = 7;
	int GRAPH_I=8; int X_I=9; int Y_I=10; int BEHAV_I=11;
	int cam_x = floor((float)duk_to_number(ctx, CAM_X)); 
	int cam_y = floor((float)duk_to_number(ctx, CAM_Y));

	duk_get_prop_string(ctx, DRAW_LATE_I, "length");
	int len_draw_late = duk_to_int(ctx, -1); 
	duk_get_prop_string(ctx, DRAW_LAST_I, "length");
	int len_draw_last = duk_to_int(ctx, -1); 
	duk_pop(ctx); duk_pop(ctx);

	int x =0;
	int y =0;
	
	//boolean
	int dont_UPDATE_any_objs=duk_get_boolean(ctx, DONT_UPDATE_OBJS_I);
/////////
////////////////////////// MARKER FOR MODIFYING STUFF	
	duk_get_prop_string(ctx, OBJLIST_I, "length");
	int len = duk_to_int(ctx, -1); //negetive for reverse index
	duk_pop(ctx);

	duk_get_global_string(ctx, "rmloaded_paused");
	int tmp_rmloaded_paused = duk_to_boolean(ctx,-1);
	duk_pop(ctx);

	duk_int_t rc=0; // error catching
	char garbage_char_for_error_scanf[10];

		//(int)duk_get_top(ctx) pulls last index
	int i=0; int tmpX = 0; int tmpY=0; int tmp_draw_late_or_hide=0;
	for( i =0;  i< len; i+=1){
		//duk_enum() --- might be able to use for 'loops'
		duk_get_prop_index(ctx, OBJLIST_I, i);
		// OBJ_I NOW WORKS!
		
		duk_get_prop_string(ctx, OBJ_I, "graphic");
		duk_get_prop_string(ctx, OBJ_I, "x");
		tmpX = floor((float)duk_to_number(ctx, X_I));
		duk_get_prop_string(ctx, OBJ_I, "y");
		tmpY= floor((float)duk_to_number(ctx, Y_I));
		duk_get_prop_string(ctx, OBJ_I, "behavior");
		
		if(!dont_UPDATE_any_objs){
		  // excuting obj. behavior, pulling it from behave list
		  duk_get_prop_string(ctx, BEHAVIORS, 
				(const char*)duk_to_string(ctx, BEHAV_I));
		
		  duk_dup(ctx, OBJ_I);
		  if( tmp_rmloaded_paused == 0){
			rc = duk_pcall(ctx, 1); 
				// THE '1' HERE IS FOR # of args!
		  }else{
			duk_get_prop_string(ctx, OBJ_I, "ignore_pause");
			if(duk_to_boolean(ctx,-1)){
				duk_pop(ctx); // ignore_pause
				rc = duk_pcall(ctx, 1); 
			}else{ duk_pop_n(ctx,2); }
		  }

		  if (rc != DUK_EXEC_SUCCESS) {
			//does behavior exist?
		   if(duk_has_prop_string(ctx, BEHAVIORS, 
				duk_to_string(ctx, -2)) == 0){
			printf("Error:: BEHAVIOR '%s'\n DOES NOT EXIST! "
					"with object at x-%i y-%i: %s\n",
				duk_to_string(ctx, BEHAV_I), 
				tmpX, 
				tmpY, 
				duk_to_string(ctx, -1)); //error
		   }else{ //problem with object running behavior
			if (duk_is_error(ctx, -1)) {
			   	duk_get_prop_string(ctx, -1, "stack");
			   printf("error (stack info)\n ""(see trace for line number in top function):\n%s\n", 
					   duk_to_string(ctx, -1));
		       		duk_pop(ctx);
			}
    			printf("(For line number/function, see top trace )"
					"\n"
					" Error in behavior '%s' "
					"with object at x-%i y-%i: %s\n", 
				duk_to_string(ctx, BEHAV_I), 
				floor((float)duk_to_number(ctx, X_I)), 
				floor((float)duk_to_number(ctx, Y_I)), 
				duk_to_string(ctx, -1)); // error
		   }
		   fgets(garbage_char_for_error_scanf, 3, stdin);
		  }

		duk_pop(ctx); // return val
		}////dont_UPDATE_any_objs	
		
		duk_get_prop_string(ctx, OBJ_I, "x");
		tmpX = floor((float)duk_to_number(ctx, -1));
		duk_get_prop_string(ctx, OBJ_I, "y");
		tmpY= floor((float)duk_to_number(ctx, -1));
		duk_pop(ctx); duk_pop(ctx); //x, y

		lookupbyxy__rmloaded_launch_game_objs__add_xy( tmpX, tmpY, i);

		duk_get_prop_string(ctx, OBJ_I, "draw_1late_2last");
		tmp_draw_late_or_hide = duk_to_int(ctx,-1);
		duk_pop(ctx);
		 if(tmp_draw_late_or_hide == 0){
			sketch( ( char*)duk_to_string(ctx, GRAPH_I),  
				cam_x + 
				 floor((float)duk_to_number(ctx, X_I)), 
	       			cam_y + 
				 floor((float)duk_to_number(ctx, Y_I)), 
				' ');
		 }else{if(tmp_draw_late_or_hide == 1){
			duk_dup(ctx, OBJ_I);	
			duk_put_prop_index(ctx, DRAW_LATE_I,len_draw_late);
			len_draw_late +=1 ;}
		 if(tmp_draw_late_or_hide == 2){
			duk_dup(ctx, OBJ_I);	
			duk_put_prop_index(ctx, DRAW_LAST_I,len_draw_last);
			len_draw_last +=1;} } 
		duk_pop_n(ctx, 5);   //graph // x // y // behavior //obj
	}
	return 0;  /* one return value */
}
///////////////////////////////////////////////////
///////////  FOR SKETCHING OBJ_LISTS, see rmloaded_sketch_all_objs
////////////////////////////////////////////////
// js: ( objlist, behaviors, cam_x, cam_y, dont_draw_any_objs)
static duk_ret_t js_port_duktape_batch_SKETCH_run_behaveupdateloc_objLRG_list(
		duk_context *ctx ){
	
	// indexing inputs (location on duktape stack)
	int OBJLIST_I = 0; int BEHAVIORS= 1;
       	int CAM_X =2; int CAM_Y =3; 
	int DONT_UPDATE_OBJS_I = 4;
	int DRAW_LATE_I = 5; int DRAW_LAST_I =6;
	int OBJ_I = 7;
	int GRAPH_I=8; int X_I=9; int Y_I=10; int BEHAV_I=11;
	
	duk_get_prop_string(ctx, DRAW_LATE_I, "length");
	int len_draw_late = duk_to_int(ctx, -1); 
	duk_get_prop_string(ctx, DRAW_LAST_I, "length");
	int len_draw_last = duk_to_int(ctx, -1); 
	duk_pop(ctx); duk_pop(ctx);

	int cam_x = floor((float)duk_to_number(ctx, CAM_X)); 
	int cam_y = floor((float)duk_to_number(ctx, CAM_Y));

	//boolean
	int dont_UPDATE_any_objs=duk_get_boolean(ctx, DONT_UPDATE_OBJS_I);

	int x =0;
	int y =0;

	duk_get_prop_string(ctx, OBJLIST_I, "length");
	int len = duk_to_int(ctx, -1); //negetive for reverse index
	duk_pop(ctx);

	duk_int_t rc=0; // error catching
	char garbage_char_for_error_scanf[10];

	duk_get_global_string(ctx, "rmloaded_paused");
	int tmp_rmloaded_paused = duk_to_boolean(ctx,-1);
	duk_pop(ctx);
		//(int)duk_get_top(ctx) pulls last index
	int i=0; int tmp_draw_late_or_hide=0;
	for( i =0;  i< len; i+=1){
		//duk_enum() --- might be able to use for 'loops'
		duk_get_prop_index(ctx, OBJLIST_I, i);
		// OBJ_I NOW WORKS!	
		
		duk_get_prop_string(ctx, OBJ_I, "graphic");
		duk_get_prop_string(ctx, OBJ_I, "x");
		duk_get_prop_string(ctx, OBJ_I, "y");
		duk_get_prop_string(ctx, OBJ_I, "behavior");
		
		if(!dont_UPDATE_any_objs){
	 	  // excuting obj. behavior, pulling it from behave list
		  duk_get_prop_string(ctx, BEHAVIORS, 
				(const char*)duk_to_string(ctx, BEHAV_I));
		  duk_dup(ctx, OBJ_I);
		  if( tmp_rmloaded_paused == 0){
			rc = duk_pcall(ctx, 1); 
				// THE '1' HERE IS FOR # of args!
		  }else{
			duk_get_prop_string(ctx, OBJ_I, "ignore_pause");
			if(duk_to_boolean(ctx,-1)){
				duk_pop(ctx); // ignore_pause
				rc = duk_pcall(ctx, 1); 
			}else{ duk_pop_n(ctx,2);}
		  }

		  if (rc != DUK_EXEC_SUCCESS) {
			//does behavior exist?
		   if(duk_has_prop_string(ctx, BEHAVIORS, 
				duk_to_string(ctx, -2)) == 0){
			printf("Error:: BEHAVIOR '%s'\n DOES NOT EXIST! "
					"with object at x-%i y-%i: %s\n",
				duk_to_string(ctx, BEHAV_I), 
				floor((float)duk_to_number(ctx, X_I)), 
				floor((float)duk_to_number(ctx, Y_I)), 
				duk_to_string(ctx, -1)); //error
		   }else{ //problem with object running behavior
			if (duk_is_error(ctx, -1)) {
			   	duk_get_prop_string(ctx, -1, "stack");
			   printf("error (stack info)\n ""(see trace below for line number failures in functions):\n%s\n", 
					   duk_to_string(ctx, -1));
		       		duk_pop(ctx);
			}
    			printf("(For line number/function, see topmost traces (look above this text) )"
					"\n"
					" Error in behavior '%s' "
					"with object at x-%i y-%i: %s\n",
				duk_to_string(ctx, BEHAV_I), 
				floor((float)duk_to_number(ctx, X_I)), 
				floor((float)duk_to_number(ctx, Y_I)), 
				duk_to_string(ctx, -1)); // error
		   }
		   fgets(garbage_char_for_error_scanf, 3, stdin);
		  }

		  duk_pop(ctx); // return val
		} //dont_UPDATE_any_objs

		duk_get_prop_string(ctx, OBJ_I, "draw_1late_2last");
		tmp_draw_late_or_hide = duk_to_int(ctx,-1);
		duk_pop(ctx);
		 if(tmp_draw_late_or_hide == 0){
			sketch( ( char*)duk_to_string(ctx, GRAPH_I),  
				cam_x + 
				  floor((float)duk_to_number(ctx, X_I)), 
	       			cam_y + 
				  floor((float)duk_to_number(ctx, Y_I)), 
				' ');
		 }else{if(tmp_draw_late_or_hide == 1){
			duk_dup(ctx, OBJ_I);	
			duk_put_prop_index(ctx, DRAW_LATE_I,len_draw_late);
			len_draw_late +=1 ;}
		 if(tmp_draw_late_or_hide == 2){
			duk_dup(ctx, OBJ_I);	
			duk_put_prop_index(ctx, DRAW_LAST_I,len_draw_last);
			len_draw_last +=1;} }

		//catch x, y--- based on lrg_obj_list index
		lookup_lrg_objx_catch[i]= 
			floor((float)duk_to_number(ctx, X_I));
		lookup_lrg_objy_catch[i]= 
			floor((float)duk_to_number(ctx, Y_I));

		duk_pop_n(ctx, 5);   //graph // x // y // behavior //obj
	}
	return 0;  /* one return value */
}
///////////////////////////////////////////////////
/////////// END: FOR SKETCHING OBJ_LISTS, see rmloaded_sketch_all_objs
////////////////////////////////////////////////
//generates objs.
static duk_ret_t _js_port_duktape_rmloaded_gen_objs_from_gridstr_HELPER(
		duk_context *ctx, int char_i, int CHARS_2OBJS_STACKPOS,
	        int RM_OBJS, // duk-stack pos, can input be RM_OBJS_LRG
		int rm_objs_len, int OPTIONAL_objs_pre_stringified,
		int x, int y){
	int JSON_STRINGIFY_JSFUNCT = 9;
	int JSON_PARSE_JSFUNCT = 10;
	
	duk_int_t rc;

	char char_i_str[2];
	char_i_str[0] = char_i;
	char_i_str[1] = '\0';

	if( !OPTIONAL_objs_pre_stringified ){
		duk_dup(ctx, JSON_PARSE_JSFUNCT);		
		duk_dup(ctx, JSON_STRINGIFY_JSFUNCT);
		
		duk_get_prop_string( 
			ctx, CHARS_2OBJS_STACKPOS, (char*)char_i_str);
		
		rc = duk_pcall(ctx, 1); //js stringify,
		rc = duk_pcall(ctx, 1); //js parse,  
		//can check error here. 
		//currently, just obj at top of stack
		//modifying x and y
		
		duk_push_int( ctx, x);
		duk_put_prop_string( ctx, -2, "x");
		duk_push_int( ctx, y);
		duk_put_prop_string( ctx, -2, "y");

		duk_put_prop_index( 
			ctx, RM_OBJS, rm_objs_len);
		   //transfering generated obj (index -1)
	}else{
		duk_dup(ctx, JSON_PARSE_JSFUNCT);
		
		duk_get_prop_string( 
			ctx, CHARS_2OBJS_STACKPOS, (char*)char_i_str);
		
		rc = duk_pcall(ctx, 1); //js parse,  
		//can check error here. 
		//currently, just obj at top of stack
		//modifying x and y
		duk_push_int( ctx, x);
		duk_put_prop_string( ctx, -2, "x");
		duk_push_int( ctx, y);
		duk_put_prop_string( ctx, -2, "y");

		duk_put_prop_index( 
			ctx, RM_OBJS, rm_objs_len);
		   //transfering generated obj (index -1)
	}
}
const char * js_port_duktape_rmloaded_gen_objs_from_gridstr_JSWRAPER(){
return
"function rmloaded_gen_objs_from_gridstr( get_rm, getGridstr, x_init, y," 
"	  chars_2objs, chars_2lrgobjs, OPTIONAL_objs_pre_stringified){"
" _rmloaded_gen_objs_from_gridstr("
" get_rm, getGridstr, x_init, y, chars_2objs, chars_2lrgobjs,"
"OPTIONAL_objs_pre_stringified,"
"Object.keys(chars_2objs).join(''), Object.keys(chars_2lrgobjs).join(''),"
"JSON.stringify, JSON.parse);"
"}";
}
// js: ( rm, gridstr, x_init, y, chars_2objs({}), chars_2lrgobjs({}),
//       OPTIONAL_obs_pre_stringified, 
//       CHARS_2OBJS_KEYS_STR, CHARS_2LRGOBJS_KEYS_STR
//	JSON_STRINGIFY_JSFUNCT,  JSON_PARSE_JSFUNCT) (11 args)
static duk_ret_t js_port_duktape_rmloaded_gen_objs_from_gridstr(
		duk_context *ctx ){
	// function( get_rm, getGridstr, x_init, y, 
	//    chars_2objs, chars_2lrgobjs, OPTIONAL_objs_pre_stringified)
	// indexing inputs (location on duktape stack)
	int ROOM = 0; int GRIDDSTR = 1; int X_INIT = 2; int Y = 3;
	int CHARS_2OBJS = 4; int CHARS_2LRGOBJS = 5;//jsons:{char:objects)
	int OPTIONAL_OBJS_PRE_STRINGIFIED = 6; // if true, above-char:strs
	
	int CHARS_2OBJS_KEYS_STR = 7; 
	int CHARS_2LRGOBJS_KEYS_STR = 8; // in c version ONLY!
		// is Object.keys(chars_2objs).join(""), 
		//	Object.keys(chars_2lrgobjs).join("")
		//	in js, in c it would be much larger and unwieldy.
	
	int JSON_STRINGIFY_JSFUNCT = 9;
	int JSON_PARSE_JSFUNCT = 10;
		//easier than digging through c-stack objs for them
	int chars_2objs_keys_str_len = 
		duk_get_length( ctx, CHARS_2OBJS_KEYS_STR);
	char * chars_2objs_keys_str = 
		(char *)duk_to_string(ctx, CHARS_2OBJS_KEYS_STR);
	int chars_2objslrg_keys_str_len = 
		duk_get_length( ctx, CHARS_2LRGOBJS_KEYS_STR);
	char * chars_2objslrg_keys_str = 
		(char *)duk_to_string(ctx, CHARS_2LRGOBJS_KEYS_STR);

	// added on runtime
	int RM_OBJS = 11; int RM_OBJS_LARGE =12;
	duk_get_prop_string(ctx, ROOM, "objs");
	duk_get_prop_string(ctx, ROOM, "objs_large");
	
	int rm_objs_len = duk_get_length(ctx, RM_OBJS); 
	int rm_objs_lrg_len = duk_get_length(ctx, RM_OBJS_LARGE); 

	int x_init = floor((float)duk_to_number(ctx, X_INIT)); 
	int y = floor((float)duk_to_number(ctx, Y));
	char * getGridstr = ( char*)duk_to_string(ctx, GRIDDSTR);
	int getGridstr_len = duk_get_length( ctx, GRIDDSTR );
	
	//boolean
	int OPTIONAL_objs_pre_stringified = 
		duk_get_boolean(ctx, OPTIONAL_OBJS_PRE_STRINGIFIED);
	
	int i=0; int j = 0;
	char char_i;
	int x = x_init - 1;
	int obj_found=0;
	for( i =0;  i< getGridstr_len; i+=1){
		char_i = getGridstr[i]; 
		if( char_i == '\n'){y += 1; x = x_init-1; continue;}
		
		x+=1;
		
		obj_found =0; //Below is for OBJS in chars_list
		for( j = 0; j < chars_2objs_keys_str_len; j+=1){
		  if(char_i == chars_2objs_keys_str[j]){
			  obj_found = 1; continue;}}
		if(obj_found== 1){ // found in chars_2objs
		   //generates objs.
		   _js_port_duktape_rmloaded_gen_objs_from_gridstr_HELPER(
		          ctx, char_i, CHARS_2OBJS, 
			  RM_OBJS, rm_objs_len,
			 OPTIONAL_objs_pre_stringified, x, y  );
		   rm_objs_len += 1;
		}

		obj_found =0; //Below is for OBJS_LARGE in chars_list
		for( j = 0; j < chars_2objslrg_keys_str_len; j+=1){
		  if(char_i == chars_2objslrg_keys_str[j]){
			  obj_found = 1; continue;}}
		if(obj_found== 1){ // found in chars_2objslrg
		   _js_port_duktape_rmloaded_gen_objs_from_gridstr_HELPER(
		          ctx, char_i, CHARS_2LRGOBJS, 
			  RM_OBJS_LARGE, rm_objs_lrg_len,
			  OPTIONAL_objs_pre_stringified, x, y );
		   rm_objs_lrg_len += 1;
		}		
		//GOTTA DO ABOVE WITH chars_2objslrg_keys_str!!!
	}
	// objs/ objs_larg
	duk_pop_n(ctx,2); 

	return 0;  /* no return value */
}


// js: ( objlist, cam_x, cam_y, dont_draw_any_objs)
static duk_ret_t js_port_duktape_batch_draw_obj_list(
		duk_context *ctx ){
	// indexing inputs (location on duktape stack)
	int OBJLIST_I = 0; int CAM_X =1; int CAM_Y =2;
	int DONT_DRAW_OBJS_I=3;       
	int OBJ_I = 4;

	int cam_x = floor((float)duk_to_number(ctx, CAM_X)); 
	int cam_y = floor((float)duk_to_number(ctx, CAM_Y));

	//boolean
	int dont_draw_any_objs = duk_get_boolean(ctx, DONT_DRAW_OBJS_I);
	if(dont_draw_any_objs == 1){ return 0;}

	duk_get_prop_string(ctx, OBJLIST_I, "length");
	int len = duk_to_int(ctx, -1); //negetive for reverse index
	duk_pop(ctx);

	int i=0;
	for( i =0;  i< len; i+=1){
		//duk_enum() --- might be able to use for 'loops'
		duk_get_prop_index(ctx, OBJLIST_I, i);
		// OBJ_I NOW WORKS!
		
		duk_get_prop_string(ctx, OBJ_I, "graphic");
		duk_get_prop_string(ctx, OBJ_I, "x");
		duk_get_prop_string(ctx, OBJ_I, "y");

		draw( ( char*)duk_to_string(ctx, -3),  // graph
			cam_x + 
			  floor((float)duk_to_number(ctx, -2)), // x
	       		cam_y + 
			  floor((float)duk_to_number(ctx, -1)), // y
			' ');
		duk_pop_n(ctx, 4);   //graph // x // y //obj
	}
	return 0;  /* one return value */
}
static duk_ret_t js_port_duktape_batch_sketch_obj_list(
		duk_context *ctx ){
	// indexing inputs (location on duktape stack)
	int OBJLIST_I = 0; int CAM_X =1; int CAM_Y =2;
	int DONT_DRAW_OBJS_I=3;       
	int OBJ_I = 4;

	int cam_x = floor((float)duk_to_number(ctx, CAM_X)); 
	int cam_y = floor((float)duk_to_number(ctx, CAM_Y));

	//boolean
	int dont_draw_any_objs = duk_get_boolean(ctx, DONT_DRAW_OBJS_I);
	if(dont_draw_any_objs == 1){ return 0;}

	duk_get_prop_string(ctx, OBJLIST_I, "length");
	int len = duk_to_int(ctx, -1); //negetive for reverse index
	duk_pop(ctx);

	int i=0;
	for( i =0;  i< len; i+=1){
		//duk_enum() --- might be able to use for 'loops'
		duk_get_prop_index(ctx, OBJLIST_I, i);
		// OBJ_I NOW WORKS!
		
		duk_get_prop_string(ctx, OBJ_I, "graphic");
		duk_get_prop_string(ctx, OBJ_I, "x");
		duk_get_prop_string(ctx, OBJ_I, "y");

		sketch( ( char*)duk_to_string(ctx, -3),  // graph
			cam_x + (int)floor(duk_to_number(ctx, -2)), // x
	       		cam_y + (int)floor(duk_to_number(ctx, -1)), // y
			' ');
		duk_pop_n(ctx, 4);   //graph // x // y //obj
	}
	return 0;  /* one return value */
}

// js: function( objlist);  
static duk_ret_t js_port_duktape_batch_objlist_remove_dead(
		duk_context *ctx ){
	// indexing inputs (location on duktape stack)
	int OBJLIST_I = 0; 
	int OBJ_I = 1;

	duk_get_prop_string(ctx, OBJLIST_I, "length");
	int len = duk_to_int(ctx, -1); //negetive for reverse index
	duk_pop(ctx);
	
	int i=0;

	for( i =0;  i<len; i+=1){
		//duk_enum() --- might be able to use for 'loops'
		duk_get_prop_index(ctx, OBJLIST_I, i);
		// OBJ_I NOW WORKS!


		duk_get_prop_string(ctx, OBJ_I, "dead");
		
		if(duk_to_boolean(ctx, -1)){
			//remove dead
			
			duk_get_prop_string(ctx, OBJLIST_I, "splice");
			duk_dup(ctx, OBJLIST_I);
			//printf("%s", duk_to_string(ctx, -1));
			duk_push_int(ctx, i);
			duk_push_int(ctx, 1);
			// THIS ONE IS NEEDED FOR FUNCTS THAT NEED 'THIS'!!!
			duk_pcall_method(ctx, 2);
		//	printf("\n'%s' ", 
			//	duk_to_string(ctx, -1)); 
			duk_pop(ctx);
			
			//adjusting index
			len -=1; 
			i-=1;
		}
		duk_pop_n(ctx, 2); //remove boolean
		//clearing obj from buffer

	}


	return 0;  /* 0 return value */
}

// "rmloaded_lookupprop_getlrgobjs_len"
// js: function( getProp(1char_str) );  // returns 1 int (length) 
static duk_ret_t js_port_duktape_rmloaded_lookupprop_getlrgobjs_len(
		duk_context *ctx ){
	//input: prop
	duk_push_int(ctx, 
	 	lookupbyprop__rmloaded_launch_game_objs_large__get_listlength(
		 	(char)(duk_get_string(ctx,-1)[0])));	
	return 1;  /* 1 return value */
}
// "rmloaded_lookupprop_getlrgobjs_i"
// js: function( getProp, got_list_i );  
static duk_ret_t js_port_duktape_rmloaded_lookupprop_getlrgobjs_i(
		duk_context *ctx ){
	
	int i = duk_get_int(ctx,-1);
	char prop;
	prop = (char)(duk_get_string(ctx,-2)[0]);
	
	if(lookupbyprop__rmloaded_launch_game_objs_large__get_listlength( prop) 
		<= i){ duk_push_null(ctx); return 1; } 

	duk_get_global_string(ctx, "_rmloaded_launch_game_objs_large");
	duk_get_prop_index(ctx, -1, 
		lookupbyprop__rmloaded_launch_game_objs_large__get_list_i(
			prop, i));
	duk_insert( ctx, -2);
        duk_pop(ctx); // _for__rmloaded_launch_game_objs_large	
	
	return 1;  /* 1 return value */
}
// NOTE: BELOW USES A ROUNDING TRICK, AND CAN GIVE FALS POSITIVES!!!
// CHECK ACTUAL XY!
// "rmloaded_lookupxy_getobjs_len"
// js: function( x, y );  returns: 1 int (length) 
static duk_ret_t js_port_duktape_rmloaded_lookupxy_getobjs_len(
		duk_context *ctx ){

	duk_push_int( ctx,   // x, y 
	 	lookupbyxy__rmloaded_launch_game_objs__at_listlength(
		 	duk_get_int(ctx,-2), duk_get_int(ctx,-1)));	
	
	return 1;  /* 1 return value */
}
// NOTE: BELOW USES A ROUNDING TRICK, AND CAN GIVE FALS POSITIVES!!!
// CHECK ACTUAL XY!!
// "rmloaded_lookupxy_getobjs_at"
// js: function( x, y,  got_list_i );  
static duk_ret_t js_port_duktape_rmloaded_lookupxy_getobjs_at(
		duk_context *ctx ){

	int x = duk_get_int(ctx, -3); 
	int y = duk_get_int(ctx, -2); 
	int i = duk_get_int(ctx, -1);
	if(lookupbyxy__rmloaded_launch_game_objs__at_listlength(x,y)<=i ){
		duk_push_null(ctx); 
		return 1; }

	duk_get_global_string(ctx, "_rmloaded_launch_game_objs");
	duk_get_prop_index(ctx, -1, 
		lookupbyxy__rmloaded_launch_game_objs__at( x,  y, i ) );
	duk_insert( ctx, -2);
        duk_pop(ctx); // _for__rmloaded_launch_game_objs_large	

	return 1;  /* 1 return value */
}


// js: function( objlist, obj_to_save_lookup_too);  
static duk_ret_t js_port_duktape_rmloaded_settup_lookup_objs(
		duk_context *ctx ){
	// indexing inputs (location on duktape stack)
	int OBJLIST_I = 0;  int OBJ_I = 1;

	duk_get_prop_string(ctx, OBJLIST_I, "length");
	int len = duk_to_int(ctx, -1); //negetive for reverse index
	duk_pop(ctx);
	
	int i=0;
	// BELOW IS FOR STRESS TESTING, REMOVE NEXT LINE!!!
	//for(int j=0; j<3; j+=1){
	for( i =0;  i< len; i+=1){
		//duk_enum() --- might be able to use for 'loops'
		duk_get_prop_index(ctx, OBJLIST_I, i);
		// OBJ_I NOW WORKS!

		duk_get_prop_string(ctx, OBJ_I, "x");
		duk_get_prop_string(ctx, OBJ_I, "y");

		lookupbyxy__rmloaded_launch_game_objs__add_xy( 
				floor((float)duk_to_number(ctx, -2)), //y
				floor((float)duk_to_number(ctx, -1)), //x
				i);
		
		duk_pop_n(ctx, 3);   //x	//y //obj	

	}
	//}


		// DON'T NEED BELOW, GOT LENGTH!!!
		//if( duk_is_null_or_undefined(ctx, 1)){
		//	duk_pop(ctx);
		//	break;}
		/*
		duk_get_prop_index(ctx, 1, 1);
		duk_get_prop_index(ctx, 1, 2);
		duk_pop(ctx);
		duk_pop(ctx);
		*/
		
	// https://duktape.org/api.html#duk_pcall
	//  call a function :D
	// duk_pcall()
		

		//duk_get_global_string(ctx, "");

//https://duktape.org/api.html#duk_has_prop
	// duk_has_prop()
	
	//duk_put_prop_index()
	//duk_put_prop_string() 
	//duk_put_prop()

	//duk_get_global_string();

	
	//printf("%i", i);

	//duk_get_prop_index(ctx, 0, 0);
	

	//duk_get_prop_string(ctx, 1, "x");

	//check to see if value is empty
	//duk_is_null_or_undefined(ctx, -3);

	
	//printf( "%i", duk_to_int(ctx, 2));

	//duk_pop(ctx);
	//duk_pop(ctx);
	

	//duk_get_prop_string(ctx, 0, )

	return 0;  /* one return value */
}

void rmloaded_batch_n_collisions_duktape_port_settup(duk_context *ctx){
	duk_push_c_function(ctx, js_port_duktape_tree_colhandler_clear, 0);
	duk_put_global_string(ctx, "_tree_cols_clear");

	duk_push_c_function(ctx, js_port_duktape_tree_colhandler_insert, 3);
	duk_put_global_string(ctx, "_tree_cols_insert");

	duk_push_c_function(ctx, js_port_duktape_rmloaded_settup_lookup_objs, 1);
	duk_put_global_string(ctx, "rmloaded_settup_lookup_props_obj");

	duk_push_c_function(ctx, js_port_duktape_rmloaded_settup_lookup_lrg, 1);
	duk_put_global_string(ctx, "rmloaded_settup_lookup_props_lrg");


	duk_push_c_function(ctx, js_port_duktape_batch_draw_obj_list, 4);
	duk_put_global_string(ctx, "batch_draw_obj_list");

	//////////////////////////////////////
	//// SKETCH FOR BATCH DRAWING rmloaded_sketch_all_objs
	duk_push_c_function(ctx, js_port_duktape_batch_sketch_obj_list, 4);
	duk_put_global_string(ctx, "batch_sketch_obj_list");
	duk_push_c_function(ctx, 
         js_port_duktape_batch_SKETCH_run_behaveupdateloc_objLRG_list,7);
	duk_put_global_string(ctx, 
		"batch_SKETCH_n_run_behave_n_updateloc_obj_LRG_list");
	duk_push_c_function(ctx, 
	 js_port_duktape_batch_SKETCH_n_run_behave_n_updateloc_obj_list,7);
	duk_put_global_string(ctx, 
		"batch_SKETCH_n_run_behave_n_updateloc_obj_list");
	duk_push_c_function(ctx, 
         js_port_duktape_batch_SKETCH_run_behaveupdateloc_objLRG_list,7);
	duk_put_global_string(ctx, //copy of above so for-async js version
	  "batch_SKETCH_n_updateloc_obj_LRG_list");
	duk_push_c_function(ctx, 
	 js_port_duktape_batch_SKETCH_n_run_behave_n_updateloc_obj_list,7);
	duk_put_global_string(ctx, //copy of above so for-async js version
	  "batch_SKETCH_n_updateloc_obj_list");
	//// SKETCH FOR rmloaded_sketch_all_objs
	////////////////////////////////

	duk_push_c_function(ctx, 
		js_port_duktape_batch_draw_run_behaveupdateloc_objLRG_list, 7);
	duk_put_global_string(ctx, "batch_draw_n_run_behave_n_updateloc_obj_LRG_list");

	duk_push_c_function(ctx, 
	   js_port_duktape_batch_draw_n_run_behave_n_updateloc_obj_list, 7);
	duk_put_global_string(ctx, 
			"batch_draw_n_run_behave_n_updateloc_obj_list");

	duk_push_c_function(ctx, 
		js_port_duktape_batch_objlist_remove_dead, 1);
	duk_put_global_string(ctx, "batch_objlist_remove_dead");


	duk_push_c_function( ctx,
			js_port_duktape_rmloaded_col_test_settup_vars, 0);
	duk_put_global_string(ctx, "rmloaded_col_test_settup_xy_n_lrg_list");
	duk_push_c_function( ctx,
			js_port_duktape_rmloaded_col, 3);
	duk_put_global_string(ctx, "rmloaded_col_test2");

	
	duk_push_c_function( ctx,
			js_port_duktape_rmloaded_col_SIMPLE, 3);
	duk_put_global_string(ctx, "rmloaded_col_test_SIMPLE");

	duk_push_c_function( ctx,
			js_port_duktape_rmloaded_col_GET_OBJ, 4);
	duk_put_global_string(ctx, "rmloaded_col_GET_OBJ");
	

	duk_push_c_function( ctx,
			js_port_duktape_rmloaded_lookupprop_getlrgobjs_i, 2);
	duk_put_global_string(ctx, "rmloaded_lookupprop_getlrgobjs_i");
	duk_push_c_function( ctx,
			js_port_duktape_rmloaded_lookupprop_getlrgobjs_len, 1);
	duk_put_global_string(ctx, "rmloaded_lookupprop_getlrgobjs_len");
	duk_push_c_function( ctx,
			js_port_duktape_rmloaded_lookupxy_getobjs_len, 2);
	duk_put_global_string(ctx, "rmloaded_lookupxy_getobjs_len");
	duk_push_c_function( ctx,
			js_port_duktape_rmloaded_lookupxy_getobjs_at, 3);
	duk_put_global_string(ctx, "rmloaded_lookupxy_getobjs_at");
	
	duk_push_c_function( ctx,
		js_port_duktape_rmloaded_gen_objs_from_gridstr, 11);
	duk_put_global_string(ctx, "_rmloaded_gen_objs_from_gridstr");
	duk_push_string(ctx, 
		js_port_duktape_rmloaded_gen_objs_from_gridstr_JSWRAPER());
	duk_eval_noresult(ctx);
	
	
	/*
	duk_push_c_function(ctx, js_port_duktape_draw_grid, 5);
		duk_put_global_string(ctx, // draw_grid
				draw_grid_js_c_funct_name());
		duk_push_string(ctx, draw_grid_js_funct() ) ;
		duk_eval_noresult(ctx);
	
	duk_push_c_function(ctx, 
		js_port_duktape_draw_canvas_get, 0);
	duk_put_global_string(ctx, "draw_canvas_get");
	duk_push_c_function(ctx, 
		js_port_duktape_draw_canvas_set, 1);
	duk_put_global_string(ctx, "draw_canvas_set");
	duk_push_c_function(ctx, 
		js_port_duktape_draw_settup_canvas_custom, 2);
	duk_put_global_string(ctx, "draw_settup_canvas_custom");
	duk_push_c_function(ctx, 
		js_port_duktape_draw_settup_canvas, 0);
	duk_put_global_string(ctx, "draw_settup_canvas");
	duk_push_c_function(ctx, 
		js_port_duktape_draw_clear_canvas, 0);
	duk_put_global_string(ctx, "draw_clear_canvas");
	*/	
}




#endif



