///////////// Index of functions: ////////////////
//API_TAG// 
// Basic string operations, could be used in other projects.
// ALL THE BELOW RETURN A FORMATED STRING, 'GRIDSTR'
//	function gridstr_width( str)
//	function gridstr_make(  x, y){
//	function gridstr_fill( string, 
//		char_to_fill_with, ignore_chars_or_Empty_str)
//
//	function gridstr_charCountPriorToIndex( 
//		getStr, getChar, getIndex, getQuadrantOrNull)
//		//quadrants: 1 up left, 2 up right, 3 lower left,4 lwr rght
//
//	//one size fits-all draw:
//	function gridstr_overlay( s_to, s_from, x, y, overlayChar_or_null)
//	
//	// below is because my duktape.js don't work with replaceAll
//	// probably a good idea to use this instead (returns moded str)
//	function gridstr_replaceall(str_in, char_replace, char_replacewith)
//API_TAG// 
//
//	//The '2darr' is only used because JS don't allow char changes 
//	// to strings!!!
//	function _gridstr__2darr_fill( 2d_arr, fillchar)
//	function _gridstr__2darr_auto_buffer_get(str)
//	function _gridstr__2darr_txt_to_2darr(txt)
//
//	function _gridstr__2darr_crop_at_0_n_max(arr, offset, max)
//	function _gridstr__2darr_overlay( 
//		arr_to, arr_from, x, y, alpha_char)
//	function gridstr__from_2darr( 2d_arr )
//	
function gridstr_replaceall(str_in, char_replace, char_replacewith){
  return str_in.replaceAll(char_replace, char_replacewith);}

function gridstr_replace_allchars_EXCEPT(
	getStr, getChar_dont_replace, getChar_replaceWith){
		getStr =getStr.split(""); 
		var len = getStr.length; 
		for(var i =0; i< len; i+=1){
			if(getStr[i] != '\n' && 
				getStr[i] != getChar_dont_replace ){
					getStr[i] = getChar_replaceWith; }}
		return getStr.join("");
}

//API_TAG//
// BELOW IS NOT 100% ACCURATE, JUST CHECKS TOP LINE!!!
// (will be good for most grids)
function gridstr_width( str){
	ret = str.indexOf("\n");
	if(ret < 0){ if(str.length >0){ return str.length;}
		return 0;}
	return ret; }
function gridstr_height( str){
	return str.split("\n").length; }
//API_TAG//
function gridstr_charCountPriorToIndex( 
		getStr, getChar, getIndex, getQuardant_or_UNDEF){
	//quadrants: 1 up left, 2 up right, 3 lower left,4 lwr rght
	if(getIndex >= getStr.length ){ getIndex = getStr.length-1;}
	var count = 0; var code = getChar.charCodeAt(0);
	var halfWidth= Math.floor(gridstr_width(getStr)/2);
	var tmpOverHlfway = 0;
	var i_frm_nwLine =0; var newLine_code = "\n".charCodeAt(0);
	for( var i =0; i<= getIndex; i+=1){
	    if( getStr.charCodeAt(i) == newLine_code ){ i_frm_nwLine=0;
		   if((halfWidth+ i)*2 > getStr.length){tmpOverHlfway =1;}
		}else{ i_frm_nwLine += 1; }

	    if( getStr.charCodeAt(i) == code){ 
		if(getQuardant_or_UNDEF == void null){count += 1;continue;}

		if(getQuardant_or_UNDEF==1 || getQuardant_or_UNDEF==3 ){
			if(i_frm_nwLine > halfWidth){continue;} 
		}else{ if(i_frm_nwLine <= halfWidth){continue;} }
		if(getQuardant_or_UNDEF > 2 && tmpOverHlfway==0){continue;}
		if(getQuardant_or_UNDEF <= 2 && tmpOverHlfway==1){continue;}
		count += 1;  } } 
	return count;
} 


function gridstr_make(  x, y){
	tmp = Array.apply(null, Array(x)).map(x => 0).join("");
	tmp += "\n";
	return Array.apply(null, Array(y)).map(x => tmp).join("")
		.slice(0,-1); }
function gridstr_fill( string, 
		char_to_fill_with, ignore_chars_or_Empty_str){
	return string.split(RegExp("[^\n"+ignore_chars_or_Empty_str+"]"))
		.join(char_to_fill_with); 	}

//////////////////////////////////////////////
/////// THE 2D ARRAY-THING IS AN OPTIMIZATON FOR 
//////////// JAVASCRIPT, 
///////////// As such, many 'gridstr' functions are NOT
///////////// the same as the ones in c.
////////////////////

// used basically for canvas
function _gridstr__2darr_width( arr_2d ){
	width = arr_2d[0].length;
	for(i=0; i< arr_2d.length; i+=1){
		if(width != arr_2d[i].length){ return 0;}	}
	return width; }
function _gridstr__2darr_fill( arr_2d, fillchar){
	for(var i=0; i< arr_2d.length; i+=1){
		arr_2d[i] = arr_2d[i].map(x => fillchar); }	}
_gridstr__2d_auto_buffer = {};
_gridstr__2darr_auto_buffer_PREV = {};
_gridstr__2d_autobuffer_count = 0;  _GRIDSTR_2D_AUTOBUFFER_MAX = 4000;
// when auto_buffer reaches max, it sets buff to prev_buff, and resets buff.
function _gridstr__2darr_auto_buffer_get(str){ 
	out = _gridstr__2d_auto_buffer[str];
	if(out == undefined){  
		_gridstr__2d_autobuffer_count	+=1;
		if( _gridstr__2d_autobuffer_count > 
			      _GRIDSTR_2D_AUTOBUFFER_MAX){
			_gridstr__2d_autobuffer_count = 0;
			_gridstr__2darr_auto_buffer_PREV =
				_gridstr__2d_auto_buffer;
			_gridstr__2d_auto_buffer = {}; }

		out = _gridstr__2darr_auto_buffer_PREV[str];
		if(out == undefined){
			out = _gridstr__2darr_txt_to_2darr(str);
			_gridstr__2d_auto_buffer[str] = out;}
	}
	return out; }
function _gridstr__2darr_txt_to_2darr(txt){ // text to array
	txt2 = txt.split("\n"); 
	// splitting str into chars
	for( var i=txt2.length-1; i>= 0; i-=1){
		txt2[i] = txt2[i].split(""); };
	return txt2; }
function _gridstr__2darr_crop_at_0_n_max(arr, offset, max){ 
	//v2 and v3 are ints: v2 < v3
	len = arr.length;
	if(offset < 0){ if( offset + len> max ){ 
			return arr.slice( -offset, (max-(offset +len)) );
		}else{	return arr.slice( -offset,  len ); 	}
	}else{	if( offset + len> max ){ 
			return arr.slice( 0, (max-(offset +len)) );
		}else{	return arr.slice( 0,  len);	} }}
// gridstr...eventually
function _gridstr__2darr_overlay( 
	arr_to, arr_from, x, y, alpha_char){ 
	
	x = Math.round(x); y = Math.round(y);
	//cropping y to fit on screen!
	len = arr_to.length;
	arr_from = _gridstr__2darr_crop_at_0_n_max(
			arr_from, y, arr_to.length);	
		//	arr_from, y, G._disp_max_y);
	//cropping x to fit on screen!
	// I can probably catch the arr_to[i] length if 
	// it's a grid I'm dealing with. 
	for( var i=arr_from.length-1; i>= 0; i-=1){
		arr_from[i]= 
			_gridstr__2darr_crop_at_0_n_max(arr_from[i], x, 
				arr_to[i].length); }
	
	//display
	//arr_2d = G._main_disp2d;
	if( y<0){ y =0;} if(x<0){x=0;}
	if(alpha_char == ""){
		for(var i=0; i<arr_from.length; i+=1){
			for(var j=0; j< arr_from[i].length; j+=1){
				arr_to[i+y][j+x] = arr_from[i][j];	}}
	}else{ // for if using an alpha-char
		for(var i=0; i<arr_from.length; i+=1){
			for(var j=0; j< arr_from[i].length; j+=1){
				if(arr_from[i][j] != alpha_char){
				arr_to[i+y][j+x] = arr_from[i][j];}}}
}	}
// for sketch_grid_DRAW_UNDER_TRANSPCHAR(0,0, "xxx xxx"," "); 
function _gridstr__2darr_overlay_DRAW_UNDER_OVERLAYCHAR( 
	arr_to, arr_from, x, y, alpha_char){ 
	
	x = Math.round(x); y = Math.round(y);
	//cropping y to fit on screen!
	len = arr_to.length;
	arr_from = _gridstr__2darr_crop_at_0_n_max(
			arr_from, y, arr_to.length);	
		//	arr_from, y, G._disp_max_y);
	//cropping x to fit on screen!
	// I can probably catch the arr_to[i] length if 
	// it's a grid I'm dealing with. 
	for( var i=arr_from.length-1; i>= 0; i-=1){
		arr_from[i]= 
			_gridstr__2darr_crop_at_0_n_max(arr_from[i], x, 
				arr_to[i].length); }
	
	//display
	//arr_2d = G._main_disp2d;
	if( y<0){ y =0;} if(x<0){x=0;}
	if(alpha_char == ""){
		for(var i=0; i<arr_from.length; i+=1){
			for(var j=0; j< arr_from[i].length; j+=1){
				arr_to[i+y][j+x] = arr_from[i][j];	}}
	}else{ // for if using an alpha-char
		for(var i=0; i<arr_from.length; i+=1){
			for(var j=0; j< arr_from[i].length; j+=1){
				if(arr_to[i+y][j+x] == alpha_char){
				arr_to[i+y][j+x] = arr_from[i][j];}}}
}	}
function _gridstr__from_2darr( arr_2d ){
	return arr_2d.map(e => e.join('')).join('\n'); }

function gridstr_overlay(  //one size fits-all draw
	s_to,	s_from, 	 x, y, 
	overlayChar_or_null){

	// using actual 'too' buffer will mess up the buffer itself. 
	//txt_to_2dArr = _gridstr__2darr_auto_buffer_get(s_to);
	txt_to_2dArr = _gridstr__2darr_txt_to_2darr(s_to)
	txt_from_2dArr = _gridstr__2darr_auto_buffer_get(s_from); 

	_gridstr__2darr_overlay(
		txt_to_2dArr, txt_from_2dArr, x, y, overlayChar_or_null);
	// from https://stackoverflow.com/questions/2016143/trying-to-join-a-two-dimensional-array-in-javascript
	//draw( _gridstr__from_2darr(txt_to_2dArr), 0, 0);
	return _gridstr__from_2darr(txt_to_2dArr);
}

//API_TAG// 
// untested, should work. 
function gridstr_char_get(str_in, x, y, str_width_for_optimizing_OR_0){
	
	if( str_width_for_optimizing_OR_0 != 0){
		
		if( x< 0 || y<0 || x>(str_width_for_optimizing_OR_0-1)){ 
			return "";} 
		var return_char = str_in.charAt( x+
			y*(str_width_for_optimizing_OR_0+1));
		return return_char;}
	var return_var = gridstr_overlay(  //one size fits-all draw
		"\t",	str_in, 	 -x, -y, 
		null);
	if( return_var=="\t"){ return "";} // gristr shouldn't use tabs
	return return_var;
}

function gridstr_overlay_grid(  //one size fits-all draw
	s_to,	s_from, x, y,	overlayChar_or_null){
	return gridstr_overlay(s_to, s_from, x, y, overlayChar_or_null);
} 

function gridstr_reverse_text(getTxt, getLen){ // len if 4 c version
	return getTxt.split("").reverse().join("");	}

// only works for grids,
// can probably catch results 
function gridstr_transpose(getTxt, getLen){ //getLen for  c version
//API_TAG// 
	getTxt=getTxt.split("\n");
	var out_grid = [];
	// should be able to do this by just reading the characters
	// to the new grid. (linearly )
	out_grid = getTxt[0].split("");
	for(var i=1; i< getTxt.length; i+=1){
		for(var j=0; j< getTxt[i].length; j+=1){
			out_grid[j] += getTxt[i][j];
	}	}
	return out_grid.join("\n"); }


// this is without catch, use ACTUAL gridstr_rotate.js 
// 	( no underscore: gridstr_rotate())
function _gridstr_rotate( getTxt, getAngle, transp_char){
	//getTxt= gridstr_overlay( getTxt, getTxt, -1,-1);
	var arr2d = getTxt.split("\n");
	
		for(var i =0; i< arr2d.length; i+=1){
			arr2d[i] =arr2d[i].split("");}
	
	
	//reversing angle, as I'm scanning all points in the arr2d_out 
	//grid, verses drawing directly (some points are skipped that way)
	var tmpCos = .001*Math.round(1000 * Math.cos(-getAngle)); 
	var tmpSin = .001*Math.round(1000 * Math.sin(-getAngle)); 
	
	//file_input(arr2d[0].length + " ---- "+ arr2d.length);
	//var arr2d_out =gridstr_make(  
	//	arr2d[0].length-1, arr2d.length-1).split("\n");
	var arr2d_out =gridstr_fill( gridstr_make( 
		arr2d[0].length-1, arr2d.length-1), 
			transp_char, "").split("\n");
	//draw(getTxt, 0, 0,"" );
	for(var i =0; i< arr2d_out.length; i+=1){
		arr2d_out[i] =arr2d_out[i].split("");}
	
	var len_x = arr2d_out[0].length; var len_y = arr2d_out.length;
	//file_input(len_x + " " + len_y);
	//setting and dealing with rounding (think: de-antalyzing crap)
	if( len_x % 2.0 < 1.0){var x_off = (len_x)/2;
	}else{ var x_off = (len_x-1)/2;}
	if( len_y % 2.0 < 1.0){var y_off = (len_y)/2;
	}else{ var y_off = (len_y-1)/2;}
	 
	// itterating through CANVAS TO DRAW ON! RATHER THAN DRAW TOO!
	// This way, hopefully every pixel is taken, (antalizing?)
	//draw(x_off + " "+ y_off + " "+ len_x + " "+len_y, 0, 0,"" );
	
	for(var i =0; i< len_y; i+=1){
	  for(var j=0; j< len_x; j+=1){

		var x = j - x_off; var y = i-y_off; //offset

		var x_prime = x*tmpCos + y*tmpSin;
		var y_prime = -x*tmpSin + y*tmpCos;
		
		x_prime = Math.floor(x_prime+x_off ); 
		y_prime = Math.floor(y_prime+y_off );
		
		//file_log(x +' ' + y);
		if(x_prime>=0 && y_prime>=0){
			if( y_prime< len_y 
			  && x_prime< len_x){
				arr2d_out[i][j] = arr2d[y_prime][x_prime];
		}}
		//arr2d[i] =arr2d[i].split("");
	 }}
	// end fucking rot code
	for(var i =0; i< arr2d_out.length; i+=1){
		arr2d_out[i] = arr2d_out[i].join("");}
	arr2d_out = arr2d_out.join("\n");
	//draw(arr2d_out, 0, 0,"" );
	
	// if I need to anti-atalyze, this is the time...
	// maybe shrink and overlay?(with offset, of course)
	
	return arr2d_out;
}

//API_TAG// 
// returns [x,y] OR null for no result
function gridstr_indexOf_char_getXY( getGridstr, getChar){
//API_TAG// 
	var tmpIndex = getGridstr.indexOf(getChar );
	if(tmpIndex == -1 ){ return null;}
	var tmpLines = getGridstr.substr(0,tmpIndex + 1).split('\n');
	return [ tmpLines[tmpLines.length-1].length-1, tmpLines.length-1];
}

