cd ../COMPILE_THIS_FILE
one_with_dlls.c.VIM_C_S.bat
