
////////////////////////////////////////////////
////////////////////////////////////////////////
////  _sketch_3d_CORE_draw_cols_n_sprites (NEED C VERSION)
////////////////////////////////////////////////
////////////////////////////////////////////////

// draw collumns for js:

// inspired ( eg: rewritten using slightly different algorithm)
// from following code:
// https://www.playfuljs.com/a-first-person-engine-in-265-lines/
	// looks like there is some good maths from:
	// http://nicmendoza.github.io/playfuljs-demos/raycaster/
	//	basically, the source I was inspired by, + sprites


function _sketch_3d_sprites_at_tile(
		got_PREV_X, got_PREV_Y,
		caught_x, caught_y, screen_x, //caught_x & y are tile xy
		gotAngleNO_PLAYER_OFFSET, // for x tile
		gotAngle_camera, // 
		gotCam_x, gotCam_y, // for calc dist
		cam_height, cam_tilt, inSketch_height, inSketch_width,
		gotColgroup,
		gotFocalLength,
		dist_max,
		isShadow,
		fade_start_precent_Default_pnt60){

	//OK, this is for SMALL objects
	var  tmpLen = rmloaded_lookupxy_getobjs_len( 
				caught_x, caught_y );//gotColgroup);
	for(var i=0; i< tmpLen; i+=1){		
		var o = rmloaded_lookupxy_getobjs_at(caught_x, caught_y, i);
		if(o == void null){ continue;} 
			//above is to prevent a nasty error
		if( o.hasOwnProperty("colgroup") == -1){ continue;}
		if( o.colgroup.indexOf(gotColgroup) == -1){ continue;}
		sketch_3d__convertobj(o);
		//maths got mostly from 
		// http://nicmendoza.github.io/playfuljs-demos/raycaster/
		var tmp_width = o.d3width;// * gotFocalLength;
		var tmp_height = o.d3height;
		

		
		// ANOTHER tutorial...?
		//https://dev.opera.com/articles/3d-games-with-canvas-and-raycasting-part-2

		// Minus .5 because that is what I used for the 
		// Other one 
		
		// OLD
		//var dist_x = o.x 
		//	-0.5 - (gotCam_x); //- 0.5);
		//var dist_y = o.y 
		//	-0.5 - (gotCam_y); //- 0.5);
		
		//below doesn't use o.x/y directly so same code should 
		//work for objs_large
		var dist_x = caught_x
			+(o.x-Math.floor(o.x)) // tile fractional offset
			-0.5 - (gotCam_x); //- 0.5);
		var dist_y = caught_y 
			+(o.y-Math.floor(o.y)) // tile fractional offset
			-0.5 - (gotCam_y); //- 0.5);
		var dist_total = Math.sqrt(dist_x*dist_x + dist_y*dist_y);
		
		


		//var height = (tmp_height * inSketch_height)/ dist_total;
		//var height = (tmp_height * (inSketch_height/2))/ z;
		

		var z =  dist_total * Math.cos(gotAngleNO_PLAYER_OFFSET);

		//OK, I think the ratio is off, because everything 
		//else seems to work... just mangified screen location 
		// ALSO: I need make sure the camera angle is >0 !
		//  (or the additional rotation messes it up
		//  ...
		//  IT SHOULD'T WORK, BUT IT DOES!!!!
		//var screen_ratio = ((inSketch_width)/1.5)/ gotFocalLength;
		var screen_ratio = (inSketch_width)* gotFocalLength;
			
		var width = (tmp_width* screen_ratio)/ dist_total;
			//(tmp_width* inSketch_width)/ dist_total;

		var o_angle = Math.atan2(dist_y,dist_x);
			// these are reversed....?
		var o_angle_with_camera =  (gotAngle_camera)- o_angle;
		o_angle_with_camera = o_angle_with_camera % (Math.PI*2);
		if(o_angle_with_camera >= Math.PI){
				o_angle_with_camera -= Math.PI * 2;    }
		if(o_angle_with_camera <= -Math.PI){
				o_angle_with_camera += Math.PI * 2;    }
		

		var camera_x_offset =  ((inSketch_width-1) / 2 ) 
			-(width/2)
			-(screen_ratio * o_angle_with_camera);
		
	
		var x_to_draw_at= camera_x_offset ;
		
		var y_to_draw_at = Math.ceil(
		   _sketch_3d_get_scrn_y(
			inSketch_height, o.z-tmp_height, 
			z, cam_tilt, cam_height));
		var y_to_draw_at_END = 
		   _sketch_3d_get_scrn_y(
			inSketch_height, o.z, 
			z, cam_tilt, cam_height);
		var height =Math.abs(y_to_draw_at_END - y_to_draw_at);
		//file_input(height);
			// in the  code this is located in, 
			//  cam_height is *100 because the other 
			// draw functions use that. 
		
		//BELOW 3 IFs ARE OPTIMIZING,
		//	THEY WORK, but I want to draw full 
		//	sprites, so scaling them down like this 
		//	seems like a bad idea... If I want to 
		//	cut them down, (gridstr operations) first, 
		//	it would work
		if(height + y_to_draw_at < 0||
		    y_to_draw_at > inSketch_height){ continue;}
		//if(y_to_draw_at < 0){
		//	height += y_to_draw_at;
		//	y_to_draw_at = 0; }
		//if(height + y_to_draw_at > inSketch_height){
		//	height = inSketch_height-y_to_draw_at;}
		if(isShadow){ var tmp_graphic = " ";
		}else{ var tmp_graphic = o.d3graphic;}
		if(o.d3simplescale == true){
		  sketch_grid_DRAW_UNDER_TRANSPCHAR( 
			gridstr_scale(
				_sketch_3d__fade_out_txt( tmp_graphic, 
					dist_total, dist_max,
					fade_start_precent_Default_pnt60),
				width, height), 
			x_to_draw_at, y_to_draw_at,
			_sketch_3d_BLANK_TO_DRAW_CHAR); // transparent char
		}else{
		   sketch_grid_DRAW_UNDER_TRANSPCHAR( 
			gridstr_scale_nearest_neighbor(
				_sketch_3d__fade_out_txt( tmp_graphic, 
					dist_total, dist_max,
					fade_start_precent_Default_pnt60),
				width, height), 
			x_to_draw_at, y_to_draw_at,
			_sketch_3d_BLANK_TO_DRAW_CHAR); // transparent char
		}
	}
	
	
	var tmpLen=_sketch_3d_lrgobj_diagnol_dist_1turn_catch.length;
	//OK, this is for LARGE objects
	if( _sketch_3d__lrgobj_sprites_1turn_catch == false){ 
	   _sketch_3d__lrgobj_sprites_1turn_catch = true; 
	   for(var i=0; i< tmpLen; i+=1){		
		if(_sketch_3d_lrgobj_diagnol_dist_1turn_catch[i]
		   .d3loaded !=
			_sketch_3d_lrgobj_diagnol_dist_1turn_catch[i]
			.graphic){
		     sketch_3d__convertobj_lrg(
			_sketch_3d_lrgobj_diagnol_dist_1turn_catch[i]);
		}	}}

	//file_input(tmpLen);
	for(var i=0; i< tmpLen; i+=1){		
		var o = _sketch_3d_lrgobj_diagnol_dist_1turn_catch[i];
		if(o == void null){ continue;} 
		//Above to avoid nasty error
		var tmp_x_ongrid = Math.ceil(caught_x- o.x);
		var tmp_y_ongrid = Math.ceil(caught_y- o.y);

		var tmp_graphic = gridstr_char_get(o.graphic, 
			tmp_x_ongrid, tmp_y_ongrid, 0);
			//basically, just pulling char. 

		if( tmp_graphic == ""){ continue;}
		//maths got mostly from 
		// http://nicmendoza.github.io/playfuljs-demos/raycaster/
		var tmp_width = 1;gotFocalLength;
		var tmp_draw_depth =
			o.d3floors[tmp_y_ongrid][ tmp_x_ongrid];
		var tmp_draw_ceil =  
			o.d3ceils[tmp_y_ongrid][ tmp_x_ongrid];
		//	tmp_draw_depth
		//	-o.d3ceils[tmp_y_ongrid][tmp_x_ongrid];
		//tmp_draw_depth = tmp_draw_depth- tmp_height;
		//var tmp_draw_depth = o.d3ceils[tmp_y_ongrid][tmp_x_ongrid];
		//var tmp_height =  
		//	o.d3floors[tmp_y_ongrid][ tmp_x_ongrid]
		//	-tmp_draw_depth;	
		//below doesn't use o.x/y directly so same code should 
		//work for objs_large
		var dist_x = caught_x
			+(o.x-Math.floor(o.x)) // tile fractional offset
			-0.5 - (gotCam_x); //- 0.5);
		var dist_y = caught_y 
			+(o.y-Math.floor(o.y)) // tile fractional offset
			-0.5 - (gotCam_y); //- 0.5);
		var dist_total = Math.sqrt(dist_x*dist_x + dist_y*dist_y);
				
		var z =  dist_total * Math.cos(gotAngleNO_PLAYER_OFFSET);
		
		var screen_ratio = (inSketch_width)* gotFocalLength;
			
		var width = (tmp_width* screen_ratio)/ dist_total;
			//(tmp_width* inSketch_width)/ dist_total;

		var o_angle = Math.atan2(dist_y,dist_x);
			// these are reversed....?
		var o_angle_with_camera =  (gotAngle_camera)- o_angle;
		o_angle_with_camera = o_angle_with_camera % (Math.PI*2);
		if(o_angle_with_camera >= Math.PI){
				o_angle_with_camera -= Math.PI * 2;    }
		if(o_angle_with_camera <= -Math.PI){
				o_angle_with_camera += Math.PI * 2;    }
		

		var camera_x_offset =  ((inSketch_width-1) / 2 ) 
			-(width/2)
			-(screen_ratio * o_angle_with_camera);
		
		var x_to_draw_at= camera_x_offset ;
		var y_to_draw_at = Math.ceil(
		   _sketch_3d_get_scrn_y(
			inSketch_height, o.z+tmp_draw_ceil, 
			z, cam_tilt, cam_height));
		var y_to_draw_at_END = _sketch_3d_get_scrn_y(
			inSketch_height, o.z+ tmp_draw_depth, 
			z, cam_tilt, cam_height);

		var height =  Math.abs(y_to_draw_at_END - y_to_draw_at);
		//file_input(y_to_draw_at);
			// in the  code this is located in, 
			//  cam_height is *100 because the other 
			// draw functions use that.
		
		//next ifs are optimizing
		if(height + y_to_draw_at < 0||
		   y_to_draw_at > inSketch_height){ continue;}
		if(y_to_draw_at < 0){
			height += y_to_draw_at;
			y_to_draw_at = 0; }
		if(height + y_to_draw_at > inSketch_height){
			height = inSketch_height-y_to_draw_at;}
		
		if(isShadow){ var tmp_graphic = " ";}
		sketch_grid_DRAW_UNDER_TRANSPCHAR( 
			gridstr_scale(
				_sketch_3d__fade_out_txt( tmp_graphic, 
					dist_total, dist_max,
					fade_start_precent_Default_pnt60),
				 width, height), 
			x_to_draw_at, y_to_draw_at,
			_sketch_3d_BLANK_TO_DRAW_CHAR); // transparent char
	}	
	
}

//list of possible list
function _sketch_3d_lrgobj_diagnol_dist_1turn_catch__SETTUP(
		x, y, getCol_Prop, maxDist ){
	//file_input(x + " " + y + " "+getCol_Prop+" "+ maxDist);
	_sketch_3d_lrgobj_diagnol_dist_1turn_catch = [];
	var tmp_len = rmloaded_lookupprop_getlrgobjs_len( getCol_Prop );
	for(var i =0; i< tmp_len; i+=1){
		var tmp_o =rmloaded_lookupprop_getlrgobjs_i( getCol_Prop, i );
		var tmp_dist = 
			_sketch_3d_lrgobj_diagnol__dist_to_point(
				tmp_o, x, y );
		if(tmp_dist <=maxDist ){ // close
			_sketch_3d_lrgobj_diagnol_dist_1turn_catch 	
				.push( tmp_o);	}	
}	}



function _sketch_3d_get_scrn_y( inSketch_height,
	point_z, z,//z= distance_with_anti_fisheye_z,
	getCam_tilt, getCam_height){

	return (inSketch_height / 2)	//center of screen
		+ (( point_z)/z)//height offset
		+ getCam_tilt	//tilt
		+(((getCam_height)/2)/z); }
//NOTE: RETURNS DIST SMALLER THAN ACTUAL DISTANCE!!! 
//	SO ONLY USE THIS FOR OPTIMIZATIONS (AS A FIRST TEST!!!
// <=0  means MIGHT intersect!
function _sketch_3d_lrgobj_diagnol__dist_to_point(
		o, x, y){// o = object
	var width = o.graphic.indexOf("\n"); // getting width... 
						// not perfect
	if( width == -1){ width = o.graphic.length;}
	var height = (o.graphic.length - 1)/width;
	var o_center_x = o.x - (width/2);
	var o_center_y = o.y - (height/2);

	return 	Math.sqrt(
		   Math.pow(x - o_center_x,2)+Math.pow(y - o_center_y,2)),
		- (width/2) - (height/2)
		-2;//the 2 is a bit extra, just in cast
}
	

//var _SKETCH_3DSTEP_MAX_TOP_DRAWN = 24; //should set to canvas_height
//var _SKETCH_3DSTEP_MAX_BOTTOM_DRAWN = 0;

var _sketch_3d_rayvars__MAX_VARS = 120;
var _sketch_3d_rayvars__angle = 
	new Float32Array(_sketch_3d_rayvars__MAX_VARS);
var _sketch_3d_rayvars__angle_NO_PLAYER_OFFSET = 
		new Float32Array(_sketch_3d_rayvars__MAX_VARS);
var _sketch_3d_rayvars__x = 
	new Float32Array(_sketch_3d_rayvars__MAX_VARS); 
var _sketch_3d_rayvars__x_rndNdir = 
	new Float32Array(_sketch_3d_rayvars__MAX_VARS); 
var _sketch_3d_rayvars__y = new Float32Array(_sketch_3d_rayvars__MAX_VARS);
var _sketch_3d_rayvars__y_rndNdir = 
	new Float32Array(_sketch_3d_rayvars__MAX_VARS);
var _sketch_3d_rayvars__x_run = 
	new Float32Array(_sketch_3d_rayvars__MAX_VARS);
var _sketch_3d_rayvars__y_rise = 
	new Float32Array(_sketch_3d_rayvars__MAX_VARS);
var _sketch_3d_rayvars__top_drawn = 
	new Float32Array(_sketch_3d_rayvars__MAX_VARS);
var _sketch_3d_rayvars__bottom_drawn=
	new Float32Array(_sketch_3d_rayvars__MAX_VARS);
var _sketch_3d_rayvars__dist =
	new Float32Array(_sketch_3d_rayvars__MAX_VARS);
var _sketch_3d_rayvars__prev_dist =
	new Float32Array(_sketch_3d_rayvars__MAX_VARS);
var _sketch_3d_rayvars__PREV_X_X_PRECENT =//for drawing textures/borders
	new Float32Array(_sketch_3d_rayvars__MAX_VARS);

var _sketch_3d_rayvars__prev_shadow = // boolean
	new Int8Array(_sketch_3d_rayvars__MAX_VARS);

//var _sketch_3d_MAX_WALLBRDR_DIST = 6;

	// is used in devide by, so = 0 gives Infinity...



//'s-' vars a single-ray paramiters. They are handled as 
// indexed lists. (so s_x[i] is the same ray as s_y[i]
function _sketch_3d_ray_step_1_tile( i, s_x, s_y, 
	s_x_rndNdir, s_y_rndNdir, 
	     s_dist, s_prev_dist, s_x_run, s_y_rise,
		s_prev_x_precent_4border ){ //s is _sketch_3dstep_vars
	s_prev_dist[i] = s_dist[i];
	
	// I think this can be used for drawing textures for walls.
	// The idea is, for a  collision with a 2d grid, the 
	// x or y will be a round number, the other will have a remainder
	// The remainder ,as it's a 1x grid, will be %!
	s_prev_x_precent_4border[i] = s_y[i] -Math.floor(s_y[i])  +
		s_x[i] - Math.floor(s_x[i]);
	//file_input(s_prev_x_precent_4border[i]);

	if(s_x_run[i] > 0){ var dx = Math.floor(s_x[i]+1) -s_x[i]; 
	}else{ var dx = Math.ceil(s_x[i]-1) -s_x[i]; }
	
	if(s_y_rise[i] >0){ var dy = Math.floor(s_y[i]+1) - s_y[i];
	}else{ var dy = Math.ceil(s_y[i]-1) - s_y[i];  }
	
	// dy = dx*rise/run;  y = y+(dx*rise/run); x = x+(dy/(rise/run))
	var dist_y_if_using_dx =  dx*(s_y_rise[i]/s_x_run[i]);
	var dist_x_if_using_dy =  dy/(s_y_rise[i]/s_x_run[i]);
	
	var len_using_dx = Math.sqrt(
		(dx*dx)+(dist_y_if_using_dx*dist_y_if_using_dx));
	var len_using_dy = Math.sqrt(
		(dy*dy)+(dist_x_if_using_dy*dist_x_if_using_dy));

	// getting the SMALLER one!
	if( len_using_dx < len_using_dy){
		s_dist[i] +=  len_using_dx;
		s_x[i] += dx;
		s_y[i] += dist_y_if_using_dx;
		
	}else{
		s_dist[i] +=  len_using_dy;
		s_y[i] += dy;
		s_x[i] += dist_x_if_using_dy;
	}
	//getting a rounded version of x and y
	if(s_x_run[i] > 0){ s_x_rndNdir[i] = Math.ceil(s_x[i]); 
	}else{ s_x_rndNdir[i] = Math.floor(s_x[i]+1); }
	
	if(s_y_rise[i] >0){ s_y_rndNdir[i] = Math.ceil(s_y[i]); 
	}else{  s_y_rndNdir[i] = Math.floor(s_y[i]+1); }
}

//NOTE: skybox was hacked together, and will NOT scale with 
//	screen size! (so scale the skybox image FIRST!) 
//
//OK< the 'sketch' bits should probably be embeded directly in 
//	the 'sketch' code!!! (most of it). 
// AAAAAND: for getting object data, should be: 
// 	getMapAt(x,y, colgroup){
// 		Test if map is 3d enabled 
// 		if not, make it so!
// 		--- catch height/depth/tilegfx!
// 			this way, only need one getMapAt}
//--- need to set x/y size for canvas. (may have alreay done this) 
//	for input. Then, for drawing, have a automatic 
//	'draw this' state, or be able to pull and use custom!
//	(same thing with drawing 2d objs. )
//---- MIGHT be able to get away with JUST doing 
//	the 3dstep bit in a seperate c function! 

// base-name: sketch_3d
// Below toggles on 1x per sketch_3d o
var _sketch_3d__lrgobj_sprites_1turn_catch = false; 

var _SKETCH_3D_MAP_NO_TILE_HEIGHT = -200;
var _SKETCH_3D_MAP_NO_TILE_DEPTH = 70;
var _SKETCH_3D_MAP_NO_TILE_FLOOR_TEXTURE = "-\n+\n+";
var _SKETCH_3D_MAP_NO_TILE_CIEL_TEXTURE = "+\n+\n-";

var _sketch_3d__caught_tile_ceilheight = 0;// define on runtime
var _sketch_3d__caught_tile_floordepth = 0; // define on runtime
var _sketch_3d__caught_tile_texture_floor= "";// define on runtime
var _sketch_3d__caught_tile_texture_ceil = ""; // define on runtime
//NOT WORKING!!!! (untested, not in use, really)
//Below is to streamline tile-reading!
function _skech_3d__catchMapTile_N_covert_tile( x, y, get_tag){
	//file_input(x +" " + y + " " + get_tag);
	var o = rmloaded_col_GET_OBJ(x, y, get_tag);

	if(o == void null){	
		_sketch_3d__caught_tile_ceilheight = 
			_SKETCH_3D_MAP_NO_TILE_HEIGHT;
		_sketch_3d__caught_tile_floordepth = 
			_SKETCH_3D_MAP_NO_TILE_DEPTH;
		_sketch_3d__caught_tile_texture_floor= 
			_SKETCH_3D_MAP_NO_TILE_FLOOR_TEXTURE;
		_sketch_3d__caught_tile_texture_ceil = 
			_SKETCH_3D_MAP_NO_TILE_CIEL_TEXTURE;
	}else{
		if(o.d3loaded != o.graphic){
			//runs on demand, MAY BE NULL!!!
					// all: d3loaded z
					//  LARGE MAPS:
					// d3ceils d3floors d3texturemaps 
					// 	//texuremaps can be null!
					// SPRITE VARS:
					// d3graphic d3height d3width 
					// LARGE_SPRITE VARS:
					// d3ceils d3floors d3texturemaps
					// 	--NOTE: CURRENTLY UNUSED
					// 	AND I THINK CEILS AND 
					//	DEPTHS WOULD WORK BETTER:
					//	AS THESE CAN HAVE TOP/
					// 	bottom unlike LARGE_MAPS!
			sketch_3d__convertobj_lrg(o);
		}

		var tmpz=  o.z;
		//from rmloaded_batch_n_collisions.js
		var tmpChar = gridstr_overlay(  
				" ",	o.graphic, 
				-(x-o.x), -(y-o.y),
				false, 	true, null);
		_sketch_3d__caught_tile_texture_floor="-\n"+tmpChar+"\n"+tmpChar;
		_sketch_3d__caught_tile_texture_ceil = tmpChar+"\n"+tmpChar+"\n-";
		
		_sketch_3d__caught_tile_floordepth = 
			o.z + o.d3floors[ (y-o.y)][(x-o.x)];
		_sketch_3d__caught_tile_ceilheight = 
			o.z + o.d3ceils[ (y-o.y)][(x-o.x)];
	}
}



/*
function getMapFloor_Height( caught_x, caught_y, get_obj){
	// NOTE ON FUTURE EDITS:
	// I'm going to be using heightmaps, so I need to 
	// get obj.data, 
	// so...
	// 	Why not also throw in a 'z' value? 
	// 	this would allow large objects to be used,
	// 	as it could 'walk' up or down things. 
	// 	( merge) 
	var tmpChar = rmloaded_col_test_SIMPLE(caught_x, caught_y, get_tag);
	if(tmpChar  == "#"){return -100;} //2;}
	if(tmpChar  == "" ){ return 70;} // -1000;} arbitrary, should modify
	return 3;//3;
}
function getMapRoof_Depth(caught_x, caught_y,get_tag){
	// NOTE ON FUTURE EDITS:
	// I'm going to be using heightmaps, so I need to 
	// get obj.data, 
	// so...
	// 	Why not also throw in a 'z' value? 
	// 	this would allow large objects to be used,
	// 	as it could 'walk' up or down things. 
	// 	( merge) 
	var tmpChar = rmloaded_col_test_SIMPLE(caught_x, caught_y, get_tag);
	if( tmpChar == "#"){return -150;}
	if( tmpChar == "" ){ return -200;} // 1000:} arbitrary, should modify
	return -100;
}
function getMapTexture_floor(caught_x, caught_y,get_tag){ 
	var tmpChar = rmloaded_col_test_SIMPLE(caught_x, caught_y, get_tag);
	if(tmpChar == ""){ tmpChar = "-\n+\n+"; }
	return "-\n"+tmpChar+"\n"+tmpChar;
}
function getMapTexture_ceil(caught_x, caught_y,get_tag){ 
	var tmpChar = rmloaded_col_test_SIMPLE(caught_x, caught_y, get_tag);
	if(tmpChar == ""){ tmpChar = "+\n+\n-"; }
	return tmpChar+"\n"+tmpChar+"\n-";
}
*/
// OK, if I translate this to c, that MIGHT do it, as this is 
// some, odd, 90-99% of the code work. 
function _sketch_3d_CORE_draw_cols_n_sprites( 
		origin_x_NEED_OFFSET, origin_y_NEEDS_OFFSET, 
		getAngle,cam_height,cam_tilt,
		get_col_tag_for_walls, get_col_tag_for_sprites,
		inSketch_width, inSketch_height, 
		dist_max,
		shadowgrid_or_null, shadowgrid_shadow_char, 
		shadowgrid_x, shadowgrid_y,
		MAX_WALLBRDER_DIST_default_6,
		fieldOfView_Default_pnt8,
		fade_start_precent_Default_pnt60){ 
	

	var origin_x = -1+ origin_x_NEED_OFFSET; 
		// offset PROBABLY isnt accurate
	var origin_y = -1+ origin_y_NEEDS_OFFSET;
		// offset PROBABLY isnt accurate
	
	// think of this as having a list of structs named 's'
	var s_angle = _sketch_3d_rayvars__angle;
	var s_angle_NO_PLAYER_OFFSET = 
		_sketch_3d_rayvars__angle_NO_PLAYER_OFFSET;
 	var s_x = _sketch_3d_rayvars__x;
	var s_x_rndNdir = _sketch_3d_rayvars__x_rndNdir;
	var s_y = _sketch_3d_rayvars__y;
	var s_y_rndNdir = _sketch_3d_rayvars__y_rndNdir;
	var s_x_run = _sketch_3d_rayvars__x_run;
	var s_y_rise = _sketch_3d_rayvars__y_rise;
	var s_top_drawn = _sketch_3d_rayvars__top_drawn;
	var s_bottom_drawn = _sketch_3d_rayvars__bottom_drawn;
	var s_dist = _sketch_3d_rayvars__dist;
	var s_prev_dist = _sketch_3d_rayvars__prev_dist;
	var s_prev_x_precent_4border =_sketch_3d_rayvars__PREV_X_X_PRECENT;
	
	var s_prev_shadow = _sketch_3d_rayvars__prev_shadow;
	var HACK_MOD_fadedist_1turn_if_shadow_ends = 0;

	//importing inSketch_width/height
	//var inSketch_width = draw_canvas_get_width();
	//var inSketch_height = draw_canvas_get_height()
	// initializing the lists/resetting vars (top 'while' runs 1x):
	for(var i=0; i< inSketch_width; i+=1){
		var x = i / inSketch_width - 0.5;
         	var angle_without_player_offset = 
			Math.atan2(x, fieldOfView_Default_pnt8);
		
		s_angle_NO_PLAYER_OFFSET[i] = angle_without_player_offset;
		s_angle[i] = angle_without_player_offset +getAngle;
		s_x_run[i] = Math.cos(s_angle[i]); 
		s_y_rise[i] = Math.sin(s_angle[i]);
		
		s_prev_x_precent_4border[i] = 2; // high-balling it
		s_x_rndNdir[i] = origin_x-100; // -100 is placeholder
		s_y_rndNdir[i] = origin_y-100; // -100 is placeholder
		// s.x & s.y & s.dist set in .._step_1_tile below
		s_x[i] = origin_x; s_y[i] = origin_y;

		s_dist[i] = _sketch_3d_DIST_START;
		s_prev_dist[i] = s_dist[i];

		s_top_drawn[i] = inSketch_height;
		s_bottom_drawn[i] = 0;
	
		s_prev_shadow[i] = 0

		s_bottom_drawn[i] = 0;
		s_top_drawn[i] = inSketch_height;}//inSketch_height;}
	//can probably remove s.dist and s.maxdist from struct...
	var cur_dist = _sketch_3d_DIST_START; 
	

	var caught_x = Math.floor(origin_x); 
	var caught_y = Math.floor(origin_y);
	var caught_prev_x = caught_x;
	var caught_prev_y = caught_y;

	
	//load below global vars
	_skech_3d__catchMapTile_N_covert_tile( 
		caught_x, caught_y, get_col_tag_for_walls);
	var roof_depth_tile = _sketch_3d__caught_tile_ceilheight;
	var floor_depth_tile =_sketch_3d__caught_tile_floordepth;
	var texture_char_tile_floor = _sketch_3d__caught_tile_texture_floor;
	var texture_char_tile_ceil = _sketch_3d__caught_tile_texture_ceil;
	
	if(shadowgrid_or_null != void null){
		var shadowgrid_width = gridstr_width(shadowgrid_or_null);}
	var caught_istile_shadow = false;
	/* using a singleton above
	var floor_depth_tile =  getMapFloor_Height( 
		caught_x, caught_y, get_col_tag_for_walls);
	var roof_depth_tile =  getMapRoof_Depth( 
			caught_x, caught_y, get_col_tag_for_walls);
	var texture_char_tile_floor = getMapTexture_floor( 
			caught_x, caught_y, get_col_tag_for_walls);
	var texture_char_tile_ceil =getMapTexture_ceil(
			caught_x, caught_y, get_col_tag_for_walls);
	*/
		
	while(cur_dist< dist_max){
	   for(var i = 0; i < inSketch_width; i += 1){ 
	   	_sketch_3d_ray_step_1_tile( i, s_x, s_y, 
			s_x_rndNdir, s_y_rndNdir,  
			s_dist, s_prev_dist,  s_x_run, s_y_rise,
			s_prev_x_precent_4border);
	   }
	   for(var screen_x = 0; screen_x < inSketch_width;  screen_x += 1){ 
	
	     if(s_bottom_drawn[screen_x] >= s_top_drawn[screen_x]){ 
		   continue; }	
	    if(s_x_rndNdir[screen_x] != caught_x 
		   || s_y_rndNdir[screen_x] != caught_y){
		
		caught_prev_x = caught_x;
		caught_prev_y = caught_y;

		// gotta handle shadowwork here
		//shadowgrid_or_null, shadowgrid_shadow_char, 
		//shadowgrid_x, shadowgrid_y, shadowgrid_width,
		    //caught_istile_shadow
		 //file_input(gridstr_char_get("",-1,-1,0) == "");

		var caught_x =  s_x_rndNdir[screen_x]; 
		var caught_y = s_y_rndNdir[screen_x];   
		if( shadowgrid_or_null != void null){
			if(gridstr_char_get(shadowgrid_or_null,
				Math.ceil(shadowgrid_x +caught_x), 
				Math.ceil(shadowgrid_y +caught_y), 
				shadowgrid_width) 
				 == shadowgrid_shadow_char){
			//file_input(shadowgrid_or_null);

			caught_istile_shadow = true;
			}else{ caught_istile_shadow = false;}
		}else{caught_istile_shadow = false;}
		//added
		if(caught_istile_shadow == true &&
			s_prev_shadow[screen_x] == false){
				HACK_MOD_fadedist_1turn_if_shadow_ends=1;
		}else{HACK_MOD_fadedist_1turn_if_shadow_ends =0;}
		s_prev_shadow[screen_x] = caught_istile_shadow;

		//load below global vars
		_skech_3d__catchMapTile_N_covert_tile( 
			caught_x, caught_y, get_col_tag_for_walls);
		var roof_depth_tile = _sketch_3d__caught_tile_ceilheight;
		var floor_depth_tile =_sketch_3d__caught_tile_floordepth;
		var texture_char_tile_floor= 
			    _sketch_3d__caught_tile_texture_floor;
			//_sketch_3d__fade_out_txt( _sketch_3d__caught_tile_texture_floor,
			 //  s_prev_dist[screen_x] *
			 //   Math.cos(s_angle_NO_PLAYER_OFFSET[screen_x]),
			//	dist_max);
		var texture_char_tile_ceil = _sketch_3d__caught_tile_texture_ceil;
			// _sketch_3d__fade_out_txt( _sketch_3d__caught_tile_texture_ceil,
			  //  s_prev_dist[screen_x] *
			  //  Math.cos(s_angle_NO_PLAYER_OFFSET[screen_x]),
				//   dist_max);
	
		_sketch_3d_sprites_at_tile(
			caught_prev_x,caught_prev_y,
			caught_x, caught_y, screen_x,
			s_angle_NO_PLAYER_OFFSET[screen_x],
			getAngle, //s_angle[i],
			origin_x, origin_y,
			cam_height, cam_tilt, 
			inSketch_height, inSketch_width,
			get_col_tag_for_sprites, 
			fieldOfView_Default_pnt8,
			dist_max,
			caught_istile_shadow 
				-HACK_MOD_fadedist_1turn_if_shadow_ends,
			fade_start_precent_Default_pnt60
				-HACK_MOD_fadedist_1turn_if_shadow_ends);
	   }
	    
	     for(var i=0; i<2; i+=1){	
		if(i==0){
			 var z =s_prev_dist[screen_x] *
			     Math.cos(s_angle_NO_PLAYER_OFFSET[screen_x]);
			var draw_bottom_start = -10000;
			var draw_top_start = 10000;}
		if(i==1){ 
			var draw_bottom_start = s_bottom_drawn[screen_x];
			var draw_top_start = s_top_drawn[screen_x];
			var z =  s_dist[screen_x] * 
			    Math.cos(s_angle_NO_PLAYER_OFFSET[screen_x]);}
		/////////////////////////////////////////////////
		///drawing cols/faces/////////////////////////////////////
		//////////////////////////////////////////////////////////
		 var floor_depth = _sketch_3d_get_scrn_y(
			inSketch_height, floor_depth_tile, 
			z, cam_tilt, cam_height);
			//100 is just a multiplyer so cam moves faster
		
		var roof_depth =_sketch_3d_get_scrn_y(
			inSketch_height, roof_depth_tile, 
			z, cam_tilt, cam_height);
		
		_sketch_3d__draw_col_between(
			i, s_prev_dist[screen_x], s_angle[screen_x], 
				// drawing tiles
			caught_istile_shadow //light-on!
				-HACK_MOD_fadedist_1turn_if_shadow_ends, 
			s_prev_x_precent_4border[screen_x],
			s_top_drawn[screen_x],  s_bottom_drawn[screen_x],
				// hight/bottom limit
			draw_top_start, floor_depth, // height/bottom 
			//above and the next block with this have issues
			texture_char_tile_ceil, screen_x,
			dist_max,
			MAX_WALLBRDER_DIST_default_6,
			fieldOfView_Default_pnt8,
			fade_start_precent_Default_pnt60
				-HACK_MOD_fadedist_1turn_if_shadow_ends);
		 //////////////////
		     ////////THINK I WILL ADD SPRITES ON TILE HERE!!!
		     ///////////
		
		  //DRAWING 'roof'
		 _sketch_3d__draw_col_between(
			i, s_prev_dist[screen_x], s_angle[screen_x], //drawing tiles
			caught_istile_shadow //light-on!
			    -HACK_MOD_fadedist_1turn_if_shadow_ends,
			 s_prev_x_precent_4border[screen_x], 
			 //% offset of x, 4 tile border
			// (the idea is x or y is a flat integer,
			// 	the other will be the ONLY offset)
			 s_top_drawn[screen_x],  s_bottom_drawn[screen_x],// hight/bottom limit
			 roof_depth, draw_bottom_start,
			 texture_char_tile_floor, screen_x,
		 	dist_max,
			MAX_WALLBRDER_DIST_default_6,
			fieldOfView_Default_pnt8,
			fade_start_precent_Default_pnt60
		 		-HACK_MOD_fadedist_1turn_if_shadow_ends);

		if(roof_depth >s_bottom_drawn[screen_x]){
			s_bottom_drawn[screen_x] = roof_depth;}
		if(floor_depth <s_top_drawn[screen_x]){
			s_top_drawn[screen_x] = floor_depth;}
	     }
	  }
	   cur_dist +=1;
	}
}
/*
var fade_txt_PUNCTUATION_regex = new RegExp('[^\s\w]','g');
var fade_txt_PUNCTUATION_LARGE_regex = new RegExp('[#$%&?@<>]','g');
var fade_txt_PUNCTUATION_SMALL_regex = new RegExp('[^\s\w#$%&?@<>]','g');
*/
var _sketch_3d__fade_txt_CHARSLRG_regex = new RegExp('[a-zA-Z0-9#$%&?@<>=]','g');
var _sketch_3d__fade_txt_CHARSSML_regex = new RegExp(
	'[!()\\[\\]|\\\\;{}+:~]','g');
var _sketch_3d__fade_txt_CHARSTNY_regex = new RegExp('[' + "'" + '",^*\._-]','g');

//K, gotta replace ALL major punction, it looks like...
// K, looks like I can do it ALL with 2 sweeps...

// OK, have to think of this as: brightest to least bright. 
// SO: I could just have a basic 3-4 texture thing, and work my way down. 
function _sketch_3d__fade_out_txt( txtgrid, dist, distmax,
			fade_start_precent_Default_pnt60){
  var dist_precent = dist/distmax;
  //file_input(dist_precent);
  while(1){ //switch-thingy without being a switch.
	 // fade_too = [0] LARGECHARS, [1] MID'', [2] FAR''
	if( dist_precent < fade_start_precent_Default_pnt60){ 
		return txtgrid;}
	//if( dist_precent < .60){ fade_too = "::."; break;	}
	if( dist_precent < fade_start_precent_Default_pnt60 + .10){ 
		fade_too = ":. "; break; }
	// else is >75% to distmax
	fade_too = ".. "; break;	}
  return txtgrid
	.replace( _sketch_3d__fade_txt_CHARSTNY_regex, fade_too[2]) 
	.replace( _sketch_3d__fade_txt_CHARSSML_regex, fade_too[1] ) 
	.replace( _sketch_3d__fade_txt_CHARSLRG_regex, fade_too[0] );
}

// placeholder for 'filled char' 
function _sketch_3d__draw_col_between(
	drawing_tiles_NOT_cols, getDistance, angle, //maybe angle 4 skybox
	istile_shadow,  //if so, lights off
	precent_through_x_tile, //% offset of x, 4 tile border
	height_limit,  floor_limit,// hight/bottom limit
	top_of_drawing, bottom_of_drawing, // height/bottom 
	texture_char, get_screen_x, //scanline_x is which screen x is drawn
	dist_max,
	MAX_WALLBRDER_DIST_default_6,
	fieldOfView_Default_pnt8,
	fade_start_precent_Default_pnt60){ 
	
	//file_input( precent_through_x_tile);
	if( top_of_drawing < height_limit){
		if( top_of_drawing > floor_limit){ 
			var y_top = top_of_drawing;
		}else{ var y_top = floor_limit;}
	}else{ var y_top = height_limit;}

	if( bottom_of_drawing > floor_limit){
		if( bottom_of_drawing < height_limit){
			var y_bottom = bottom_of_drawing;
		}else{ var y_bottom = height_limit;}
	}else{  var y_bottom = floor_limit;}
	
	if( y_bottom >= y_top){ return;};
	if( istile_shadow){texture_char = " ";
	}else{
	//rendering depth
	  var tmp_fade_char = 
		_sketch_3d__fade_out_txt( texture_char, getDistance, 
	 	dist_max, fade_start_precent_Default_pnt60);//dist_max);
	
	  if( tmp_fade_char != texture_char){ texture_char= tmp_fade_char;
	  }else{ if((getDistance < 
		   dist_max*fade_start_precent_Default_pnt60) &&
	  		getDistance < MAX_WALLBRDER_DIST_default_6){ 
		// drawing 'border' to walls ( horizontal)
		// OK, there are a few border options:
		// draw and don't draw are two (for 'tops' of surfaces)
		//file_input(texture_char);
		var prec_thr_x_add_4_dist =  
			((getDistance / MAX_WALLBRDER_DIST_default_6) 
			  *0.16);
		 //if(getDistance > MAX_WALLBRDER_DIST_default_6/2){
		//	prec_thr_x_add_4_dist = 0.0;}
		if(!drawing_tiles_NOT_cols ){
			if( precent_through_x_tile <
					prec_thr_x_add_4_dist ||
				precent_through_x_tile >
					1.0-prec_thr_x_add_4_dist 
			
			){texture_char =
					"*\n|\n*";
			}else{
			// for below, 2 should be texture char.
			  texture_char = "=\n"+ texture_char[2] + "\n=";}
	  }	} }
	}
	
	sketch_grid_DRAW_UNDER_TRANSPCHAR( gridstr_scale(//Math.floor(getDistance),
	//sketch_grid( gridstr_scale(//Math.floor(getDistance),
		texture_char,//""+drawing_tiles_NOT_cols, ////Math.floor(getDistance), 
		1,   Math.ceil(Math.abs(y_top -y_bottom)), 0),  //1,0),//
		get_screen_x, Math.ceil(y_bottom), 
		_sketch_3d_BLANK_TO_DRAW_CHAR ); //  transp_char_or_0);	


		//1,   Math.abs(y_top -y_bottom), 0),  //1,0),//
		//get_screen_x, y_bottom, " " ); //  transp_char_or_0);
	
}

////////////////////////////////////////////////
////////////////////////////////////////////////
////  _sketch_3d_CORE_draw_cols_n_sprites (NEED C VERSION)
////////////////////////////////////////////////
////////////////////////////////////////////////

