

_file_load_js_cd = "";
file_data = null; // tmp. var used to import vars
file_data_eval = null; // tmp. var defined in importing vars tmp. var 
			// 
function _file_get_file_src( filename){
	filename = filename.split("/").slice(0,-1).join("/")+"/";
	filename = filename.replace("//", "/");
	return filename;
}

var _file_load_js_cd = "./";

// from https://stackoverflow.com/questions/13261970/how-to-get-the-absolute-path-of-the-current-javascript-file-name
// --- this don't work right, so I'm using it to yank the _src dir, 
// as it will always be in the filepath.
function absFileLoc(filename) {
  var scriptElements = document.getElementsByTagName('script');
  for (var i = scriptElements.length-1; i >=0; i--) {
    var source = scriptElements[i].src;
    if (source.indexOf(filename) > -1) {
      var location = source.substring(0, 
	      source.indexOf(filename)) + filename;
      return location;	}	}
  return false;	}
//pulling current js file
//absFileLoc: last one loaded SHOULD be file.js...
//OTHERS ARE LOADED INTO HTML, BUT THE LOADING FAILS!
// (I try to load 'file.js' MANY times, each gets an instance.)
var _file_core_js = absFileLoc("file.js").split("_src")[0] + 
	"_src/LOAD_2_core_js/";
function file_core_js_cd(){ return _file_core_js; }
function file_js_cd(){ return _file_load_js_cd;}
var _file_dir_cd = "./";
function file_dir_cd(){ return _file_dir_cd; }
function file_js_cd(){ return _file_load_js_cd; }
// https://stackoverflow.com/questions/7308908/waiting-for-dynamically-loaded-script
// File load:
function __file_load_promise( getFileName){
        return new Promise(function(resolve, reject) {
                var script = document.createElement('script');
                script.onload = function(){resolve(1);};
		script.onerror = function(){
			document.head.removeChild(script);
			resolve(0);};
		script.src = getFileName; 
                document.head.appendChild(script);
        });
}

var _file_check_loaded_js = {};
function _file_check_add_filename(getStrfilename){
	getStrfilename=getStrfilename.split("\\").join("/")
		 .split("/").slice(-1)[0];
	_file_check_loaded_js[getStrfilename]=true; }
//API_TAG//
function file_check_loaded( getStrfilename){//returns nothing,throws err
	//dependency checker for js files.  //API_TAG//
	getStrfilename=getStrfilename.split("\\").join("/")
		 .split("/").slice(-1)[0];
	if(_file_check_loaded_js[getStrfilename] == undefined){
		file_input("Dependency for '" + getStrfilename 
			+ "' requested and not found. Requested from: "+
			file_js_cd() +_file_load_js_cd_file	); }	}

var _file_load_js_cd_file ="";
var _file_caught_src_dir_list = [];
async function file_load_js( get_cd, getFileName_or_list ){
	//https://javascript.info/onload-onerror
	if(typeof getFileName_or_list == "object"){
		var f = getFileName_or_list;
		for(var i=0; i< f.length; i+=1){
			await file_load_js( get_cd, f[i]); }
		return 1;	}

	var getFileName =getFileName_or_list;

	var f =  get_cd + getFileName;
	console.log("LOADING: " + f);

	_file_caught_src_dir_list.push(_file_load_js_cd + "");
	_file_load_js_cd = _file_get_file_src( get_cd + getFileName );
	var tmp_caught_filename = _file_load_js_cd_file;

	_file_load_js_cd_file = getFileName
	ret = await __file_load_promise(f );
	if(file_data_eval != null){
		tmp_eval = file_data_eval; 
		file_data_eval = null;
		await tmp_eval(); 
	}
        _file_check_add_filename(getFileName);
	
	_file_load_js_cd_file =tmp_caught_filename;
	_file_load_js_cd = _file_caught_src_dir_list.pop();;

	return ret;
}
function file_input(txt_in, g1, g2, g3, g4, g5, g6, g7, g8, g9, g10){ 
	var a =[g1, g2, g3, g4, g5, g6, g7, g8, g9, g10];
	var b = "";
	for(var i=0; i< a.length; i+=1){
		if(a[i] != undefined){ b+=" " + a[i];}}
	return prompt(txt_in + b,"");} 
function file_log(txt_in){ _update_log_text_1_turn +=
	txt_in + "<br>";}
// searches file tree parent folders ( a few up) 
async function file_treeload_js( get_cd, getFileName ){
	splitname = (get_cd + getFileName).split("/");
	len = splitname.length;
	for( i=0; i< splitname.length; i+=1){
	   splitname.slice(i,len).join("/");
	   if(await file_load_js("", splitname.slice(i,len).join("/") )){
		return 1; }
	   if(await file_load_js("../", splitname.slice(i,len).join("/") )){
		return 1;} }
	return 0;

}
/*
async function file_load_js( getFileName ){
	//https://javascript.info/onload-onerror
	f =  _file_load_js_cd + getFileName;
	console.log("LOADING: " + f);

	caught_src_dir = _file_load_js_cd + "";
	_file_load_js_cd = _file_get_file_src( _file_load_js_cd + getFileName );
	
	script = document.createElement('script');
	script.src = f;
	document.head.append(script);
		
	script.onload = function() {_file_callback_toggle_success = 1;}
	script.onerror = function() {_file_callback_toggle_fail=1;}
	
	console.log("scr: " + caught_src_dir);
	while(_file_callback_toggle_success ==0 
			&& _file_callback_toggle_fail == 0){
		await _file_sleep(100); } //100 arbitrary
	
	

	console.log("SRC: " + caught_src_dir);
	_file_load_js_cd = caught_src_dir + "";
	if(_file_callback_toggle_success){
		_file_callback_toggle_success =0;
		_file_callback_toggle_fail = 0;
		return 1;
	}else{
		console.log("ERROR:failed to load: " + f );
		_file_callback_toggle_success =0;
		_file_callback_toggle_fail = 0;
		return 0;
	}
}
*/

// file_data is GOT from files, defined as   file_data = ``
file_data = null;
async function file_load_js_data( get_cd , filename ){
	//https://javascript.info/onload-onerror
	await file_load_js( get_cd, filename);
	// all files will be labeled with file_data = `TEST TO GET`;
	retData = null;
	if(file_data!= null){
		retData = file_data; 
		file_data = null;	}

	 return retData; 

}
async function file_save( NOT_JS_cd, filename, get_txt ){
	//NOT IDEAL
	return await file_save_dialog( filename, get_txt); 
}
async function file_load( NOT_JS_cd, filename ){
	//NOT IDEAL
	return await file_load_dialog();
}


var _file_copybox_resolve_buttn; //is changed into _resolve("foo") by promises. 
		// allowing the keypress to be bound to it 
		// to resume promise.
async function _file_copybox_wait_button_press(){
await new Promise( function(resolve,reject){ 
	_file_copybox_resolve_buttn = resolve;});}
		
		
async function file_copybox(  getTextToShow ){
  var tmp_div = document.createElement('div');
  var tmp_txtBox = document.createElement("textarea");
	tmp_txtBox.innerHTML = getTextToShow;
	tmp_txtBox.id = "tmp_txtBox";
  var tmp_txtBox_button = document.createElement("button"); 
  var tmp_txtBox_button_select = document.createElement("button"); 
  	tmp_txtBox_button_select.onclick = function(){
		document.getElementById("tmp_txtBox").focus();
		document.getElementById("tmp_txtBox").select();}
	tmp_txtBox_button_select.innerHTML = "Select txt box contents";
  tmp_div.appendChild( document.createElement("br"));
  tmp_div.appendChild( tmp_txtBox );
  tmp_div.appendChild( document.createElement("br"));
  tmp_div.appendChild( tmp_txtBox_button );
  tmp_div.appendChild( tmp_txtBox_button_select );

  tmp_txtBox_button.innerHTML = "Press me to proceed";
  tmp_txtBox_button.onclick = function(){_file_copybox_resolve_buttn("");};
  document.body.appendChild(tmp_div);

  var caught_onkeydown = document.onkeydown;
 	document.onkeydown = function(){};
  await _file_copybox_wait_button_press();
  document.onkeydown = caught_onkeydown;
  
  var tmp_return = tmp_txtBox.value;
  tmp_div.remove();
  return tmp_return;
}

// https://stackoverflow.com/questions/34495796/javascript-promises-with-filereader
function _file_copybox_readFile(file){
  return new Promise((resolve, reject) => {
    var fr = new FileReader();  
    fr.onload = () => {
      resolve(fr.result )
    };
    fr.onerror = reject;
    fr.readAsText(file);
  });
}


async function file_load_dialog(  ){
  var tmp_div = document.createElement('div');
  var tmp_file_input = document.createElement('input');
  	tmp_file_input.type= "file";
	tmp_file_input.id = "tmp_file_input";
  var tmp_proceed_button = document.createElement("button"); 
  tmp_div.appendChild( tmp_file_input );
  tmp_div.appendChild( document.createElement("br"));
  tmp_div.appendChild( tmp_proceed_button );

  tmp_proceed_button.innerHTML = "Press me to proceed";
  tmp_proceed_button.onclick = function(){_file_copybox_resolve_buttn("");};
  document.body.appendChild(tmp_div);
  await _file_copybox_wait_button_press();
 
	//accessing file
  var i1 = document.getElementById("tmp_file_input");
  var tmp_file = i1.files[0];
  try{ var tmp_return = await _file_copybox_readFile(tmp_file);
  }catch(e){ tmp_return = null;}
  tmp_div.remove();
  return tmp_return;
}


// need to add preface test and filename...
// maybe... need to think about this
async function file_save_dialog( filename, get_txt ){
  var tmp_div = document.createElement('div');
  var tmp_proceed_button = document.createElement("button"); 
  
  var tmp_blob = new Blob([get_txt], {
    type: 'text/plain'	});
   var tmp_link = document.createElement("a"); 
  tmp_link.href = URL.createObjectURL(tmp_blob);
  tmp_link.download = filename;
  tmp_link.innerHTML = "Click here to download the file";
  tmp_div.appendChild(tmp_link); 

  tmp_div.appendChild( document.createElement("br"));
  tmp_div.appendChild( tmp_proceed_button );

  tmp_proceed_button.innerHTML = "Press me to proceed";
  tmp_proceed_button.onclick = function(){_file_copybox_resolve_buttn("");};
  document.body.appendChild(tmp_div);
  await _file_copybox_wait_button_press();
 
  tmp_div.remove();
  return;
}




