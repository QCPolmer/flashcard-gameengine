// NEEDS TO HAVE grid IMPORTED, OR THIS WON'T RUN!!!
#if defined(DUK_VERSION)	
void progen_CORE_duktape_port_settup(duk_context *ctx);
#endif

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
/////////////// Ducktape Port //////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

#if defined(DUK_VERSION)



static duk_ret_t duk_ml_CORE_runword_cmds(duk_context *ctx) {
    // Get the first argument (obj1)
    duk_idx_t o_idx = 0;
    duk_idx_t otarget_idx = 1;
    duk_idx_t sentence_idx = 2;
    duk_idx_t getStruct_idx = 3;
    duk_idx_t rm_OPTIONAL_idx = 4;

    duk_get_prop_string(ctx, getStruct_idx, "_mml_word_locs"); //stack:1
    duk_idx_t locs_mags_idx = 5;
    duk_get_prop_string(ctx, getStruct_idx, "cmds"); //stack:2
    duk_idx_t cmds_idx = 6;
	
    duk_get_prop_string(ctx, getStruct_idx, "_mml_word_loc1_start");
    int _mml_word_loc1_start = duk_get_int(ctx, -1); 
	duk_pop(ctx); // _mml_word_loc1_start
    const char* sentence; 	
    sentence =(const char*)duk_get_string( ctx, sentence_idx);
    int sentence_length =(int)duk_get_length(ctx, sentence_idx);
    int MAG_INDEX = 1;
    int loc_finished_count =0;
	
   int length = (int)duk_get_length(ctx, locs_mags_idx);

   const char* cmd_funct_name;

   int cur_loc=0; int char_i=0; int mag_i=0;
   // rm_OPTIONAL_idx, locs_mags_idx, 
   for(int i=0; i< length; i+=2){
	while(1){
		//printf("%ia",i);
		duk_get_prop_index(ctx, locs_mags_idx,i);
		cur_loc = (int)duk_get_int(ctx, -1);
			duk_pop(ctx);
		char_i = sentence[ cur_loc ];
		duk_get_prop_index(ctx, locs_mags_idx, i+MAG_INDEX);
		mag_i = (int)duk_get_int(ctx, -1);
			duk_pop(ctx);
		//printf("%ib",i);
		///////////
		if(char_i == ','){ 
		   if(i==0){//first IF part of 'word'
			loc_finished_count+=1;
			duk_push_int(ctx, (duk_int_t)_mml_word_loc1_start); 
			duk_put_prop_index(ctx, locs_mags_idx,i);
			break;}
		    loc_finished_count +=1; break;}
		if(char_i == '=' || char_i == '>' || char_i == '<'){
		   
		   if(char_i == '='){  mag_i =0;}
		   if(char_i == '>'){  mag_i +=1;}
		   if(char_i == '<'){  mag_i -=1; }
			
		   duk_push_int(ctx, (duk_int_t)mag_i);
		   duk_put_prop_index( ctx, locs_mags_idx, i+MAG_INDEX );
		   duk_push_int(ctx, (duk_int_t)cur_loc + 1);//cur_loc+=1;
		   duk_put_prop_index(ctx, locs_mags_idx,i);
		   continue;
		}
		//printf("%ic",i);
		//running cmds 
		duk_get_prop_string(ctx, cmds_idx, (const char*)&char_i);
			//stack:3
		//printf("%iC",i);
		
		//command list
		if(!duk_is_undefined(ctx, -1)){ 
			
		     //printf("%id",i);
		     //first item in retrieved cmd (functname)
		     duk_get_prop_index(ctx, -1, 0);//funct_name
			//stack:4
		     cmd_funct_name = (const char*)duk_get_string(ctx,-1);
		     //printf("%iD",i);
		     //printf("++%i++%s++",duk_get_length(ctx,-2),
		 	//duk_get_string(ctx,-1));
		     //
		     //o,otarget, i/2, // i/2 is 'track', # comma running! 
		     //   locs_mags[i+MAG_INDEX],func_cmdlist,rm_OPTIONAL)
		     //setting up function(cmd) to run:
		     duk_get_global_string(ctx,  cmd_funct_name );
		     duk_dup(ctx, o_idx);
		     duk_dup(ctx, otarget_idx);
		     duk_push_int(ctx, (int)i/2); //track
		     duk_push_int(ctx, (int)mag_i); //magnitude
		     duk_dup(ctx, -7); //command params (right index?)	
		     duk_dup(ctx, rm_OPTIONAL_idx);
		     duk_call(ctx, 6); //executing! //return: //stack:5
			//top of stack is return
		     //printf("%ie",i);
		     
		     if (duk_get_type(ctx, -1) == DUK_TYPE_NUMBER) {	
			if((int)duk_get_int(ctx,-1) ==1){
			   //cleaning up
		     	   duk_pop(ctx);// function return //stack:5
 		     	   duk_pop(ctx);//funct_name //stack:4
			   duk_pop(ctx);//cmds //stack:3
				
			  //first 'track', means early termination:
			  if(i==0){ 
				//cleaning up
		     		//cmds, _mml_word_locs, 
   				duk_pop(ctx); duk_pop(ctx); //stack:2, 1
				//returning 2
				duk_push_int(ctx, (duk_int_t)2);
				return 1; //first IF part of 'word' 
			}else{ break; }
			}
			//printf("%if",i);
			
		     }

		  //printf("%iG",i);
		  duk_pop(ctx);// function return //stack:5
		  duk_pop(ctx);//funct_name //stack:4
		}	  

		//running cmds
		  duk_pop(ctx); //stack:3

		//zzz
			//first, the'if'block   
		  duk_push_int(ctx, (duk_int_t)cur_loc + 1);//cur_loc+=1;
		  duk_put_prop_index(ctx, locs_mags_idx, i); 
		  if(i !=0){ break;}
	
  }   }
    //cmds, _mml_word_locs,  // //stack:2,1
   duk_pop(ctx); duk_pop(ctx); 
   
   //locs_mags.length == length below
   if(loc_finished_count >= (length/2) ){ duk_push_int(ctx, (duk_int_t)1);
   }else{ duk_push_null(ctx);}
   //returns 1 value, '1' for done /w word, 'null' for not
   return 1;
}

// THIS IS A (MOSTLY) 1-1 TRANSLATION OF THE JS VERSION,
// 	CHECK THAT VERSION IF THIS STARTS GIVING TROUBLE!!!
static duk_ret_t duk_ml_behav_mml_status_CORE(duk_context *ctx) {
    // Get the first argument (obj1)
    duk_idx_t o_idx = 0;
    if(0==duk_has_prop_string(ctx, o_idx, 
		"_statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS")){ return 0;}
      
    duk_get_prop_string(ctx, o_idx, 
		"_statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS");
    duk_idx_t stats_ID_idx = 1;

    duk_get_global_string(ctx,  "rmloaded_room" );
    duk_idx_t rmLoaded_ID_idx = 2;

    int tmpTime = 0;
    
    duk_idx_t cmds_ID_idx = 3;

    int tmpLen = (int)duk_get_length(ctx, stats_ID_idx);
    for(int i=tmpLen-5; i>=0; i-=5){
	// pulls cmds FIRST and FUNCTION, DUPLICATES them 
	// as params later!
	duk_get_prop_index( ctx, stats_ID_idx, (int)i+4); //cmds
	duk_get_prop_index( ctx, -1, 0); //cmds[0] //funct-name
	duk_get_global_string( ctx,
		(const char*)duk_get_string( ctx, -1) ); //FUNCTION PNTR
	
	//function paramiters
	duk_dup(ctx, o_idx); //o
	duk_dup(ctx, o_idx); //o
	duk_push_int(ctx, (int)-1); //-1	

	duk_get_prop_index( ctx, stats_ID_idx, (int)i+1); //magnitude
	duk_dup( ctx, cmds_ID_idx); //cmds

	duk_dup(ctx, rmLoaded_ID_idx); //rmloaded_room

	duk_get_prop_index( ctx, stats_ID_idx, (int)i+2); //time
	//pulling time
	tmpTime = (int)duk_get_int( ctx, -1);

	// calling functing, removing too function and getting return
	duk_call(ctx, 7); //7 params, then funct call... 
	
	//itterating:
	tmpTime -= 1;
	if( tmpTime ==0 || 1 == (int)duk_get_int(ctx,-1) ){ //the return
		duk_get_prop_string(ctx, stats_ID_idx, "splice");
		// duk_call_method requires a obj for 'this'
		duk_dup(ctx, stats_ID_idx);
		duk_push_int(ctx, (int)i);
		duk_push_int(ctx, 5); 
		duk_call_method(ctx, 2); //calling "splice"
		duk_pop(ctx); //removing return...
	}else{
		duk_push_int(ctx, (int)(tmpTime));
		//setting time -=1...
		duk_put_prop_index(ctx, stats_ID_idx,  (int)(i+2)); 
	}
	duk_pop(ctx); duk_pop(ctx); duk_pop(ctx);  
		//funct-name // return  //cmds,

    }
    if((int)duk_get_length(ctx, stats_ID_idx) == 0 ){
	duk_del_prop_string(ctx, o_idx, 
		"_statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS"); }    

    duk_pop(ctx); //stats_ID_idx, 
		//_statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS
    return 0;
}


void ml_CORE_duktape_port_settup(duk_context *ctx){
	
	duk_push_c_function(ctx,
		duk_ml_behav_mml_status_CORE,1);
	duk_put_global_string(ctx, "_behav_mml_status_CORE");
	duk_push_c_function(ctx,
		duk_ml_CORE_runword_cmds,5);
	duk_put_global_string(ctx, "_ml_CORE_runword_cmds");
	//duk_push_string( ctx, "Object.assign = _object_assign;");
	//duk_eval_noresult(ctx);
		
}

#endif
