// updates collision table
	//
   //for some reason, duktape auto-loads functions
  var _rmloaded_lookup_lrg_colgroups ={};
	var _rmloaded_lookup_xlocs = {};
  var rmloaded_col_test_settup_xy_n_lrg_list = function(){
	_rmloaded_lookup_lrg_colgroups = [];
	  _rmloaded_lookup_xlocs = [];
  }
	//(_rmloaded_launch_game_objs);
  //var _rmloaded_ADD_OBJ_TO_XLOCS = function(obj){
//	var key = obj.x*5000+obj.y;
//	if( _rmloaded_lookup_xlocs[key] == undefined){
///		_rmloaded_lookup_xlocs[key] = [];	}
//	_rmloaded_lookup_xlocs[key].push(obj);	}
  var rmloaded_settup_lookup_props_obj = function(objs){
	for(var i=0; i< objs.length; i+=1){
		_rmloaded_lookup_xloc_update(objs[i]);	} }
	//(_rmloaded_launch_game_objs_large)
  
//  var _rmloaded_ADD_LRGOBJ_TO_COLGROPUS = function(obj){
//	for(var j=0; j< obj.colgroup.length; j+=1){
//		if(_rmloaded_lookup_lrg_colgroups[obj.colgroup[j]]==undefined){
//		  _rmloaded_lookup_lrg_colgroups[obj.colgroup[j]] = []; }
//		_rmloaded_lookup_lrg_colgroups[obj.colgroup[j]].push(
//			obj);	}	}

var  batch_draw_obj_list = function(objs, cam_x, cam_y,dont_draw_any_objs){
	if(dont_draw_any_objs == 1){ return;}
	 cam_x = Math.floor(cam_x); cam_y = Math.floor(cam_y);
	 for(var i=0; i< objs.length; i+=1){
		obj = objs[i];
		draw( obj.graphic,  cam_x + Math.floor(obj.x), 
			cam_y + Math.floor(obj.y), ' ');
  	}	}
  var batch_objlist_remove_dead = function(objs){
	for(var i= objs.length-1; i>=0; i-=1){
		if(objs[i].dead == true){
			objs.splice(i,1); } } }

  var rmloaded_settup_lookup_props_lrg = function(objs){
	for(var i=0; i< objs.length; i+=1){
		_rmloaded_lookup_colgrp_update( objs[i] ); } }
	//(_rmloaded_launch_game_objs_large)
 var batch_draw_obj_HELPER_SCRIPT = function(obj, cam_x, cam_y){
	if( obj.draw_1late_2last == 0 || obj.draw_1late_2last == undefined){
		  draw( obj.graphic,  cam_x + Math.floor(obj.x), 
			  Math.floor(cam_y) + obj.y, ' ');
		}else{ if(obj.draw_1late_2last==1){
			_rmloaded_draw_after_lrgobjs_buffer.push( obj);
	 	}if(obj.draw_1late_2last==2){
			_rmloaded_draw_last_buffer.push( obj);}
 } 	}

  var batch_draw_n_run_behave_n_updateloc_obj_list = async function( 
		objs,  behaviors, cam_x, cam_y,
  		dont_draw_any_objs,
  		getdraw_after_lrgobjs_buffer, getdraw_last_buffer){
	for(var i=0; i< objs.length; i+=1){
		obj = objs[i];
		if( !rmloaded_paused || obj.ignore_pause){
			await behaviors[obj.behavior](obj); } 
		if(dont_draw_any_objs != 1){
			batch_draw_obj_HELPER_SCRIPT(obj, cam_x, cam_y);}
		_rmloaded_lookup_xloc_update(obj);
  	}	}

  var batch_draw_n_run_behave_n_updateloc_obj_LRG_list = async function( 
		objs_large, behaviors, cam_x, cam_y,
  		dont_draw_any_objs,
  		getdraw_after_lrgobjs_buffer, getdraw_last_buffer ){
	 for(var i=0; i< objs_large.length; i+=1){
		obj = objs_large[i];
		if( !rmloaded_paused || obj.ignore_pause){
			await behaviors[obj.behavior](obj); } 
		if(dont_draw_any_objs !=1){
			batch_draw_obj_HELPER_SCRIPT(obj, cam_x, cam_y);}
	} 	}
//API_TAG//
///////////////////////////////////////////////////
/// generates a 'tile' part of a room. 
//  c version is coded-in
/////////////////////////////////////////////////
function rmloaded_gen_objs_from_gridstr( get_rm, getGridstr, x_init, y, 
	    chars_2objs, chars_2lrgobjs, OPTIONAL_objs_pre_stringified){
		//chars_2objs/lrgobjs are: {"char":obj}
		// OR: {"char":objs_stringified} (much faster)
		//    WITH OPTIONAL_objs_pre_stringified true!!!
//API_TAG//
	var len= getGridstr.length; 
	var chars_str = Object.keys(chars_2objs).join("") + 
			Object.keys(chars_2lrgobjs).join("");
	var x = x_init-1; var tmpO = null;
	for(var i=0; i< len; i+=1){
		var char_i = getGridstr[i];
		if( char_i == "\n"){y += 1; x = x_init-1; continue;}
		x += 1;
		if( chars_str.indexOf( char_i ) == -1){ continue;}
		if(chars_2objs[ char_i ] != undefined){
			tmpO = chars_2objs[ char_i ];
			if( !OPTIONAL_objs_pre_stringified ){ 
			    tmpO = JSON.stringify( tmpO ); }
			tmpO = JSON.parse( tmpO );
			tmpO.x = x; tmpO.y = y;
			get_rm.objs.push( tmpO );
			continue;	}
		if(chars_2lrgobjs[ char_i ] != undefined){
			tmpO = chars_2lrgobjs[ char_i ];
			if( !OPTIONAL_objs_pre_stringified ){ 
				tmpO = JSON.stringify( tmpO ); }
			tmpO = JSON.parse( tmpO );
			tmpO.x = x; tmpO.y = y;
			get_rm.objs_large.push( tmpO );
	printf("TRACE\n");
			continue;	}
	}
}
///////////////////////////////////////////////////
///FOR SKETCHING OBJ_LISTS, see rmloaded_sketch_all_objs
/////////////////////////////////////////////////
 function batch_sketch_obj_list(objs, cam_x, cam_y){
	 cam_x = Math.floor(cam_x); cam_y = Math.floor(cam_y);	 
	 for(var i=0; i< objs.length; i+=1){
		obj = objs[i];
		sketch( obj.graphic, cam_x + Math.floor(obj.x), 
			cam_y + Math.floor(obj.y), ' ');
  	}	}
///////////////////////////////////////////////////
///FOR SKETCHING OBJ_LISTS, see rmloaded_sketch_all_objs
/////////////////////////////////////////////////
   //FOR NO-ASYNC, USE NEXT FUNCTION!!!
  async function batch_SKETCH_n_run_behave_n_updateloc_obj_list( 
		objs,  behaviors, cam_x, cam_y,
  		dont_RUN_N_UPDATE, //only here in case I do multi-room
  		getSketch_after_lrgobjs_buffer, getSketch_last_buffer){
	for(var i=0; i< objs.length; i+=1){
		obj = objs[i];
		if(!dont_RUN_N_UPDATE){
		   if( !rmloaded_paused || obj.ignore_pause){
			await behaviors[obj.behavior](obj); } }
		batch_SKETCH_obj_HELPER_SCRIPT(obj, cam_x, cam_y);
		if(!dont_RUN_N_UPDATE){ _rmloaded_lookup_xloc_update(obj);}
  	}	}
  // no async version
  function batch_SKETCH_n_updateloc_obj_list( 
		objs,  behaviors, cam_x, cam_y,
  		UNUSED_PLACEHOLDER, //so I can use above funct in c version
  		getSketch_after_lrgobjs_buffer, getSketch_last_buffer){
	for(var i=0; i< objs.length; i+=1){
		obj = objs[i];
		batch_SKETCH_obj_HELPER_SCRIPT(obj, cam_x, cam_y);
  	}	}
///////////////////////////////////////////////////
///FOR SKETCHING OBJ_LISTS, see rmloaded_sketch_all_objs
/////////////////////////////////////////////////
  //FOR NO-ASYNC, USE NEXT FUNCTION!!!
   async function batch_SKETCH_n_run_behave_n_updateloc_obj_LRG_list( 
		objs_large, behaviors, cam_x, cam_y,
  		dont_RUN_N_UPDATE, //only here in case I do multi-room
  		getSketch_after_lrgobjs_buffer, getSketch_last_buffer ){
	  for(var i=0; i< objs_large.length; i+=1){
		obj = objs_large[i];
		if(!dont_RUN_N_UPDATE){
		   if( !rmloaded_paused || obj.ignore_pause){
			await behaviors[obj.behavior](obj); } }
		batch_SKETCH_obj_HELPER_SCRIPT(obj, cam_x, cam_y);}
  	}
  // no async version
   function batch_SKETCH_n_updateloc_obj_LRG_list( 
		objs_large, behaviors, cam_x, cam_y,
  		UNUSED_PLACEHOLDER, //so I can use above funct in c version
  		getSketch_after_lrgobjs_buffer, getSketch_last_buffer ){
	  for(var i=0; i< objs_large.length; i+=1){
		obj = objs_large[i];
		batch_SKETCH_obj_HELPER_SCRIPT(obj, cam_x, cam_y);}
  	} 	
///////////////////////////////////////////////////
/////////// END: FOR SKETCHING OBJ_LISTS, see rmloaded_sketch_all_objs
/////////////////////////////////////////////////
function batch_SKETCH_obj_HELPER_SCRIPT(obj, cam_x, cam_y){
	if(obj.draw_1late_2last == 0 || obj.draw_1late_2last == undefined){
		sketch( obj.graphic,  cam_x + Math.floor(obj.x), 
			cam_y + Math.floor(obj.y), ' ');
		}else{ if(obj.draw_1late_2last==1){
			_rmloaded_sketch_after_lrgobjs_buffer.push( obj);
	 	}if(obj.draw_1late_2last==2){
			_rmloaded_sketch_last_buffer.push( obj);
		}
 } 	}
///////////////////////////////////////////////////
/////////// END: FOR SKETCHING OBJ_LISTS, see rmloaded_sketch_all_objs
/////////////////////////////////////////////////

   var  _rmloaded_lookup_xloc_update =function(obj){
	var key = Math.floor(obj.x) * 5000 +Math.floor(obj.y);
	if(_rmloaded_lookup_xlocs[key] == void null){ 
		_rmloaded_lookup_xlocs[key] = [obj]; 
	}else{ _rmloaded_lookup_xlocs[key].push(obj); } }

   // BELOW IS FOR obj_large!!!
   var  _rmloaded_lookup_colgrp_update= function( obj){ 
	for( var i=0; i< obj.colgroup.length; i+=1){
		if(_rmloaded_lookup_lrg_colgroups[obj.colgroup[i]] == 
			void null){ 
		     _rmloaded_lookup_lrg_colgroups[obj.colgroup[i]] = [obj]; 
		}else{ _rmloaded_lookup_lrg_colgroups[obj.colgroup[i]]
				.push(obj);} } }

//API_TAG//	
   var rmloaded_col_test_SIMPLE = function(x,y,prop){ // prop is col-prop
	   	// I think it takes a single char
	   // RETURNS: "" for no collision, or char of collision
	var out = _rmloaded_col_test(x,y,prop);
	if(out[1].length >0){ return out[0][0];}
	return "";	}
   var rmloaded_col_GET_OBJ = function( x,y,prop){// prop is col-prop
	   	// I think it takes a single char. 
	   // RETURNS: obj collided with
	var out = _rmloaded_col_test(x,y,prop);
	if(out[0].length >0){ return out[1][out[1].length-1];}
	return null;	}
//API_TAG//

   // returns a list of cols at that position!
   // ... 
   // Wait... if I just return a list of objs AND collision characters...
   // so generate a string from collision characters... 
   // ------THIS ONLY WORKS IN HTML VERSION!!! USE SOMETHING ELSE!!!
	// --------- RETURNS [objlist, "charshit"];
   var _rmloaded_col_test= function(x,y, col_group){ // col_group is 1 char
	x = Math.floor(x); y = Math.floor(y);
	var ret_objs=[]; var ret_chars=[];
	var objs = _rmloaded_lookup_xlocs[x*5000+y];
	if( objs != void null){ 
		// can catch obj_ys[obj.y] AND obj.y
		for(var i=0; i< objs.length; i+=1){
	   	   if(Math.floor(objs[i].y) == y && 
			   	Math.floor(objs[i].x) == x && 
			   objs[i].colgroup.indexOf(col_group)!=-1){
			
			ret_objs.push( objs[i]);
	   		ret_chars.push(objs[i].graphic);} 	} 	}
	// ADD A CHECK FOR LARGE OBJECTS HERE!!! IT WILL SPEED THINGS UP!!!
	if(_rmloaded_lookup_lrg_colgroups[col_group] != void null){
		var objs = _rmloaded_lookup_lrg_colgroups[col_group];
		var rmloaded_char = " ";
		for(var i=0; i< objs.length; i+=1){
			rmloaded_char= gridstr_overlay(  
				" ",	objs[i].graphic, 
				-(x-objs[i].x), -(y-objs[i].y),
				false, 	true, null);
			// file_input(objs[i].graphic + " " +
			//	(x-objs[i].x) + " " + (y-objs[i].y));
			if(rmloaded_char != " "){
				ret_objs.push( objs[i]);
	   			ret_chars.push( rmloaded_char );	} }	}

	return [ ret_chars, ret_objs];
   }

//API_TAG//
    // NOTE: THE NEXT FEW FUNCTIONS ARE AVAILABLE IN C ( SEE THEIR 
	// IMPLIMENTATIONS IN rmloaded_batch... .c ) 
	// AND I'M HOPING I CAN USE THEM FOR VIEW/LIGHT OVERLAYS 	
///---Below is like:list of loaded data that has to be used via function
    var rmloaded_lookupprop_getlrgobjs_i = function( getProp, i ){
	if(rmloaded_lookupprop_getlrgobjs_len( getProp ) <=i){ return null;}
	return _rmloaded_lookup_lrg_colgroups[getProp][i]; }
///---Below is like:list of loaded data that has to be used via function
    var rmloaded_lookupprop_getlrgobjs_len = function( getProp ){
	if(_rmloaded_lookup_lrg_colgroups[getProp] == undefined){ return 0;}
	return _rmloaded_lookup_lrg_colgroups[getProp].length; }
    // NOTE: BELOW USES ROUNDING, AND CAN GIVE FALSE POSITIVES!!
    //  MEANING: CHECK ACTUAL X AND Y AFTERWARDS!!!
///---Below is like:list of loaded data that has to be used via function
    var rmloaded_lookupxy_getobjs_len = function( x, y ){ 
	key = Math.floor(x) * 5000 + Math.floor(y);
	if(_rmloaded_lookup_xlocs[key] == undefined){return 0; }
	return _rmloaded_lookup_xlocs[key].length;}
    // NOTE: BELOW USES ROUNDING, AND CAN GIVE FALSE POSITIVES!!
    //  MEANING: CHECK ACTUAL X AND Y AFTERWARDS!!!
///---Below is like:list of loaded data that has to be used via function
    var rmloaded_lookupxy_getobjs_at = function( x, y, i ){
	var x = Math.floor(x); var y= Math.floor(y);
	if( rmloaded_lookupxy_getobjs_len( x, y ) <=i){ return null;}
	key = x * 5000 +y;
	return _rmloaded_lookup_xlocs[key][i]; }
//API_TAG//


