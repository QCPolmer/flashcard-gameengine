
#include <stdio.h>
#include <stdlib.h>
// SEE DUKTAPE BINDING AT END OF FILE
#if defined(DUK_VERSION)
void file_duktape_port_settup( duk_context *ctx,  
		int numb_of_args, char** args_list);
#endif 

//FOR RUNNING A JS FILE IN DUKTAPE:
// see the js_port_duktape library, it modifies 
// the js file. This allows the file to use 
// the sleep function from js_html AND this older 
// verson of js!
// (basically, the 'await sleep' adn 'async function' things
// 	get the 'await' and 'async' removed (easer to do in js))
void file_debug_scanf(int max_char_size_of_textblock){
	// THIS IS DECLAIRED IN DUKTAPE VERSION... 
	// IT'S file_debug_scanf_js__duktape_funct
	// for the js wrapper (I had to make one paramiter optional)
	}
void file_debug_printf(char * printThis){
	printf("%s", printThis); }
//API_TAG// prints to ERROR, for C-version of game engine ONLY
void file_debug_printf_ERROR(char * printThis){
//API_TAG//
	fprintf(stderr, "%s", printThis); }
int file_load_get_size_or_neg_one(char * filename){
	FILE* f = fopen(filename, "r");
	if(f == NULL){  return -1;}
	
	int count_tot = 0;
	while(fgetc(f) != EOF){ count_tot += 1;}
	rewind(f);

	fclose(f); f = NULL;
	return count_tot; // one for adding the '\0'
}
int file_load__use_get_size_beforehand(
		char * alter_this_string, char * filename, 
		int chars_to_read__PRECALC_THIS){
	FILE* f = fopen(filename, "r");
	if(f == NULL){  return 0;}

	
	int count_tot= chars_to_read__PRECALC_THIS;
	int count = 0;
	while( count< count_tot){ 
		alter_this_string[count] = fgetc(f); count+=1; }
	alter_this_string[count] = '\0'; ///terminating string
	// '\0' != "\0"!!!!
	fclose(f); f = NULL;
	return 1;
}
int file_save(char * filename, char * text){
	FILE* f = fopen( filename, "w");
	
	if(f == NULL){ return 0;  
	}else{ fprintf(f, "%s", text );} 
	fclose(f);
	return 1;
}


int _file_argument_number=0;
char ** _file_argument_list;
//API_TAG//
char* file_argument_get( int arg_to_get){
// returns the command line argument argument or ""; 
// For making command line stuff, try file_argument_paramsget 	//API_TAG//
	if(_file_argument_number <= arg_to_get){ return ""; }
	return (char*)_file_argument_list[ arg_to_get ]; }
void file_argument_settup( int numb_of_args, char** args_list){
	_file_argument_list = args_list;
	_file_argument_number = numb_of_args;	
	return; }


// LOOK IN THE file_INJECT_C.js file! Running m.js there will
//  generate this code (AND test it FIRST!!! A basic 'does it compile')
const char * file_load_js__duktape_funct(){
	return
	"var FILE_MULTILINE_CHAR='`';"


	//INJECT_C_CODE_FROM_FILE_HERE//
"	\n"
"function file_debug_scanf(blocksize_or_null){\n"
"\n"
"		if ( !(typeof blocksize_or_null === 'number')) { \n"
"			blocksize_or_null = 1000;}\n"
"		 return _file_debug_scanf(blocksize_or_null);\n"
"};\n"
"\n"
"var _file_embedded=undefined; //test2\n"
"if(one_js_embeded_file == undefined){ \n"
"var one_js_embeded_file = function(){return '';}}\n"
"var FILE_EMBEDED_SPLIT_BY= \"//EMBEDED_CODE_BLOCK//\";\n"
"\n"
"function _file_embedded_load(getFileName){\n"
"\n"
"\n"
"\n"
"	if( _file_embedded == undefined){\n"
"			_file_embedded = {};\n"
"			var tmpfiles=\n"
"		       one_js_embeded_file().split(FILE_EMBEDED_SPLIT_BY);\n"
"		       for(var i=1; i<tmpfiles.length;i+=2){\n"
"				_file_embedded[tmpfiles[i]]=\n"
"					tmpfiles[i+1];\n"
"			}\n"
"		}\n"
"		return _file_embedded[getFileName];\n"
"}\n"
"\n"
"\n"
"\n"
"function file_remove(get_cd, getFileName){\n"
"		if(getFileName!=undefined){ \n"
"		  	get_cd = get_cd + getFileName;	 };\n"
"		return _file_remove(get_cd);}\n"
"\n"
"function file_load_js_noembed(get_cd, getFileName){ \n"
"\n"
"\n"
"		return file_load_js(get_cd, getFileName, 1);}\n"
"	\n"
"function file_load_noembed(get_cd, getFileName){ \n"
"\n"
"\n"
"\n"
"		return file_load(get_cd, getFileName, 1);}\n"
"\n"
"function file_treeload_js_noembed(get_cd, getFileName){ \n"
"\n"
"\n"
"\n"
"\n"
"		if(getFileName==undefined){\n"
"	       		return file_treeload_js(get_cd)};\n"
"		return file_treeload_js(get_cd+getFileName);}\n"
"\n"
"var _file_load__last_load_from_embedded = false;\n"
"function file_load( get_cd, getFileName, \n"
"	\n"
"	__FOR_INTERAL_USE_load_non_embedded){ \n"
"\n"
"		_file_load__last_load_from_embedded = false;\n"
"		if( getFileName !== undefined){ \n"
"			var tmpName = getFileName;\n"
"		   	while('./\\\\'.indexOf(tmpName[0]) !=-1){\n"
"				tmpName=tmpName.substring(1);}\n"
"			if( __FOR_INTERAL_USE_load_non_embedded != 1 && \n"
"			   _file_embedded_load(tmpName)!==undefined){\n"
"			       _file_load__last_load_from_embedded = true;\n"
"			       return _file_embedded_load(tmpName);}\n"
"		}else{getFileName = ''; } \n"
"		return _file_load( get_cd + getFileName );\n"
"	}\n"
"\n"
"\n"
"function file_scrub_comments( s){ \n"
"\n"
"\n"
"\n"
"	s = s.split(\"\\n\");\n"
"	for(var i=s.length-2; i>0; i-=1){\n"
"		var line_scrubbed = s[i].trim();\n"
"		if( line_scrubbed[0] == \"/\" && line_scrubbed[1] == \"/\"){\n"
"			s.splice(i,1);\n"
"		}	}\n"
"	return s.join(\"\\n\");\n"
"}\n"
"\n"
"\n"
"function _file_preprocess_js( str_in){\n"
"\n"
"\n"
"\n"
"		var f = str_in;\n"
"		f = f\n"
"			.split('\\r\\n').join('\\n')\n"
"			.split('\\r').join('\\n')\n"
"			.split('aw'+'ait ').join('')\n"
"			.split('as'+'ync function').join('function');\n"
"	 	   f=_file_multiline_handler(f, FILE_MULTILINE_CHAR, '\\\\n\" + \\n \"' );\n"
"		return f; }\n"
"\n"
"\n"
"function _file_multiline_handler( \n"
"	    str_in, process_between_or_blank_str, replace_lines_with){\n"
"\n"
"\n"
"\n"
"		\n"
"		if(process_between_or_blank_str == ''){\n"
"			var process_between = '@#$$$$^^&&**';\n"
"	    		var f = process_between+ str_in + process_between;\n"
"		}else{ var f = str_in;\n"
"			process_between =process_between_or_blank_str; }\n"
"\n"
"		if(f.indexOf( process_between )!= -1){\n"
"			var f_tmp = f.split(process_between);\n"
"			for(var i=1;i<f_tmp.length; i+=2){\n"
"			   f_tmp[i]=  '(\\\"' +\n"
"			   f_tmp[i].split('\\\"').join('\\\\\"')\n"
"			   	.split('\\n').join(replace_lines_with) + \n"
"			    '\\\")'; \n"
"			}\n"
"		       f = f_tmp.join('');\n"
"		} return f; }  \n"
"		\n"
"\n"
"var file_duktape_license = \n"
"\n"
"'\\nThis game-engine is licensed under MIT liscense, \\nhowever, it uses 3 different libraries (also MIT liscense):\\n-- the licenses are baked into any generated executable generated,\\n\\tvia running via terminal with param -duktape_license\\n\\n///////////////////////////////////////\\n/////////////////////////////////////////////\\n/// LICENSE FOR FLASHCARD GAME ENGINE, EXCLUDING ADDITIONAL COMPONENTS\\n///  (see below for additional licenses, all MIT)\\n///////////////////////////////////////\\n/////////////////////////////////////////////'+\n"
"'\\n\\nCopyright 2026 Harrison Mansolf\\n\\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the \"Software\"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:\\n\\nThe above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.\\n\\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\\n\\n'+\n"
"'\\n\\n///////////////////////////////////////\\n/////////////////////////////////////////////\\n/////////// LICENSES FOR COMPONENTS:\\n//////////////////////////////////\\n////////////////////////////////////////\\n'+\n"
"'LICENSE FOR DUKTAPE JS INTERPRETER https://duktape.org/, WHICH IS USED IN THE SOURCE CODE \\n\\n\\n The MIT License (MIT) \\n\\nCopyright (c) 2013-present, Duktape authors (see AUTHORS.rst)\\n\\nPermission is hereby granted, free of charge, to any person obtaining a copy\\nof this software and associated documentation files (the \"Software\"), to deal\\nin the Software without restriction, including without limitation the rights\\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\\ncopies of the Software, and to permit persons to whom the Software is\\nfurnished to do so, subject to the following conditions:\\n\\nThe above copyright notice and this permission notice shall be included in\\nall copies or substantial portions of the Software.\\n\\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN \\nTHE SOFTWARE. \\n\\n\\n' +\n"
"'LICENSE FOR windows_dirent.h (https://github.com/tronkko/dirent):\\n\\nThe MIT License (MIT)\\n\\nCopyright (c) 1998-2019 Toni Ronkko\\n\\nPermission is hereby granted, free of charge, to any person obtaining a copy\\nof this software and associated documentation files (the \"Software\"), to deal\\nin the Software without restriction, including without limitation the rights\\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\\ncopies of the Software, and to permit persons to whom the Software is\\nfurnished to do so, subject to the following conditions:\\n\\nThe above copyright notice and this permission notice shall be included in all\\ncopies or substantial portions of the Software.\\n\\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\\nSOFTWARE. \\n\\n'+\n"
"'LISCENSE FOR POLYSHELL:MIT License\\n\\nCopyright (c) 2022 llamasoft\\n\\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the \"Software\"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:\\n\\nThe above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.\\n\\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\\n\\n'\n"
";\n"
"\n"
"\n"
"var file_data_eval = null; // declare load files \n"
"var file_data = null; // not used\n"
"var _file_load_js_cd = '';\n"
"var _file_load_js_cd_file = '';\n"
"\n"
"function file_js_cd(){ return _file_load_js_cd;}\n"
"\n"
"function file_js_cd_file(){ return _file_load_js_cd_file;} \n"
"function _file_get_file_src( filename){\n"
"		filename =  \n"
"			filename.split('/').slice(0,-1).join('/')+'/';\n"
"		filename = filename.replace('//', '/');\n"
"		return filename;\n"
"	};	\n"
"\n"
"var _file_check_loaded_js = {};\n"
"function _file_check_add_filename(getStrfilename){\n"
"	getStrfilename=getStrfilename.split(\"\\\\\").join(\"/\")\n"
"		 .split(\"/\").slice(-1)[0];\n"
"	_file_check_loaded_js[getStrfilename]=true; }\n"
"function file_check_loaded( getStrfilename){\n"
"	getStrfilename=getStrfilename.split(\"\\\\\").join(\"/\")\n"
"		 .split(\"/\").slice(-1)[0];\n"
"	if(_file_check_loaded_js[getStrfilename] == undefined){\n"
"		file_input(\"Dependency for '\" + getStrfilename \n"
"			+ \"' requested and not found. Requested from: \"+\n"
"			file_js_cd() +_file_load_js_cd_file	); }	}\n"
"\n"
"\n"
"function file_load_js( get_cd, getFileName_or_list, \n"
"	__FOR_INTERAL_USE_load_non_embedded){ \n"
"\n"
"\n"
"	  if(typeof getFileName_or_list == \"object\"){ \n"
"		var f = getFileName_or_list;\n"
"	  	for(var i=0; i< f.length; i+=1){ file_load_js(get_cd, f[i],\n"
"			__FOR_INTERAL_USE_load_non_embedded); } \n"
"		return 1; };\n"
"\n"
"	   var getFileName = getFileName_or_list;\n"
"	   if( getFileName == undefined){ getFileName = ''; } \n"
"	   if(getFileName.search('/') == -1){ \n"
"	   	getFileName = './'+getFileName;}\n"
"	   var f = file_load( get_cd, getFileName, \n"
"				__FOR_INTERAL_USE_load_non_embedded);\n"
"	   if(f==null){return 0;\n"
"	   }else{\n"
"		if( !_file_load__last_load_from_embedded){\n"
"	   		f = _file_preprocess_js(f);}\n"
" 	  };\n"
"	\n"
"	 _file_check_add_filename(getFileName);	\n"
"\n"
"	   var caught_src_dir = _file_load_js_cd;\n"
"	   var caught_src_file = _file_load_js_cd_file;\n"
"	   _file_load_js_cd_file = getFileName;\n"
"	   _file_load_js_cd =_file_get_file_src(get_cd +getFileName); \n"
"\n"
" 	   try{\n"
"		if( f.search(\"#\"+\"IF_C_VERSION\")!= -1){\n"
"			 f = f.split(\"#\"+\"IF_C_VERSION\")[1]; }\n"
"		new Function('return this;')().eval(f);\n"
"		if(file_data_eval != null){\n"
"			file_data_eval(); file_data_eval = null; }\n"
"	   }catch(e){ // below is a check for if 'draw' isn't there.\n"
"		file_debug_printf('JS, ERROR, ' +  \n"
"			+ 'Last [file_treeload_js()] call was:  \\n ' +\n"
"			+ file_js_cd_file() + '\\n'+\n"
"			   'ERROR:' +e \n"
"			+'\\n\\nif error is in that file, linetext = \\n '+\n"
"			'Line:' + e.lineNumber + ' : \\n' \n"
"			+ f.split( '\\n')[e.lineNumber-1]);\n"
"		file_debug_scanf();\n"
"	   } \n"
"	   _file_load_js_cd = caught_src_dir;\n"
"	   _file_load_js_cd_file = caught_src_file;\n"
"	return 1; }; \n"
"\n"
"\n"
"\n"
"function file_treeload_js( get_cd, getFileName ){\n"
"\n"
"\n"
"\n"
"	var splitname = getFileName.split('/');\n"
"	var len = splitname.length;\n"
"	for( i=0; i< splitname.length; i+=1){\n"
"	   splitname.slice(i,len).join('/');\n"
"	   if( file_load_js('',splitname.slice(i,len).join('/') )){\n"
"		return 1; }\n"
"	   if( file_load_js( '../',splitname.slice(i,len).join('/') )){\n"
"		return 1;} }\n"
"	return 0; }\n"
"\n"
"function file_run_js_debug( getStr){\n"
"		var f = getStr;\n"
"		try{\n"
"			new Function('return this;')().eval(f);\n"
"			if(file_data_eval != null){\n"
"			   file_data_eval(); file_data_eval = null; }\n"
"		   }catch(e){ \n"
"			file_debug_printf('JS, ERROR, ' +  \n"
"			+ 'Last [file_treeload_js()] call was:  \\n ' +\n"
"			+ file_js_cd_file() + '\\n'+\n"
"			   'ERROR:' +e \n"
"			+'\\n\\nif error is in that file, linetext = \\n '+\n"
"			'Line:' + e.lineNumber + ' : \\n' \n"
"			+ f.split( '\\n')[e.lineNumber-1]);\n"
"			file_debug_scanf();\n"
"	   } \n"
"	}\n"
"\n"
"function file_load_js_nodebug( get_cd, getFileName){\n"
"\n"
"	   var f = file_load( get_cd,  getFileName);\n"
"	   if(f==null){return 0;\n"
"	   }else{\n"
"	   	f = _file_preprocess_js(f);\n"
" 	  	} \n"
"	   var caught_src_dir = _file_load_js_cd;\n"
"	   var caught_src_file = _file_load_js_cd_file;\n"
"	   _file_load_js_cd_file = getFileName;\n"
"	   _file_load_js_cd =_file_get_file_src(get_cd +getFileName); \n"
"	   new Function('return this;')().eval(f);\n"
"  	   _file_load_js_cd = caught_src_dir;\n"
"	   _file_load_js_cd_file = caught_src_file;\n"
"	   \n"
"	   return 1;	  \n"
"	};\n"
"\n"
"\n"
"function file_load_js_data( get_cd, getFileName){\n"
"\n"
"\n"
"\n"
"	   var  f = file_load( get_cd,  getFileName);\n"
"	   if(f==null){return 0;\n"
"	   }else{ return f.split(FILE_MULTILINE_CHAR)[1];}  \n"
"	}\n"
"\n"
"function file_save( get_cd, getFileName, getData){\n"
"		if( getData == undefined){ \n"
"			getData = getFileName; getFileName = ''; } \n"
"		_file_save(get_cd + getFileName, getData);\n"
"	}\n"
"\n"
"function file_log( getTextIn){\n"
"\n"
"\n"
"		file_debug_printf('\\n'+file_js_cd_file()\n"
"			.split('/').pop()+ \n"
"		': '+getTextIn +'\\n');\n"
"	};\n"
"\n"
"function file_log_input( getTextIn){\n"
"\n"
"\n"
"		file_debug_printf('\\n'+file_js_cd_file()\n"
"			.split('/').pop()+ \n"
"		': '+getTextIn +'\\n');\n"
"		return file_debug_scanf();\n"
"	};\n"
" \n"
"function file_input( getTextIn, g1, g2, g3, g4, g5, g6, g7, g8, g9, g10){\n"
"\n"
"\n"
"\n"
"		var a = [g1, g2, g3, g4, g5, g6, g7, g8, g9, g10];\n"
"		var b =\"\";\n"
"		for(var i=0; i< a.length; i+=1){ \n"
"			if(a[i]!=undefined){b+= \" \"+a[i];}}\n"
"		file_debug_printf(getTextIn+ b +'\\n');\n"
"		return file_debug_scanf();\n"
"	};\n"
"\n"
"\n"
" \n"
"var file_argument_paramsget = function( \n"
"		get_1_char_prefixes_str, get_list_params_to_get ){\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
" \n"
"	var i =1; // param 0 is filename\n"
"	var ret_array = []; var reading_tag = 0;\n"
"\n"
"	while(file_argument_get(i).length != 0){\n"
"		if(reading_tag == 1){\n"
"		    if( get_1_char_prefixes_str.indexOf(\n"
"			    file_argument_get(i)[0]) == -1){\n"
"				ret_array.push( file_argument_get(i) );\n"
"		    }else{ \n"
"				reading_tag = 0;}	\n"
"		}\n"
"		if(reading_tag == 0){\n"
"		   for( var j=0; j< get_list_params_to_get.length; j+=1){\n"
"		     \n"
"\n"
"		      if(get_list_params_to_get[j] == file_argument_get(i)){\n"
"		  	reading_tag =1;\n"
"\n"
"			if( ret_array.length ==0 ){ \n"
"				ret_array.push( file_argument_get(i));}\n"
"			break;\n"
"		   } }\n"
"		}	\n"
"	    i+=1; }\n"
"	return ret_array;\n"
"}\n"
"\n"
" \n"
"var file_arguments_get_filelist_from_params = function( ){\n"
"\n"
"\n"
"\n"
"	var arg_src_files = \n"
"	    file_argument_paramsget(\"-\", [\"-I\", \"-i\", \"-input\", \"--input\"]);\n"
"	var arg_src_dirs_all_files = \n"
"	    file_argument_paramsget(\"-\", [\"-Idir\", \"-idir\" ]);\n"
"	var arg_src_dirs_js_only = \n"
"	    file_argument_paramsget(\"-\", [\"-Idir_js\", \"-idir_js\" ]);\n"
" \n"
"\n"
"	arg_src_files.shift(); \n"
"	arg_src_dirs_all_files.shift(); arg_src_dirs_js_only.shift();\n"
"	\n"
"\n"
"	for(var i=0; i< arg_src_files; i+=1){\n"
"		arg_src_files[i]= file_dir_cd() + arg_src_files[i];}\n"
"	for(var i =0; i< arg_src_dirs_all_files.length; i+=1){ \n"
"		var tmpfiles =file_dir_search(\n"
"			file_dir_cd()+ arg_src_dirs_all_files[i], 0);\n"
"		if(tmpfiles != null){ \n"
"			arg_src_files = arg_src_files.concat(tmpfiles); } }\n"
"	for(var i =0; i< arg_src_dirs_js_only.length; i+=1){ \n"
"	  var tmpfiles =file_dir_search( \n"
"	\n"
"		  file_dir_cd()+arg_src_dirs_js_only[i], 0,[\"js$\"]);\n"
"	  \n"
"	  if(tmpfiles != null){ \n"
"			arg_src_files = arg_src_files.concat(tmpfiles); } }\n"
"	\n"
"	\n"
"\n"
"	return arg_src_files;\n"
"}\n"
"\n"
"var _file_core_js_cd = '.';\n"
"var _cd_param = file_argument_paramsget('-', ['-file_core_js_cd']);\n"
"if( _cd_param.length>=2){  \n"
"	if(file_dir( \"./\", _cd_param[1])!= 0){ \n"
"		_file_core_js_cd = _cd_param[1]; } }\n"
" \n"
"function file_core_js_cd( ){ return _file_core_js_cd + \"/\"; }\n"
"\n"
"\n"
"\n"
" \n"
"var file_pull_all_data_from_filelist = function(getFileList,\n"
"	OPTIONAL_remove_comments_from_js){\n"
"\n"
"\n"
"	var return_list =[];\n"
"	if( OPTIONAL_remove_comments_from_js){\n"
"		for(var i=0; i< getFileList.length; i+=1){\n"
"			var l = getFileList[i];\n"
"			if( l[l.length -2] ==\"j\" && l[l.length -1]==\"s\"){\n"
"			  return_list.push( \n"
"				_file_preprocess_js(\n"
"				file_scrub_comments(file_load(l)))  );\n"
"			}else{ return_list.push( file_load(l));  } }\n"
"		return return_list;\n"
"	}\n"
"	for(var i=0; i< getFileList.length; i+=1){\n"
"		return_list.push( file_load(getFileList[i]));	}\n"
"	return return_list;\n"
"}\n"
" \n"
"var file_scalpel_data = function( file_name, textblock_to_insert_text_between){\n"
"	var tmpfileText = file_load(file_name).split(\n"
"		textblock_to_insert_text_between);\n"
"	if(tmpfileText.length > 2){ return tmpfileText[1]; }\n"
"	return \"\";\n"
"}\n"
" \n"
"var file_inject_data_singleblock = function( str_to_inject, file_name, textblock_to_insert_text_between ){\n"
"\n"
"	var tmpfileText = file_load(file_name).split(\n"
"		textblock_to_insert_text_between);\n"
"	if(tmpfileText.length > 2){ \n"
"		tmpfileText = tmpfileText[0] + \n"
"			textblock_to_insert_text_between +\n"
"			'\\n'+str_to_inject+ '\\n' +\n"
"			textblock_to_insert_text_between +\n"
"			tmpfileText.pop(); }\n"
"	file_save(file_name, tmpfileText );\n"
"}\n"
"\n"
"\n"
"function _file_load_save_dialog_input( preface_text){\n"
"	_file_save_dialog_prev.dir = file_dir_cd();\n"
"	_file_save_dialog_prev.js_dir = file_js_cd();\n"
"\n"
"	var f = _file_save_dialog_prev;\n"
"	var tmp_names_list = \"\";\n"
"	for(var i=0; i< f.length; i+=1){\n"
"		tmp_names_list += i + \": \" + f[i]+ \"\\n\";}\n"
"	var tmp_input =  file_input(\n"
"		preface_text + \"\\n\"+ (\"\\n\" + \n"
" \"( you can typically drop the file or dir to terminal to get the name) \\n\" + \n"
" \"Common and prev save locs (copy and paste is your friend)\\n\" + \n"
" \"Common files ( '1:' gets substituted for the entry below) \\n\" + \n"
" \"\") +\n"
"   		\"dir: \" + f.dir + \"\\n\" + \n"
"		\"js_dir: \" + f.js_dir + \"\\n\"+\n"
"		tmp_names_list);\n"
"	var tmp_keys = Object.keys(_file_save_dialog_prev);\n"
"	for(var i=0; i< tmp_keys.length; i+=1){\n"
"		if(tmp_input.indexOf(tmp_keys[i] + \":\" )==0){\n"
"			tmp_input = _file_save_dialog_prev[tmp_keys[i]] +\n"
"				tmp_input.split(\":\").slice(1).join(\":\");\n"
"			tmp_input.replace( tmp_keys[i]+\":\", \n"
"				_file_save_dialog_prev[tmp_keys[i]]);}	}\n"
"	_file_save_dialog_prev.unshift(tmp_input.trim());\n"
"	_file_save_dialog_prev.pop(); \n"
"	return _file_save_dialog_prev[0];}\n"
"	\n"
"function file_load_dialog( ){ \n"
"\n"
"\n"
"	\n"
"\n"
"	return file_load( _file_load_save_dialog_input(\n"
"		\"Input fileName to load too.\").trim());	}\n"
"\n"
"var _file_save_dialog_prev = []; _file_save_dialog_prev[6] = undefined;\n"
"	\n"
"function file_save_dialog( getData ){ \n"
"\n"
"	\n"
"	return file_save( _file_load_save_dialog_input(\n"
"		   \"Input fileName to save too.\").trim(),\"\",getData);	}\n"
"\n"
"var _file_copybox_cmdcaught = \"\";\n"
"\n"
"function file_copybox( getTextToShow, default_command_blank_str_to_reset ){ \n"
"	\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"		\n"
"	if(default_command_blank_str_to_reset !== undefined){\n"
"	 _file_copybox_cmdcaught = default_command_blank_str_to_reset;}\n"
"	var docname = \"tmpz251.txt\"; //random tmp-name\n"
"	file_save(file_dir_cd(), docname , getTextToShow );\n"
"\n"
"	tmp_copybox_confirmed = _file_copybox_cmdcaught;\n"
"	while(_file_copybox_cmdcaught == \"\" || \n"
"		tmp_copybox_confirmed != _file_copybox_cmdcaught){\n"
"\n"
"	 	 _file_copybox_cmdcaught  =\n"
"			file_input((\"\\n\" + \n"
" \"Enter command to launch a text document\\n\" + \n"
" \"(eg: notepad for windows, leafpad for linux (after confirmation, \\n\" + \n"
" \"	 will be caught, so will need to close app to redefine. ) ) \\n\" + \n"
" \"\")).trim(); \n"
"		tmp_copybox_confirmed = \n"
"			file_input(\"please type it again\").trim();	}\n"
"	file_system(_file_copybox_cmdcaught+\" \"+file_dir_cd()+docname );\n"
"	var ret_string= file_load(file_dir_cd(),docname);\n"
"	file_remove(file_dir_cd(),docname);\n"
"	_update_mouse_end();\n"
"	return ret_string;\n"
"}\n"
"\n"
"function system_return_output(getCmd){\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"	var tmpCd = file_dir_cd();\n"
"\n"
"	var docname = \"tmpz251.txt\"; var errordocname = \"tmpze12.txt\";\n"
"	file_system(getCmd+' > \"'+ tmpCd +docname \n"
"			+'\" 2> \"'+  tmpCd +errordocname + '\"');\n"
"	var outRtrnErrorArray= [file_load( tmpCd ,docname), \n"
"			file_load( tmpCd ,errordocname)];\n"
"	\n"
"	file_remove( tmpCd ,docname);\n"
"	file_remove( tmpCd ,errordocname);\n"
"	return outRtrnErrorArray;\n"
"}\n"
" "
//INJECT_C_CODE_FROM_FILE_HERE//
	;
}

///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
/////////  Duktape port, does nothing otherwise ///////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////

//#if defined(DUK_VERSION)
#if defined(DUK_VERSION)
///////////////////////////////
// in js: function file_system(filename)... return 0 no errors, 1 error, 
//  system runs a system command... beware;
//API_TAG// 
// file_system( system_command) -- runs a system command, 
// 	platform dependant
//API_TAG// 
static duk_ret_t js_port_duktape_file_system(duk_context *ctx){
	duk_push_int(ctx, system((char *)duk_to_string(ctx, 0)));  
	return 0; } /* one return value */ 
static duk_ret_t js_port_duktape_file_remove(duk_context *ctx){
	duk_push_int(ctx, remove((char *)duk_to_string(ctx, 0)));  
	return 0; } /* one return value */ 
///////////////////////////////
// file_debug_scanf(int max_char_size_of_textblock)
// 	(EDIT- returns 'null' for end of file, so can 
// 		accept pipes)
static duk_ret_t js_port_duktape_file_debug_scanf(duk_context *ctx) {
	int DEFAULT_MAX_SCANF = 3000;
	if( (int)duk_to_int(ctx, 0)<10){ 
		DEFAULT_MAX_SCANF = duk_to_int(ctx, 0); }
	//char tmp_input_block[ DEFAULT_MAX_SCANF ];
	char *tmp_input_block = 
		(char*) malloc( DEFAULT_MAX_SCANF * sizeof(char));	

	if( NULL==fgets(tmp_input_block, duk_to_int(ctx, 0)-1, stdin )){
		duk_push_null(ctx);
	}else{	
		duk_push_string(ctx, (char * ) tmp_input_block); };

	free(tmp_input_block);
	return 1;  /* one return value */ 
}
///////////////////////////////
// in js: function printf(filename)... return nothing;
static duk_ret_t js_port_duktape_file_debug_printf(duk_context *ctx) {
	file_debug_printf( (char *)duk_to_string(ctx, 0));
	return 0;  /* one return value */ 
}
static duk_ret_t js_port_duktape_file_debug_printfERR(duk_context *ctx) {
	file_debug_printf_ERROR( (char *)duk_to_string(ctx, 0));
	return 0;  /* one return value */ 
}
///////////////////////////////
// in js: function save(filename)... return nothing;
static duk_ret_t js_port_duktape_file_save(duk_context *ctx) {
	if( file_save( (char *)duk_to_string(ctx, 0), 
			(char *)duk_to_string(ctx, 1) )){
		duk_push_int(ctx, 1);	}
	duk_push_int(ctx, 0);  
	return 0;  /* one return value */ 
}
///////////////////////////////
// in js: function load(filename)... return string
static duk_ret_t js_port_duktape_file_load(duk_context *ctx) {
	//char *c = file_load( (char*)duk_to_string(ctx, 0));

	int filesize = file_load_get_size_or_neg_one(
			(char*)duk_to_string(ctx, 0) ) ;
	if(filesize == -1){  //One added above
		duk_push_null(ctx);
		return 1;}
	
	// needed to change to deal with large files, 
	// malloc works for that
	char *c = (char*)malloc(filesize +1);
	file_load__use_get_size_beforehand(
			c, (char*)duk_to_string(ctx, 0), filesize);


	
	if(c == NULL){  duk_push_null(ctx); 
		duk_push_null(ctx);
		free(c);
		return 1;}

	
	duk_push_string(ctx, c);
	free(c);

	return 1;
}
///////////////////////////////
// in js: function file_argument_get(filename)... 
//  returns argument or ""
static duk_ret_t js_port_duktape_file_argument_get(duk_context *ctx) {
	duk_push_string( ctx, 
		file_argument_get( duk_to_int(ctx, 0)));
	return 1;  /* one return value */ 
}
//API_TAG//
////////////////////////////////
// file_exit (c only) exit, terminates c program
static duk_ret_t js_port_duktape_exit(duk_context *ctx) {
	exit(0); // for number of errors, NOT set
	return 1;  /* one return value */ 
}
//API_TAG//

// this does NOT use argument... it should run without that, 
// incase for some reason arguments cannot be used
void _file_duktape_port_settup( duk_context *ctx){

	duk_push_c_function(ctx, js_port_duktape_file_debug_scanf, 1);
	duk_put_global_string(ctx, "_file_debug_scanf");
	//duk_push_string( // file_debug_scanf( optional_size_of_txt_bock);
	//	ctx, file_debug_scanf_js__duktape_funct());
	//duk_eval_noresult(ctx); 
	

	duk_push_c_function(ctx, js_port_duktape_file_system, 1);
	duk_put_global_string(ctx, "file_system");
	duk_push_c_function(ctx, js_port_duktape_file_remove, 1);
	duk_put_global_string(ctx, "_file_remove");
	duk_push_c_function(ctx, js_port_duktape_file_debug_printf, 1);
	duk_put_global_string(ctx, "file_debug_printf");
	duk_push_c_function(ctx, js_port_duktape_file_debug_printfERR, 1);
	duk_put_global_string(ctx, "file_debug_printf_ERROR");
	duk_push_c_function(ctx, js_port_duktape_file_load, 1);
	duk_put_global_string(ctx, "_file_load");
	duk_push_c_function(ctx, js_port_duktape_file_save, 2);
	duk_put_global_string(ctx, "_file_save");
	duk_push_c_function(ctx, js_port_duktape_file_argument_get, 1);
	duk_put_global_string(ctx, "file_argument_get");

	duk_push_c_function(ctx, js_port_duktape_exit, 0);
	duk_put_global_string(ctx, "file_exit");

	duk_push_string( // file_load_js
			// file_load_js_nodebug
			// file_load_js_data
			ctx, file_load_js__duktape_funct() ) ;
		duk_eval_noresult(ctx); 
}
// with arguments.
void file_duktape_port_settup( duk_context *ctx,  
		int numb_of_args, char** args_list){
	_file_duktape_port_settup( ctx);
	file_argument_settup( numb_of_args, args_list);
	
}
#endif 
