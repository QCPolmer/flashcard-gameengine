
#include <stdio.h>
#include <stdlib.h>
// SEE DUKTAPE BINDING AT END OF FILE
#if defined(DUK_VERSION)
void file_duktape_port_settup( duk_context *ctx,  
		int numb_of_args, char** args_list);
#endif 

//FOR RUNNING A JS FILE IN DUKTAPE:
// see the js_port_duktape library, it modifies 
// the js file. This allows the file to use 
// the sleep function from js_html AND this older 
// verson of js!
// (basically, the 'await sleep' adn 'async function' things
// 	get the 'await' and 'async' removed (easer to do in js))
void file_debug_scanf(int max_char_size_of_textblock){
	// THIS IS DECLAIRED IN DUKTAPE VERSION... 
	// IT'S file_debug_scanf_js__duktape_funct
	// for the js wrapper (I had to make one paramiter optional)
	}
void file_debug_printf(char * printThis){
	printf("%s", printThis); }
//API_TAG// prints to ERROR, for C-version of game engine ONLY
void file_debug_printf_ERROR(char * printThis){
//API_TAG//
	fprintf(stderr, "%s", printThis); }
int file_load_get_size_or_neg_one(char * filename){
	FILE* f = fopen(filename, "r");
	if(f == NULL){  return -1;}
	
	int count_tot = 0;
	while(fgetc(f) != EOF){ count_tot += 1;}
	rewind(f);

	fclose(f); f = NULL;
	return count_tot; // one for adding the '\0'
}
int file_load__use_get_size_beforehand(
		char * alter_this_string, char * filename, 
		int chars_to_read__PRECALC_THIS){
	FILE* f = fopen(filename, "r");
	if(f == NULL){  return 0;}

	
	int count_tot= chars_to_read__PRECALC_THIS;
	int count = 0;
	while( count< count_tot){ 
		alter_this_string[count] = fgetc(f); count+=1; }
	alter_this_string[count] = '\0'; ///terminating string
	// '\0' != "\0"!!!!
	fclose(f); f = NULL;
	return 1;
}
int file_save(char * filename, char * text){
	FILE* f = fopen( filename, "w");
	
	if(f == NULL){ return 0;  
	}else{ fprintf(f, "%s", text );} 
	fclose(f);
	return 1;
}


int _file_argument_number=0;
char ** _file_argument_list;
//API_TAG//
char* file_argument_get( int arg_to_get){
// returns the command line argument argument or ""; 
// For making command line stuff, try file_argument_paramsget 	//API_TAG//
	if(_file_argument_number <= arg_to_get){ return ""; }
	return (char*)_file_argument_list[ arg_to_get ]; }
void file_argument_settup( int numb_of_args, char** args_list){
	_file_argument_list = args_list;
	_file_argument_number = numb_of_args;	
	return; }


// LOOK IN THE file_INJECT_C.js file! Running m.js there will
//  generate this code (AND test it FIRST!!! A basic 'does it compile')
const char * file_load_js__duktape_funct(){
	return
	"var FILE_MULTILINE_CHAR='`';"


	//INJECT_C_CODE_FROM_FILE_HERE//
"function file_debug_scanf(a){return\"number\"!=typeof a&&(a=1e3),_file_debug_scanf(a)}function _file_embedded_load(a){if(void 0==_file_embedded){_file_embedded={};for(var b=one_js_embeded_file().split(FILE_EMBEDED_SPLIT_BY),c=1;c<b.length;c+=2)_file_embedded[b[c]]=b[c+1]}return _file_embedded[a]}function file_remove(a,b){return void 0!=b&&(a+=b),_file_remove(a)}function file_load_js_noembed(a,b){return file_load_js(a,b,1)}function file_load_noembed(a,b){return file_load(a,b,1)}function file_treeload_js_noembed(a,b){return file_treeload_js(void 0==b?a:a+b)}function file_load(a,b,c){if(_file_load__last_load_from_embedded=!1,void 0!==b){for(var d=b;-1!=\"./\\\\\".indexOf(d[0]);)d=d.substring(1);if(1!=c&&void 0!==_file_embedded_load(d))return _file_load__last_load_from_embedded=!0,_file_embedded_load(d)}else b=\"\";return _file_load(a+b)}function file_scrub_comments(a,b){a=a.split(\"\\n\");for(var c=a.length-2;c>0;c-=1){var d=a[c].trim();\"/\"==d[0]&&\"/\"==d[1]&&a.splice(c,1)}return a.join(\"\\n\")}function _file_preprocess_js(a){var b=a;return b=b.split(\"\\r\\n\").join(\"\\n\").split(\"\\r\").join(\"\\n\").split(\"await \").join(\"\").split(\"async function\").join(\"function\"),b=_file_multiline_handler(b,FILE_MULTILINE_CHAR,'\\\\n\" + \\n \"')}function _file_multiline_handler(a,b,c){if(\"\"==b)var d=\"@#$$$$^^&&**\",e=d+a+d;else{var e=a;d=b}if(-1!=e.indexOf(d)){for(var f=e.split(d),g=1;g<f.length;g+=2)f[g]='(\"'+f[g].split('\"').join('\\\\\"').split(\"\\n\").join(c)+'\")';e=f.join(\"\")}return e}function file_js_cd(){return _file_load_js_cd}function file_js_cd_file(){return _file_load_js_cd_file}function _file_get_file_src(a){return a=a.split(\"/\").slice(0,-1).join(\"/\")+\"/\",a=a.replace(\"//\",\"/\")}function _file_check_add_filename(a){a=a.split(\"\\\\\").join(\"/\").split(\"/\").slice(-1)[0],_file_check_loaded_js[a]=!0}function file_check_loaded(a){a=a.split(\"\\\\\").join(\"/\").split(\"/\").slice(-1)[0],void 0==_file_check_loaded_js[a]&&file_input(\"Dependency for '\"+a+\"' requested and not found. Requested from: \"+file_js_cd()+_file_load_js_cd_file)}function file_load_js(a,b,c){if(\"object\"==typeof b){for(var d=b,e=0;e<d.length;e+=1)file_load_js(a,d[e],c);return 1}var f=b;void 0==f&&(f=\"\"),-1==f.search(\"/\")&&(f=\"./\"+f);var d=file_load(a,f,c);if(null==d)return 0;_file_load__last_load_from_embedded||(d=_file_preprocess_js(d)),_file_check_add_filename(f);var g=_file_load_js_cd,h=_file_load_js_cd_file;_file_load_js_cd_file=f,_file_load_js_cd=_file_get_file_src(a+f);try{-1!=d.search(\"#IF_C_VERSION\")&&(d=d.split(\"#IF_C_VERSION\")[1]),new Function(\"return this;\")().eval(d),null!=file_data_eval&&(file_data_eval(),file_data_eval=null)}catch(a){file_debug_printf(\"JS, ERROR, NaN\"+ +file_js_cd_file()+\"\\nERROR:\"+a+\"\\n\\nif error is in that file, linetext = \\n Line:\"+a.lineNumber+\" : \\n\"+d.split(\"\\n\")[a.lineNumber-1]),file_debug_scanf()}return _file_load_js_cd=g,_file_load_js_cd_file=h,1}function file_treeload_js(a,b){var c=b.split(\"/\"),d=c.length;for(i=0;i<c.length;i+=1){if(c.slice(i,d).join(\"/\"),file_load_js(\"\",c.slice(i,d).join(\"/\")))return 1;if(file_load_js(\"../\",c.slice(i,d).join(\"/\")))return 1}return 0}function file_run_js_debug(a){var b=a;try{new Function(\"return this;\")().eval(b),null!=file_data_eval&&(file_data_eval(),file_data_eval=null)}catch(a){file_debug_printf(\"JS, ERROR, NaN\"+ +file_js_cd_file()+\"\\nERROR:\"+a+\"\\n\\nif error is in that file, linetext = \\n Line:\"+a.lineNumber+\" : \\n\"+b.split(\"\\n\")[a.lineNumber-1]),file_debug_scanf()}}function file_load_js_nodebug(a,b){var c=file_load(a,b);if(null==c)return 0;c=_file_preprocess_js(c);var d=_file_load_js_cd,e=_file_load_js_cd_file;return _file_load_js_cd_file=b,_file_load_js_cd=_file_get_file_src(a+b),new Function(\"return this;\")().eval(c),_file_load_js_cd=d,_file_load_js_cd_file=e,1}function file_load_js_data(a,b){var c=file_load(a,b);return null==c?0:c.split(FILE_MULTILINE_CHAR)[1]}function file_save(a,b,c){void 0==c&&(c=b,b=\"\"),_file_save(a+b,c)}function file_log(a){file_debug_printf(\"\\n\"+file_js_cd_file().split(\"/\").pop()+\": \"+a+\"\\n\")}function file_log_input(a){return file_debug_printf(\"\\n\"+file_js_cd_file().split(\"/\").pop()+\": \"+a+\"\\n\"),file_debug_scanf()}function file_input(a,b,c,d,e,f,g,h,i,j,k){for(var l=[b,c,d,e,f,g,h,i,j,k],m=\"\",n=0;n<l.length;n+=1)void 0!=l[n]&&(m+=\" \"+l[n]);return file_debug_printf(a+m+\"\\n\"),file_debug_scanf()}function file_core_js_cd(){return _file_core_js_cd+\"/\"}function _file_load_save_dialog_input(a){_file_save_dialog_prev.dir=file_dir_cd(),_file_save_dialog_prev.js_dir=file_js_cd();for(var b=_file_save_dialog_prev,c=\"\",d=0;d<b.length;d+=1)c+=d+\": \"+b[d]+\"\\n\";for(var e=file_input(a+\"\\n\\n( you can typically drop the file or dir to terminal to get the name) \\nCommon and prev save locs (copy and paste is your friend)\\nCommon files ( '1:' gets substituted for the entry below) \\ndir: \"+b.dir+\"\\njs_dir: \"+b.js_dir+\"\\n\"+c),f=Object.keys(_file_save_dialog_prev),d=0;d<f.length;d+=1)0==e.indexOf(f[d]+\":\")&&(e=_file_save_dialog_prev[f[d]]+e.split(\":\").slice(1).join(\":\"),e.replace(f[d]+\":\",_file_save_dialog_prev[f[d]]));return _file_save_dialog_prev.unshift(e.trim()),_file_save_dialog_prev.pop(),_file_save_dialog_prev[0]}function file_load_dialog(){return file_load(_file_load_save_dialog_input(\"Input fileName to load too.\").trim())}function file_save_dialog(a){return file_save(_file_load_save_dialog_input(\"Input fileName to save too.\").trim(),\"\",a)}function file_copybox(a,b){void 0!==b&&(_file_copybox_cmdcaught=b);var c=\"tmpz251.txt\";for(file_save(file_dir_cd(),c,a),tmp_copybox_confirmed=_file_copybox_cmdcaught;\"\"==_file_copybox_cmdcaught||tmp_copybox_confirmed!=_file_copybox_cmdcaught;)_file_copybox_cmdcaught=file_input(\"\\nEnter command to launch a text document\\n(eg: notepad for windows, leafpad for linux (after confirmation, \\n\\t will be caught, so will need to close app to redefine. ) ) \\n\").trim(),tmp_copybox_confirmed=file_input(\"please type it again\").trim();file_system(_file_copybox_cmdcaught+\" \"+file_dir_cd()+c);var d=file_load(file_dir_cd(),c);return file_remove(file_dir_cd(),c),_update_mouse_end(),d}function system_return_output(a){var b=file_dir_cd(),c=\"tmpz251.txt\",d=\"tmpze12.txt\";file_system(a+' > \"'+b+c+'\" 2> \"'+b+d+'\"');var e=[file_load(b,c),file_load(b,d)];return file_remove(b,c),file_remove(b,d),e}var _file_embedded=void 0;if(void 0==one_js_embeded_file)var one_js_embeded_file=function(){return\"\"};var FILE_EMBEDED_SPLIT_BY=\"//EMBEDED_CODE_BLOCK//\",_file_load__last_load_from_embedded=!1,file_duktape_license='\\nThis game-engine is licensed under MIT liscense, \\nhowever, it uses 3 different libraries (also MIT liscense):\\n-- the licenses are baked into any generated executable generated,\\n\\tvia running via terminal with param -duktape_license\\n\\n///////////////////////////////////////\\n/////////////////////////////////////////////\\n/// LICENSE FOR FLASHCARD GAME ENGINE, EXCLUDING ADDITIONAL COMPONENTS\\n///  (see below for additional licenses, all MIT)\\n///////////////////////////////////////\\n/////////////////////////////////////////////\\n\\nCopyright 2026 Harrison Mansolf\\n\\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the \"Software\"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:\\n\\nThe above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.\\n\\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\\n\\n\\n\\n///////////////////////////////////////\\n/////////////////////////////////////////////\\n/////////// LICENSES FOR COMPONENTS:\\n//////////////////////////////////\\n////////////////////////////////////////\\nLICENSE FOR DUKTAPE JS INTERPRETER https://duktape.org/, WHICH IS USED IN THE SOURCE CODE \\n\\n\\n The MIT License (MIT) \\n\\nCopyright (c) 2013-present, Duktape authors (see AUTHORS.rst)\\n\\nPermission is hereby granted, free of charge, to any person obtaining a copy\\nof this software and associated documentation files (the \"Software\"), to deal\\nin the Software without restriction, including without limitation the rights\\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\\ncopies of the Software, and to permit persons to whom the Software is\\nfurnished to do so, subject to the following conditions:\\n\\nThe above copyright notice and this permission notice shall be included in\\nall copies or substantial portions of the Software.\\n\\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN \\nTHE SOFTWARE. \\n\\n\\nLICENSE FOR windows_dirent.h (https://github.com/tronkko/dirent):\\n\\nThe MIT License (MIT)\\n\\nCopyright (c) 1998-2019 Toni Ronkko\\n\\nPermission is hereby granted, free of charge, to any person obtaining a copy\\nof this software and associated documentation files (the \"Software\"), to deal\\nin the Software without restriction, including without limitation the rights\\nto use, copy, modify, merge, publish, distribute, sublicense, and/or sell\\ncopies of the Software, and to permit persons to whom the Software is\\nfurnished to do so, subject to the following conditions:\\n\\nThe above copyright notice and this permission notice shall be included in all\\ncopies or substantial portions of the Software.\\n\\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\\nIMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\\nFITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\\nAUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\\nLIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\\nOUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE\\nSOFTWARE. \\n\\nLISCENSE FOR POLYSHELL:MIT License\\n\\nCopyright (c) 2022 llamasoft\\n\\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the \"Software\"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:\\n\\nThe above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.\\n\\nTHE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\\n\\n',file_data_eval=null,file_data=null,_file_load_js_cd=\"\",_file_load_js_cd_file=\"\",_file_check_loaded_js={},file_argument_paramsget=function(a,b){for(var c=1,d=[],e=0;0!=file_argument_get(c).length;){if(1==e&&(-1==a.indexOf(file_argument_get(c)[0])?d.push(file_argument_get(c)):e=0),0==e)for(var f=0;f<b.length;f+=1)if(b[f]==file_argument_get(c)){e=1,0==d.length&&d.push(file_argument_get(c));break}c+=1}return d},file_arguments_get_filelist_from_params=function(){var a=file_argument_paramsget(\"-\",[\"-I\",\"-i\",\"-input\",\"--input\"]),b=file_argument_paramsget(\"-\",[\"-Idir\",\"-idir\"]),c=file_argument_paramsget(\"-\",[\"-Idir_js\",\"-idir_js\"]);a.shift(),b.shift(),c.shift();for(var d=0;d<a;d+=1)a[d]=file_dir_cd()+a[d];for(var d=0;d<b.length;d+=1){var e=file_dir_search(file_dir_cd()+b[d],0);null!=e&&(a=a.concat(e))}for(var d=0;d<c.length;d+=1){var e=file_dir_search(file_dir_cd()+c[d],0,[\"js$\"]);null!=e&&(a=a.concat(e))}return a},_file_core_js_cd=\".\",_cd_param=file_argument_paramsget(\"-\",[\"-file_core_js_cd\"]);_cd_param.length>=2&&0!=file_dir(\"./\",_cd_param[1])&&(_file_core_js_cd=_cd_param[1]);var file_pull_all_data_from_filelist=function(a,b,c){var d=[];if(b){for(var e=0;e<a.length;e+=1){var f=a[e];\"j\"==f[f.length-2]&&\"s\"==f[f.length-1]?null==c?d.push(_file_preprocess_js(file_scrub_comments(file_load(f)))):d.push(c(_file_preprocess_js(file_scrub_comments(file_load(f))))):d.push(file_load(f))}return d}for(var e=0;e<a.length;e+=1)d.push(file_load(a[e]));return d},file_scalpel_data=function(a,b){var c=file_load(a).split(b);return c.length>2?c[1]:\"\"},file_inject_data_singleblock=function(a,b,c){var d=file_load(b).split(c);d.length>2&&(d=d[0]+c+\"\\n\"+a+\"\\n\"+c+d.pop()),file_save(b,d)},_file_save_dialog_prev=[];_file_save_dialog_prev[6]=void 0;var _file_copybox_cmdcaught=\"\"; "
//INJECT_C_CODE_FROM_FILE_HERE//
	;
}

///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
/////////  Duktape port, does nothing otherwise ///////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////

//#if defined(DUK_VERSION)
#if defined(DUK_VERSION)
///////////////////////////////
// in js: function file_system(filename)... return 0 no errors, 1 error, 
//  system runs a system command... beware;
//API_TAG// 
// file_system( system_command) -- runs a system command, 
// 	platform dependant
//API_TAG// 
static duk_ret_t js_port_duktape_file_system(duk_context *ctx){
	duk_push_int(ctx, system((char *)duk_to_string(ctx, 0)));  
	return 0; } /* one return value */ 
static duk_ret_t js_port_duktape_file_remove(duk_context *ctx){
	duk_push_int(ctx, remove((char *)duk_to_string(ctx, 0)));  
	return 0; } /* one return value */ 
///////////////////////////////
// file_debug_scanf(int max_char_size_of_textblock)
// 	(EDIT- returns 'null' for end of file, so can 
// 		accept pipes)
static duk_ret_t js_port_duktape_file_debug_scanf(duk_context *ctx) {
	int DEFAULT_MAX_SCANF = 3000;
	if( (int)duk_to_int(ctx, 0)<10){ 
		DEFAULT_MAX_SCANF = duk_to_int(ctx, 0); }
	//char tmp_input_block[ DEFAULT_MAX_SCANF ];
	char *tmp_input_block = 
		(char*) malloc( DEFAULT_MAX_SCANF * sizeof(char));	

	if( NULL==fgets(tmp_input_block, duk_to_int(ctx, 0)-1, stdin )){
		duk_push_null(ctx);
	}else{	
		duk_push_string(ctx, (char * ) tmp_input_block); };

	free(tmp_input_block);
	return 1;  /* one return value */ 
}
///////////////////////////////
// in js: function printf(filename)... return nothing;
static duk_ret_t js_port_duktape_file_debug_printf(duk_context *ctx) {
	file_debug_printf( (char *)duk_to_string(ctx, 0));
	return 0;  /* one return value */ 
}
static duk_ret_t js_port_duktape_file_debug_printfERR(duk_context *ctx) {
	file_debug_printf_ERROR( (char *)duk_to_string(ctx, 0));
	return 0;  /* one return value */ 
}
///////////////////////////////
// in js: function save(filename)... return nothing;
static duk_ret_t js_port_duktape_file_save(duk_context *ctx) {
	if( file_save( (char *)duk_to_string(ctx, 0), 
			(char *)duk_to_string(ctx, 1) )){
		duk_push_int(ctx, 1);	}
	duk_push_int(ctx, 0);  
	return 0;  /* one return value */ 
}
///////////////////////////////
// in js: function load(filename)... return string
static duk_ret_t js_port_duktape_file_load(duk_context *ctx) {
	//char *c = file_load( (char*)duk_to_string(ctx, 0));

	int filesize = file_load_get_size_or_neg_one(
			(char*)duk_to_string(ctx, 0) ) ;
	if(filesize == -1){  //One added above
		duk_push_null(ctx);
		return 1;}
	
	// needed to change to deal with large files, 
	// malloc works for that
	char *c = (char*)malloc(filesize +1);
	file_load__use_get_size_beforehand(
			c, (char*)duk_to_string(ctx, 0), filesize);


	
	if(c == NULL){  duk_push_null(ctx); 
		duk_push_null(ctx);
		free(c);
		return 1;}

	
	duk_push_string(ctx, c);
	free(c);

	return 1;
}
///////////////////////////////
// in js: function file_argument_get(filename)... 
//  returns argument or ""
static duk_ret_t js_port_duktape_file_argument_get(duk_context *ctx) {
	duk_push_string( ctx, 
		file_argument_get( duk_to_int(ctx, 0)));
	return 1;  /* one return value */ 
}
//API_TAG//
////////////////////////////////
// file_exit (c only) exit, terminates c program
static duk_ret_t js_port_duktape_exit(duk_context *ctx) {
	exit(0); // for number of errors, NOT set
	return 1;  /* one return value */ 
}
//API_TAG//

// this does NOT use argument... it should run without that, 
// incase for some reason arguments cannot be used
void _file_duktape_port_settup( duk_context *ctx){

	duk_push_c_function(ctx, js_port_duktape_file_debug_scanf, 1);
	duk_put_global_string(ctx, "_file_debug_scanf");
	//duk_push_string( // file_debug_scanf( optional_size_of_txt_bock);
	//	ctx, file_debug_scanf_js__duktape_funct());
	//duk_eval_noresult(ctx); 
	

	duk_push_c_function(ctx, js_port_duktape_file_system, 1);
	duk_put_global_string(ctx, "file_system");
	duk_push_c_function(ctx, js_port_duktape_file_remove, 1);
	duk_put_global_string(ctx, "_file_remove");
	duk_push_c_function(ctx, js_port_duktape_file_debug_printf, 1);
	duk_put_global_string(ctx, "file_debug_printf");
	duk_push_c_function(ctx, js_port_duktape_file_debug_printfERR, 1);
	duk_put_global_string(ctx, "file_debug_printf_ERROR");
	duk_push_c_function(ctx, js_port_duktape_file_load, 1);
	duk_put_global_string(ctx, "_file_load");
	duk_push_c_function(ctx, js_port_duktape_file_save, 2);
	duk_put_global_string(ctx, "_file_save");
	duk_push_c_function(ctx, js_port_duktape_file_argument_get, 1);
	duk_put_global_string(ctx, "file_argument_get");

	duk_push_c_function(ctx, js_port_duktape_exit, 0);
	duk_put_global_string(ctx, "file_exit");

	duk_push_string( // file_load_js
			// file_load_js_nodebug
			// file_load_js_data
			ctx, file_load_js__duktape_funct() ) ;
		duk_eval_noresult(ctx); 
}
// with arguments.
void file_duktape_port_settup( duk_context *ctx,  
		int numb_of_args, char** args_list){
	_file_duktape_port_settup( ctx);
	file_argument_settup( numb_of_args, args_list);
	
}
#endif 
