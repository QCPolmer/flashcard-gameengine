// NEEDS TO HAVE grid IMPORTED, OR THIS WON'T RUN!!!
#if defined(DUK_VERSION)	
void draw_duktape_port_settup(duk_context *ctx);
#endif

char _draw_canvas[4000];  int _draw_canvas_width;   int _draw_canvas_length;
// NOTE: not sure how I did the height and width thing, they seem to 
// be reversed in canvas. 
int _draw_canvas_js_height =0; int _draw_canvas_js_width=0;
// available in JS:
//API_TAG// 
////// ALL THESE post/get stuff from the canvas (a txt-grid text string)
/////// I should be obvious which ones return something
// JS FUNCTS: 
// function draw_canvas_get_width(){ return draw_canvas_height;}
//function draw_canvas_get_height(){ return draw_canvas_width;}
char * draw_canvas_get(){ return _draw_canvas;} 
void draw_canvas_set( char* str ){ strcpy(_draw_canvas, str);}
void draw_settup_canvas_custom(int width, int height );
void draw_settup_canvas( );  //MAIN
	int DRAW_CANVAS_DFLT_WIDTH = 72; //THIS IS ONE OFF!!! 
	int DRAW_CANVAS_DFLT_HEIGHT = 24;
void draw_clear_canvas();
void draw( char* str, int x, int y, char trnsparent_or_0 );
//API_TAG//
void draw_grid( char* str, int x, int y, char trnsparent_or_0, 
		int length_NOT_IN_JS_VERSION );

	//js version is: draw_grid( str, x, y, transp_or_"", 
	// draw has same paramiters
/////////////////////////////////
void draw_settup_canvas_custom(int width, int height ){
	_draw_canvas_js_height = height; 
	_draw_canvas_js_width = width; 
		
	//clears it
	printf(
		"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
		"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
		"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
	
	//gridstr_scale(" ", _draw_canvas, height,width );
	gridstr_make( _draw_canvas, width, height);
	_draw_canvas_width = width;
	_draw_canvas_length = strlen(_draw_canvas); }
void draw_settup_canvas(){
	draw_settup_canvas_custom( 
		DRAW_CANVAS_DFLT_WIDTH, DRAW_CANVAS_DFLT_HEIGHT); }
void draw_clear_canvas(){ gridstr_fill( _draw_canvas, ' ', ""); }
// JS version does not use length
// draw_grid
void draw( char* str, int x, int y, char trnsparent_or_0 ){
	_gridstr_overlay_base(  //one size fits-all draw
		_draw_canvas, str,  	x, y, 	
		trnsparent_or_0,
		_draw_canvas_width, 0, 
		_draw_canvas_length, 0 );	}
void draw_grid( char* str, int x, int y, char trnsparent_or_0, 
		int length_NOT_IN_JS_VERSION ){
	_gridstr_overlay_base(  //one size fits-all draw
		_draw_canvas, str,  	x, y, 	
		trnsparent_or_0,
		_draw_canvas_width, 
			gridstr_0_under_50_or_width(str, 
				length_NOT_IN_JS_VERSION),  
		_draw_canvas_length, length_NOT_IN_JS_VERSION );	}


////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
/////////////// Ducktape Port //////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

#if defined(DUK_VERSION)

///////////////////////////////
// in js: draw_grid(str,x,y, transpChar_or_blank_str)... return nothing
// draw_grid_optim(IZED)
static duk_ret_t js_port_duktape_draw_grid(duk_context *ctx) {
	// the length is added via javascript in helper function 
	//  	see js_port_duktape_init 
	if(  (int)duk_get_length(ctx, 3) != 0){ // transp_char  
		draw_grid( (char*)duk_to_string(ctx, 0), 
			(int)duk_to_number(ctx, 1),
	       		(int)duk_to_number(ctx, 2),
			duk_to_string(ctx, 3)[0],
			(int)duk_to_number(ctx, 1));
	}else{
		draw_grid( (char *)duk_to_string(ctx, 0), 
			(int)duk_to_number(ctx, 1),
	       		(int)duk_to_number(ctx, 2),
	       		0,
			(int)duk_to_number(ctx, 1));	}
	return 0;  /* zero return value */
}
static duk_ret_t js_port_duktape_draw(duk_context *ctx) {
	// the length is added via javascript in helper function 
	//  	see js_port_duktape_init 
	if( strlen( (char*)duk_to_string(ctx, 3)) != 0){ // transp_char  
		draw( (char*)duk_to_string(ctx, 0), 
			(int)duk_to_number(ctx, 1),
	       		(int)duk_to_number(ctx, 2),
			duk_to_string(ctx, 3)[0]);
	}else{
		draw( (char *)duk_to_string(ctx, 0), 
			(int)duk_to_number(ctx, 1),
	       		(int)duk_to_number(ctx, 2),
	       		0);	}
	return 0;  /* zero return value */
}


///////////////////////////////
// in js: function draw_setup_canvas_custom(x,y )... return nothing
static duk_ret_t js_port_duktape_draw_canvas_get(
		duk_context *ctx ){
	duk_push_string( ctx, draw_canvas_get());
	return 1;  /* one return value */ }
static duk_ret_t js_port_duktape_draw_canvas_set(
		duk_context *ctx ){
	draw_canvas_set( (char*)duk_to_string(ctx, 0));
	return 0;  /* zero return value */ }
///////////////////////////////
///////////////////////////////
// in js: function draw_setup_canvas_custom(x,y )... return nothing
static duk_ret_t js_port_duktape_draw_settup_canvas_custom(
		duk_context *ctx ){
	draw_settup_canvas_custom(
		// minus 1 because it's needed how 'gridstr_make' 
		//  works in the c port... EG: I couldn't find the error. 
		(int)duk_to_number(ctx, 0), 
		(int)duk_to_number(ctx, 1)); 
	return 0;  /* one return value */ }
///////////////////////////////
// in js: function draw_setup_canvas( )... return nothing
static duk_ret_t js_port_duktape_draw_settup_canvas(duk_context *ctx ){
	draw_settup_canvas(); 
	return 0;  /* one return value */ }	
///////////////////////////////
// in js: function draw_clear_canvas( )... return nothing
static duk_ret_t js_port_duktape_draw_clear_canvas(duk_context *ctx){
	draw_clear_canvas(); 
	return 0;  /* one return value */ }

static duk_ret_t js_port_duktape_draw_canvas_get_width(duk_context *ctx){
	duk_push_int(ctx, _draw_canvas_js_width); 
	return 1;  /* one return value */ }
static duk_ret_t js_port_duktape_draw_canvas_get_height(duk_context *ctx){
	duk_push_int(ctx, _draw_canvas_js_height); 
	return 1;  /* one return value */ }

void draw_duktape_port_settup(duk_context *ctx){
	duk_push_c_function(ctx, js_port_duktape_draw, 4);
	duk_put_global_string(ctx, "draw");
	duk_push_c_function(ctx, js_port_duktape_draw_grid, 4);
	duk_put_global_string(ctx, "draw_grid");	
	
	duk_push_int(ctx, 72);
	duk_put_global_string(ctx, "DRAW_CANVAS_DFLT_WIDTH");
	duk_push_int(ctx, 24);
	duk_put_global_string(ctx, "DRAW_CANVAS_DFLT_HEIGHT");

	duk_push_c_function(ctx, 
		js_port_duktape_draw_canvas_get, 0);
	duk_put_global_string(ctx, "draw_canvas_get");
	duk_push_c_function(ctx, 
		js_port_duktape_draw_canvas_set, 1);
	duk_put_global_string(ctx, "draw_canvas_set");
	duk_push_c_function(ctx, 
		js_port_duktape_draw_settup_canvas_custom, 2);
	duk_put_global_string(ctx, "draw_settup_canvas_custom");
	duk_push_c_function(ctx, 
		js_port_duktape_draw_settup_canvas, 0);
	duk_put_global_string(ctx, "draw_settup_canvas");
	duk_push_c_function(ctx, 
		js_port_duktape_draw_clear_canvas, 0);
	duk_put_global_string(ctx, "draw_clear_canvas");

	duk_push_c_function(ctx, js_port_duktape_draw_canvas_get_height, 0);
	duk_put_global_string(ctx, "draw_canvas_get_height");
	duk_push_c_function(ctx, js_port_duktape_draw_canvas_get_width, 0);
	duk_put_global_string(ctx, "draw_canvas_get_width");
		
}

#endif
