//async function usleep( ms ){
//API_TAG// 
// ---------------------------NOTE ON 'await ' !!!!
// ----  I auto-remove 'await ' from ANY JS CODE in the c version. 
// ---- this will allow the 'await function()' to be nested. 
// ---- I don't think this will cause issues, but we will see. 
// ---- So if you need to use 'await ' in text, use 'a-wait' or something.
//API_TAG// 
//API_TAG// 
async function usleep( ms ){
// Probably should use 'await update_sleep()';'  //API_TAG// 
	return new Promise(resolve => setTimeout(resolve, ms));		}
 //API_TAG// 
async function update_sleep( ms ){
// use: 'await update_sleep( ms)'. (or use general update())	
// Still not standardized wait, so should probably stick to 
// 'await update()'  //API_TAG// 
	return new Promise(resolve => setTimeout(resolve, ms));	 }

//////////////////////////////////
/// MOUSE HANDLER
////////////////////////////////

// THESE ARE SYSTEM OS SPECIFIC, USE controller_mouse_x ETC. 
function _update_controller_mouseset_HTML_VERSION(
	x, y, justPressed, justReleased){
    if(justPressed){  _controller_mouse_down_OS_SETS = 1;}
    if(justReleased){ _controller_mouse_up_OS_SETS = 1;}
		_controller_mouse_x_OS_SETS = x; 
		_controller_mouse_y_OS_SETS = y;
}

// grok helped with this. 

// this is all callbacks, so happens automatically once settup.
// meaning, no 'update' so to speak, save the one that swaps 
// _update_mouse_x -> controller_mouse_x
var _update_html_prev_x =0;
function _update_controller_event_HTML_VERSION(getEvent_down_1_up_2_move_3, event, getDivDisp){

    var tmpSel = window.getSelection();
    tmpSel.removeAllRanges();

    var tmpRange;
    
    // Check if caretRangeFromPoint is supported (Chrome, Edge)
    if (document.caretRangeFromPoint) {
        tmpRange = document.caretRangeFromPoint(
		event.clientX, event.clientY);
    } 
    // If not, use caretPositionFromPoint for Firefox
    else if (document.caretPositionFromPoint) {
        let position = document.caretPositionFromPoint(event.clientX, event.clientY);
        if (position) {
            tmpRange = document.createRange();
            tmpRange.setStart(position.offsetNode, position.offset);
            tmpRange.collapse(true);
        }
    } else {
        console.log("Neither caretRangeFromPoint nor caretPositionFromPoint is supported");
        return;
    }
    
    if (tmpRange) { tmpSel.addRange(tmpRange); }

    // Your existing logic for getting and logging position
    var tmpDiv = _update_controller_mouse__DIV_HTML;
    var tmpRange_CLONE = tmpSel.getRangeAt(0).cloneRange(); 
    tmpRange_CLONE.setStart(tmpDiv, 0);
    var tmpSplit = tmpRange_CLONE.toString(); //.trim()
      //.split("\r\n").join("\n").split("\r").join("\n").split('\n');
    var y = Math.floor(tmpSplit.length/draw_canvas_get_width());
    var x = -1 + tmpSplit.length - (y * draw_canvas_get_width());
    if(x==-1){ if(_update_html_prev_x>draw_canvas_width/2){
		x=draw_canvas_width;}else{x=0;}} 
    _update_html_prev_x = x;
    if(y==-1){y=0;}   

    //if(x == 0){ x = 1; }; if(y == 0){ return null; };

    if( getEvent_down_1_up_2_move_3 == 1){ 
	_update_controller_mouseset_HTML_VERSION(x, y, 1, 0);} 
    if( getEvent_down_1_up_2_move_3 == 2){ 
	_update_controller_mouseset_HTML_VERSION(x, y, 0, 1);}
    if( getEvent_down_1_up_2_move_3 == 3){ 
	_update_controller_mouseset_HTML_VERSION(x, y, 0, 0);}
}

var _update_update_controller_mouse_initialized_HTML_VERSION = 0;
var _update_controller_mouse__DIV_HTML = null;
function update_update_controller_mouse_settup_RUNS_1x_HTML_VERSION( ){
	
	if(_update_controller_mouse__DIV_HTML == null){
	 _update_controller_mouse__DIV_HTML= _draw_canvas_div;}
	
	if(_update_controller_mouse__DIV_HTML == null){return;}

	if(!_update_update_controller_mouse_initialized_HTML_VERSION){
	  _update_update_controller_mouse_initialized_HTML_VERSION=1; 
	}else{return;}
	
 	_update_controller_mouse__DIV_HTML.addEventListener('mousedown', 
	  function(getevent) { _update_controller_event_HTML_VERSION(
		1,getevent, _update_controller_mouse__DIV_HTML);
		 } );
	_update_controller_mouse__DIV_HTML.addEventListener('mouseup', 
	  function(getevent) { _update_controller_event_HTML_VERSION(
		2,getevent, _update_controller_mouse__DIV_HTML);
		} );
	_update_controller_mouse__DIV_HTML.addEventListener('mousemove', 
	  function(getevent) { _update_controller_event_HTML_VERSION(
		3,getevent, _update_controller_mouse__DIV_HTML); 
		} );
	//same as mouse-up, hopefully will get rid of the 
	// 'mouse-still-clicked' 	condition
	_update_controller_mouse__DIV_HTML.addEventListener('mouseleave', 
	  function(getevent) { _update_controller_event_HTML_VERSION(
		2,getevent, _update_controller_mouse__DIV_HTML);
		 } );
	
}
//this version, all the stuff is handled via callbacks, so 
// no real 'update' besides the main one: this sets up the system. 
update_controller_mouse_OS_SPECIFIC =
	update_update_controller_mouse_settup_RUNS_1x_HTML_VERSION;


/////////////////////////////////
// END MOUSE HANDLER
// ////////////////////////////////


var _update_now, _update_delta, _update_then = window.performance.now();
var _update_MAX_FAMERT_DIFF = 60;
var UPDATE_FRAMERATE_X = 1000; //multiplier, to interface with html
_update_framerate = 24;
//API_TAG//
var _update_log_text_1_turn = "";
async function update_dont_clear(){
// 	use: await update_dont_clear(); 
//	updates draw-canvas without clearing it 
// 	sleeps 1/24 sec
// 	//API_TAG// 
	_update_now = window.performance.now(); 
	_update_delta = _update_now - _update_then;
	while((UPDATE_FRAMERATE_X / _update_delta) > _update_framerate){ 
		// console.log((UPDATE_FRAMERATE_X / _update_delta));
		//This here 'zooms in', waiting less on framerate
		tmpFrameRt_diff =  
		    (UPDATE_FRAMERATE_X-_update_framerate) / _update_delta;
		if(tmpFrameRt_diff > _update_MAX_FAMERT_DIFF){
			await update_sleep(10);
		}else{ await update_sleep(1);}
		_update_now = window.performance.now();
		_update_delta = _update_now-_update_then; }
	_update_then = _update_now; 
	//console.log(draw_canvas.map(e => e.join("")).join('<br>').length);
	_draw_canvas_div.innerHTML = 
		draw_canvas.map(e => e.join("")).join('<br>');
	if(_update_log_text_1_turn != ""){
		_draw_canvas_div.innerHTML 
			+= "<br>" + _update_log_text_1_turn;
		_update_log_text_1_turn = "";}
	}
//API_TAG// 
function update_set_framerate(getfps){ 
// Sets framerate. Not sure if this is working right. 
// current fps= 24 	//API_TAG// 
	_update_framerate = getfps;};

//function update_keyboard(){}; // see module for is
//API_TAG// 
async function update(){
// 	use: await update(); 
//	updates draw-canvas, clearing it
// 	sleeps 1/24 sec
// 	//API_TAG// 
	update_controller_mouse();
	update_controller(); // see module for this.
	await update_dont_clear();
	draw_clear_canvas();	}
//API_TAG// 
async function update_start_game(){
// Settups the enviornment to start game. 
// 	Run once at start of game, or after pausing game 
// 	environment (NOT pausing game itself!) //API_TAG// 
	// this is basically used for the c functions
	_update_dont_clear();
}
//API_TAG// 
async function update_stop_game(){
// run this at end of game, to 'exit' 
// 	basically is used with c port
//API_TAG// 
	// this is basically used for the c functions
	// so.. this is a placeholder, so everything runs
	// (and if specific setups want to be done...
}
//API_TAG//


