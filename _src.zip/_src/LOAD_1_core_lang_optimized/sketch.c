// NEEDS TO HAVE grid IMPORTED, OR THIS WON'T RUN!!!
#if defined(DUK_VERSION)	
void sketch_duktape_port_settup(duk_context *ctx);
#endif
 
char *  _sketch_canvas;  int _sketch_canvas_width;   
int _sketch_canvas_length; int _sketch_canvas_height; 
void _sketch_canvas_var_init(){ 
	_sketch_canvas =  (char *)malloc(10); 
        _sketch_canvas[0] = '\0';		
	return;}
void _sketch_canvas_var_resize( int size){  //the +1 is just a caution, 
					// as I don't know c well.  
	_sketch_canvas =  realloc(_sketch_canvas, size +1);
	return; }
void _sketch_canvas_var_terminate(){ 
	free( _sketch_canvas);
	return;}

// this is further modified before launching, see next funct. 
void _sketch_init(char* str_to_use, int str_length){
	_sketch_canvas_length = str_length;
	_sketch_canvas_width = 
		gridstr_0_under_50_or_width(str_to_use, _sketch_canvas_length );
	if(_sketch_canvas_width == 0){ _sketch_canvas_height =0;
	}else{_sketch_canvas_height = 
		(int)((str_length)/(_sketch_canvas_width)); }
	_sketch_canvas_var_resize( str_length);
	strcpy(_sketch_canvas, str_to_use);
	return; 
}
char* sketch_init_js_funct(){
	return 
	"var _sketch_stack = [[]];"
	"function sketch_init( get_2d_gridstr){"
	  "_sketch_stack.push( sketch_get() );"
	  "if(_sketch_stack.length >=50){ file_input("
	  	"'_sketch_stack has max(50) items! Looks like "
		" sketch_end, which is needed with sketch_init, was not "
	       	"used! CHECK CODE TO MAKE SURE 1x "
	        "SKETCH_END PER SKETCH_INIT!!!');}"
	  "_sketch_init( get_2d_gridstr, get_2d_gridstr.length);};";}
char* sketch_end_js_funct(){ 
	return "function sketch_end(){"	
//void sketch_grid( str, x, y, transp_char);
		"var nxtSketch=  _sketch_stack.pop();"
		"_sketch_init( nxtSketch, nxtSketch.length );};";}

/*
var _sketch_stack = [[]];
function sketch_init( get_2d_gridstr){
	_sketch_stack.push(sketch_canvas);
	sketch_canvas = _gridstr__2darr_txt_to_2darr(
			 	get_2d_gridstr);
	sketch_canvas_width = sketch_canvas[0].length;
	sketch_canvas_height = sketch_canvas.length; }
function sketch_end(){ sketch_canvas = _sketch_stack.pop(); }
//needs testing:
function sketch_char(str, x,y){
	if( x>0 && x< sketch_canvas_width &&
		y>0 && y< sketch_canvas_height){
			sketch_canvas[y][x]= str[0];	} }
//needs testing:
function sketch_char_get( x,y){
	if( x>0 && x< sketch_canvas_width &&
		y>0 && y< sketch_canvas_height){
			return	sketch_canvas[y][x];	} 
	return null; }
*/

// NOTE: not sure how I did the height and width thing, they seem to 
// be reversed in canvas. 
int _sketch_canvas_js_height =0; int _sketch_canvas_js_width=0;
// available in JS:
////// ALL THESE post/get stuff from the canvas (a txt-grid text string)
/////// I should be obvious which ones return something
// JS FUNCTS: 
// function sketch_canvas_get_width(){ return sketch_canvas_height;}
//function sketch_canvas_get_height(){ return sketch_canvas_width;}
char * sketch_get(){ return _sketch_canvas;}

void sketch( char* str, int x, int y, char trnsparent_or_0 );
void sketch_grid( char* str, int x, int y, char trnsparent_or_0, 
		int length_NOT_IN_JS_VERSION );



// JS version does not use length
// sketch_grid
void sketch_char( char* str, int x, int y ){
	_gridstr_overlay_base(  //one size fits-all sketch
		_sketch_canvas, str,  x, y, 	
		0,//trnsparent_or_0,
		_sketch_canvas_width, 0, 
		_sketch_canvas_length, 0 );	}
void sketch_char_get( char* str_1_char_return, int x, int y ){
	// the 'gridstr get width' thing looks 1px off. 
	gridstr_char_get( _sketch_canvas, str_1_char_return, 
		_sketch_canvas_length, 
		x, y, _sketch_canvas_width );
	return; 
}
void sketch( char* str, int x, int y, char trnsparent_or_0 ){
	_gridstr_overlay_base(  //one size fits-all sketch
		_sketch_canvas, str,  	x, y, 	
		trnsparent_or_0,
		_sketch_canvas_width, 0, 
		_sketch_canvas_length, 0 );	}
void sketch_replaceall( char *char_to_replace, char *char_to_replace_with){
	char a = char_to_replace[0];
	char b = char_to_replace_with[0];
	for(int i=0; i<_sketch_canvas_length 
			&& _sketch_canvas[i]!='\0'; i+=1){
		if(_sketch_canvas[i] == a){ 
			_sketch_canvas[i] = b; }
	} }
void sketch_grid( char* str, int x, int y, char trnsparent_or_0, 
		int length_NOT_IN_JS_VERSION ){
	_gridstr_overlay_base(  //one size fits-all sketch
		_sketch_canvas, str,  	x, y, 	
		trnsparent_or_0,
		_sketch_canvas_width, 
			gridstr_0_under_50_or_width(str, length_NOT_IN_JS_VERSION),  
		_sketch_canvas_length, length_NOT_IN_JS_VERSION );	}
void sketch_grid_DRAW_UNDER_TRANSPCHAR( 
		char* str, int x, int y, char trnsparent_or_0, 
		int length_NOT_IN_JS_VERSION ){
	_gridstr_overlay_base_UNDER_OVERLAYCHAR( //for special cases
		_sketch_canvas, str,  	x, y, 	
		trnsparent_or_0,
		_sketch_canvas_width, 
			gridstr_0_under_50_or_width(str, length_NOT_IN_JS_VERSION),  
		_sketch_canvas_length, length_NOT_IN_JS_VERSION );	}


// this define at start shit will only work with const keywork.. I hope... 
//  SO... only 
struct _rays_oclock_struct{ int x_sign; int y_sign; int i_is_x_j_is_y;};
struct _rays_oclock_struct _ray_oclock[] = {
	{1,-1,0}, //0
	{1,-1,1}, //1
	{1,1,1}, //2
	{1,1,0}, //3
	{-1,1,0}, //4
	{-1,1,1}, //5
	{-1,-1,1}, //6
	{-1,-1,0}}; //7
struct _rays_oclock_struct _ray_oclock_stagger[] = {
	{1,-1,0}, //0
	{1,1,1}, //1
	{-1,1,0}, //2
	{-1,-1,1}, //3
	{1,-1,1}, //4
	{1,1,0}, //5
	{-1,1,1}, //6
	{-1,-1,0}}; //7
char * _sketch_draw_shadow_ray_js_funct(){
return ""
"function _sketch_draw_shadows_ray( "
  "o_clock_strt, o_clock_end, "
	"max_depth, x_offset, y_offset, wall_map_gfx, wall_x, wall_y," 
	"gridstr_screen_light_spaces_for_opaque,  draw_light_char,"
	"OPTIONAL_stagger_o_clock_drawing){"
	
	"if(OPTIONAL_stagger_o_clock_drawing == void null){"
		"OPTIONAL_stagger_o_clock_drawing = 0;} "
	"if(OPTIONAL_stagger_o_clock_drawing == true){"
		"OPTIONAL_stagger_o_clock_drawing = 1;} "

	"_sketch_draw_shadows_ray_C_BASE( "
  		"o_clock_strt, o_clock_end, "
		"max_depth, x_offset, y_offset, "
		"wall_map_gfx, wall_map_gfx.length,"
		"wall_x, wall_y, "
		"gridstr_screen_light_spaces_for_opaque, " 
			"gridstr_screen_light_spaces_for_opaque.length, "
		"draw_light_char, OPTIONAL_stagger_o_clock_drawing );"	

	"}";	}
char * _sketch_draw_shadow_ray_js_funct_name(){
	return "_sketch_draw_shadows_ray_C_BASE";	}
//translated from js version... that one is probably (a bit) more readable
void _sketch_draw_shadows_ray( 
  	int o_clock_strt, int o_clock_end, 
	int max_depth, int x_offset, int y_offset, 
	char* wall_map_gfx, int wall_map_length,
	int wall_x, int wall_y, 
	char * gridstr_screen_light_spaces_for_opaque_IN, 
		int gridstr_screen_light_spaces_for_opaque_length,
	char * draw_light_char,
	int OPTIONAL_stagger_o_clock_drawing ){
	// the last two should allow secondary light 
	// 	sources, if I draw all light on one map, then use 
	// 	that map as 'gridstr_screen_light'
	
	
	//char gridstr_screen_light_spaces_for_opaque[
	//	_gridstr_scale__sizeof_gen_gridstr(
	//			(max_depth*2),(max_depth*2) ) ];
	char *gridstr_screen_light_spaces_for_opaque = (char*) malloc(
		_gridstr_scale__sizeof_gen_gridstr(
				(max_depth*2),(max_depth*2) ) 
			* sizeof(char));

	//scaling to ray-size (will need to place x-(1/2raysize)
	if(gridstr_screen_light_spaces_for_opaque_length > 1){
		gridstr_scale_nearest_neighbor( 
			gridstr_screen_light_spaces_for_opaque_IN,
			gridstr_screen_light_spaces_for_opaque,
			max_depth*2, max_depth*2); 
	}else{
		gridstr_screen_light_spaces_for_opaque[0] = '\0';
	}

	int wll_wdth = gridstr_0_under_50_or_width(wall_map_gfx, wall_map_length);
	int scrn_wdth = gridstr_0_under_50_or_width(
		gridstr_screen_light_spaces_for_opaque, 
		gridstr_screen_light_spaces_for_opaque_length);
	float inverse_line_for_tapering = 0;
	char tmpchar_for_getchar[2]; tmpchar_for_getchar[1]='\0'; 

     for(int o_clock = o_clock_strt;o_clock < o_clock_end; o_clock+=1){
	int x_sign = _ray_oclock[o_clock].x_sign;
	int y_sign = _ray_oclock[o_clock].y_sign;
	int i_is_x_j_is_y = _ray_oclock[o_clock].i_is_x_j_is_y;
	if(OPTIONAL_stagger_o_clock_drawing == 1){
		x_sign = _ray_oclock_stagger[o_clock].x_sign;
		y_sign = _ray_oclock_stagger[o_clock].y_sign;
		i_is_x_j_is_y =_ray_oclock_stagger[o_clock].i_is_x_j_is_y;}

	//var max_depth = 40;
	int min_len =0;  int max_len=1;
	//int prev_line[ max_depth ];
	int *prev_line = (int*) malloc( max_depth
		* sizeof(int));
	for(int i=0; i< max_depth; i+=1){ prev_line[i] = 0;}
	prev_line[0] = 1;

	//int cur_line[ max_depth ];
	int *cur_line = (int*) malloc( max_depth
		* sizeof(int));
	int x=0; int y=0; int prev_j = 0;
	
	for(int i=0; i< max_depth; i+=1){	
	    if(i_is_x_j_is_y){
	 	for(int j=min_len; j< max_len; j+=1){
			if(i == 0){  prev_j = 0;
			}else{ prev_j= floor((((float)j+.3)/((float)i))
					*((float)i-1.0));}
			// changed with i_is_x_j_is_y 
			// the (j+.3) for rounding(really .5, .3 for looks)
			x =  i*x_sign+ x_offset; y=j*y_sign+y_offset;
			if( prev_line[prev_j] ==1){ 
				
				gridstr_char_get(wall_map_gfx, 
					tmpchar_for_getchar,
					wall_map_length,
				  	x-wall_x, y- wall_y, wll_wdth);
				if( tmpchar_for_getchar[0] =='\0'
					|| tmpchar_for_getchar[0] == ' '){
						cur_line[j] = 1;}
				//optimizing for large draw area
				if(x > _sketch_canvas_width+1 || 
					 x <-1 || y<-1 ||	
				   y > _sketch_canvas_height+1){continue;}
				
				gridstr_char_get(
				  gridstr_screen_light_spaces_for_opaque, 
				  	tmpchar_for_getchar,
				        gridstr_screen_light_spaces_for_opaque_length,
				  	x- x_offset+max_depth,
					y-y_offset+max_depth,
					scrn_wdth); 
				if(tmpchar_for_getchar[0] !=' '){
					 sketch(draw_light_char, x, y,0);}
		}	} 
	    }else{
		for(int j=min_len; j< max_len; j+=1){
			if(i == 0){  prev_j = 0;
			}else{ prev_j= floor((((float)j+.3)/((float)i))
					*((float)i-1.0));}
			// changed with i_is_x_j_is_y
			// the (j+.3) for rounding(really .5, .3 for looks)
			x = j*x_sign+ x_offset; y=i*y_sign+y_offset;
			if( prev_line[prev_j] ==1){ 
				gridstr_char_get(wall_map_gfx, 
					tmpchar_for_getchar,
					wall_map_length,
				  	x-wall_x, y- wall_y, wll_wdth);
				if( tmpchar_for_getchar[0] =='\0'
					|| tmpchar_for_getchar[0] == ' '){
						cur_line[j] = 1;}
				//optimizing for large draw area
				if(x > _sketch_canvas_width+1 || 
					 x <-1 || y<-1 ||
				   y > _sketch_canvas_height+1){continue;}
				
				gridstr_char_get(
				  gridstr_screen_light_spaces_for_opaque, 
				  	tmpchar_for_getchar,
				        gridstr_screen_light_spaces_for_opaque_length,
				  	x- x_offset+max_depth,
					y-y_offset+max_depth,
					scrn_wdth); 
				if(tmpchar_for_getchar[0] !=' '){
					 sketch(draw_light_char, x, y,0);}
		}	} 
	    }
	  for(int l=0; l<max_depth; l+=1){ 
		prev_line[l] = cur_line[l];
	  	cur_line[l] = 0; }
	//tapering, detecting max line length (i+j and max_depth) 
	/////////linear:
	//var inverse_line_for_tapering = max_depth-i;
	/////////quadratic:
	//var inverse_line_for_tapering = -1 + Math.pow(max_depth-i,2);
	/////////squar_root:
	//var inverse_line_for_tapering =  Math.sqrt(max_depth-i,2);
	//////////circular:
	  inverse_line_for_tapering=-1.0+ sqrt( pow((float)max_depth,2.0)-
					pow((float)i,2.0)) ;
	  if(max_len > 2 && max_len >= (int)inverse_line_for_tapering){	
		max_len = inverse_line_for_tapering;}
	  max_len +=1;
 	
	  }	
		free( prev_line );
		free( cur_line );
	}
	
	
	free( gridstr_screen_light_spaces_for_opaque );
}

////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
/////////////// Ducktape Port //////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

#if defined(DUK_VERSION)

static duk_ret_t js_port_duktape___sketch_draw_shadow_ray(duk_context *ctx){

   _sketch_draw_shadows_ray( 
	 duk_to_int(ctx,0), duk_to_int(ctx,1),
	 duk_to_int(ctx,2), duk_to_int(ctx,3), duk_to_int(ctx,4),
	 (char*) duk_to_string(ctx,5), duk_to_int(ctx,6),
  	 duk_to_int(ctx, 7), duk_to_int(ctx, 8),
	 (char*)duk_to_string(ctx, 9),
	 	duk_to_int(ctx, 10),
	 (char*)duk_to_string(ctx, 11),
	 duk_to_int(ctx,12));
	 //int o_clock_strt, int o_clock_end, 
	//int max_depth, int x_offset, int y_offset, 
	//char* wall_map_gfx, int wall_map_length,
	//int wall_x, int wall_y, 
	//char * gridstr_screen_light_spaces_for_opaque_IN, 
	//	int gridstr_screen_light_spaces_for_opaque_length,
	//char * draw_light_char,
	//int OPTIONAL_stagger_o_clock_drawing );
	return 0;  // no returns
}
static duk_ret_t js_port_duktape__sketch_init(duk_context *ctx) {
	_sketch_init( (char*)duk_to_string(ctx, 0), 
			duk_to_int(ctx, 1));
	return 0;  /* zero return value */
}
//sketch_end is used purely with js.

//sketch_char( char* str, int x, int y 
//sketch_char_get( char* str_return, int x, int y )
static duk_ret_t js_port_duktape_sketch_char( duk_context *ctx){
	sketch_char( (char*)duk_to_string(ctx, 0), 
			duk_to_int(ctx, 1), duk_to_int(ctx, 2)); 
	return 0;  /* zero return value */
}
static duk_ret_t js_port_duktape_sketch_char_get( duk_context *ctx){
	char ret_string[2];
	ret_string[1] ='\0';
	sketch_char_get( (char*)ret_string, 
			duk_to_int(ctx, 0), duk_to_int(ctx, 1));
	duk_push_string( ctx, 	(char*)ret_string);
	return 1;  /* zero return value */
}


///////////////////////////////
// in js: sketch_grid(str,x,y, transpChar_or_blank_str)... return nothing
// sketch_grid_optim(IZED)
static duk_ret_t js_port_duktape_sketch_grid(duk_context *ctx) {
	// the length is added via javascript in helper function 
	//  	see js_port_duktape_init 
	if( (int)duk_get_length(ctx, 3) != 0){ // transp_char  
		sketch_grid( (char*)duk_to_string(ctx, 0), 
			(int)duk_to_number(ctx, 1),
	       		(int)duk_to_number(ctx, 2),
			duk_to_string(ctx, 3)[0],
			(int)duk_get_length(ctx, 0));
	}else{
		sketch_grid( (char *)duk_to_string(ctx, 0), 
			(int)duk_to_number(ctx, 1),
	       		(int)duk_to_number(ctx, 2),
	       		0,
			(int)duk_to_number(ctx, 0));	}
	return 0;  /* zero return value */
}
// sketch_grid_optim(IZED) (THIS ONE FOR DRAWING 'UNDER' STUFF!!
///sketch_grid_DRAW_UNDER_TRANSPCHAR(str, x, y, transp_char);////
static duk_ret_t js_port_duktape_sketch_grid_UT(duk_context *ctx) {
	//sketch_grid__DRAW_UNDER_TRANSPCHAR
	// the length is added via javascript in helper function 
	//  	see js_port_duktape_init 
	if( (int)duk_get_length(ctx, 3) != 0){ // transp_char  
		sketch_grid_DRAW_UNDER_TRANSPCHAR( 
			(char*)duk_to_string(ctx, 0), 
			(int)duk_to_number(ctx, 1),
	       		(int)duk_to_number(ctx, 2),
			duk_to_string(ctx, 3)[0],
			(int)duk_get_length(ctx, 0));
	}else{
		sketch_grid_DRAW_UNDER_TRANSPCHAR( 
			(char *)duk_to_string(ctx, 0), 
			(int)duk_to_number(ctx, 1),
	       		(int)duk_to_number(ctx, 2),
	       		0,
			(int)duk_get_length(ctx, 0));	}
	return 0;  /* zero return value */
}
static duk_ret_t js_port_duktape_sketch(duk_context *ctx) {
	// the length is added via javascript in helper function 
	//  	see js_port_duktape_init 
	if( strlen( (char*)duk_to_string(ctx, 3)) != 0){ // transp_char  
		sketch( (char*)duk_to_string(ctx, 0), 
			(int)duk_to_number(ctx, 1),
	       		(int)duk_to_number(ctx, 2),
			duk_to_string(ctx, 3)[0]);
	}else{
		sketch( (char *)duk_to_string(ctx, 0), 
			(int)duk_to_number(ctx, 1),
	       		(int)duk_to_number(ctx, 2),
	       		0);	}
	return 0;  /* zero return value */
}


///////////////////////////////
// in js: function sketch_setup_canvas_custom(x,y )... return nothing
static duk_ret_t js_port_duktape_sketch_get(
		duk_context *ctx ){
	duk_push_string( ctx, sketch_get());
	return 1;  /* one return value */ }


static duk_ret_t js_port_duktape_sketch_get_width(
		duk_context *ctx ){
	duk_push_int( ctx, _sketch_canvas_width);
	return 1;  /* one return value */ }

// char_to_replace, char_to_replace_with
static duk_ret_t js_port_duktape_sketch_replaceall(
		duk_context *ctx ){

	sketch_replaceall( 
		(char *)duk_get_string(ctx, 0), 
		(char *)duk_get_string(ctx, 1));

	return 0;  /* return 0 values */ }


void sketch_duktape_port_settup(duk_context *ctx){
	//placeholder
	_sketch_canvas_var_init();
	
	duk_push_c_function(ctx, js_port_duktape_sketch_char_get, 2);
	duk_put_global_string(ctx, "sketch_char_get");
	
	duk_push_c_function(ctx, js_port_duktape_sketch_char, 3);
	duk_put_global_string(ctx, "sketch_char");

	duk_push_c_function(ctx, js_port_duktape_sketch_replaceall, 2);
	duk_put_global_string(ctx, "sketch_replaceall");
	
	duk_push_c_function(ctx, js_port_duktape_sketch_get_width, 0);
	duk_put_global_string(ctx, "sketch_get_width");

	duk_push_c_function(ctx, js_port_duktape_sketch, 4);
	duk_put_global_string(ctx, "sketch");

	duk_push_c_function(ctx, js_port_duktape__sketch_init, 2);	
	duk_put_global_string(ctx, "_sketch_init");// _sketch_init= c funct
		duk_push_string(ctx, sketch_init_js_funct() ) ;
		duk_eval_noresult(ctx);

	duk_push_string(ctx, sketch_end_js_funct() ) ;
	duk_eval_noresult(ctx);

	duk_push_c_function(ctx, js_port_duktape_sketch, 4);
	duk_put_global_string(ctx, "sketch");
	duk_push_c_function(ctx, js_port_duktape_sketch_grid, 4);
	duk_put_global_string(ctx, "sketch_grid");	

	///sketch_grid_DRAW_UNDER_TRANSPCHAR(str, x, y, transp_char);////
	duk_push_c_function(ctx, js_port_duktape_sketch_grid_UT, 4);
	duk_put_global_string(ctx, // sketch_grid
		"sketch_grid_DRAW_UNDER_TRANSPCHAR");
	
	duk_push_c_function(ctx, //_sketch_draw_shadows_ray
			js_port_duktape___sketch_draw_shadow_ray, 13);
	duk_put_global_string(ctx, 
			_sketch_draw_shadow_ray_js_funct_name() );
		duk_push_string(ctx, _sketch_draw_shadow_ray_js_funct() );
		duk_eval_noresult(ctx);

	duk_push_c_function(ctx, 
		js_port_duktape_sketch_get, 0);
	duk_put_global_string(ctx, "sketch_get");
	
		
}
void  sketch_duktape_port_cleanup(){ 
	_sketch_canvas_var_terminate(); return;	 } 

#endif
