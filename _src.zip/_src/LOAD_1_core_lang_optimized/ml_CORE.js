//API_TAG//
//returns 1 if move to next word, 
// returns 2 if a 'pause' from a function in first statement. 
//	( stops script ) 
async function _ml_CORE_runword_cmds( o, otarget, sentence, 
		getStruct, rm_OPTIONAL){
//API_TAG//
	// getStruct._mml_word_locs = [loc, mag, loc, mag]

	//Now, RUN IT!!!
	//file_input( progen_mix_stringify(getStruct));
	var locs_mags = getStruct._mml_word_locs;
	var loc_finished_count =0;
	var MAG_INDEX = 1;
	var cmds = getStruct.cmds;	
	
	for(var i=0; i<locs_mags.length; i+=2){
		while(1){
		  //checking for hard-coded characters
		  var char_i = sentence.charAt(locs_mags[i]);
		  if( "<=>,".indexOf(char_i) != -1){
			if(char_i == ","){ 
				if(i==0){//first IF part of 'word'
				    loc_finished_count+=1;
				    locs_mags[i]= 
				  	getStruct._mml_word_loc1_start;	 
				    break;}
				loc_finished_count+=1; break;}
			if(char_i == "="){ locs_mags[i +MAG_INDEX] = 0;
			}else{ if(char_i == ">"){ 
				locs_mags[i +MAG_INDEX] +=1;
			}else{ locs_mags[i +MAG_INDEX] -=1; }} 
		    locs_mags[i]+=1; continue;}
 		  
		  //running cmds
		  var func_cmdlist= cmds[char_i];
		  if(func_cmdlist != void null){ if(1 == 
		     await ml_catch_globalNamespace[func_cmdlist[0]]( 
			o,otarget, i/2, // i/2 is 'track', # comma running! 
			  locs_mags[i+MAG_INDEX],func_cmdlist,rm_OPTIONAL)){
			if(i==0){ return 2; //first IF part of 'word' 
			}else{ break; } } } //other parts,
			//first, the'if'block   
		  locs_mags[i]+=1; 
		  if(i !=0){ break;}
		  //repeat character delays (expanded for tempo/etc)
		  //if(char_i == sentence.charAt(locs_mags[i])){ break; }
		}	
	} 
	if(loc_finished_count >= locs_mags.length/2){ return 1;} 
}
async function _behav_mml_status_CORE( o){ //status is stored in 
//API_TAG//
	if(o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS == null){ 
			return;}
	var tmpStats = o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS;
	//reverse itterating, so can remove list items cleanly:
	
	for(var i=tmpStats.length-5; i>=0; i-=5){
		//o, otarget, track(-1), magnitude, 
		//  list_cmds, rm_OPTIONAL, NEW_time_left_SATUS_STUFF_ONLY)
		
		if((tmpStats[i+2] -=1) ==0  //define TIME and check...
			| //bitwise OR, ALWAYS runs second part vs. '||'
		 await rmloaded_b_globalThis[ tmpStats[i+4][0] ]( 
		   o,o, -1, tmpStats[i+1], tmpStats[i+4], rmloaded_room, 
		   tmpStats[i+2])){ //mml-functs returns 1 for early break
			tmpStats.splice(i, 5); } //removing items
	}
	if(tmpStats.length == 0){ 
		delete o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS;}
}
