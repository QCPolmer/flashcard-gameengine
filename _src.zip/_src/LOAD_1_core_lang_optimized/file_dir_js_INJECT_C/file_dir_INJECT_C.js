//API_TAG//
function file_dir( get_cd, dir_name){ 
// returns a list of filenames, or null for file_not_found	//API_TAG//
			
			if(dir_name == undefined){ dir_name = ''}	
			if(_file__dir_open(get_cd + dir_name)==0){return null;}
			var retlist=[];
			
			var i=0;
			while( _file__dir_curfile_or_blank() !=''){
				retlist[i]=_file__dir_curfile_or_blank();
				_file__dir_getnextfile_or_blank();
				i+=1;
			}
			_file__dir_close();
			return retlist;
		}


//API_TAG//
var file_dir_embed_in_c_file = function(getDirsList, getFile_to_inject_with, getTextToInjectBetween, OPTIONAL_remove_comments_from_js,
 OPTIONAL_getJsTxtCompression_funct ){
// No returns;		//API_TAG//
	file_inject_data_singleblock( 
		file_dir_gen_embedable_c( getDirsList,
			OPTIONAL_remove_comments_from_js,
			OPTIONAL_getJsTxtCompression_funct), 
		getFile_to_inject_with, 
		getTextToInjectBetween );
}
var FILE_DIR_EMBEDED_CODE_TAG = FILE_EMBEDED_SPLIT_BY;//defined in file.c
//API_TAG//
var file_dir_gen_embedable_c = function( getDirsList, 
	OPTIONAL_remove_comments_from_js,
	OPTIONAL_getJsTxtCompression_funct ){
// returns a c-code-formatted string from dirlist[filenames], 
	//  generated from file_dir_search works well //API_TAG//
    var ret_str="";
    for(var j=0; j< getDirsList.length;j+=1){
	var getStartDir = getDirsList[j];
	var TMP_FILE_DEPTH_SEARCH=6;

	//file_log_input(getStartDir);

	var getFilesList = file_dir_search(
		getStartDir, TMP_FILE_DEPTH_SEARCH);
	   
	var getFile_text = file_pull_all_data_from_filelist(getFilesList,
		OPTIONAL_remove_comments_from_js,
		OPTIONAL_getJsTxtCompression_funct);
	

	for(var i=0; i<getFilesList.length; i+=1){
		ret_str += '\n"' + FILE_DIR_EMBEDED_CODE_TAG + '"\n' +
			'"' +getFilesList[i].substring( 
				getStartDir.length ) + '"' +
			'\n"' +  FILE_DIR_EMBEDED_CODE_TAG
			+ '"\n';
		ret_str +=  file_dir_convert_text_to_c_str( 
					getFile_text[i]);
	}
   }
   return ret_str;
}




//API_TAG//
function file_dir_rmdir(startDir, getDirName){
// remove a dir, returns nothing //API_TAG//
	_file_dir_rmdir(starDir+ getDirName);}
//API_TAG//
function file_dir_mkdir( startDir, getDirName){
// Make a dir, will generate multiple dirs is 
// the 'topmost' dirs do not exist.  //API_TAG//
	if(getDirName == undefined || getDirName == ""){
		getDirName = startDir; startDir ="";}
	getDirName=getDirName.split("/");
	for(var i=0; i<=getDirName.length; i+=1){
		_file_dir_mkdir( startDir+ getDirName.slice(0,i).join("/"));
}	}

//API_TAG//
function file_dir_copy( getDir_toCopy, getDir_toMake, 
		getCopyDepth, getRegex_partslist_to_match,
		getRegex_partslist_to_EXCLUDE){
//	A selective copy. Regex can be left balank, OR USE A LIST!!!
//	EG: ["js$","c$"], ["a$"]	//API_TAG//
	if(getDir_toCopy[getDir_toCopy.length - 1]!='/'){
		getDir_toCopy =  getDir_toCopy + '/';}
	if(getDir_toMake[getDir_toMake.length - 1]!='/'){
		getDir_toMake =  getDir_toMake + '/';}

	tmp_files =  file_dir_search(
		getDir_toCopy, getCopyDepth, getRegex_partslist_to_match,
		getRegex_partslist_to_EXCLUDE);
	tmp_out_files = [];
	for(var i=0; i< tmp_files.length; i+=1){
		tmp_out_files[i] = getDir_toMake + 
			tmp_files[i].split( getDir_toCopy)[1]; }

	
	//	return;

	for(var i=0; i< tmp_out_files.length; i+=1){
		tmpOutFile = tmp_out_files[i].split("/"); 
		tmpOutFile.pop();
		file_dir_mkdir( tmpOutFile.join("/"), "");}
	
	for(var i=0; i< tmp_files.length; i+=1){
		file_save( tmp_out_files[i], 
			file_load_noembed(tmp_files[i])); }
}
//API_TAG//
var file_dir_convert_text_to_c_str = function( str_in){
//returns c str	//API_TAG//
	return '\"' +
		str_in.split('\\').join('\\\\')
		.split('\"').join('\\\"')
		.split('\r\n').join('\n')
		.split('\n').join('\\n"\n"')
		+' \"';
}
//API_TAG//
var file_dir_UNconvert_text_to_c_str = function( str_in){
//used as the opposite of the '...dir_convert_text_to_c... //API_TAG//
	str_in = str_in
		.split('\r\n').join('\n')
		.split('\\\"').join('\"')
		.split('\\\\').join('\\')
		.split('\\n"\n"').join('\n');

	str_in = str_in.split('"');
	str_in.shift();
	str_in.pop();
	str_in = str_in.join('"');
	
	return 	str_in;
}
//API_TAG//
var file_dir_search = function( startFileLoc, maxRecursiveDepth,
		list_of_regex, list_of_exclude_regex){
// returns a list of filenames, regex can be undefined
// regex eg: ["js$", "c$"], ["a$"]  //API_TAG//
	var tmpList = _file_dir_search( 
			startFileLoc, maxRecursiveDepth, list_of_regex);
	if( list_of_exclude_regex == undefined){ return tmpList; }
	var tmpNotList = _file_dir_search( 
		startFileLoc, maxRecursiveDepth, list_of_exclude_regex);
	for(var i=tmpList.length-1; i>= 0; i-=1){
		if(tmpNotList.indexOf(tmpList[i]) != -1){
			tmpList.splice(i,1);}	}
	return tmpList
}

var _file_dir_search = function( getStartFileLoc, getMaxRecursiveDepth, 
	getPartsOfFileNames_or_regex_List){
	var getPartsOfFileNames_List = getPartsOfFileNames_or_regex_List;

	var ret_list = [];

	//handling inputs
	if (getStartFileLoc == undefined || getStartFileLoc == "") {
		getStartFileLoc = ".";}
	if(getStartFileLoc[getStartFileLoc.length-1] != "/"){
		getStartFileLoc = getStartFileLoc + "/";}
	if (getMaxRecursiveDepth == undefined) { 
		getMaxRecursiveDepth = 0;  }
	if (getPartsOfFileNames_List == undefined) { 
		 getPartsOfFileNames_List = [];}
	

	//pulling root dir
	var tmp_file_data = file_dir( getStartFileLoc, "");
	if(tmp_file_data == null){ return undefined;}
	tmp_file_data.shift(); tmp_file_data.shift();//removing '.', '..'

		
	//searching through root dir
	for(var i=0; i< tmp_file_data.length; i+=1){
		//recursion! (if desired)
		if(file_dir(getStartFileLoc, tmp_file_data[i])!= null ){
			if( getMaxRecursiveDepth > 0){
			   ret_list =  ret_list.concat( file_dir_search(
				getStartFileLoc + tmp_file_data[i],
				getMaxRecursiveDepth - 1, 
				getPartsOfFileNames_List)); }
			continue;
		};
		if(getPartsOfFileNames_List.length ==0){
			ret_list.push( getStartFileLoc +
					tmp_file_data[i]);}
		 for(var j=0; j< getPartsOfFileNames_List.length; j+=1){
			if( tmp_file_data[i].search(
				getPartsOfFileNames_List[j]) != -1 ){
				ret_list.push( getStartFileLoc +
					tmp_file_data[i]);
				break;
		}	 }  	 
	}
	return ret_list;

}

//API_TAG//
var file_dir_join_file_list_data = function(get_list_of_files){
// return a string of loaded files from file_names_list in 	//API_TAG//
	var ret_string = "";
	for(var i=0; i< get_list_of_files.length; i+=1){
		tmp_file_data = _file_load( get_list_of_files[i]);
		if( tmp_file_data != "" && tmp_file_data != null){
		    if((get_list_of_files[i].indexOf('.')!=-1) &&
			    (get_list_of_files[i].split('.').pop()== "js")){
			tmp_file_data = _file_preprocess_js(tmp_file_data);}
		    ret_string = tmp_file_data + ret_string + "\n";
	}	} 
	return ret_string;
}

var _file_dir_cur_cd = '.';
var _cd_param = file_argument_paramsget('-', ['-file_dir_cd']);
if( _cd_param.length>=2){ 
	if(file_dir("./", _cd_param[1])!= 0){ 
		_file_dir_cur_cd= _cd_param[1];
	} }
//API_TAG//
function file_dir_cd( dir_name){
// returns directory the file was lunched from 
// (can be set as an argument, '-file_dir_cd' )
// paramiter currently does nothing    //API_TAG//
	if (dir_name !== undefined) {
			//change dir, or see if possible
	}
	return _file_dir_cur_cd + "/";
}
// for the running js file
//API_TAG//
function file_dir_cd_js( ){ return file_js_cd(); } ;
//returns file_js_cd (directory of js file running). 
// should use that instead  //API_TAG//
//NEED TO SET TO SHARED LIBRARIES FOR JS STUFF
var _file_core_js_cd = '.';
var _cd_param = file_argument_paramsget('-', ['-file_core_js_cd']);
if( _cd_param.length>=2){  
	if(file_dir( "./", _cd_param[1])!= 0){ 
		_file_core_js_cd = _cd_param[1]; } }
//API_TAG//
function file_core_js_cd( ){ return _file_core_js_cd.split("\\").join("/") + "/"; }
//pulls the LOAD2...CORE_JS file in _src (used mostly for bundling)	//API_TAG//
// for the running js file
function file_dir_cd_js( ){ return file_js_cd(); } 
