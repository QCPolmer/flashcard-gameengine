
echo  \`" > $null <# \" >NUL  " >/dev/null <<EOF \" 
:: modified https://github.com/llamasoft/polyshell
:: This one gives a bs 1st line echo, but runs on sh. 

@ECHO OFF
REM =====
REM =====
REM =====
REM ===============================================
REM =====
REM ===== Batch Script Begin ==================
REM =====
REM ===============================================
REM =====


set caught_cd=%cd%

:: path to executable folder:
set mypath=%~dp0
:: set mypath=%cd%
set my_execute_js=m.js
:: below is to put the directory before the .js file
set my_execute_js_dir=%~dp0
set "my_execute_js_dir=%my_execute_js_dir:\=/%"
set my_execute_js=%my_execute_js_dir%%my_execute_js%

set "mypath=%mypath:\=/%"
set compiler_cmds_n_src=/../_utilitys/interpreter_c_base_params.win.txt
set compiler_cmds="" 
::  (above) is defined later
set ex=_src/INTERPRETER/interpreter_win.exe
:: (above) ex is Exectuable Name, can be a system one

set src=_src/COMPILE_THIS
set js_core=/../LOAD_2_core_js

set mp=%mypath%

set foundex=NULL
if exist "%mp%/../../../../../../%ex%" set foundex=%mp%/../../../../../../%ex% 
if exist "%mp%/../../../../../%ex%" set foundex=%mp%/../../../../../%ex%
if exist "%mp%/../../../../%ex%" set foundex=%mp%/../../../../%ex%
if exist "%mp%/../../../%ex%" set foundex=%mp%/../../../%ex%
if exist "%mp%/../../%ex%" set foundex=%mp%/../../%ex%
if exist "%mp%/../%ex%" set foundex=%mp%/../%ex%
if exist "%ex%" set foundex=%mp%/%ex%

if exist "%mp%/../../../../../../%src%" cd "%mp%/../../../../../../%src%"
if exist "%mp%/../../../../../%src%" cd "%mp%/../../../../../%src%"
if exist "%mp%/../../../../%src%" cd "%mp%/../../../../%src%"
if exist "%mp%/../../../%src%" cd "%mp%/../../../%src%"
if exist "%mp%/../../%src%" cd "%mp%/../../%src%"
if exist "%mp%/../%src%" cd "%mp%/../%src%"
if exist "%mp%/%src%" cd "%mp%/%src%"

for /f "delims=" %%i in (%cd%%compiler_cmds_n_src%) do ( set compiler_cmds=%%i )

:: getting js_core file
set tmp_cd=%cd%
cd %cd%%js_core%
set js_core_cd=%cd%
cd %tmp_cd%


:: run command OR look for executable
( %compiler_cmds% "%my_execute_js%" -file_dir_cd "%caught_cd%" -file_core_js_cd "%js_core_cd%" "%*" ) && ( goto end_location ) 

::if above failed
:: RUNS FROM COMPILE_THIS AS CD!!!
if not %foundex%==NULL ( 
		echo ----------------------
		echo ---------------------------------
		echo ---Launching interpreter:
		echo ---------------------------------
		echo ----------------------
		echo %foundex% -run_js "%my_execute_js%" -file_dir_cd "%caught_cd%" -file_core_js_cd "%js_core_cd%" "%*"  


%foundex% -run_js "%my_execute_js%" -file_dir_cd "%caught_cd%" -file_core_js_cd "%js_core_cd%" "%*"  

  goto end_location
)



cd "%mypath%"



set /p Input="interpreter failed, press any key to continue" 
echo .
echo command that failed
echo %compiler_cmds% "%mypath%/%my_execute_js%" -file_dir_cd "%caught_cd%"  "%*"	
echo  .
echo ----------------------------
echo -- FOR RUNNING VIA INTERPRETER (generally, tcc with _src OR precompiled)
echo -----------------------------
echo Failed to execute %compiler_cmds% . The way this script works is it goes up the file tree and locates %src% [ can look up 4-5 files ], then goes to that directory and runs main.js using commands from %compiler_cmds_n_src%. If your running the script using this method, make sure _src exists, and %compiler_cmds_n_src% [inside _src] contains instructions for a given compiler [ tcc is default, but that can be changed in %compiler_cmds_n_src%. ]
echo The compiler can be located relative to _src, if your going for portable, just leave the location for compiler relative to _src. 
echo -----------------------------
echo -- FOR RUNNING USING PRECOMPILED INTERPRETER
echo -----------------------------
echo Also failed to find executable _src with precompiled interpreter in file path.
echo Go to (_src/INTERPRETER), there is a cmd file that given a c compiler is on the system it can generate the interpreter executable. 
echo (_src/INTERPRETER) can also generate a portable interpreter to put above code projects if you don't want to include the full source code with projects.  


:end_location
cd "%caught_cd%"
set /p Input=Enter Text to continue: 


REM =====
REM =====
REM =====
REM ===============================================
REM =====	
REM ====== Batch Script End ======
REM =====
REM ===============================================
GOTO :eof
TYPE CON >NUL
BATCH_SCRIPT




#> 
# ===== PowerShell Script Begin =====
echo "... but also a PowerShell script!"
# ====== PowerShell Script End ======

exit



EOF
# ==========
# ====================================================
# ==========
# ===== Bash Script Begin =============================
# ==========
# ====================================================
# ==========

caught_cd="$PWD"

# path to executable folder
_cwd=$(readlink -f "$0")
_cwd=$(dirname  "$_cwd")
#  _cwd="$PWD";
_exec_this_js_file="m.js";

ex=_src/INTERPRETER/interpreter_lin.exe


# read -p "dirname:$_exec_this_js_file "  username

compiler_cmds_n_src=/../_utilitys/interpreter_c_base_params.unix.txt
compiler_cmds="" # this will fill in later

src=_src/COMPILE_THIS
js_core=../LOAD_2_core_js

foundex="NULL"	

if [ -f "$_cwd/../../../../../../$ex" ] ; 
	then foundex="$_cwd/../../../../../../$ex"; fi;
if [ -f "$_cwd/../../../../../$ex" ] ; 
	then foundex="$_cwd/../../../../../$ex"; fi;
if [ -f "$_cwd/../../../../$ex" ] ; 
	then foundex="$_cwd/../../../../$ex"; fi;	
if [ -f "$_cwd/../../../$ex" ] ; 
	then foundex="$_cwd/../../../$ex"; fi;
if [ -f "$_cwd/../../$ex" ] ; then foundex="$_cwd/../../$ex"; fi;
if [ -f "$_cwd/../$ex" ] ; then foundex="$_cwd/../$ex"; fi;
if [ -f "$_cwd/$ex" ] ; then foundex="$_cwd/$ex"; fi;


if [ -d "$_cwd/../../../../../../$src" ] ; 
	then cd "$_cwd/../../../../../../$src"; fi;
if [ -d "$_cwd/../../../../../$src" ] ; 
	then cd "$_cwd/../../../../../$src"; fi;
if [ -d "$_cwd/../../../../$src" ] ; then cd "$_cwd/../../../../$src"; fi;
if [ -d "$_cwd/../../../$src" ] ; then cd "$_cwd/../../../$src"; fi;
if [ -d "$_cwd/../../$src" ] ; then cd "$_cwd/../../$src"; fi;
if [ -d "$_cwd/../$src" ] ; then cd "$_cwd/../$src"; fi;
if [ -d "$_cwd/$src" ] ; then cd "$_cwd/$src"; fi;

# read -p "dirname:$_cwd/../../../../../../$src"  username

# echo "passing all paramiters via $@, first paramiter is js file to load"; 
# echo TRACE:::: ../___duktape_src_ONCE_COMPILED_CAN_OMIT/duktape.c -run one_with_dlls.c $_cwd/$_exec_this_js_file;

# reading file, line by line. printf would work if new lines needed
while read line
do
compiler_cmds=$compiler_cmds$line
done < $PWD$compiler_cmds_n_src

#getting js_core_loc_src
tmp_cd=$PWD
cd $js_core
js_core_cd=$PWD
cd $tmp_cd

# this is error testing in sh. ( not '!' operator! )
if ! $compiler_cmds "$_cwd/$_exec_this_js_file" -file_dir_cd "$caught_cd" -file_core_js_cd "$js_core_cd" $@
# elif [ 1 -eq 1]
then
	echo $foundex
	if ! [ $foundex = "NULL" ]
	then
		echo ----------------------
		echo ---------------------------------
		echo ---Launching interpreter:
		echo ---------------------------------
		echo ----------------------
		echo $foundex -run_js "$_cwd/$_exec_this_js_file" -file_dir_cd "$caught_cd" -file_core_js_cd "$js_core_cd" $@

 		$foundex -run_js "$_cwd/$_exec_this_js_file" -file_dir_cd "$caught_cd" -file_core_js_cd "$js_core_cd" $@
  	else
		echo 
		echo ------------ COMMANDS THAT FAILED:
		echo	$compiler_cmds "$_cwd/$_exec_this_js_file" -file_dir_cd "$caught_cd" $@ 
		echo	$foundex "$_cwd/$_exec_this_js_file" -file_dir_cd "$caught_cd" $@
		echo [also couldnt find the executable file]
		echo
		echo It didnt work! Maybe the compiler wasnt found [ see  $_compiler_base.unix.txt ] or something else broke...
		echo
		echo -----------------------------
		echo -- FOR RUNNING USING PRECOMPILED INTERPRETER
		echo -----------------------------
		echo Also failed to find executable _src with precompiled interpreter in file path.
		echo Go to _src/INTERPRETER, there is a cmd file that given a c compiler is on the system it can generate the interpreter executable. 	
		echo _src/INTERPRETER can also generate a portable interpreter to put above code projects if you dont want to include the full source code with projects. 
	fi
fi

cd "$caught_cd"
exit $?


# ==========
# ====================================================
# ==========
# ====== Bash Script End =======================
# ==========
# ==================================================
# ==========
case $- in *"i"*) cat /dev/stdin >/dev/null ;; esac
exit




