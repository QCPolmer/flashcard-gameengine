//file_debug_printf("\n\n test2  test \n\n");

// https://softwareengineering.stackexchange.com/questions/307467/what-are-good-habits-for-designing-command-line-arguments
// ----
// see 'POSIX' system stuff on page... it helps
///////////////////////////////////////////////////

//  file_argument_AUTORUN(); 
//  file_argument_AUTORUN_and_setParams(['paramiters','to','run');
//  file_load_js_cd();  // will be set to the js dir!








////////////////////////////////
////////////////////////////////
////////////////////////////////
//////ABOVE IS FILE_ARGUMENTS.js//////////////////////////
////////////////////////////////
////////////////////////////////
////////////////////////////////
////////////////////////////////
////////////////////////////////
////////////////////////////////
////////////////////////////////
////////////////////////////////
////////////////////////////////
////////////////////////////////
////////////////////////////////
////////////////////////////////




var main_run_after_script = function(){
	file_input(`
WARNING!!!
This could potentially break the source code, if an error isn't found!
CLOSE THIS AND BACK UP _SRC PRIOR TO RUNNING!!!
(wouldn't help to have the file to inject to open as well, 
	so it can be saved to revert to 'working' version...)

IF EVERYTHING IS BACKED UP, PRESS ENTER 2 TIMES, OTHERWISE, CLOSE THIS 
AND BACK THE STUFF UP!!!
	`); file_input("");
	// FOR actual use, with an extra param below
	//
	//file_dir_copy(file_js_cd()+"../../", file_js_cd()+"./_src",
	//	1, ["js$"]);
	var tmp_file_to_inject_too = "../file_dir.c";
	var tmp_file_to_inject_too_BACKUP = "./file_dir.c.BACKUP";
	var tmp_file_to_inject_from = "./file_dir_INJECT_C.js";
	var MY_TEXT_TO_EMBED_BETWEEN = "//INJECT_C_CODE_FROM_FILE_HERE//";
	var js_preprocess_file = true;

	var FILE_DOCS_SEPERATOR = "//API_TAG//";
	// the next one is because loading 'file_whatever' will 
	// override file functions
	var caught_cd = file_dir_cd();
	
	file_log_input("\n backing up file in m.js directory...\n");
	var tmp_backup = file_scrub_comments(file_load_noembed( 
				caught_cd, tmp_file_to_inject_too ));
	file_save(caught_cd, tmp_file_to_inject_too_BACKUP,
		tmp_backup );

	// this block will remove comment form api tags:
	var tmp_file_txt = file_load_noembed( 
				caught_cd, tmp_file_to_inject_from );
	var tmp_file_txt = tmp_file_txt.split(FILE_DOCS_SEPERATOR);
	for(var i=1; i< tmp_file_txt.length; i+=2){
	   tmp_file_txt[i] = tmp_file_txt[i].split("\n\r").join("\n")
			.split(/\/\/.*\n/).join("\n");}
	tmp_file_txt = _file_preprocess_js(tmp_file_txt.join(""));
	if(js_preprocess_file){ 
		tmp_file_txt = _file_preprocess_js(tmp_file_txt); }
	
	//testing UglifyJS-ing it 6/8/2026
	file_load_js_noembed( caught_cd, 
		"/../../_utilitys/UglifyJS.MyMinify.js");
	
	file_log("Looking for _utilitys/UglifyJS.MyMinify.js...");
	if(typeof UglifyJS == "undefined"){
		file_log("UglifyJS.MyMinify.js " +
			"---NOT FOUND---! Running script anyway...");
	}else{	file_log("FOUND! running UglifyJS.MyMinify on code...  ");
		tmp_file_txt = UglifyJS.MyMinify(tmp_file_txt);
	}

	file_debug_printf("testing file for errors...");
	// testing script:
	file_run_js_debug(tmp_file_txt);

	file_log_input(`
		Press enter to continue injecting code,
			close this program to stop injecting.
		`);



	file_inject_data_singleblock( 
		file_dir_convert_text_to_c_str( 
			tmp_file_txt ),
		caught_cd + tmp_file_to_inject_too, 
		MY_TEXT_TO_EMBED_BETWEEN);	

	var done = "";
	while( done.trim() !="done"){
		done = file_input(` 
			DONE! 
	LEAVE THIS FILE OPEN AND TRY RUNNING THIS SCRIPT AGAIN!
			NO ERROR ON STARTUP PROBABLY MEANS YOUR GOOD!
		IF THERE IS AN ERROR, ENTER 'r' TO ROLLBACK
			('r' reverts the file to it's pre-inject state!)
			
		---ONLY CLOSE OR TYPE 'done' TO QUIT AFTER TESTING!
`);
		if( done.trim() == "r"){
		  file_save(caught_cd, tmp_file_to_inject_too,
			tmp_backup );		
			if(file_input("done, try inject again?(y)\n")
				.trim() == 'y'){
					main_run_after_script(); }
			break;
		}
	}
	

	return;
	
} 


main_run_after_script();
/*
var file_data_eval = async function(){ 
	file_dir_convert_file_to_c_str();
		return;		


}*/


