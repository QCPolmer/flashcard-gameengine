// this is (mostly) a copy of draw.js that doesn't get draw...
// 	It's here to have a fast-method of per-pixel drawing. 
// use: sketch_init( get_txt) to init. and 
// 	sketch_end() to end. 
// 	ONLY HAVE ONE RUNNING AT A TIME, 
// 	BUT CAN RUN A SUB-FUCTION (whatever) WITH ONE, 
// 		AS THE STACK WILL CATCH PREVIOUS!!!

var _sketch_stack = [[]];
//API_TAG// 
function sketch_init( get_2d_gridstr){
	_sketch_stack.push(sketch_canvas);
	sketch_canvas = _gridstr__2darr_txt_to_2darr(
			 	get_2d_gridstr);
	sketch_canvas_width = sketch_canvas[0].length;
	sketch_canvas_height = sketch_canvas.length; }
function sketch_end(){ sketch_canvas = _sketch_stack.pop(); }
//needs testing:
function sketch_char(str, x,y){
	if( x>0 && x< sketch_canvas_width &&
		y>0 && y< sketch_canvas_height){
			sketch_canvas[y][x]= str[0];	} }
//needs testing:
function sketch_char_get( x,y){
	if( x>0 && x< sketch_canvas_width &&
		y>0 && y< sketch_canvas_height){
			return	sketch_canvas[y][x];	} 
	return ""; }



//sketch_canvas is 2d list in js
var sketch_canvas = []; var sketch_canvas_width = 0; var sketch_canvas_height = 0;
// function sketch_settup_canvas_custom( width, height)
function sketch_get(){ return _gridstr__from_2darr(sketch_canvas); }
// below will depend on 'sketch_grid' function!!!


var _ray_oclock = { // 8 rays
	0:{ x_sign:1, y_sign:-1, i_is_x_j_is_y:false}, 
	1:{ x_sign:1, y_sign:-1, i_is_x_j_is_y:true}, 
	2:{ x_sign:1, y_sign:1, i_is_x_j_is_y:true}, 
	3:{ x_sign:1, y_sign:1, i_is_x_j_is_y:false},
	4:{ x_sign:-1, y_sign:1, i_is_x_j_is_y:false},
	5:{ x_sign:-1, y_sign:1, i_is_x_j_is_y:true}, 
	6:{ x_sign:-1, y_sign:-1, i_is_x_j_is_y:true},
	7:{ x_sign:-1, y_sign:-1, i_is_x_j_is_y:false}
};
var _ray_oclock_stagger = { //8 rays
	// draws in 2 sweeps instead of 1, for slow framerate
	0:{ x_sign:1, y_sign:-1, i_is_x_j_is_y:false}, 
	1:{ x_sign:1, y_sign:1, i_is_x_j_is_y:true}, 
	2:{ x_sign:-1, y_sign:1, i_is_x_j_is_y:false},
	3:{ x_sign:-1, y_sign:-1, i_is_x_j_is_y:true},
	4:{ x_sign:1, y_sign:-1, i_is_x_j_is_y:true}, 
	5:{ x_sign:1, y_sign:1, i_is_x_j_is_y:false},
	6:{ x_sign:-1, y_sign:1, i_is_x_j_is_y:true}, 
	7:{ x_sign:-1, y_sign:-1, i_is_x_j_is_y:false}
}
//basically used internally
function _sketch_draw_shadows_ray( 
  o_clock_strt, o_clock_end, 
	max_depth, x_offset, y_offset, wall_map_gfx, wall_x, wall_y, 
	gridstr_screen_light_spaces_for_opaque,  draw_light_char,
	OPTIONAL_stagger_o_clock_drawing){
	//draw_light_char = "&";
	// the last two should allow secondary light 
	// 	sources, if I draw all light on one map, then use 
	// 	that map as 'gridstr_screen_light'
	x_offset = Math.floor(x_offset); y_offset= Math.floor(y_offset);
	//scaling to ray-size (will need to place x-(1/2raysize)
	if(gridstr_screen_light_spaces_for_opaque.length > 1){
		gridstr_screen_light_spaces_for_opaque = 
			gridstr_scale_nearest_neighbor( 
				gridstr_screen_light_spaces_for_opaque,
				max_depth*2, max_depth*2); }

	var wll_wdth = gridstr_width(wall_map_gfx);
	var scrn_wdth = gridstr_width(
		gridstr_screen_light_spaces_for_opaque);
	var tmp_sketch_width = sketch_get_width();
     for(var o_clock = o_clock_strt;o_clock < o_clock_end; o_clock+=1){
	if(OPTIONAL_stagger_o_clock_drawing != true){
		var ray_key = _ray_oclock[ o_clock ];
	}else{ var ray_key = _ray_oclock_stagger[ o_clock ];}
	var x_sign = ray_key.x_sign;
	var y_sign = ray_key.y_sign;
	var i_is_x_j_is_y = ray_key.i_is_x_j_is_y;
	//var max_depth = 40;
	var min_len =0;  var max_len=1;
	var prev_line = new Int8Array(max_depth);
	     prev_line[0] = 1;
	var cur_line = new Int8Array(max_depth);
	var x=0; var y=0; var prev_j =0; //defined later
	var inverse_line_for_tapering = 0 // defined later
	var tmpChar = "" //defined later
	for(var i=0; i< max_depth; i+=1){	
	    if(i_is_x_j_is_y){
	 	for(var j=min_len; j< max_len; j+=1){
			if(i == 0){ prev_j = 0;
			}else{prev_j= Math.floor(((j+.3)/(i))*(i-1));}
			// changed with i_is_x_j_is_y 
			// the (j+.3) for rounding(really .5, .3 for looks)
			x =  i*x_sign+ x_offset; y=j*y_sign+y_offset;
			if( prev_line[prev_j] ==1){ 
				tmpChar=gridstr_char_get(wall_map_gfx, 
				  	x-wall_x,y- wall_y,wll_wdth);
				
				if(tmpChar=="" ||
				  tmpChar==" "){
						cur_line[j] = 1;}
				//optimizing for large draw area
				if(x <0 || y<0 || 
					x > sketch_canvas_width ||
				      y >sketch_canvas_height){continue;}
				if(scrn_wdth ==0){
					sketch(draw_light_char, x, y,"");
				}else{ if(gridstr_char_get(
				gridstr_screen_light_spaces_for_opaque, 
				  	x- x_offset+max_depth,
					y-y_offset+max_depth,
					scrn_wdth)!=" "){
					sketch(draw_light_char, x, y,"");
				}}
		}	} 
	    }else{
		for(var j=min_len; j< max_len; j+=1){
			if(i == 0){ prev_j = 0;
			}else{prev_j =Math.floor(((j+.3)/(i))*(i-1));}
			// changed with i_is_x_j_is_y
			// the (j+.3) for rounding(really .5, .3 for looks)
			x =  j*x_sign+ x_offset; y=i*y_sign+y_offset;
			if( prev_line[prev_j] ==1){ 
				tmpChar=gridstr_char_get(wall_map_gfx, 
				  	x-wall_x,y- wall_y,wll_wdth);
				if(tmpChar=="" ||
				  tmpChar==" "){
						cur_line[j] = 1;}
				//optimizing for large draw area
				if(x <0 || y<0 || 
					x > sketch_canvas_width ||
				      y >sketch_canvas_height){continue;}
				if(scrn_wdth ==0){
					sketch(draw_light_char, x, y,"");
				}else{ if(gridstr_char_get(
				gridstr_screen_light_spaces_for_opaque, 
				  	x- x_offset+max_depth,
					y-y_offset+max_depth,
					scrn_wdth)!=" "){
					sketch(draw_light_char, x, y,"");
				}}
		}	} 
	    }
	//prev_line = cur_line.concat();
	  prev_line = cur_line;
	  cur_line = new Int8Array(max_depth);
	  //prev_line = cur_line.concat();
	//tapering, detecting max line length (i+j and max_depth) 
	/////////linear:
	//var inverse_line_for_tapering = max_depth-i;
	/////////quadratic:
	//var inverse_line_for_tapering = -1 + Math.pow(max_depth-i,2);
	/////////squar_root:
	//var inverse_line_for_tapering =  Math.sqrt(max_depth-i,2);
	//////////circular:
	  inverse_line_for_tapering=-1+Math.sqrt(Math.pow(max_depth,2)-
					Math.pow(i,2)) ;
	  if(max_len > 2 && max_len >= inverse_line_for_tapering){	
		max_len = inverse_line_for_tapering;}
	  max_len +=1;
 	}	}
}

// need to do:
function sketch( str, x, y, transp_char_or_0){
	_gridstr__2darr_overlay( 
		sketch_canvas, _gridstr__2darr_auto_buffer_get(str),
		Math.floor(x),  Math.floor(y), 	transp_char_or_0);
}
function sketch_grid( str, x, y, transp_char_or_0){
	//document.body.innerHTML = str;
	//console.log(str);
	// console.log( _gridstr__2darr_auto_buffer_get(str));
	_gridstr__2darr_overlay( 
		sketch_canvas, _gridstr__2darr_auto_buffer_get(str),
		x,y, 	transp_char_or_0);
}
//NOTE: below is NOT as fast in JS, but MUCH faster in C. 
// ( as it requires initialized and deinitializing the sketch in js)
// Probably best to use when needed, and not more. 
function sketch_replaceall(char_to_replace, char_to_replace_with){
	var tmp_str = sketch_get();
	sketch_end();
	sketch_init(tmp_str.replaceAll(
		char_to_replace, char_to_replace_with));
}
// This is here for speed, as doing this with 2 gridstrs
// will be slower for drawing many many things
// (though will work: have one gridstr overlay another) 
function sketch_grid_DRAW_UNDER_TRANSPCHAR(str, x, y, transp_char_or_0){
	_gridstr__2darr_overlay_DRAW_UNDER_OVERLAYCHAR( 
		sketch_canvas, _gridstr__2darr_auto_buffer_get(str),
		x,y, 	transp_char_or_0);	
}
function sketch_get_width(){ return sketch_canvas_width;}
//API_TAG// 
