////////////////////////////////////////
//////// REQUIRES DRAW LIB
///////////////////////////
/// INCLUDING BELOW IN THE 'one.c' FILE, IN CASE IT'S POSSIBLE 
//	TO BUNDLE IT WITH WITH COMPILER, SO I DON'T NEED DLLS!


// https://stackoverflow.com/questions/10918206/cross-platform-sleep-function-for-c
#if defined(DUK_VERSION)
void update_duktape_port_settup(duk_context *ctx);
#endif



//this will replace curses
//void addch(char getchar){ printf("%c", getchar);}
//
////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
/////////////// MOUSE SECTION /////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//

int _update_mouseX = 0; int _update_mouseY = 0;
int _update_mouse_up = 0; int _update_mouse_down = 0;
void _update_mouse_check_N_C_update(int x, int y, 
		int getPressed, int getReleased){
	// resetting these in update_controller_mouse_duktape_port
	//_update_mouse_up = 0; _update_mouse_down = 0;
	if(getPressed){  _update_mouse_down = 1; }
	if(getReleased){ _update_mouse_up = 1; }
	_update_mouseX = x; _update_mouseY = y;
}
////////////////////////////////////////////////////////
////// MOUSE SECTION- WINDOWS
/////////////////////////////////////////////

/// GROK 2.0 (THE AI) WROTE THE MOUSE SECTION,
//	I HELPED, AND PUT A LOT IN THE CODE,
//	BUT I WANT TO GIVE GROK CREDIT!!!
#if defined(_WIN32) || defined(WIN32) || defined(WIN64) || defined(_WIN64)
int _win_mouse_init= 0;
void _update_mouse_end(){ 
	_win_mouse_init =0; }

// GROK 2.0 MOSTLY WROTE THIS!!! I'm not good with low-level mouse stuff
void _update_mouse_checkClicks() {
    static HANDLE hStdin = INVALID_HANDLE_VALUE; // Make hStdin static to initialize once
    
    if (hStdin == INVALID_HANDLE_VALUE || _win_mouse_init ==0) {
	_win_mouse_init = 1;
        hStdin = GetStdHandle(STD_INPUT_HANDLE);
        if (hStdin == INVALID_HANDLE_VALUE) {
            printf("Failed to get stdin handle\n");
            return;
        }
        
        // Ensure mouse input is enabled
        DWORD mode = 0;
        if (!GetConsoleMode(hStdin, &mode)) {
            printf("Failed to get console mode\n");
            return;
        }
        mode &= ~0x0040; // Disable Quick Edit Mode
        mode |= 0x0080 | 0x0010; // Enable Extended Flags and Mouse Input
        if (!SetConsoleMode(hStdin, mode)) {
            printf("Failed to set console mode\n");
            return;
        }
    }
	
    INPUT_RECORD irInBuf[128];
    DWORD cNumRead;
    DWORD eventsProcessed = 0;
    
    // Process all events in the buffer
    if (PeekConsoleInput(hStdin, irInBuf, 128, &cNumRead) && cNumRead > 0) {
        for (DWORD i = 0; i < cNumRead; i++) {
            if (irInBuf[i].EventType == MOUSE_EVENT) {
                MOUSE_EVENT_RECORD mer = irInBuf[i].Event.MouseEvent;
                if( //mouse up
		   (mer.dwButtonState == 0 && mer.dwEventFlags == 0) || 
         	  (mer.dwEventFlags & MOUSE_MOVED && mer.dwButtonState 
				== 0)) { 
    			_update_mouse_check_N_C_update(
        		mer.dwMousePosition.X, mer.dwMousePosition.Y, 0, 1);
		}else if(mer.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED) { //mouse down
		   _update_mouse_check_N_C_update(
		     mer.dwMousePosition.X, mer.dwMousePosition.Y, 1, 0);
                
		} else if (mer.dwEventFlags & MOUSE_MOVED) { // Mouse move
                    _update_mouse_check_N_C_update(
		     mer.dwMousePosition.X, mer.dwMousePosition.Y, 0, 0);
                }
                // Consume only mouse events
                INPUT_RECORD irTemp;
                ReadConsoleInput(hStdin, &irTemp, 1, &cNumRead);
                eventsProcessed++;
            } else { // For non-mouse events, keep track but not consume
                eventsProcessed++;}
        }
        // Now, push back all events we didn't consume explicitly
        DWORD remainingEvents = cNumRead - eventsProcessed;
        if (remainingEvents > 0) {
            INPUT_RECORD irTemp[128];
            DWORD cNumReadTemp;
            if (PeekConsoleInput(hStdin, irTemp, remainingEvents, &cNumReadTemp)) {
                // Push back all remaining events
                WriteConsoleInput(hStdin, irTemp, remainingEvents, &cNumReadTemp);
}	}	}	}
#endif

////////////////////////////////////////////////////////
////// MOUSE SECTION- LINUX
/////////////////////////////////////////////

/// GROK 2.0 (THE AI) WROTE THE MOUSE SECTION,
//	I HELPED, AND PUT A LOT IN THE CODE,
//	BUT I WANT TO GIVE GROK CREDIT!!!

#if defined(__unix__) || defined(__unix__) || defined(__unix) || defined(__LINUX__)
// LINUX:
//
#include <stdio.h>
#include <unistd.h>
#include <termios.h>
#include <fcntl.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/ioctl.h>

// Set terminal to raw mode for immediate input
void _update_mouse_set_raw_mode(struct termios *old_termios) {
    struct termios new_termios;
    tcgetattr(STDIN_FILENO, old_termios);
    new_termios = *old_termios;
    new_termios.c_lflag &= ~(ICANON | ECHO); // Non-canonical, no echo
    tcsetattr(STDIN_FILENO, TCSANOW, &new_termios);
}

// Restore terminal settings
void _update_mouse_restore_mode(struct termios *old_termios) {
    tcsetattr(STDIN_FILENO, TCSANOW, old_termios);
}

static struct termios old_termios;

//////////////////
/// NOT CURRENTLY USED, SHOULD RESTORE MOUSE -STATE
//	FOR HIGHLIGHTING IN LINUX (otherwise, no mouse use!)
///////////
static int rawModeInitialized = 0;
static int _lin_mouse_init = 0;  
                            
void _update_mouse_end(){ // Disable mouse tracking
    printf("\033[?1000l\033[?1002l");
    fflush(stdout);
    _update_mouse_restore_mode(&old_termios);
    //just added...	
    rawModeInitialized = 0; 
    _lin_mouse_init =0;
} 

// GROK 2.0 MOSTLY WROTE THIS!!! I'm not good with low-level mouse stuff

void _update_mouse_init_if_not_Init_and_set_exit_cleanup(){ // Enable mouse tracking with movement for xterm
   if(_lin_mouse_init == 0 ){ _lin_mouse_init =1;
	printf("\033[?1000h\033[?1003h"); 
	//printf("\033[?1000h\033[?1002h");
	fflush(stdout);
}  } // 1000 for button events, 1002 for mouse movement

// MAY NEED TO MODIFY BUTTON CODES BASED ON TERMINAL
int MOUSE_BUTTON1 =1; int MOUSE_BUTTON2 =2; int MOUSE_BUTTON3 = 0;
int MOUSE_MOVE_LOW_RANGE = 32; int MOUSE_MOVE_HIGH_RANGE = 40;

int _linux_mouse_x = 0; int _linux_mouse_y=0; int _linux_mouse_button=0;
//linux version, MOUSE CONSTANTS SET IN KEYBOARD HANDLER FOR LINUX
// 		(its cleaner
void _update_mouse_checkClicks() {
    
    //_update_mouseX =_linux_mouse_x; _update_mouseY= _linux_mouse_y; 
    _update_mouse_init_if_not_Init_and_set_exit_cleanup();
    int tmp_button_pressed =0; int tmp_button_released =0;
    int b = _linux_mouse_button-32; 
    _linux_mouse_button=0;

   if (b >= MOUSE_MOVE_LOW_RANGE && b <= MOUSE_MOVE_HIGH_RANGE){ //moving
   } else if (b == MOUSE_BUTTON1 || b == MOUSE_BUTTON2 ||  
			b == MOUSE_BUTTON3 ) { tmp_button_pressed=1;
    } else if (b == 3) { tmp_button_released=1;
                    }else {}  
    // 33 if offset for mouse that linux throws in
    _update_mouse_check_N_C_update( _linux_mouse_x, _linux_mouse_y, 
		tmp_button_pressed, tmp_button_released);
	//int _linux_mouse_button=0;
    if (!rawModeInitialized) {
        _update_mouse_set_raw_mode(&old_termios);
        rawModeInitialized = 1; }

    return;
}

#endif

////////////////////////////////////////////////////////
////// MOUSE SECTION- SHARED 
/////////////////////////////////////////////
/// GROK 2.0 (THE AI) WROTE THE MOUSE SECTION,
//	I HELPED, AND PUT A LOT IN THE CODE,
//	BUT I WANT TO GIVE GROK CREDIT!!!

// the pre-defined global mouse vars:
// var _controller_mouse_x_OS_SETS=0; var _controller_mouse_y_OS_SETS=0;
// var _controller_mouse_up_OS_SETS=0; var _controller_mouse_down_OS_SETS=0
static duk_ret_t update_controller_mouse_duktape_port(duk_context *ctx){
#if defined(_WIN32) || defined(WIN32) || defined(WIN64) || defined(_WIN64) || defined(__unix__) || defined(__unix__) || defined(__unix) || defined(__LINUX__)
	_update_mouse_checkClicks();
	if(_update_mouse_up ==1){ _update_mouse_down = 0;}
	duk_push_int( ctx, _update_mouseX);
	duk_put_global_string(ctx, "_controller_mouse_x_OS_SETS");
	duk_push_int( ctx, _update_mouseY);
	duk_put_global_string(ctx, "_controller_mouse_y_OS_SETS");
	duk_push_int( ctx, _update_mouse_up);
	duk_put_global_string(ctx, "_controller_mouse_up_OS_SETS");
	duk_push_int( ctx, _update_mouse_down);
	duk_put_global_string(ctx, "_controller_mouse_down_OS_SETS");
	//resetting here to not override the 'up' command!	
	_update_mouse_up = 0; _update_mouse_down=0;
#endif
	return 0;
	//duk_push_c_function( ctx,
	//		js_port_duktape_rmloaded_col_SIMPLE, 3);
	//duk_put_global_string(ctx, "rmloaded_col_test_SIMPLE");
}




////////////////////////////////////////////////////////
////// END MOUSE SECTION
/////////////////////////////////////////////

//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
/////////////// LINUX   VERSION: /////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
// djgpp runs below code, unless I check for __DOS__...
// I doubt other dos compilers will work at all.
#if defined(__DJGPP__)
#else

#if defined(__unix__) || defined(__unix__) || defined(__unix) || defined(__LINUX__)
// this unistd is used for usleep
#include <unistd.h>
// File: clear_screen.c
// https://stackoverflow.com/questions/228617/how-do-i-clear-the-console-in-both-windows-and-linux-using-c
void clear(void) { printf("\x1B[2J"); }

// https://stackoverflow.com/questions/448944/c-non-blocking-keyboard-input
// https://stackoverflow.com/questions/421860/capture-characters-from-standard-input-without-waiting-for-enter-to-be-pressed/912796#912796
#include <unistd.h>
#include <termios.h>

/*
char getch_OLD() {
        char buf = 0;
        struct termios old = {0};
        if (tcgetattr(0, &old) < 0)
                perror("tcsetattr()");
        old.c_lflag &= ~ICANON;
        old.c_lflag &= ~ECHO;
        old.c_cc[VMIN] = 1;
        old.c_cc[VTIME] = 0;
        if (tcsetattr(0, TCSANOW, &old) < 0)
                perror("tcsetattr ICANON");
        if (read(0, &buf, 1) < 0)
                perror ("read()");
        old.c_lflag |= ICANON;
        old.c_lflag |= ECHO;
        if (tcsetattr(0, TCSADRAIN, &old) < 0)
                perror ("tcsetattr ~ICANON");
        return (buf);
}
*/
// https://stackoverflow.com/questions/23958647/backspace-cant-be-detected-in-linux-terminal-kr-1-10-exercize
int getch(void)
{


 struct termios oldt,
    newt;
    int ch;
    tcgetattr( STDIN_FILENO, &oldt );
    newt = oldt;
    newt.c_lflag &= ~( ICANON | ECHO );
    tcsetattr( STDIN_FILENO, TCSANOW, &newt );
    ch = getchar();
    tcsetattr( STDIN_FILENO, TCSANOW, &oldt );
    return ch;
}


#include <stdio.h>
#include <sys/select.h>
#include <sys/ioctl.h>

int kbhit() {
    static const int STDIN = 0;
    static int initialized = 0;

    if (! initialized) {
        // Use termios to turn off line buffering
	struct termios term;
        tcgetattr(STDIN, &term);
        term.c_lflag &= ~ICANON;
        tcsetattr(STDIN, TCSANOW, &term);
        setbuf(stdin, NULL);
        initialized = 1;
    }

    int bytesWaiting;
    ioctl(STDIN, FIONREAD, &bytesWaiting);
    return bytesWaiting;
}

//LINUX char handler
void _update_getch( char * str_in){
	//if(kbhit()){ 
	if(kbhit()){
		char c = getch();
		if(c == '\n'||c =='\r'){ sprintf(str_in, "Enter"); return;}
		if(c == 127||c == 8 || c =='\b'){
			sprintf(str_in, "Backspace"); return;} 
		if(c == '\t'){sprintf(str_in, "Tab"); return;} 
		// DELETE SEEMS HARD TO CODE!
		// 	Probably better to just use Esc. as needed.
		//if(ch == '\ '){sprintf(str_in, " "); return;} 
		//if(c == 27){sprintf(str_in, "Escape"); return;} 
		if(c == '\033'){
		 	if(!kbhit()){ sprintf(str_in, "Escape"); return;} 
		       if(kbhit()){
			 c = getch();
			 if(c == '['){ 
				//zzz
			 	c = getch();
				//mouse events ignoring (handled elsewhere)
				if(c =='M'){
					// Ignore mouse event
					for (int i = 0;
					  i < 3 && kbhit(); i++) {
					    c = getch();
						//c>=64 = movement
					    if(i==0 && c<64){
						_linux_mouse_button =
						  (unsigned char)c +0;}
					    if(i==1 ){
						_linux_mouse_x = 
						   (unsigned char)c -33;}
					    if(i==2 ){
						_linux_mouse_y = 
						  (unsigned char)c -33;} }
					// trying again
					return _update_getch( str_in);
				}else{
			          if(c == 'A'){ 
				    sprintf(str_in, "ArrowUp"); return;}
			   	  if(c == 'B'){ 
				    sprintf(str_in, "ArrowDown"); return;}
			    	  if(c == 'C'){ 
				    sprintf(str_in, "ArrowRight"); return;}
			     	  if(c == 'D'){ 
				    sprintf(str_in, "ArrowLeft"); return;}
				} 
                        	_update_getch( str_in); 
                        return;
		}	}       }
		
		sprintf(str_in,"%c", c);
	}else{ sprintf(str_in,""); } 
}
	//Native linux function
	//void usleep(int waitTime)

void _update_dont_clear(){
	//setting location and drawing;
	printf("\033[%d;%dH", 1,1);
	printf("%s", _draw_canvas);
	 }

//https://stackoverflow.com/questions/448944/c-non-blocking-keyboard-input


void update_start_game( ){ clear();
	//enable nonblocking
	 printf("\e[?25l"); // hide cursor
}
	
void update_stop_game( ){ clear();
	//blocking
	//fcntl(0, F_SETFL, fcntl(0, F_GETFL) | O_BLOCK);
	printf("\e[?25h"); // show cursor
}
void my_usleep(int get_milliseconds){
	// without this next line, it don't work right. 
	// not great with posix, so I'm not sure why.
	fflush(stdout);		
	usleep(get_milliseconds);
}

#endif

// for 'sleep'
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
/////////////// DOS VERSION: /////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
#if defined(__DOS__) || defined(__MSDOS__)

#ifdef __WATCOMC__
//#include <i86.h>
// got from 'perplexity.ai'
void gotoxy(int x, int y){ 
  printf("\033[%i;%iH", y, x); }//may have x/y reversed... 
// got from 'perplexity.ai'
void clrscr(){ printf("\033[2J\033[H"); }
#endif
void clear(void) { clrscr(); }
void my_usleep(int waitTime) { }//delay(waitTime/ 1000); }// in microseconds 

#define BUFSIZE2 2000
	char buffer[BUFSIZE2];
void _update_dont_clear(){ 
	
   	setvbuf(stdout, buffer, _IOFBF, BUFSIZE2);
	int i=0; int j=0; 
	//ESCAPE SEQUENCES (I think \033 is for esc in printf:
	//https://www.robvanderwoude.com/ansi.php#CursorPositioning
	// your code here
    	//printf("\033[?25h"); // show cursor
	
	gotoxy(0,0);
	j=0; while( j<1000){ //_draw_canvas[j]!='\0'){  
			putchar(_draw_canvas[j]); j+=1;  }

	/*
	while(i<10000000){
		printf("%i++++", i);
		j=0; while( j<1400){ //_draw_canvas[j]!='\0'){  
			putchar(_draw_canvas[j]); j+=1;  }
		
		//printf("%s", _draw_canvas);
		i+=1;
		gotoxy(0,0);
	}
	*/

//gotoxy(0,0); //printf("%s", _draw_canvas);
 }

#define ESCAPE_SEQUENCE_CHAR 224
void _update_getch( char * str_in){
  	
	setbuf(stdin, NULL); // disable buffering on stdin
			//MAYBE will result in speed-increase
	char ch = 0; 
	if(kbhit()){
		ch = getch();
		
		if(ch == '\r'|| ch == '\n'){
			sprintf(str_in, "Enter"); return;} 
		if(ch == '\b'){sprintf(str_in, "Backspace"); return;} 
		if(ch == '\t'){sprintf(str_in, "Tab"); return;} 
		//if(ch == '\ '){sprintf(str_in, " "); return;} 
		if(ch == 27){sprintf(str_in, "Escape"); return;} 

		//printf("\n %i %i\n", ch, getch());		
#ifdef __WATCOMC__
		if((int)ch > 0 || (int)ch== ESCAPE_SEQUENCE_CHAR){ // arrow key code=0, followed by 2knd 
#else
		if ((int)ch >= 0 ){ //arrow key code = 0, followed by 2knd
#endif
			sprintf(str_in, "%c", (int)ch); 
		}else{ 		    
			ch = getch();
		    
		    if(ch ==  77){sprintf(str_in, "ArrowRight"); return;} 
			if(ch == 75){sprintf(str_in, "ArrowLeft"); return;} 
			if(ch ==  72){sprintf(str_in, "ArrowUp"); return;} 
			if(ch == 80){sprintf(str_in, "ArrowDown"); return;} 

			//uncaught 
			sprintf(str_in, "%i", ch);
		}	
		return;
	}
	sprintf(str_in, "");
}
#undef ESCAPE_SEQUENCE_CHAR
void update_start_game( ){ clear();
	//hide cursor
//	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
 //  CONSOLE_CURSOR_INFO info;
  // info.dwSize = 100;
   //info.bVisible = 0;
   //SetConsoleCursorInfo(consoleHandle, &info);

}// initscr(); _update_dont_clear(); }
void update_stop_game( ){ clear();
	//show cursor
//	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
  // CONSOLE_CURSOR_INFO info;
  // info.dwSize = 100;
  // info.bVisible = 1;
  // SetConsoleCursorInfo(consoleHandle, &info);
	 }// endwin(); }


#endif
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
/////////////// WINDOWS VERSION: /////////////////////////
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
#if defined(_WIN32) || defined(WIN32) || defined(WIN64) || defined(_WIN64)
// found at: 
//http://filipivianna.blogspot.com/2010/07/usleep-on-windows-win32.html
//
//
#include <windows.h>
#include <conio.h>
// https://stackoverflow.com/questions/228617/how-do-i-clear-the-console-in-both-windows-and-linux-using-c
void clear(void) {
    HANDLE hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
    COORD topLeft = {0, 0};
    DWORD dwCount, dwSize;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(hOutput, &csbi);
    dwSize = csbi.dwSize.X * csbi.dwSize.Y;
    FillConsoleOutputCharacter(hOutput, 0x20, dwSize, topLeft, &dwCount);
    FillConsoleOutputAttribute(hOutput, 0x07, dwSize, topLeft, &dwCount);
    SetConsoleCursorPosition(hOutput, topLeft);
}
//already defined!
//char getch(){
//	return _getch();
//}
void my_usleep(int waitTime) {
	
    __int64 time1 = 0, time2 = 0, freq = 0;

    QueryPerformanceCounter((LARGE_INTEGER *) &time1);
    QueryPerformanceFrequency((LARGE_INTEGER *)&freq);
	
    do { 
        QueryPerformanceCounter((LARGE_INTEGER *) &time2);
    } while((time2-time1) < waitTime);
}
void _update_dont_clear(){
	//goto start.
	COORD topLeft = {0, 0};
	HANDLE hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleCursorPosition(hOutput, topLeft);

	printf("%s", _draw_canvas);
	//for(int i2=0; i2< _draw_canvas_length; i2++){ 
	//	addch( _draw_canvas[i2] );}
	//free(sub_str);
	}

#define ESCAPE_SEQUENCE_CHAR 224
//WINDOWS char handler
void _update_getch( char * str_in){
  	char ch = 0; 
	if(kbhit()){
		ch = getch();
		
		if(ch == '\r'|| ch == '\n'){
			sprintf(str_in, "Enter"); return;} 
		if(ch == '\b'){sprintf(str_in, "Backspace"); return;} 
		if(ch == '\t'){sprintf(str_in, "Tab"); return;} 
		//if(ch == '\ '){sprintf(str_in, " "); return;} 
		if(ch == 27){sprintf(str_in, "Escape"); return;} 

		//printf("\n %i %i\n", ch, getch());		
#ifdef __WATCOMC__
		if((int)ch > 0){ // arrow key code=0, followed by 2knd 
#else
		if ((int)ch >= 0 ){ //arrow key code = 0, followed by 2knd
#endif
			sprintf(str_in, "%c", (int)ch); 
		}else{ 		    
			ch = getch();
		    
		    if(ch ==  77){sprintf(str_in, "ArrowRight"); return;} 
			if(ch == 75){sprintf(str_in, "ArrowLeft"); return;} 
			if(ch ==  72){sprintf(str_in, "ArrowUp"); return;} 
			if(ch == 80){sprintf(str_in, "ArrowDown"); return;} 

			//uncaught 
			sprintf(str_in, "%i", ch);
		}	
		return;
	}
	sprintf(str_in, "");
}
#undef ESCAPE_SEQUENCE_CHAR
//can probably remove these...
void update_start_game( ){ clear();
	//hide cursor
	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
   CONSOLE_CURSOR_INFO info;
   info.dwSize = 100;
   info.bVisible = 0;
   SetConsoleCursorInfo(consoleHandle, &info);

}// initscr(); _update_dont_clear(); }
void update_stop_game( ){ clear();
	//show cursor
	HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
   CONSOLE_CURSOR_INFO info;
   info.dwSize = 100;
   info.bVisible = 1;
   SetConsoleCursorInfo(consoleHandle, &info);
	 }// endwin(); }

#endif
//below is for ifndef (if not) __DJGPP__!!!
#endif

char * update_dont_clear_js_c_funct_name(){ return "_update_dont_clear"; }
char * update_dont_clear_js_funct(){
	return 
	"var _update_now, _update_delta, _update_then = Date.now();"
	"var _update_MAX_FAMERT_DIFF = 20;"
	"function update_dont_clear(){ "
		"_update_now = Date.now(); "
		"_update_delta = _update_now - _update_then;"
		//"while(0){"
		"while( (1000 / _update_delta) > _update_framerate){" 
			//This here 'zooms in', waiting less on framerate
			"tmpFrameRt_diff =  "
				"(1000-_update_framerate) / _update_delta;"
			"if(tmpFrameRt_diff > _update_MAX_FAMERT_DIFF){"
				"update_sleep(10);"
			"}else{ update_sleep(1);}"
			"_update_now = Date.now();"
			"_update_delta = _update_now-_update_then; }"
		"_update_dont_clear();"
		"_update_then = _update_now; }";};
//NOT actually used, the 'update js function'
void _update( ){ //clears screen after update
	_update_dont_clear();
	draw_clear_canvas(); }
char * update_js_funct(){
	return "function update(){ "
			"update_controller_mouse();"
			"controller_interpreter(controllers[0],"
		       		"duktape_os_getch(),'');"
			"update_controller();"
			"update_dont_clear();"
			"draw_clear_canvas();"
	"}";};
char * update_js_funct_set_framerate_limit(){
	return 
	"_update_framerate = 24;"
	"function update_set_framerate(getfps){ "
		"_update_framerate = getfps;}"; }

// NOT this
void update_sleep( int numb_milisecs ){ 
	//Sleep(numb_milisecs); // don't run fast enough
	my_usleep(numb_milisecs *1000);
	//my_sleep( numb_milisecs);	
}

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////// Duktape Port/////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
#if defined(DUK_VERSION)
//////////////////////////////
///////////////////////////////
// in js: function update( )... return nothing
static duk_ret_t js_port_duktape__update_dont_clear(duk_context *ctx){
	_update_dont_clear(); 
	return 0;  /* one return value */ }
///////////////////////////////
// in js: function update_sleep( )... return nothing
static duk_ret_t js_port_duktape_update_sleep(duk_context *ctx){
	update_sleep( (int) duk_to_number(ctx, 0));
	return 0;  /* one return value */ } 
///////////////////////////////
// in js: function update_start_game( )... return nothing
static duk_ret_t js_port_duktape_update_start_game(duk_context *ctx){
	update_start_game(); 
	return 0;  /* one return value */}
///////////////////////////////
// in js: function update_pause_rmloaded_loop( )... return nothing
static duk_ret_t js_port_duktape_update_stop_game(duk_context *ctx){	
	update_stop_game(); 
	return 0;  /* one return value */}

/////////////////////////////////////////////
//// simple function, as it's port specific, 
//	I'm just using it here. 
////////////////////////
int js_port_duktape_os_getch__A_PREV = '\0';
static duk_ret_t js_port_duktape_os_getch(
		duk_context *ctx ){
   	char a[20];
	_update_getch(a );
	if(a[0] != '\0'){ // this block is removing duplicate keypresses.
		if(a[0] == js_port_duktape_os_getch__A_PREV){
			char tmp_a[20];
			_update_getch(tmp_a );
			if(tmp_a[0] != '\0'){
				sprintf(a, "%s", tmp_a);
			}
		} }

	js_port_duktape_os_getch__A_PREV = a[0];
	duk_push_string( ctx, a); 
	return 1;  /* one return value */ }
static duk_ret_t js_port_duktape_update_mouse_end( duk_context *ctx){
                _update_mouse_end();
		return 0; /* return 0 values */ }

void update_duktape_port_settup(duk_context *ctx){

	duk_push_c_function(ctx, update_controller_mouse_duktape_port, 0);
	duk_put_global_string(ctx, "update_controller_mouse_OS_SPECIFIC");

	duk_push_c_function(ctx, js_port_duktape_os_getch, 0);
	duk_put_global_string(ctx, "duktape_os_getch");
	
	duk_push_c_function(ctx, js_port_duktape__update_dont_clear, 0);
	duk_put_global_string(ctx, "_update_dont_clear");
	duk_push_string( // update_dont_clear()
			ctx, update_dont_clear_js_funct() ) ;
		duk_eval_noresult(ctx); 
	duk_push_string( // update()
			ctx, update_js_funct() ) ;
		duk_eval_noresult(ctx); 
	duk_push_string( // update_set_framerate()
			ctx, update_js_funct_set_framerate_limit() ) ;
		duk_eval_noresult(ctx); 
	duk_push_c_function(ctx, js_port_duktape_update_sleep, 1);
	duk_put_global_string(ctx, "update_sleep");
	duk_push_c_function(ctx, js_port_duktape_update_start_game, 0);
	duk_put_global_string(ctx, "update_start_game");
	duk_push_c_function(ctx, js_port_duktape_update_stop_game, 0);
	duk_put_global_string(ctx, "update_stop_game");
	// needed for copybox (leaving terminal, and returning)
	duk_push_c_function(ctx, js_port_duktape_update_mouse_end, 0);
	duk_put_global_string(ctx, "_update_mouse_end"); 
	


}
#endif
