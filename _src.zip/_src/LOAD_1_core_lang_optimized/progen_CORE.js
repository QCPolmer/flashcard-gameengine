
//API_TAG//
function progen_CORE_obj_join(obj, obj_pull_vars_from){
//API_TAG//
	for( var key in obj_pull_vars_from){
		//if( !obj.hasOwnProperty( key ) ){
			obj[key] = obj_pull_vars_from[key];} //}
	return obj;
}


//API_TAG//
function progen_CORE_NOROLL_indefinite_shuffled_d_roll( 
	max_roll, index, number_of_decks){ //rolls AS IF this # of decks
//API_TAG//
	index = Math.abs(index ); max_roll = max_roll* number_of_decks; 
	var random_deckdraw_number = Math.abs(Math.floor(index /max_roll));	    var strt_index = Math.abs( Math.floor( 
	   Math.sin( random_deckdraw_number ) * (max_roll-1)));
	
	//more randomness, going reverse order if divisible by 3
	if( random_deckdraw_number % 2 != 0){var i_draw = index % max_roll;
	}else{ var i_draw = max_roll-1 - (index % max_roll); }		

	var shuffles = 3+(random_deckdraw_number % 3);	
	for(var j=0; j< shuffles; j+=1){
	  //cutting deck, gives * max_roll to randomization multiplier
	  i_draw = i_draw + (random_deckdraw_number % max_roll );
	  if( i_draw >= max_roll){ i_draw -= max_roll;}	

	 i_draw +=1; //shuffling deck, counts up if %2, or down
	 if( i_draw % 2 ==0 ){ i_draw = strt_index + Math.floor(i_draw /2);
	 }else{  i_draw = strt_index - Math.floor(i_draw /2); }

	 if( i_draw < 0){ i_draw += max_roll;} 
	 if( i_draw >= max_roll){ i_draw -= max_roll;}
	}
	return Math.ceil((i_draw+1)/number_of_decks); 
}

