
//API_TAG//
///////////////
//NOTE: touchscreen.js is STAND ALONE: it has no dependencies.
//	and only binds a callback to divs on screen!
//	(in the game engine this is built on, 
//			one_html.js
//		is where this is used! )
//
////////////////////////////////////////
//example of 'touch to show keyboard buttons':
//////////////////
// <!-- this is basically pagentry: the button just changes focus, input box is for tricking page to show keyboard, but can take no text! -->
// <input type="text" placeholder="show keyboard(touchscreen)" maxlength="1" id="showkeys_div" onblur="document.getElementById('showkeys_div').value='';" />
// <button onclick="document.getElementById('showkeys_div').blur()"> hide keyboard(touchscreen) </button>
////////////////////////////////
///////////////////////
// getMyGamepadElements:{ "div_id":["data_to_send_to_callback"],
// 	"div_id2":"data_to_send_to_callback"  
// 	} // ETC.
// getCallbackFunct = function(getListOfPressedDataSignals)
// 	(see touchscreen_CALLBACK_REDEFINE for an example ballback)
function touchscreen_SETTUP( getMyGamepadElements, getCallbackFunct ){
	touchscreen_CALLBACK_REDEFINE = getCallbackFunct;
	touchscreenElements = getMyGamepadElements
//API_TAG//


	var touchscreenElements_keys = Object.keys(touchscreenElements);
	for(var i=0; i< touchscreenElements_keys.length; i+=1){
	   console.log(touchscreenElements_keys[i]);
	   var tmp_div = document.getElementById(touchscreenElements_keys[i]);
	   tmp_div.addEventListener( "mousedown", touchscreenKeys_DOWN);
	   tmp_div.addEventListener( "mouseup", touchscreenKeys_UP);
	   tmp_div.addEventListener("mouseleave",touchscreenKeys_UP);
	   tmp_div.addEventListener( "touchstart", 
			touchscreenKeys_DOWN,{ passive: false });
	   tmp_div.addEventListener("touchmove",touchscreenKeys_UP);
	   tmp_div.addEventListener("touchend", touchscreenKeys_UP);
	   tmp_div.addEventListener("touchcancel",touchscreenKeys_UP);
	
	   //blocking right click for menu (as holding a press
	   //	will bring up menu...)
	   tmp_div.oncontextmenu = function() {return false;}
	}
	setInterval( touchscreen_intervalFunct, 41.67 ); //41.67==1/24th a second?

}

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
///////// ONLY NEED ABOVE!!!   ///////////////////////////////
///////////  It will settup everything, below is internal ////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////


// This pulls keypresses out of 
function touchscreen_CALLBACK_REDEFINE( getGamepadPressedList ){
	if(getGamepadPressedList.length != 0){
		console.log(JSON.stringify(getGamepadPressedList));}
}


var touchscreentouches= [];
var touchscreenMouseClickingButton= null;
//should rig to connect to keypresses...
function touchscreenKeys_DOWN( event){ 
   //event.target I THINK is the div...
   if(event.type.indexOf("touch") != -1 ){ 
	event.preventDefault(); //prevents scaling and panning via touches
	touchscreentouches = event.touches; 
   }else{ touchscreenMouseClickingButton = event.target.id;  } }
function touchscreenKeys_UP( event){ 
   //event.target I THINK is the div...
   if(event.type.indexOf("touch") != -1 ){ 
	event.preventDefault(); //prevents scaling and panning via touches
	touchscreentouches = event.touches; 
   }else{ touchscreenMouseClickingButton = null; } }

function touchscreen_intervalFunct(){
	//console.log("BBB");
	//touchscreentouches= [];
	//touchscreenMouseClickingButton
	var tmpTouchingButtonsIds= [];
	if(touchscreenMouseClickingButton != null){
		tmpTouchingButtonsIds.push(touchscreenMouseClickingButton); }
	for(var i=0; i< touchscreentouches.length; i+=1){
       		var target = document.elementFromPoint(
		   touchscreentouches[i].clientX, touchscreentouches[i].clientY); 
		//DATA ABOVE, DO SOMETHING WITH!
		if(target !=  null && target.id != null){
		  tmpTouchingButtonsIds.push(target.id); }
		//console.log(target);
	}
	var tmp_cmds_pressed = [];
	for(var i= 0; i< tmpTouchingButtonsIds.length; i+=1){
		if(null != touchscreenElements[tmpTouchingButtonsIds[i]]){
			tmp_cmds_pressed.push(touchscreenElements[
				tmpTouchingButtonsIds[i]]);}}
	touchscreen_CALLBACK_REDEFINE( tmp_cmds_pressed );
}


