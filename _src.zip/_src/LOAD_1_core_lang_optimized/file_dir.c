#if defined(_WIN32) || defined(WIN32) || defined(WIN64) || defined(_WIN64)

#ifdef __WATCOMC__
#include <direct.h>
#else
#include <direct.h>
#include "windows_dirent.h"
#endif


#else
#if defined(__DOS__) || defined(__MSDOS__) || defined(_DOS4GW) || defined(_DOS4G)
#include <direct.h>
//#include "windows_dirent.h"
#else
//linux
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

#endif

#if defined(DUK_VERSION)
static void file_dir_duktape_port_settup(duk_context *ctx);
#endif 

int file_dir_mkdir(const char *dirname) {
#if defined(_WIN32) || defined(WIN32) || defined(WIN64) || defined(_WIN64)
    return _mkdir(dirname);
#else
#if defined(__DOS__) || defined(__MSDOS__)
     return _mkdir(dirname);
#else
    //linux
    return mkdir(dirname, 0777);
#endif
#endif
}
//API_TAG// 
void file_dir_rmdir(const char *dirname){
// remove a directory	//API_TAG// 
	rmdir( dirname );

}

struct dirent *file__dir_entry;
DIR *file__dir_folder;
// 1 means it's  folder, 0 is no folder. 
int file__dir_close(){
	closedir(file__dir_folder);
	return 1;
}
char* file__dir_curfile_or_blank(){
	if( file__dir_entry == NULL){ return "";}
	return file__dir_entry->d_name;
}
char* file__dir_getnextfile_or_blank(){
	file__dir_entry=readdir(file__dir_folder);

	if( file__dir_entry == NULL){ return "";}
	return file__dir_entry->d_name;	
}
int file__dir_open(char* filename){
	file__dir_folder = opendir(filename);
	if(file__dir_folder == NULL){	return 0;	}

	file__dir_entry=readdir(file__dir_folder);
	return 1;
}
const char * file_dir_js__duktape_funct(){
	return ""

		//INJECT_C_CODE_FROM_FILE_HERE//
"\n"
"function file_dir( get_cd, dir_name){ \n"
"// returns a list of filenames, or null for file_not_found	\n"
"			\n"
"			if(dir_name == undefined){ dir_name = ''}	\n"
"			if(_file__dir_open(get_cd + dir_name)==0){return null;}\n"
"			var retlist=[];\n"
"			\n"
"			var i=0;\n"
"			while( _file__dir_curfile_or_blank() !=''){\n"
"				retlist[i]=_file__dir_curfile_or_blank();\n"
"				_file__dir_getnextfile_or_blank();\n"
"				i+=1;\n"
"			}\n"
"			_file__dir_close();\n"
"			return retlist;\n"
"		}\n"
"\n"
"\n"
"\n"
"var file_dir_embed_in_c_file = function(getDirsList, getFile_to_inject_with, getTextToInjectBetween, OPTIONAL_remove_comments_from_js){\n"
"// No returns;		\n"
"	file_inject_data_singleblock( \n"
"		file_dir_gen_embedable_c( getDirsList,\n"
"			OPTIONAL_remove_comments_from_js), \n"
"		getFile_to_inject_with, \n"
"		getTextToInjectBetween );\n"
"}\n"
"var FILE_DIR_EMBEDED_CODE_TAG = FILE_EMBEDED_SPLIT_BY;//defined in file.c\n"
"\n"
"var file_dir_gen_embedable_c = function( getDirsList, \n"
"	OPTIONAL_remove_comments_from_js ){\n"
"\n"
"	//  generated from file_dir_search works well \n"
"    var ret_str=\"\";\n"
"    for(var j=0; j< getDirsList.length;j+=1){\n"
"	var getStartDir = getDirsList[j];\n"
"	var TMP_FILE_DEPTH_SEARCH=6;\n"
"\n"
"	//file_log_input(getStartDir);\n"
"\n"
"	var getFilesList = file_dir_search(\n"
"		getStartDir, TMP_FILE_DEPTH_SEARCH);\n"
"	   \n"
"	var getFile_text = file_pull_all_data_from_filelist(getFilesList,\n"
"		OPTIONAL_remove_comments_from_js);\n"
"	\n"
"\n"
"	for(var i=0; i<getFilesList.length; i+=1){\n"
"		ret_str += '\\n\"' + FILE_DIR_EMBEDED_CODE_TAG + '\"\\n' +\n"
"			'\"' +getFilesList[i].substring( \n"
"				getStartDir.length ) + '\"' +\n"
"			'\\n\"' +  FILE_DIR_EMBEDED_CODE_TAG\n"
"			+ '\"\\n';\n"
"		ret_str +=  file_dir_convert_text_to_c_str( \n"
"					getFile_text[i]);\n"
"	}\n"
"   }\n"
"   return ret_str;\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"function file_dir_rmdir(startDir, getDirName){\n"
"// remove a dir, returns nothing \n"
"	_file_dir_rmdir(starDir+ getDirName);}\n"
"\n"
"function file_dir_mkdir( startDir, getDirName){\n"
"\n"
"// the 'topmost' dirs do not exist.  \n"
"	if(getDirName == undefined || getDirName == \"\"){\n"
"		getDirName = startDir; startDir =\"\";}\n"
"	getDirName=getDirName.split(\"/\");\n"
"	for(var i=0; i<=getDirName.length; i+=1){\n"
"		_file_dir_mkdir( startDir+ getDirName.slice(0,i).join(\"/\"));\n"
"}	}\n"
"\n"
"\n"
"function file_dir_copy( getDir_toCopy, getDir_toMake, \n"
"		getCopyDepth, getRegex_partslist_to_match,\n"
"		getRegex_partslist_to_EXCLUDE){\n"
"\n"
"//	EG: [\"js$\",\"c$\"], [\"a$\"]	\n"
"	if(getDir_toCopy[getDir_toCopy.length - 1]!='/'){\n"
"		getDir_toCopy =  getDir_toCopy + '/';}\n"
"	if(getDir_toMake[getDir_toMake.length - 1]!='/'){\n"
"		getDir_toMake =  getDir_toMake + '/';}\n"
"\n"
"	tmp_files =  file_dir_search(\n"
"		getDir_toCopy, getCopyDepth, getRegex_partslist_to_match,\n"
"		getRegex_partslist_to_EXCLUDE);\n"
"	tmp_out_files = [];\n"
"	for(var i=0; i< tmp_files.length; i+=1){\n"
"		tmp_out_files[i] = getDir_toMake + \n"
"			tmp_files[i].split( getDir_toCopy)[1]; }\n"
"\n"
"	\n"
"	//	return;\n"
"\n"
"	for(var i=0; i< tmp_out_files.length; i+=1){\n"
"		tmpOutFile = tmp_out_files[i].split(\"/\"); \n"
"		tmpOutFile.pop();\n"
"		file_dir_mkdir( tmpOutFile.join(\"/\"), \"\");}\n"
"	\n"
"	for(var i=0; i< tmp_files.length; i+=1){\n"
"		file_save( tmp_out_files[i], \n"
"			file_load_noembed(tmp_files[i])); }\n"
"}\n"
"\n"
"var file_dir_convert_text_to_c_str = function( str_in){\n"
"//returns c str	\n"
"	return '\\\"' +\n"
"		str_in.split('\\\\').join('\\\\\\\\')\n"
"		.split('\\\"').join('\\\\\\\"')\n"
"		.split('\\r\\n').join('\\n')\n"
"		.split('\\n').join('\\\\n\"\\n\"')\n"
"		+' \\\"';\n"
"}\n"
"\n"
"var file_dir_UNconvert_text_to_c_str = function( str_in){\n"
"//used as the opposite of the '...dir_convert_text_to_c... \n"
"	str_in = str_in\n"
"		.split('\\r\\n').join('\\n')\n"
"		.split('\\\\\\\"').join('\\\"')\n"
"		.split('\\\\\\\\').join('\\\\')\n"
"		.split('\\\\n\"\\n\"').join('\\n');\n"
"\n"
"	str_in = str_in.split('\"');\n"
"	str_in.shift();\n"
"	str_in.pop();\n"
"	str_in = str_in.join('\"');\n"
"	\n"
"	return 	str_in;\n"
"}\n"
"\n"
"var file_dir_search = function( startFileLoc, maxRecursiveDepth,\n"
"		list_of_regex, list_of_exclude_regex){\n"
"\n"
"// regex eg: [\"js$\", \"c$\"], [\"a$\"]  \n"
"	var tmpList = _file_dir_search( \n"
"			startFileLoc, maxRecursiveDepth, list_of_regex);\n"
"	if( list_of_exclude_regex == undefined){ return tmpList; }\n"
"	var tmpNotList = _file_dir_search( \n"
"		startFileLoc, maxRecursiveDepth, list_of_exclude_regex);\n"
"	for(var i=tmpList.length-1; i>= 0; i-=1){\n"
"		if(tmpNotList.indexOf(tmpList[i]) != -1){\n"
"			tmpList.splice(i,1);}	}\n"
"	return tmpList\n"
"}\n"
"\n"
"var _file_dir_search = function( getStartFileLoc, getMaxRecursiveDepth, \n"
"	getPartsOfFileNames_or_regex_List){\n"
"	var getPartsOfFileNames_List = getPartsOfFileNames_or_regex_List;\n"
"\n"
"	var ret_list = [];\n"
"\n"
"	//handling inputs\n"
"	if (getStartFileLoc == undefined || getStartFileLoc == \"\") {\n"
"		getStartFileLoc = \".\";}\n"
"	if(getStartFileLoc[getStartFileLoc.length-1] != \"/\"){\n"
"		getStartFileLoc = getStartFileLoc + \"/\";}\n"
"	if (getMaxRecursiveDepth == undefined) { \n"
"		getMaxRecursiveDepth = 0;  }\n"
"	if (getPartsOfFileNames_List == undefined) { \n"
"		 getPartsOfFileNames_List = [];}\n"
"	\n"
"\n"
"	//pulling root dir\n"
"	var tmp_file_data = file_dir( getStartFileLoc, \"\");\n"
"	if(tmp_file_data == null){ return undefined;}\n"
"	tmp_file_data.shift(); tmp_file_data.shift();//removing '.', '..'\n"
"\n"
"		\n"
"	//searching through root dir\n"
"	for(var i=0; i< tmp_file_data.length; i+=1){\n"
"		//recursion! (if desired)\n"
"		if(file_dir(getStartFileLoc, tmp_file_data[i])!= null ){\n"
"			if( getMaxRecursiveDepth > 0){\n"
"			   ret_list =  ret_list.concat( file_dir_search(\n"
"				getStartFileLoc + tmp_file_data[i],\n"
"				getMaxRecursiveDepth - 1, \n"
"				getPartsOfFileNames_List)); }\n"
"			continue;\n"
"		};\n"
"		if(getPartsOfFileNames_List.length ==0){\n"
"			ret_list.push( getStartFileLoc +\n"
"					tmp_file_data[i]);}\n"
"		 for(var j=0; j< getPartsOfFileNames_List.length; j+=1){\n"
"			if( tmp_file_data[i].search(\n"
"				getPartsOfFileNames_List[j]) != -1 ){\n"
"				ret_list.push( getStartFileLoc +\n"
"					tmp_file_data[i]);\n"
"				break;\n"
"		}	 }  	 \n"
"	}\n"
"	return ret_list;\n"
"\n"
"}\n"
"\n"
"\n"
"var file_dir_join_file_list_data = function(get_list_of_files){\n"
"// return a string of loaded files from file_names_list in 	\n"
"	var ret_string = \"\";\n"
"	for(var i=0; i< get_list_of_files.length; i+=1){\n"
"		tmp_file_data = _file_load( get_list_of_files[i]);\n"
"		if( tmp_file_data != \"\" && tmp_file_data != null){\n"
"		    if((get_list_of_files[i].indexOf('.')!=-1) &&\n"
"			    (get_list_of_files[i].split('.').pop()== \"js\")){\n"
"			tmp_file_data = _file_preprocess_js(tmp_file_data);}\n"
"		    ret_string = tmp_file_data + ret_string + \"\\n\";\n"
"	}	} \n"
"	return ret_string;\n"
"}\n"
"\n"
"var _file_dir_cur_cd = '.';\n"
"var _cd_param = file_argument_paramsget('-', ['-file_dir_cd']);\n"
"if( _cd_param.length>=2){ \n"
"	if(file_dir(\"./\", _cd_param[1])!= 0){ \n"
"		_file_dir_cur_cd= _cd_param[1];\n"
"	} }\n"
"\n"
"function file_dir_cd( dir_name){\n"
"\n"
"\n"
"// paramiter currently does nothing    \n"
"	if (dir_name !== undefined) {\n"
"			//change dir, or see if possible\n"
"	}\n"
"	return _file_dir_cur_cd + \"/\";\n"
"}\n"
"// for the running js file\n"
"\n"
"function file_dir_cd_js( ){ return file_js_cd(); } ;\n"
"\n"
"// should use that instead  \n"
"//NEED TO SET TO SHARED LIBRARIES FOR JS STUFF\n"
"var _file_core_js_cd = '.';\n"
"var _cd_param = file_argument_paramsget('-', ['-file_core_js_cd']);\n"
"if( _cd_param.length>=2){  \n"
"	if(file_dir( \"./\", _cd_param[1])!= 0){ \n"
"		_file_core_js_cd = _cd_param[1]; } }\n"
"\n"
"function file_core_js_cd( ){ return _file_core_js_cd.split(\"\\\\\").join(\"/\") + \"/\"; }\n"
"//pulls the LOAD2...CORE_JS file in _src (used mostly for bundling)	\n"
"// for the running js file\n"
"function file_dir_cd_js( ){ return file_js_cd(); } \n"
" "
//INJECT_C_CODE_FROM_FILE_HERE//
	;
		
}

///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////  Duktape Bindings ///////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////


#if defined(DUK_VERSION)
static duk_ret_t js_port_duktape_file__dir_open(duk_context *ctx){
	duk_push_int( ctx, file__dir_open( 
				(char*)duk_to_string(ctx, 0)));
	return 1; }
static duk_ret_t js_port_duktape_file_dir_mkdir(duk_context *ctx){
	duk_push_int( ctx, file_dir_mkdir( 
				(char*)duk_to_string(ctx, 0)));
	return 1; }
static duk_ret_t js_port_duktape_file_dir_rmdir(duk_context *ctx){
	file_dir_rmdir( (char*)duk_to_string(ctx, 0));
	return 0; }
static duk_ret_t js_port_duktape_file__dir_curfile_or_blank(duk_context *ctx){
	duk_push_string( ctx, file__dir_curfile_or_blank());
	return 1; }
static duk_ret_t js_port_duktape_file__dir_getnextfile_or_blank(duk_context *ctx){
	duk_push_string( ctx, file__dir_getnextfile_or_blank());
	return 1; }
static duk_ret_t js_port_duktape_file__dir_close(duk_context *ctx){
	file__dir_close( ); return 0; }
static void file_dir_duktape_port_settup(duk_context *ctx){
	
	duk_push_c_function(ctx, js_port_duktape_file_dir_mkdir, 1);
	duk_put_global_string(ctx, "_file_dir_mkdir");
	duk_push_c_function(ctx, js_port_duktape_file_dir_rmdir, 1);
	duk_put_global_string(ctx, "file_dir_rmdir");
	duk_push_c_function(ctx, js_port_duktape_file__dir_open, 1);
	duk_put_global_string(ctx, "_file__dir_open");
	duk_push_c_function(ctx, js_port_duktape_file__dir_close, 0);
	duk_put_global_string(ctx, "_file__dir_close");
	duk_push_c_function(
		ctx, js_port_duktape_file__dir_getnextfile_or_blank, 0);
	duk_put_global_string(ctx, "_file__dir_getnextfile_or_blank");
	duk_push_c_function(
		ctx, js_port_duktape_file__dir_curfile_or_blank, 0);
	duk_put_global_string(ctx, "_file__dir_curfile_or_blank");

	duk_push_string( ctx, file_dir_js__duktape_funct() );
	duk_eval_noresult(ctx);
}
#endif
