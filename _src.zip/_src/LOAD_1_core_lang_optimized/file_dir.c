#if defined(_WIN32) || defined(WIN32) || defined(WIN64) || defined(_WIN64)

#ifdef __WATCOMC__
#include <direct.h>
#else
#include <direct.h>
#include "windows_dirent.h"
#endif


#else
#if defined(__DOS__) || defined(__MSDOS__) || defined(_DOS4GW) || defined(_DOS4G)
#include <direct.h>
//#include "windows_dirent.h"
#else
//linux
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

#endif

#if defined(DUK_VERSION)
static void file_dir_duktape_port_settup(duk_context *ctx);
#endif 

int file_dir_mkdir(const char *dirname) {
#if defined(_WIN32) || defined(WIN32) || defined(WIN64) || defined(_WIN64)
    return _mkdir(dirname);
#else
#if defined(__DOS__) || defined(__MSDOS__)
     return _mkdir(dirname);
#else
    //linux
    return mkdir(dirname, 0777);
#endif
#endif
}
//API_TAG// 
void file_dir_rmdir(const char *dirname){
// remove a directory	//API_TAG// 
	rmdir( dirname );

}

struct dirent *file__dir_entry;
DIR *file__dir_folder;
// 1 means it's  folder, 0 is no folder. 
int file__dir_close(){
	closedir(file__dir_folder);
	return 1;
}
char* file__dir_curfile_or_blank(){
	if( file__dir_entry == NULL){ return "";}
	return file__dir_entry->d_name;
}
char* file__dir_getnextfile_or_blank(){
	file__dir_entry=readdir(file__dir_folder);

	if( file__dir_entry == NULL){ return "";}
	return file__dir_entry->d_name;	
}
int file__dir_open(char* filename){
	file__dir_folder = opendir(filename);
	if(file__dir_folder == NULL){	return 0;	}

	file__dir_entry=readdir(file__dir_folder);

	return 1;
}
const char * file_dir_js__duktape_funct(){
	return ""

		//INJECT_C_CODE_FROM_FILE_HERE//
"function file_dir(a,b){if(void 0==b&&(b=\"\"),0==_file__dir_open(a+b))return null;for(var c=[],d=0;\"\"!=_file__dir_curfile_or_blank();)c[d]=_file__dir_curfile_or_blank(),_file__dir_getnextfile_or_blank(),d+=1;return _file__dir_close(),c}function file_dir_rmdir(a,b){_file_dir_rmdir(starDir+b)}function file_dir_mkdir(a,b){void 0!=b&&\"\"!=b||(b=a,a=\"\"),b=b.split(\"/\");for(var c=0;c<=b.length;c+=1)_file_dir_mkdir(a+b.slice(0,c).join(\"/\"))}function file_dir_copy(a,b,c,d,e){\"/\"!=a[a.length-1]&&(a+=\"/\"),\"/\"!=b[b.length-1]&&(b+=\"/\"),tmp_files=file_dir_search(a,c,d,e),tmp_out_files=[];for(var f=0;f<tmp_files.length;f+=1)tmp_out_files[f]=b+tmp_files[f].split(a)[1];for(var f=0;f<tmp_out_files.length;f+=1)tmpOutFile=tmp_out_files[f].split(\"/\"),tmpOutFile.pop(),file_dir_mkdir(tmpOutFile.join(\"/\"),\"\");for(var f=0;f<tmp_files.length;f+=1)file_save(tmp_out_files[f],file_load_noembed(tmp_files[f]))}function file_dir_cd(a){return _file_dir_cur_cd+\"/\"}function file_dir_cd_js(){return file_js_cd()}function file_core_js_cd(){return _file_core_js_cd.split(\"\\\\\").join(\"/\")+\"/\"}function file_dir_cd_js(){return file_js_cd()}var file_dir_embed_in_c_file=function(a,b,c,d,e){file_inject_data_singleblock(file_dir_gen_embedable_c(a,d,e),b,c)},FILE_DIR_EMBEDED_CODE_TAG=FILE_EMBEDED_SPLIT_BY,file_dir_gen_embedable_c=function(a,b,c){for(var d=\"\",e=0;e<a.length;e+=1)for(var f=a[e],g=6,h=file_dir_search(f,g),i=file_pull_all_data_from_filelist(h,b,c),j=0;j<h.length;j+=1)d+='\\n\"'+FILE_DIR_EMBEDED_CODE_TAG+'\"\\n\"'+h[j].substring(f.length)+'\"\\n\"'+FILE_DIR_EMBEDED_CODE_TAG+'\"\\n',d+=file_dir_convert_text_to_c_str(i[j]);return d},file_dir_convert_text_to_c_str=function(a){return'\"'+a.split(\"\\\\\").join(\"\\\\\\\\\").split('\"').join('\\\\\"').split(\"\\r\\n\").join(\"\\n\").split(\"\\n\").join('\\\\n\"\\n\"')+' \"'},file_dir_UNconvert_text_to_c_str=function(a){return a=a.split(\"\\r\\n\").join(\"\\n\").split('\\\\\"').join('\"').split(\"\\\\\\\\\").join(\"\\\\\").split('\\\\n\"\\n\"').join(\"\\n\"),a=a.split('\"'),a.shift(),a.pop(),a=a.join('\"')},file_dir_search=function(a,b,c,d){var e=_file_dir_search(a,b,c);if(void 0==d)return e;for(var f=_file_dir_search(a,b,d),g=e.length-1;g>=0;g-=1)-1!=f.indexOf(e[g])&&e.splice(g,1);return e},_file_dir_search=function(a,b,c){var d=c,e=[];void 0!=a&&\"\"!=a||(a=\".\"),\"/\"!=a[a.length-1]&&(a+=\"/\"),void 0==b&&(b=0),void 0==d&&(d=[]);var f=file_dir(a,\"\");if(null!=f){f.shift(),f.shift();for(var g=0;g<f.length;g+=1)if(null==file_dir(a,f[g])){0==d.length&&e.push(a+f[g]);for(var h=0;h<d.length;h+=1)if(-1!=f[g].search(d[h])){e.push(a+f[g]);break}}else b>0&&(e=e.concat(file_dir_search(a+f[g],b-1,d)));return e}},file_dir_join_file_list_data=function(a){for(var b=\"\",c=0;c<a.length;c+=1)tmp_file_data=_file_load(a[c]),\"\"!=tmp_file_data&&null!=tmp_file_data&&(-1!=a[c].indexOf(\".\")&&\"js\"==a[c].split(\".\").pop()&&(tmp_file_data=_file_preprocess_js(tmp_file_data)),b=tmp_file_data+b+\"\\n\");return b},_file_dir_cur_cd=\".\",_cd_param=file_argument_paramsget(\"-\",[\"-file_dir_cd\"]);_cd_param.length>=2&&0!=file_dir(\"./\",_cd_param[1])&&(_file_dir_cur_cd=_cd_param[1]);var _file_core_js_cd=\".\",_cd_param=file_argument_paramsget(\"-\",[\"-file_core_js_cd\"]);_cd_param.length>=2&&0!=file_dir(\"./\",_cd_param[1])&&(_file_core_js_cd=_cd_param[1]); "
//INJECT_C_CODE_FROM_FILE_HERE//
	;
		
}

///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
/////////////  Duktape Bindings ///////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////


#if defined(DUK_VERSION)
static duk_ret_t js_port_duktape_file__dir_open(duk_context *ctx){
	duk_push_int( ctx, file__dir_open( 
				(char*)duk_to_string(ctx, 0)));
	return 1; }
static duk_ret_t js_port_duktape_file_dir_mkdir(duk_context *ctx){
	duk_push_int( ctx, file_dir_mkdir( 
				(char*)duk_to_string(ctx, 0)));
	return 1; }
static duk_ret_t js_port_duktape_file_dir_rmdir(duk_context *ctx){
	file_dir_rmdir( (char*)duk_to_string(ctx, 0));
	return 0; }
static duk_ret_t js_port_duktape_file__dir_curfile_or_blank(duk_context *ctx){
	duk_push_string( ctx, file__dir_curfile_or_blank());
	return 1; }
static duk_ret_t js_port_duktape_file__dir_getnextfile_or_blank(duk_context *ctx){
	duk_push_string( ctx, file__dir_getnextfile_or_blank());
	return 1; }
static duk_ret_t js_port_duktape_file__dir_close(duk_context *ctx){
	file__dir_close( ); return 0; }
static void file_dir_duktape_port_settup(duk_context *ctx){
	
	duk_push_c_function(ctx, js_port_duktape_file_dir_mkdir, 1);
	duk_put_global_string(ctx, "_file_dir_mkdir");
	duk_push_c_function(ctx, js_port_duktape_file_dir_rmdir, 1);
	duk_put_global_string(ctx, "file_dir_rmdir");
	duk_push_c_function(ctx, js_port_duktape_file__dir_open, 1);
	duk_put_global_string(ctx, "_file__dir_open");
	duk_push_c_function(ctx, js_port_duktape_file__dir_close, 0);
	duk_put_global_string(ctx, "_file__dir_close");
	duk_push_c_function(
		ctx, js_port_duktape_file__dir_getnextfile_or_blank, 0);
	duk_put_global_string(ctx, "_file__dir_getnextfile_or_blank");
	duk_push_c_function(
		ctx, js_port_duktape_file__dir_curfile_or_blank, 0);
	duk_put_global_string(ctx, "_file__dir_curfile_or_blank");

	duk_push_string( ctx, file_dir_js__duktape_funct() );
	duk_eval_noresult(ctx);
}
#endif
