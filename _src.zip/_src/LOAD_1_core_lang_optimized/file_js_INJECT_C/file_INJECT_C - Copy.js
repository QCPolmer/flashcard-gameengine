//API_TAG//	
function file_debug_scanf(blocksize_or_null){
// prompt input, returns what is typed. blocksize is max str-in size. 
// 	probably should use file_log_input //API_TAG//
		if ( !(typeof blocksize_or_null === 'number')) { 
			blocksize_or_null = 1000;}
		 return _file_debug_scanf(blocksize_or_null);
};

var _file_embedded=undefined; //test2
if(one_js_embeded_file == undefined){ 
var one_js_embeded_file = function(){return '';}}
var FILE_EMBEDED_SPLIT_BY= "//EMBEDED_CODE_BLOCK//";
//API_TAG//
function _file_embedded_load(getFileName){
// returns loaded_file as str or null. 
// loads a file directly from embedded(bundled) file,
// which will only work with a compiled executable (no html )
//  (dirs bundled with exe:_src/LOAD2... And m.js's dir) //API_TAG//
	if( _file_embedded == undefined){
			_file_embedded = {};
			var tmpfiles=
		       one_js_embeded_file().split(FILE_EMBEDED_SPLIT_BY);
		       for(var i=1; i<tmpfiles.length;i+=2){
				_file_embedded[tmpfiles[i]]=
					tmpfiles[i+1];
			}
		}
		return _file_embedded[getFileName];
}


//API_TAG//
function file_remove(get_cd, getFileName){
// Deletes a file. //API_TAG//
		if(getFileName!=undefined){ 
		  	get_cd = get_cd + getFileName;	 };
		return _file_remove(get_cd);}
//API_TAG//
function file_load_js_noembed(get_cd, getFileName){
//Loads and executes a js file, will NOT load one bundled with a complied 
// file (dirs bundled with exe:_src/LOAD2... And m.js's dir) . //API_TAG//
		if(getFileName==undefined){ return file_load_js(get_cd)};
		return file_load_js(get_cd+getFileName);}
//API_TAG//	
function file_load_noembed(get_cd, getFileName){
// Loads a file, returns as a string, will NOT pull from embeded
// non-existant file returns 'null' 
//  (dirs bundled with exe:_src/LOAD2... And m.js's dir) //API_TAG//
		if(getFileName==undefined){ return file_load(get_cd)};
		return file_load(get_cd+getFileName);}
//API_TAG//
function file_treeload_js_noembed(get_cd, getFileName){
// (will NOT load a bundled (embeded) file!) 
// 'treeloads' to try to execute a js file  (searching for the file at 
// each stage up the file tree (eg: bla/aab/1 , bla/1, /1) 
//  (dirs bundled with exe:_src/LOAD2... And m.js's dir) //API_TAG//
		if(getFileName==undefined){
	       		return file_treeload_js(get_cd)};
		return file_treeload_js(get_cd+getFileName);}
//API_TAG//
function file_load( get_cd, getFileName){
// returns str of filedata, or null. Will load a bundled (compiled) 
// file data based on filename, NOT cd //API_TAG//
		if( getFileName !== undefined){ 
			//loading 'embeded' file
			var tmpName = getFileName;
		   	while('./\\'.indexOf(tmpName[0]) !=-1){
				tmpName=tmpName.substring(1);}
			if( _file_embedded_load(tmpName)!==undefined){
			 return _file_embedded_load(tmpName);}
		}else{getFileName = ''; } 
		return _file_load( get_cd + getFileName );
	}
//API_TAG//
function _file_preprocess_js( str_in){
// returns js data ready to run!
// allows 'await' to appear before update for sleep and 
// the multi-line character to work (which wan't originally available 
// in this js version! //API_TAG//
		var f = str_in;
		f = f
			//top line is to solve for linux.
			.split('\r\n').join('\n')
			.split('\r').join('\n')
			.split('aw'+'ait ').join('')
			.split('as'+'ync function').join('function');
	 	   f=_file_multiline_handler(f, FILE_MULTILINE_CHAR, '\\n" + \n "' );
		return f; }

//API_TAG//
function _file_multiline_handler( 
	    str_in, process_between_or_blank_str, replace_lines_with){
//returns a js string with text between multi-line char 
// modified so it will run in this version of js as a string. 
// NOTE: ONLY USE THAT CHARACTER FOR STRINGS! OTHERWISE, IT WILL BREAK THIS
//API_TAG//		
		if(process_between_or_blank_str == ''){
			var process_between = '@#$$$$^^&&**';
	    		var f = process_between+ str_in + process_between;
		}else{ var f = str_in;
			process_between =process_between_or_blank_str; }

		//allowing multi-line strings
		if(f.indexOf( process_between )!= -1){
			var f_tmp = f.split(process_between);
			for(var i=1;i<f_tmp.length; i+=2){
			   f_tmp[i]=  '(\"' +
			   f_tmp[i].split('\"').join('\\"')
			   	.split('\n').join(replace_lines_with) + 
			    '\")'; 
			}
		       f = f_tmp.join('');
		} return f; }  
		


file_data_eval = null; // declare load files 
file_data = null; // not used
_file_load_js_cd = '';
_file_load_js_cd_file = '';
//API_TAG//
function file_js_cd(){ return _file_load_js_cd;}
// returns the running js-file current directory. //API_TAG//
//API_TAG//
function file_js_cd_file(){ return _file_load_js_cd_file;} 
// returns the currently running js-file //API_TAG//
function _file_get_file_src( filename){
		filename =  
			filename.split('/').slice(0,-1).join('/')+'/';
		filename = filename.replace('//', '/');
		return filename;
	};	

var _file_check_loaded_js = {};
function _file_check_add_filename(getStrfilename){
	getStrfilename=getStrfilename.split("\\").join("/")
		 .split("/").slice(-1)[0];
	_file_check_loaded_js[getStrfilename]=true; }
function file_check_loaded( getStrfilename){
	getStrfilename=getStrfilename.split("\\").join("/")
		 .split("/").slice(-1)[0];
	if(_file_check_loaded_js[getStrfilename] == undefined){
		file_input("Dependency for '" + getStrfilename 
			+ "' requested and not found. Requested from: "+
			file_js_cd() +_file_load_js_cd_file	); }	}

//API_TAG//
function file_load_js( get_cd, getFileName_or_list){
// Attempts to execute a js file, WILL load a js file that is embeded 
// with executable. ( this uses getFileName, NOT get_cd) 
//NOW: getFileName can be a list of filenames //API_TAG//
	  if(typeof getFileName_or_list == "object"){ 
		var f = getFileName_or_list;
	  	for(var i=0; i< f.length; i+=1){ file_load_js(get_cd, f[i]); } 
		return 1; };

	   var getFileName = getFileName_or_list;
	   if( getFileName == undefined){ getFileName = ''; } 
	   if(getFileName.search('/') == -1){ 
	   	getFileName = './'+getFileName;}
	   var f = file_load( get_cd, getFileName);
	   if(f==null){return 0;
	   }else{
	   	f = _file_preprocess_js(f);
 	  };
	
	 _file_check_add_filename(getFileName);	

	   var caught_src_dir = _file_load_js_cd;
	   var caught_src_file = _file_load_js_cd_file;
	   _file_load_js_cd_file = getFileName;
	   _file_load_js_cd =_file_get_file_src(get_cd +getFileName); 

 	   try{
	   	//for loading html files, ONLY for c
		if( f.search("#"+"IF_C_VERSION")!= -1){
			 f = f.split("#"+"IF_C_VERSION")[1]; }
		// this is a way to eval to global namespace... yeah.
		new Function('return this;')().eval(f);
		// for html version, async events dont work outside funct.
		// so I'm wrapping it in a funct.
		if(file_data_eval != null){
			file_data_eval(); file_data_eval = null; }
	   }catch(e){ // below is a check for if 'draw' isn't there.
	  	//if(typeof draw !== 'undefined' 
		// && typeof update_dont_clear !== 'undefined') 
		//	draw('JS, ERROR, Line:' + e.lineNumber +
		//	 '\n   ERROR:' +e  ,0,0,''); 
		//	update_dont_clear();
		//	update_sleep(100000);
		// 
		file_debug_printf('JS, ERROR, ' +  
			+ 'Last [file_treeload_js()] call was:  \n ' +
			+ file_js_cd_file() + '\n'+
			   'ERROR:' +e 
			+'\n\nif error is in that file, linetext = \n '+
			'Line:' + e.lineNumber + ' : \n' 
			+ f.split( '\n')[e.lineNumber-1]);
		file_debug_scanf();
	   } 
	   _file_load_js_cd = caught_src_dir;
	   _file_load_js_cd_file = caught_src_file;
	return 1; }; 


//API_TAG//
function file_treeload_js( get_cd, getFileName ){
// searches the file file tree for the js file, and loads it (if found)
// this is done by looking up the file tree, one file at a time. 
// this CAN load files bundled with compiled version 
// (dirs bundled with exe:_src/LOAD2... And m.js's dir) //API_TAG//
	var splitname = getFileName.split('/');
	var len = splitname.length;
	for( i=0; i< splitname.length; i+=1){
	   splitname.slice(i,len).join('/');
	   if( file_load_js('',splitname.slice(i,len).join('/') )){
		return 1; }
	   if( file_load_js( '../',splitname.slice(i,len).join('/') )){
		return 1;} }
	return 0; }
//API_TAG//
function file_run_js_debug( getStr){
// Runs a js string, failure doesn't crash the executable.  //API_TAG//
		var f = getStr;
		try{
		// this is a way to eval to global namespace... yeah.
			new Function('return this;')().eval(f);
		  	// for html version, 
		  	// async events dont work outside funct.
			// so I'm wrapping it in a funct.
			if(file_data_eval != null){
			   file_data_eval(); file_data_eval = null; }
		   }catch(e){ 
			file_debug_printf('JS, ERROR, ' +  
			+ 'Last [file_treeload_js()] call was:  \n ' +
			+ file_js_cd_file() + '\n'+
			   'ERROR:' +e 
			+'\n\nif error is in that file, linetext = \n '+
			'Line:' + e.lineNumber + ' : \n' 
			+ f.split( '\n')[e.lineNumber-1]);
			file_debug_scanf();
	   } 
	}
//API_TAG//
function file_load_js_nodebug( get_cd, getFileName){
// file_load_js (runs a executable with given cd (directory) 
// 	Same as file_load_js, only doesn't fail gracefully. //API_TAG//
	   var f = file_load( get_cd,  getFileName);
	   if(f==null){return 0;
	   }else{
	   	f = _file_preprocess_js(f);
 	  	} 
	   var caught_src_dir = _file_load_js_cd;
	   var caught_src_file = _file_load_js_cd_file;
	   _file_load_js_cd_file = getFileName;
	   _file_load_js_cd =_file_get_file_src(get_cd +getFileName); 
	   // this is a way to eval to global namespace... yeah.	   
	   new Function('return this;')().eval(f);
  	   _file_load_js_cd = caught_src_dir;
	   _file_load_js_cd_file = caught_src_file;
	   
	   return 1;	  
	};

//API_TAG//
function file_load_js_data( get_cd, getFileName){
// I think this is obsolite, I think it loads data embedded in a 
// js file. Now that multi-line characters work, 
// there is no reason I can't just save data in a string in a js file
// //API_TAG//
	   var  f = file_load( get_cd,  getFileName);
	   if(f==null){return 0;
	   }else{ return f.split(FILE_MULTILINE_CHAR)[1];}  
	}
//API_TAG//
function file_save( get_cd, getFileName, getData){
// returns nothing, getData is a string //API_TAG//
		if( getData == undefined){ 
			getData = getFileName; getFileName = ''; } 
		_file_save(get_cd + getFileName, getData);
	}
//API_TAG//
function file_log( getTextIn){
// This is the print (printf) function, also tries to show js file running
// Does not need a game running, not meant for use in-game
// if you need to pause afterwards, use file_log_input() //API_TAG// 
		file_debug_printf('\n'+file_js_cd_file()
			.split('/').pop()+ 
		': '+getTextIn +'\n');
	};
//API_TAG//
function file_log_input( getTextIn){
// prints the 'get text in' then gets user input, returns it. 
// does not need a game running, not meant for use in game
// if you don't want to pause and get input, use file_log  	//API_TAG//
		file_debug_printf('\n'+file_js_cd_file()
			.split('/').pop()+ 
		': '+getTextIn +'\n');
		return file_debug_scanf();
	};
//API_TAG// 
function file_input( getTextIn){
// returns: nothing
// This is the print (printf) function, also tries to show js file running
// Does not need a game running, not meant for use in-game
// if you need to pause afterwards, use file_log_input() //API_TAG// 
		file_debug_printf(getTextIn +'\n');
		return file_debug_scanf();
	};


//API_TAG// 
var file_argument_paramsget = function( 
		get_1_char_prefixes_str, get_list_params_to_get ){
// ARGS START WITH '-'
// returns a list of command line paramiters from command line 
// that are marked with -[a_text_name_in_get_list_params_to_get]
// 	eg: file_argument_paramsget( "-", ["-file_get", "-FILE_GET"]);
// FIRST PARAMITER GOT IS ALWAYS THE "-whatever" TAG!!! 
// this means if the returned list is empty, the tag was not found!
//API_TAG// 
	var i =1; // param 0 is filename
	var ret_array = []; var reading_tag = 0;

	while(file_argument_get(i).length != 0){
		if(reading_tag == 1){
		    if( get_1_char_prefixes_str.indexOf(
			    file_argument_get(i)[0]) == -1){
				ret_array.push( file_argument_get(i) );
		    }else{ 
				reading_tag = 0;}	
		}
		if(reading_tag == 0){
		   for( var j=0; j< get_list_params_to_get.length; j+=1){
		     
			//file_debug_printf( "\n"+get_list_params_to_get[j]+ "  "+ file_argument_get(i) +" "+ ((""+file_argument_get(i)) == (""+get_list_params_to_get[j])) +ret_array.length+"\n");
			//file_debug_scanf();

		      if(get_list_params_to_get[j] == file_argument_get(i)){
		  	reading_tag =1;

			if( ret_array.length ==0 ){ 
				ret_array.push( file_argument_get(i));}
			break;
		   } }
		}	
	    i+=1; }
	return ret_array;
}

//API_TAG// 
var file_arguments_get_filelist_from_params = function( ){
// returns a list of files, used to make pulling inputs easier. 
// recipe: -idir_js ./ -i -o output.js -file_dir_to_c_str 
// requires 'dir'
	var arg_src_files = 
	    file_argument_paramsget("-", ["-I", "-i", "-input", "--input"]);
	var arg_src_dirs_all_files = 
	    file_argument_paramsget("-", ["-Idir", "-idir" ]);
	var arg_src_dirs_js_only = 
	    file_argument_paramsget("-", ["-Idir_js", "-idir_js" ]);
//API_TAG// 

	//removes original param;
	arg_src_files.shift(); 
	arg_src_dirs_all_files.shift(); arg_src_dirs_js_only.shift();
	

	// adding files abreviation in front of filenames
	for(var i=0; i< arg_src_files; i+=1){
		arg_src_files[i]= file_dir_cd() + arg_src_files[i];}
	// for ALL files in dir
	for(var i =0; i< arg_src_dirs_all_files.length; i+=1){ 
		var tmpfiles =file_dir_search(
			file_dir_cd()+ arg_src_dirs_all_files[i], 0);
		if(tmpfiles != null){ 
			arg_src_files = arg_src_files.concat(tmpfiles); } }
	// for only JS files in dir
	for(var i =0; i< arg_src_dirs_js_only.length; i+=1){ 
	  var tmpfiles =file_dir_search( 
	
		  file_dir_cd()+arg_src_dirs_js_only[i], 0,["js$"]);
	  
	  if(tmpfiles != null){ 
			arg_src_files = arg_src_files.concat(tmpfiles); } }
	
	

	return arg_src_files;
}

//NEED TO SET TO SHARED LIBRARIES FOR JS STUFF
var _file_core_js_cd = '.';
var _cd_param = file_argument_paramsget('-', ['-file_core_js_cd']);
if( _cd_param.length>=2){  
	if(file_dir( "./", _cd_param[1])!= 0){ 
		_file_core_js_cd = _cd_param[1]; } }
//API_TAG// 
function file_core_js_cd( ){ return _file_core_js_cd + "/"; }
// returns location of _src/LOAD2...CORE_JS if present
// Running a precomipled verison will return running dir. 
// CAN BE SET VIA COMMAND LINE PARAM: '-file_core_js_cd' //API_TAG// 

//API_TAG// 
var file_pull_all_data_from_filelist = function(getFileList){
// returns a list of data loaded from a list of files 
// file_dir_search is good for getting the list. //API_TAG// 
	var return_list =[];
	for(var i=0; i< getFileList.length; i+=1){
		return_list.push( file_load(getFileList[i]));	}
	return return_list;
}
//API_TAG// 
var file_scalpel_data = function( file_name, textblock_to_insert_text_between){
// returns text found between the two text blocks in the file	//API_TAG// 
	var tmpfileText = file_load(file_name).split(
		textblock_to_insert_text_between);
	if(tmpfileText.length > 2){ return tmpfileText[1]; }
	return "";
}
//API_TAG// 
var file_inject_data_singleblock = function( str_to_inject, file_name, textblock_to_insert_text_between ){
// returns nothing, takes a file, opens it, and replaces 
// the text between the last paramiters (think html tag, closing tag has no backslash) //API_TAG// 
	var tmpfileText = file_load(file_name).split(
		textblock_to_insert_text_between);
	if(tmpfileText.length > 2){ 
		tmpfileText = tmpfileText[0] + 
			textblock_to_insert_text_between +
			'\n'+str_to_inject+ '\n' +
			textblock_to_insert_text_between +
			tmpfileText.pop(); }
	file_save(file_name, tmpfileText );
}


//make a list that can be pulled with: S1 DIR\ DIR_JS\
//searching to see if they are the first value, and replacing 
//if they are would probably work 
async function _file_load_save_dialog_input( preface_text){
	_file_save_dialog_prev.dir = file_dir_cd();
	_file_save_dialog_prev.js_dir = file_js_cd();

	var f = _file_save_dialog_prev;
	var tmp_names_list = "";
	for(var i=0; i< f.length; i+=1){
		tmp_names_list += i + ": " + f[i]+ "\n";}
	var tmp_input =  file_input(
		preface_text + "\n"+ `
( you can typically drop the file or dir to terminal to get the name) 
Common and prev save locs (copy and paste is your friend)
Common files ( '1:' gets substituted for the entry below) 
` +
   		"dir: " + f.dir + "\n" + 
		"js_dir: " + f.js_dir + "\n"+
		tmp_names_list);
	var tmp_keys = Object.keys(_file_save_dialog_prev);
	for(var i=0; i< tmp_keys.length; i+=1){
		if(tmp_input.indexOf(tmp_keys[i] + ":" )==0){
			tmp_input = _file_save_dialog_prev[tmp_keys[i]] +
				tmp_input.split(":").slice(1).join(":");
			tmp_input.replace( tmp_keys[i]+":", 
				_file_save_dialog_prev[tmp_keys[i]]);}	}
	_file_save_dialog_prev.unshift(tmp_input.trim());
	_file_save_dialog_prev.pop(); 
	return _file_save_dialog_prev[0];}
//API_TAG//	
async function file_load_dialog( ){ // returns loaded text or null
// a crappy version of 'open a text file' Don't use spaces in filename 
//uses save-dailog for file loc
//API_TAG//	

	return file_load( _file_load_save_dialog_input(
		"Input fileName to load too.").trim());	}

var _file_save_dialog_prev = []; _file_save_dialog_prev[6] = undefined;
//API_TAG//	
async function file_save_dialog( getData ){ // returns nothing
// A crappy version of 'save a text file' don't use spaces in filename
//API_TAG//	
	return file_save( _file_load_save_dialog_input(
		   "Input fileName to save too.").trim(),"",getData);	}

var _file_copybox_cmdcaught = "";
//API_TAG//	
async function file_copybox( getTextToShow, default_command_blank_str_to_reset ){ // returns contents of open-saved file/textarea. 
	// opens a text file (textarea in js) that text can be 
// copied from/too -- gens a tmp.txt file (removes afterwards) 
// For C version, the 'default_...' param can be set to a 
// specific editor (notepad), left blank, OR set to "" which will 
// which will ask after every use. left blank, it will ask what to use once 
//API_TAG//	

	if(default_command_blank_str_to_reset !== undefined){
	 _file_copybox_cmdcaught = default_command_blank_str_to_reset;}
	var docname = "tmp.txt";
	file_save(file_js_cd(), docname , getTextToShow );

	tmp_copybox_confirmed = _file_copybox_cmdcaught;
	while(_file_copybox_cmdcaught == "" || 
		tmp_copybox_confirmed != _file_copybox_cmdcaught){

	 	 _file_copybox_cmdcaught  =
			file_input(`
Enter command to launch a text document
(eg: notepad for windows, leafpad for linux (after confirmation, 
	 will be caught, so will need to close app to redefine. ) ) 
`).trim(); 
		tmp_copybox_confirmed = 
			file_input("please type it again").trim();	}
	file_system(_file_copybox_cmdcaught+" "+file_js_cd()+docname );	
	var ret_string= file_load(file_js_cd(),docname);
	file_remove(file_js_cd(),docname);
	return ret_string;
}
