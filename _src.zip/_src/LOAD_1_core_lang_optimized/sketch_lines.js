//API_TAG//
// runs in rmloaded_room space, so works the same as other 
// col tests. Returns a list of cols, format: [x1,y1,col1, x2,y3,col2 ...]
function sketch_line_col_test(x, y, x_end, y_end,
		colgroup,
		horiz_not_vertical, // OR null
		get_1_not_multi_pnts, //1 pnt IS somewhat faster!
		getLst, // list of % (0-1.0) to check! (OPTIONAL!) 
			// for 'spot' checking. 
		OPTIONAL_draw_every_steps){ //see main _sketch_line
//API_TAG//
	_sketch_line_col_test_SETTUP(  
		colgroup, get_1_not_multi_pnts);
	sketch_line( x, y, x_end, y_end, "NONE"," ", " ",  
		horiz_not_vertical, // can be null, and will choose 
		2, // sketch0_draw1_coltest2,  //int
		getLst, //OPTIONAL_drawprcntlist_0to1_or_null, 
		void null,//OPTIONAL_evenly_placed_OR_null
		OPTIONAL_draw_every_steps);// int # of steps OR null
		
	return _sketch_line_col_test_XYCOL_LIST;
}
var _sketch_line_col_test_XYCOL_LIST=[]; 
	//3item- cycling list:goes x,y,co,  x,y,col..
var _sketch_line_col_test_COLGROUP = "";
var _sketch_line_col_test_functPointer;
function _sketch_line_col_test_SETTUP(  
	colgroup, get_1_not_multi_pnts){
	 _sketch_line_col_test_XYCOL_LIST=[];

	_sketch_line_col_test_COLGROUP = colgroup;
	if( get_1_not_multi_pnts){
		_sketch_line_col_test_functPointer = 
			_sketch_line_col_test_dummydraw_FIRST_COL;
	}else{ _sketch_line_col_test_functPointer =
			_sketch_line_col_test_dummydraw;}}
// for use with the line function as a dummy 'draw' function
// (for use with main sketch_line function!
function _sketch_line_col_test_dummydraw(  graphic, x, y, transparent_char){
	var char_rtrn = rmloaded_col_test_SIMPLE(
			x,y,_sketch_line_col_test_COLGROUP);
		if(char_rtrn != "" ){
		  var list = _sketch_line_col_test_XYCOL_LIST;
		  var len =list.length;
		   if(len >0){ // this is for doubles!!!
	   	    if(list[ len-3]==x && list[ len-2]==y){return;}}
		  _sketch_line_col_test_XYCOL_LIST.push(
			  x, y, char_rtrn);}	}
function _sketch_line_col_test_dummydraw_FIRST_COL(  
		graphic, x, y, transparent_char){
	if(_sketch_line_col_test_XYCOL_LIST.length ==0){
		var char_rtrn= rmloaded_col_test_SIMPLE(x,y,
			_sketch_line_col_test_COLGROUP);
		if(char_rtrn!= ""){
		  _sketch_line_col_test_XYCOL_LIST.push(
			  x, y, char_rtrn);}} }


//API_TAG//
// OK... this is the core line drawing function, and it can 
// do a boatload of stuff. 
// That being said, it is not specialized. 
// So probably a good idea to write a wrapper for this 
// for specialized uses
// NOTE: draw_line does not exist, but function can draw instead of sketch
// 	For col_test, see sketch_line_col_test
// EG: sketch_line(x,y,x_end, y_end, "QRTR", "@", true, 1);//1 @ end!
function sketch_line( x, y, x_end, y_end, rotate_FULL_QRTR_NONE, //str
		//IMPORTANT: FULL WON'T BE 100% ACCURATE!!!
				//USE QRTR/NONE better accuracy. 
			//FOR FULL/QRTR: the 'point this way' 
			//part is to the right (eg: '-->' '>'=part!)
			//NOTE:keep width/length ODD for gridstr allignment
			//  ---place evenly works well with 'FULL'
		graphic, transparent_char, 
		horiz_not_vertical, // can be null, and will choose 
				// via nearest dist x or y on runtime. 
		sketch0_draw1_coltest2,  // (coltest2 should ONLY be called 
			// via sketch_line_col_test (which is 1 char wide)
		getLst, //OPTIONAL_drawprcntlist_0to1_or_null, 
			//list of %s to draw gridstr at between xy and xyend
			// eg: [0, .25, .5. .75, 1.0] 
			//	(0 and 1 are the 'line caps' ) 
			//OVERRIDES MOST OTHER FUNCTS!!!
		OPTIONAL_evenly_placed_OR_null, // NOTE: (OVERRIDES ALL!!)
		OPTIONAL_draw_every_steps // int # of steps OR null
			// EG: 10 draws ever 10 pixel steps between line!
		){ 
	//0 length lines are will draw nothing!
	if(x == x_end && y == y_end){ return; }
//API_TAG//

	//I COPIED THIS 3X, CAN PROBABLY GIVE IT OWN FUNCTION!!!
	if(horiz_not_vertical == void null){
		if(Math.abs(x_end-x) > Math.abs(y_end-y)){
		  horiz_not_vertical = 1;}else{horiz_not_vertical =0;} }
	//a few initial vars settup
	if(sketch0_draw1_coltest2 ==0){ var getdraw =sketch;
	}else{if(sketch0_draw1_coltest2 ==1){ 
		var getdraw =draw; 
	}else{if(sketch0_draw1_coltest2 ==2){ 
		var getdraw = _sketch_line_col_test_functPointer; }}}

	var step_x_dist =0; var step_y_dist =0;
	if(graphic.length == 1){ var xcenter =0; var ycenter = 0;
	}else{
	  var g_width = gridstr_width(graphic);
	  var g_height = gridstr_height(graphic);
	  //centering line
	  var xcenter = -Math.floor((g_width)/2); 
	  var ycenter = -Math.floor((g_height)/2);
		//for below: center is negetive!
	  var xfull_w_cent_offset = -(g_width + xcenter);
	  var yfull_w_cent_offset = -(g_height + ycenter);

	  //rotate graphic here!!!
	  if(rotate_FULL_QRTR_NONE == "FULL"){
		//get offset FIRST!!!
		xcenter -=
	  	  gridstr_rotation_ROTABLE_BORDER_X_OFFSET(graphic);
		ycenter -=
		  gridstr_rotation_ROTABLE_BORDER_Y_OFFSET(graphic);

		xcenter= Math.ceil(xcenter); 
		ycenter = Math.ceil(ycenter);
		var rot =Math.atan2(x-x_end, y - y_end) -(Math.PI/2);
		
		//  draw(""+rot,0,0,"");
		  
		graphic =
		   gridstr_rotation_MAKE_ROTATABLE_BORDER(
			   graphic, transparent_char);
		//still need to rotate graphic
		graphic = gridstr_rotate( graphic, rot, 
				transparent_char);
		  var lst_draw_offset =0; //unused for this 
		
	  }else{ if(rotate_FULL_QRTR_NONE == "QRTR"){
		  // OK, this is all wrong. 
		var tmp_reverse_x_y = true;;
		if( horiz_not_vertical){ tmp_reverse_x_y=0;
			if(x > x_end){ var rot = .6; //numbers here from 
			}else{ var rot = -2.0; } 	//trail and error
		}else{  if(y > y_end){ var rot = -.9; 
			}else{ var rot = 1.8; }}
		
		//file_log(graphic);
		graphic = gridstr_rotate_90_degrees(graphic, rot);
		//file_log(gridstr_rotate_90_degrees(graphic, rot));
		if( tmp_reverse_x_y){
			var tmp_var =  xcenter;
	 		g_width = gridstr_width(graphic);
	  		g_height = gridstr_height(graphic);
			xcenter = ycenter; ycenter = tmp_var;
			tmp_var = xfull_w_cent_offset;
			xfull_w_cent_offset = yfull_w_cent_offset;
			yfull_w_cent_offset = tmp_var; }
			
		if(horiz_not_vertical){ var lst_draw_offset=  
				xfull_w_cent_offset;
		}else{ var lst_draw_offset=  yfull_w_cent_offset; }
	
	  }else{ // rotate_FULL_QRTR_NONE == "NONE" (or whaterver)
		if(horiz_not_vertical){ var lst_draw_offset=  
				xfull_w_cent_offset;
		}else{ var lst_draw_offset=  yfull_w_cent_offset; }
	  }}
	  ///////////////////
		/////////////// limiting length offset for rounding
		/// below is checking if even, basically.
	 if(rotate_FULL_QRTR_NONE != "FULL"){
	  if(horiz_not_vertical){ 
	    if( (xcenter - lst_draw_offset) % 2 != 0){
		var rnd_off =1; }else{ var rnd_off = 0;}
	  }else{ if( (ycenter - lst_draw_offset) % 2 != 0){
		var rnd_off =1; }else{ var rnd_off = 0;}}//rounding offset
	  //limiting line length based on horiz or vertical
	  if(horiz_not_vertical){
		// OK, end line alignment has a rounding errors as 
		  // well... not sure how I got a '1+' into the equasion...
		  // EDIT
		  // THE FUNCTION IS LOPSIDED!!!
		  // EG: 4 rounds to 2, which means it will fall: 
		  // 0@00 OR 00@0 depending on > or < 0!
		if( x >= x_end){
			x+= rnd_off + lst_draw_offset;
			if(rnd_off == 0){ x+=1;} //even # of xchars
			x_end -=  rnd_off +lst_draw_offset;
		}else{ x -= rnd_off+ lst_draw_offset;
			x_end += rnd_off+ lst_draw_offset;
			if(rnd_off == 0){ x_end+=1;}}//even # f xchars
	  }else{
		if( y >= y_end){
			y+= rnd_off + lst_draw_offset;
			if(rnd_off == 0){ y+=1;} //even # of yrows
			y_end -=  rnd_off +lst_draw_offset;
		}else{ y -= rnd_off+ lst_draw_offset;
			y_end += rnd_off+ lst_draw_offset;
			if(rnd_off == 0){ y_end+=1;} //even # of yrows
		}
	  }	
	}
       }
	
	var xoff= xcenter; var yoff= ycenter; 
	if(OPTIONAL_draw_every_steps == void null){ 
		OPTIONAL_draw_every_steps =0;}
	
	var x_end_lst_step = x_end;
	var y_end_lst_step = y_end;
	if( horiz_not_vertical){ 
		if(x > x_end){ x_end +=1;}else{x_end-=1;}
	}else{ if(y > y_end){ y_end +=1;}else{y_end-=1;} }

	//////////////////////////////////
	// END ROT-HANDLING, INITIAL SETTUP FOR DRAW LINE!!!
	// /////////////////////////////

	var x_dist = x - x_end;
	var y_dist = y - y_end;
	if(x_dist > 0){ var sign_x = -1;}else{ var sign_x = 1; }
	if(y_dist > 0){ var sign_y = -1;}else{ var sign_y = 1; }
	x_dist = Math.abs(x_dist); y_dist = Math.abs( y_dist);
	
	//setting the step-dist for 1 and slope...
	var max_step_x_dist = x_dist/y_dist;
	if( max_step_x_dist < 1){ max_step_x_dist = 1;} 
	var max_step_y_dist = y_dist/x_dist;
	if( max_step_y_dist < 1){ max_step_y_dist =1; }
	////////////////////////////////////
	// IF getLst DEFINED: drawing list and exiting!
	// 	(AND an 'auto'-thing too, for evenly spaced!!!)
	///////////////////////////////////
	if( OPTIONAL_evenly_placed_OR_null){
		getLst= [0,1];
		//below is to override an optimization oversight above
		if(graphic.length==1){
	 		var g_width = 0;
	  		var g_height = 0;}
		if(rotate_FULL_QRTR_NONE == "FULL"){
		  var total_dist = Math.sqrt( Math.pow(x-x_end,2) +
					Math.pow(y-y_end,2));
		  var number_of_steps = 
				total_dist/ (g_width-1);
	  	  var step_dist = 1/number_of_steps;
		  var step_start =step_dist/(g_width-1);
		  for(var i=0; i< number_of_steps; i += 1){
			  getLst.push( step_start+(step_dist *i));}
		}else{
			if(horiz_not_vertical){
			   var tmp_itterator = g_width;
			   if(x > x_end){ 
			      var x_target = x_end_lst_step+xoff;
			      for(var i=x+xoff; i> x_target; 
				      i -= tmp_itterator){
			   	getdraw(  graphic, i, y+yoff +  
			            Math.floor(y_end-y+.5)
				    *(1-(x_target-i)/
					(x_target-(x+xoff)) ), 
				   transparent_char);}
			   }else{
			    var x_target = x_end_lst_step+xoff;
			    for(var i=x+xoff; i< x_target; 
				    i += tmp_itterator){
				 getdraw(  graphic, i, y+yoff +  
				    Math.floor(y_end-y+.5)
				    *(1-(x_target-i)/
					    (x_target-(x+xoff)) ),
				   transparent_char);;} }
			}else{
			   var tmp_itterator = g_height;
			   if(y > y_end){ 
			      var y_target = y_end_lst_step+yoff;
			      for(var i=y+yoff; i> y_target; 
				      i -= tmp_itterator){
			   	getdraw(  graphic, x+xoff +  
				  Math.floor(x_end-x+.5)
				  *(1-(y_target-i)/
					  (y_target-(y+yoff)) ), 
				  i, transparent_char);}
			   }else{
			    var y_target = y_end_lst_step+yoff;;
			    for(var i=y+yoff; i< y_target; 
				    i += tmp_itterator){
			   	getdraw(  graphic, x+xoff +  
				  Math.floor(x_end-x+.5)
				  *(1-(y_target-i)/
					  (y_target-(y+yoff)) ), 
				  i, transparent_char);} 
				} 
			} }
		
	}
	if( getLst != void null){
		var l =0;
		for(var i=0; i< getLst.length; i+=1){
			l = getLst[i];
			if(l <=0){
			   getdraw(  graphic, x+xoff, 
				  y+yoff, transparent_char);
			continue;}
			if(l >=1){
			   getdraw( graphic, x_end_lst_step+xoff, 
		 		y_end_lst_step+yoff, transparent_char);
			continue;}
			getdraw( graphic, 
				x+ xoff + Math.floor(x_end-x+.5)*l, 
		 		y+ yoff + Math.floor(y_end-y+.5)*l,
				transparent_char);  
		}
		return; 
		
	}
	//////////////////////////////////
	// actual stepping walk! (NOT SKIPPING STEPS ON THIS PART!
	// /////////////////////////////
	var cur_steps = 0;
	 getdraw(  graphic, x+xoff, y+yoff, transparent_char);
	
	//stepping y first if it's greater! (HALF step first step!)
	if( !horiz_not_vertical){step_y_dist +=max_step_y_dist/2;//halfstep!
	while(  step_y_dist >0 && y != y_end){
		 y += sign_y; step_y_dist -=1; cur_steps+=1;
		if(cur_steps >= OPTIONAL_draw_every_steps){
		   getdraw(  graphic, x+xoff, y+yoff, transparent_char);
		   cur_steps =0; } } 
	}else{ step_x_dist +=max_step_x_dist/2;
	while(  step_x_dist >0 && x != x_end){
		 x += sign_x; step_x_dist -=1; cur_steps+=1;
		if(cur_steps >= OPTIONAL_draw_every_steps){
		   getdraw(  graphic, x+xoff, y+yoff, transparent_char);
		   cur_steps =0; } }
	step_y_dist +=max_step_y_dist/2; // halfstep!
	while(  step_y_dist >0 && y != y_end){
		 y += sign_y; step_y_dist -=1; cur_steps+=1;
		if(cur_steps >= OPTIONAL_draw_every_steps){
		   getdraw(  graphic, x+xoff, y+yoff, transparent_char);
		   cur_steps =0; } 
	}	}
	//////////////////////////AFTER FIRST STEP//////////
	while( x != x_end || y != y_end){
		step_x_dist +=max_step_x_dist;
		while(  step_x_dist >0 && x != x_end){
		   x += sign_x; step_x_dist -=1; cur_steps+=1;
		if(cur_steps >= OPTIONAL_draw_every_steps){
		   getdraw(  graphic, x+xoff, y+yoff, 
			   transparent_char);
		   cur_steps =0; }
		}
		step_y_dist +=max_step_y_dist;
		while(  step_y_dist >0 && y != y_end){
		   y += sign_y; step_y_dist -=1; cur_steps+=1;
		   if(cur_steps >= OPTIONAL_draw_every_steps){
		      getdraw(  graphic, x+xoff, y+yoff, 
			      transparent_char);
		      cur_steps =0; }
	}	}
	// draw last place
	 //getdraw( graphic, x_end+xoff, y_end+yoff, transparent_char); 
	getdraw( graphic, x_end+xoff, y_end+yoff, transparent_char);
	getdraw( graphic, x_end_lst_step+xoff, y_end_lst_step+yoff, 
		transparent_char);
	
}

