// remove lines with TMP_BREAK
// to get back draw functionality

#ifndef M_PI
#    define M_PI 3.14159265358979323846
#endif

////////////////////////////////////////////////
////////////////////////////////////////////////
////  _sketch_3d_CORE_draw_cols_n_sprites (NEED C VERSION)
////////////////////////////////////////////////
////////////////////////////////////////////////

// draw collumns for js:

// inspired ( eg: rewritten using slightly different algorithm)
// from following code:
// https://www.playfuljs.com/a-first-person-engine-in-265-lines/
	// looks like there is some good maths from:
	// http://nicmendoza.github.io/playfuljs-demos/raycaster/
	//	basically, the source I was inspired by, + sprites
int _sketch_3d_get_scrn_y( float inSketch_height,
	float point_z, float z,//z= distance_with_anti_fisheye_z,
	float getCam_tilt, float getCam_height);
int _sketch_3d_lrgobj_diagnol__dist_to_point(
		int length, int width, int x, int y,
		int o_x, int o_y);
void _sketch_3d__draw_col_between(
	int drawing_tiles_NOT_cols, 
	float getDistance, float angle, //maybe angle 4 skybox
	int istile_shadow,  //if so, lights off
	float precent_through_x_tile, //% offset of x, 4 tile border
	float height_limit,  float floor_limit,// hight/bottom limit
	float top_of_drawing, float bottom_of_drawing, // height/bottom 
	char * texture_char_IN, float get_screen_x, //scanline_x is which screen x is drawn
	float dist_max,
	float MAX_WALLBRDER_DIST_default_6,
	float fieldOfView_Default_pnt8,
	float fade_start_precent_Default_pnt60);

char _sketch_3d_BLANK_TO_DRAW_CHAR = '	'; // TAB

int _sketch_3d__get_char_index( char char_in, char* str_to_find_index_of){
	//returns index or -1
	int i =0; 
	while( str_to_find_index_of[i] != '\0' && 
			str_to_find_index_of[i] != char_in){ i+=1; }
	if(str_to_find_index_of[i] == '\0'){ return -1;}
	return i; }

#define LARGE_I 0
#define SML_I 1
#define TNY_I 2
static const char _sketch_3d__fades_sml_chars[] = "[!()[]\\;{}+:~\0";
static const char _sketch_3d__fades_tny_chars[] = "'\",^._-\0";
static const char _sketch_3d__fades_wtspace_chars[] = "\t\n\r \0";
void _sketch_3d__fade_out_txt( char * str,  //ALTERS STRING ITSELF!!!
			// string must null \0 terminate!!!
		float dist, float dist_max, // for fading when % below
		float fade_start_precent_Default_pnt60,
		char blank_to_draw_under_char){

	float dist_precent = dist/dist_max;
	char *fade_too; // near, mid, far fade chars
	
	if( dist_precent < fade_start_precent_Default_pnt60){ 
		return;}
	//if( dist_precent < .60){ fade_too = "::."; break;	}
	if( dist_precent < fade_start_precent_Default_pnt60 + .10){ 
		fade_too = ":. \0";  
	}else{  // else is >75% to distmax
		fade_too = ".. \0"; 	}

	int i=-1; char c;
	while(str[i+1] != '\0'){ c = str[i+1]; i +=1;
		
		if(c == blank_to_draw_under_char){ continue;}
		if(-1 != _sketch_3d__get_char_index(c,
		   (char*)_sketch_3d__fades_wtspace_chars)){ continue;}
		if(-1 != _sketch_3d__get_char_index(c,
			(char*)_sketch_3d__fades_tny_chars)){ 
			str[i] = fade_too[TNY_I]; continue;}
		if(-1 != _sketch_3d__get_char_index(c,
			(char*)_sketch_3d__fades_sml_chars)){
		       	str[i] = fade_too[SML_I];	continue;}
		//The rest SHOULD  be large chars:
		str[i] = fade_too[LARGE_I];
	}
	
	return;
}
#undef LARGE_I
#undef SML_I
#undef TNY_I
// OK, if I only scanfor tiny/small characters, 
// ignore tabs and whitespace chars, 
// I should be able to reduce the time significantly.

// RUNS LIKE pcall, DOESN'T HANDLE RETURN VALUES, AND 
// REMOVES THE SAMEONE PCALL REMOVES ( function, arg1...argX) 
// 	DOES NOT RETURN ERROR, SHOWS IT INSTEAD!!!
// 	
void _sketch_3d__duktape__pcall_error_test_n_pop(
		duk_context * ctx, 
		int numb_of_arguments){
	char garbage_char_for_error_scanf[10];
	duk_int_t rc=0; // error catching
	rc = duk_pcall(ctx, numb_of_arguments); 
		//removes #of  arguments
	if (rc != DUK_EXEC_SUCCESS) {
			  if (duk_is_error(ctx, -1)) {
			   	duk_get_prop_string(ctx, -1, "stack");
			  	 printf("error (stack info)\n ""(see trace below for line number failures in functions):\n%s\n", 
					   duk_to_string(ctx, -1)); 
			  }else{printf(
				"error running sketch_3d__convertobj"); }
			  fgets(garbage_char_for_error_scanf, 3, stdin);
			}
	duk_pop(ctx);
}


//list of possible list
#define MAX_CATCH_LENGTH 200
int _sketch_3d_lrgobj_diagnol_dist_1turn_catch_LENGTH = 0;
int _sketch_3d_lrgobj_diagnol_dist_1turn_catch[MAX_CATCH_LENGTH]; 
	// this stores index for _rmloaded_launch_game_objs_large
void _sketch_3d_lrgobj_diagnol_dist_1turn_catch__SETTUP( duk_context *ctx,
		int x, int y, char *gotColgroup, int maxDist ){
	int tmp_len = lookupbyprop__rmloaded_launch_game_objs_large__get_listlength(
			gotColgroup[0]);

	_sketch_3d_lrgobj_diagnol_dist_1turn_catch_LENGTH = 0;
	//file_input(x + " " + y + " "+getCol_Prop+" "+ maxDist);
	//_sketch_3d_lrgobj_diagnol_dist_1turn_catch = [];
	//var tmp_len = rmloaded_lookupprop_getlrgobjs_len( getCol_Prop );
	duk_get_global_string(ctx, "_rmloaded_launch_game_objs_large");	
	for(int i =0; i< tmp_len; i+=1){
		if(_sketch_3d_lrgobj_diagnol_dist_1turn_catch_LENGTH 
				>= MAX_CATCH_LENGTH -1){ break;}
		int tmp_OBJ_I_N_LIST = 
			lookupbyprop__rmloaded_launch_game_objs_large__get_list_i( 
					gotColgroup[0],i);
		duk_get_prop_index(ctx, -1, tmp_OBJ_I_N_LIST);

		duk_get_prop_string(ctx, -1, "x"); //objlrg
		int o_x = (int) duk_get_number(ctx, -1); duk_pop(ctx);

		duk_get_prop_string(ctx, -1, "y"); //objlrg
		int o_y = (int) duk_get_number(ctx, -1); duk_pop(ctx);

		duk_get_prop_string(ctx, -1, "graphic"); //objlrg
		int len = (int) duk_get_length(ctx, -1);  //graphic
		int width = gridstr_0_under_50_or_width(
				(char*)duk_get_string(ctx,-1), len);
				//graphic
		
		duk_pop(ctx); //graphic
		
		
		//duk_get_prop_string(ctx, -3, "y");
		
		int tmp_dist = 
			_sketch_3d_lrgobj_diagnol__dist_to_point(
				len, width, x, y, o_x, o_y );
		
		if(tmp_dist <=maxDist ){ // close
		  _sketch_3d_lrgobj_diagnol_dist_1turn_catch[
			_sketch_3d_lrgobj_diagnol_dist_1turn_catch_LENGTH]
		   		= tmp_OBJ_I_N_LIST ;
		  _sketch_3d_lrgobj_diagnol_dist_1turn_catch_LENGTH+=1;}
	}	
	duk_pop(ctx); //"_rmloaded_launch_game_objs_large"
}
#undef MAX_CATCH_LENGTH



void _sketch_3d_c_only__scale_n_draw_under( char *tmp_graphic_IN,
		int width, int height, // SCALED height/width
		float dist, float dist_max, // for fading when % below
		float fade_start_precent_Default_pnt60,
		char blank_to_draw_under_char,
		int gridstr_scale__use_simple_scale,
		int isShadow,
		int x_to_draw_at, int y_to_draw_at
		){
	

	int len=0;while(tmp_graphic_IN[len] != '\0'){ ++len;}
	//char tmpGraphic[ len +1];
	char *tmpGraphic = (char*) malloc(
		( len +1) * sizeof(char));

	strcpy(tmpGraphic, tmp_graphic_IN);

	if(isShadow){ tmpGraphic[0] = ' '; tmpGraphic[1] = '\0';}

	int c_scaled_length = _gridstr_scale__sizeof_gen_gridstr(
			 width,  height);
	//char c_scaled[ c_scaled_length];
	char *c_scaled = (char*) malloc(
		( c_scaled_length) * sizeof(char));

	
	_sketch_3d__fade_out_txt( tmpGraphic,  //ALTERS STRING ITSELF!!!
			// string must null \0 terminate!!!
		dist, dist_max,
		fade_start_precent_Default_pnt60,
		blank_to_draw_under_char);
	
	if( gridstr_scale__use_simple_scale){
	  gridstr_scale( tmpGraphic,//tmp_graphic_IN, 
  		c_scaled,   
  		 height,  width);
	}else{
	   gridstr_scale_nearest_neighbor( tmpGraphic, //tmp_graphic_IN, 
 		 c_scaled,   
  		 height, width);
	}
	sketch_grid_DRAW_UNDER_TRANSPCHAR( 
		c_scaled, x_to_draw_at, y_to_draw_at, 
		_sketch_3d_BLANK_TO_DRAW_CHAR, 
		c_scaled_length );
	
	free(tmpGraphic);
	free( c_scaled);
	
	return;
}


int _sketch_3d__lrgobj_sprites_1turn_catch__LOADED =0;
char garbage_char_for_error_scanf_B[10];

void _sketch_3d_sprites_at_tile( duk_context *ctx,
		float got_PREV_X, float got_PREV_Y,
		float caught_x, float caught_y, float screen_x, 
			//caught_x & y are tile xy
		float gotAngleNO_PLAYER_OFFSET, // for x tile
		float gotAngle_camera, // 
		float gotCam_x, float gotCam_y, // for calc dist
		float cam_height, float cam_tilt, 
			float inSketch_height, float inSketch_width,
		char gotColgroup,
		float gotFocalLength,
		float dist_max,
		int isShadow,
		float fade_start_precent_Default_pnt60){
	
	//OK, this is for SMALL objects
	duk_get_global_string(ctx, "_rmloaded_launch_game_objs"); //stk size 1
	int tmpLen = lookupbyxy__rmloaded_launch_game_objs__at_listlength(
				caught_x, caught_y );//gotColgroup);
	
	duk_get_global_string(ctx, "sketch_3d__convertobj");

	//vars used in function
	int found_group; char tmpProp;  int j=0; 
	// continued vars used in function 
	float dist_x; float dist_y; float dist_total;
	float z; 
	float o_angle_with_camera; float o_angle;
	float width; float height;
	float screen_ratio;
	float x_to_draw_at; float camera_x_offset;
	float y_to_draw_at; float y_to_draw_at_END;
	char * tmp_graphic;

	duk_int_t rc=0;
	// object vars, will pull FIRST, then clear vars. 
	float o_x; float o_y; float o_z; 
	float tmp_width; float tmp_height;
	float o_d3width; float o_d3height; 
	int o_d3simplescale; char * o_d3graphic; char* o_graphic;
	int o_graphic_length=0;

	// JUST for large objects
	char tmp_graphic_for_lrg_obj[2];
	int tmp_y_ongrid; int tmp_x_ongrid;
	float tmp_draw_depth; float tmp_draw_ceil;
	for(int i=0; i< tmpLen; i+=1){
		
		//getting object in stack (@ loc 1) 
		duk_get_prop_index(ctx, -2,  //"_rmloaded_launch_game_objs"
			lookupbyxy__rmloaded_launch_game_objs__at( 
				caught_x,  caught_y, i ) );
		if( duk_is_undefined(ctx, -1)){ //object
			duk_pop(ctx); continue; }
		//duk_pop(ctx); continue;
		// seeing if has colgroup (lookup-table doesn't do this)
		if( duk_has_prop_string(ctx, -1, "colgroup") ==0){ //object
				duk_pop(ctx); continue;}
		
		duk_get_prop_string(ctx, -1, "colgroup"); //object
		if( duk_is_null(ctx, -1)){  // colgroup
			duk_pop(ctx); duk_pop(ctx); continue; }
		j=0; found_group =0; 
		tmpProp = duk_char_code_at(ctx,-1, j); //colgroup
		while( tmpProp != '\0'){ j+=1;
			if(tmpProp == gotColgroup){  
				found_group = 1;  break;} 
			tmpProp = duk_char_code_at(ctx,-1, j);}//clgrp
		duk_pop(ctx); //colgroup
		if(found_group ==0){ duk_pop(ctx); continue;}//obj
		
		
		duk_get_prop_string(ctx, -1, "d3loaded"); // object
		if( !duk_get_boolean(ctx, -1)){ // d3loaded
			duk_dup(ctx, -3 ); //"sketch_3d__convertobj" 
			duk_dup(ctx, -3 ); //obj 
			_sketch_3d__duktape__pcall_error_test_n_pop(
				ctx, 1); //pops obj,sketch_3d__convertobj
		}duk_pop(ctx); //d3loaded
		/////////////////////////////
		// found object, converting, then pulling vars
		//////////////////////////////////
		duk_get_prop_string(ctx, -1, "z"); //object
		o_z = (float) duk_get_number(ctx,-1); duk_pop(ctx); //z

		duk_get_prop_string(ctx, -1, "d3width"); //object
		tmp_width =(float) duk_get_number(ctx,-1); duk_pop(ctx); 

		duk_get_prop_string(ctx, -1, "d3height"); //object
		tmp_height =(float)duk_get_number(ctx,-1); duk_pop(ctx); 

		duk_get_prop_string(ctx, -1, "x"); //object
		o_x =(float)duk_get_number(ctx,-1); duk_pop(ctx); 

		duk_get_prop_string(ctx, -1, "y"); //object
		o_y =(float)duk_get_number(ctx,-1); duk_pop(ctx); 

		duk_get_prop_string(ctx, -1, "d3simplescale"); //object
		o_d3simplescale =(int)duk_get_number(ctx,-1);duk_pop(ctx);

		duk_get_prop_string(ctx, -1, "d3graphic"); //object
		o_d3graphic =(char *)duk_get_string(ctx,-1); duk_pop(ctx);


		duk_pop(ctx); // object
		///////////////////////
		// after getting ALL vars needed, 
		//removing object...
		////////////////////////
		
		
		//if(o == void null){ continue;} 
			//above is to prevent a nasty error
		//if( o.hasOwnProperty("colgroup") == -1){ continue;}
		//if( o.colgroup.indexOf(gotColgroup) == -1){ continue;}
		//sketch_3d__convertobj(o);
		//maths got mostly from 
		// http://nicmendoza.github.io/playfuljs-demos/raycaster/
		//var tmp_width = o.d3width;// * gotFocalLength;
		//var tmp_height = o.d3height;
		

		
		// ANOTHER tutorial...?
		//https://dev.opera.com/articles/3d-games-with-canvas-and-raycasting-part-2

		// Minus .5 because that is what I used for the 
		// Other one 
		
		// OLD
		//var dist_x = o.x 
		//	-0.5 - (gotCam_x); //- 0.5);
		//var dist_y = o.y 
		//	-0.5 - (gotCam_y); //- 0.5);
		
		//below doesn't use o.x/y directly so same code should 
		//work for objs_large
		dist_x = caught_x
			+(o_x- (float) floor(o_x)) // tile fractional offset
			-0.5 - (gotCam_x); //- 0.5);
		dist_y = caught_y 
			+(o_y-(float)floor(o_y)) // tile fractional offset
			-0.5 - (gotCam_y); //- 0.5);
		dist_total =  sqrt(dist_x*dist_x + dist_y*dist_y);
		
		
		//printf("\n %f %f \n", o_x, o_y);

		//var height = (tmp_height * inSketch_height)/ dist_total;
		//var height = (tmp_height * (inSketch_height/2))/ z;
		

		z =  dist_total * (float)cos(gotAngleNO_PLAYER_OFFSET);

		//OK, I think the ratio is off, because everything 
		//else seems to work... just mangified screen location 
		// ALSO: I need make sure the camera angle is >0 !
		//  (or the additional rotation fucks it up
		//  ...
		//  WHY DOES 1.5 WORK HERE!!!
		//  IT SHOULD'T WORK, BUT IT DOES!!!!
		//var screen_ratio = ((inSketch_width)/1.5)/ gotFocalLength;
		screen_ratio = (inSketch_width)* gotFocalLength;
			
		width = (tmp_width* screen_ratio)/ dist_total;
			//(tmp_width* inSketch_width)/ dist_total;
		o_angle = atan2(dist_y,dist_x);
			// these are reversed....?
		o_angle_with_camera =  (gotAngle_camera)- o_angle;
		// BELOW IS HOW TO DO MODULUS WITH FLOAT_POINT!!!
		//o_angle_with_camera = o_angle_with_camera % (M_PI*2);
		o_angle_with_camera = (float) fmod(
				(double) o_angle_with_camera,
			       (double)	(M_PI*2));
		if(o_angle_with_camera >= M_PI){
				o_angle_with_camera -= M_PI * 2;    }
		if(o_angle_with_camera <= -M_PI){
				o_angle_with_camera += M_PI * 2;    }
		

		camera_x_offset =  ((inSketch_width-1) / 2 ) 
			-(width/2)
			-(screen_ratio * o_angle_with_camera);
		
		x_to_draw_at= camera_x_offset;
		
		y_to_draw_at = ceil(
		   _sketch_3d_get_scrn_y(
			inSketch_height, o_z-tmp_height, 
			z, cam_tilt, cam_height));
		y_to_draw_at_END = 
		   _sketch_3d_get_scrn_y(
			inSketch_height, o_z, 
			z, cam_tilt, cam_height);
		height = abs(y_to_draw_at_END - y_to_draw_at);
		//printf("\n %f \n", height);
		//file_input(height);
			// in the  code this is located in, 
			//  cam_height is *100 because the other 
			// draw functions use that. 
		
		//BELOW 3 IFs ARE OPTIMIZING,
		//	THEY WORK, but I want to draw full 
		//	sprites, so scaling them down like this 
		//	seems like a bad idea... If I want to 
		//	cut them down, (gridstr operations) first, 
		//	it would work
		if(height + y_to_draw_at < 0||
		    y_to_draw_at > inSketch_height){ continue;}
		//if(y_to_draw_at < 0){
		//	height += y_to_draw_at;
		//	y_to_draw_at = 0; }
		//if(height + y_to_draw_at > inSketch_height){
		//	height = inSketch_height-y_to_draw_at;}
		
		 _sketch_3d_c_only__scale_n_draw_under( 
			o_d3graphic,//tmp_graphic,
			(int)width, (int)height, // SCALED height/width
			dist_total, dist_max, // for fading when % below
			fade_start_precent_Default_pnt60,
			_sketch_3d_BLANK_TO_DRAW_CHAR,
			o_d3simplescale,
			isShadow,
			(int)x_to_draw_at, (int)y_to_draw_at
		);
	}
	duk_pop(ctx); duk_pop(ctx); 
		//sketch_3d__convertobj //"_rmloaded_launch_game_objs" 
	//////////////////////
	////// INITIALIZING LARGE OBJECTS, IF NOT INITIALIZED!!!
	/////////////////
	duk_get_global_string(ctx, "_rmloaded_launch_game_objs_large");
      //int _sketch_3d_lrgobj_diagnol_dist_1turn_catch[MAX_CATCH_LENGTH]; 
	// this stores index for _rmloaded_launch_game_objs_large	
	tmpLen=_sketch_3d_lrgobj_diagnol_dist_1turn_catch_LENGTH;
	int tmp_equal; int is_loaded = 0;
	//OK, this is for LARGE objects
	if( _sketch_3d__lrgobj_sprites_1turn_catch__LOADED == 0){ 
	   _sketch_3d__lrgobj_sprites_1turn_catch__LOADED = 1; 
	   
	   duk_get_global_string(ctx, "sketch_3d__convertobj_lrg");
	   for(int i=0; i< tmpLen; i+=1){

		   
		tmp_equal = 0;
		duk_get_prop_index(ctx, -2, // obj_lrg 
			_sketch_3d_lrgobj_diagnol_dist_1turn_catch[i]);
		
		is_loaded = 
			duk_has_prop_string(ctx, -1,"d3loaded");//lrgobj
		duk_get_prop_string(ctx, -1, "d3loaded");//lrgobj
		

		duk_get_prop_string(ctx, -2, "graphic"); //obj_lrg
		//printf("\n%i %i\n", i, _sketch_3d_lrgobj_diagnol_dist_1turn_catch[i]);
		tmp_equal = duk_equals(ctx, -1,-2);
		duk_pop(ctx); duk_pop(ctx); // loaded, d3graphic
		
		if( tmp_equal ==0 || is_loaded==0){
		     duk_dup(ctx, -2); //sketch_3d__convertobj_lrg
		    duk_dup(ctx, -2); // obj_large
		    // basically: sketch_3d__convertobj_lrg(obj_large)
		     _sketch_3d__duktape__pcall_error_test_n_pop(
				ctx, 1); //pops obj,sketch_3d__convertobj
		}
		
	   duk_pop(ctx); //obj_large
	   } duk_pop(ctx); } //sketch_3d__convertobj_lrg
	
	//////////////////////
	////// Lookup
	/////////////////
	//file_input(tmpLen);
	//
	//_rmloaded_launch_game_objs_large STILL in stack, val -1
	
	for(int i=0; i< tmpLen; i+=1){		
		duk_get_prop_index(ctx, -1, //pre-screened lrg_obj
			_sketch_3d_lrgobj_diagnol_dist_1turn_catch[i]);
		if( duk_is_null(ctx,-1)){ 
			duk_pop(ctx); continue;} //lrg_obj
		
		duk_get_prop_string(ctx, -1, "graphic"); //object
		o_graphic =(char *)duk_get_string(ctx,-1); 
		o_graphic_length = (int) duk_get_length(ctx,-1); 
		duk_pop(ctx);
		
		//printf("\n %s\n", o_graphic);

		duk_get_prop_string(ctx, -1, "x"); //object
		o_x =(float)duk_get_number(ctx,-1); duk_pop(ctx); 

		duk_get_prop_string(ctx, -1, "y"); //object
		o_y =(float)duk_get_number(ctx,-1); duk_pop(ctx); 

		tmp_x_ongrid = (int) ceil(caught_x- o_x);
		tmp_y_ongrid = (int) ceil(caught_y- o_y);

		//tmp_graphic = gridstr_char_get(o.graphic, 
		//	tmp_x_ongrid, tmp_y_ongrid, 0);
			
		gridstr_char_get( o_graphic, tmp_graphic_for_lrg_obj, 
				//2 chars: 'C\0'
			o_graphic_length, 
			tmp_x_ongrid, tmp_y_ongrid, 0);
		
		//early termination if no collision 
		if( tmp_graphic_for_lrg_obj[0] == '\0'){ 
			duk_pop(ctx); continue;} // lrg_obj
		//printf("\n %s \n", tmp_graphic_for_lrg_obj);	

		duk_get_prop_string(ctx, -1, "z"); //object
		o_z = (float) duk_get_number(ctx,-1); duk_pop(ctx); //z

		tmp_width = 1;
		
		duk_get_prop_string(ctx, -1, "d3floors");
		duk_get_prop_index(ctx, -1, tmp_y_ongrid);
		duk_get_prop_index(ctx, -1, tmp_x_ongrid);
		
		tmp_draw_depth = (float) duk_get_number(ctx, -1);
		duk_pop(ctx); duk_pop(ctx); duk_pop(ctx); //this block
		

		duk_get_prop_string(ctx, -1, "d3ceils");
		duk_get_prop_index(ctx, -1, tmp_y_ongrid);
		duk_get_prop_index(ctx, -1, tmp_x_ongrid);
		tmp_draw_ceil = (float) duk_get_number(ctx, -1);
		duk_pop(ctx); duk_pop(ctx); duk_pop(ctx); //this block


		duk_pop(ctx); //large_object
		//Above to avoid nasty error
	
		
		
		// http://nicmendoza.github.io/playfuljs-demos/raycaster/
		//var tmp_width = 1; //gotFocalLength;
		//var tmp_draw_depth =
		//	o.d3floors[tmp_y_ongrid][ tmp_x_ongrid];
		//var tmp_draw_ceil =  
		//	o.d3ceils[tmp_y_ongrid][ tmp_x_ongrid];
		//	tmp_draw_depth
		//	-o.d3ceils[tmp_y_ongrid][tmp_x_ongrid];
		//tmp_draw_depth = tmp_draw_depth- tmp_height;
		//var tmp_draw_depth = o.d3ceils[tmp_y_ongrid][tmp_x_ongrid];
		//var tmp_height =  
		//	o.d3floors[tmp_y_ongrid][ tmp_x_ongrid]
		//	-tmp_draw_depth;	
		//below doesn't use o.x/y directly so same code should 
		//work for objs_large
		dist_x = caught_x
			+(o_x- (float) floor(o_x)) // tile fractional offset
			-0.5 - (gotCam_x); //- 0.5);
		dist_y = caught_y 
			+(o_y-(float)floor(o_y)) // tile fractional offset
			-0.5 - (gotCam_y); //- 0.5);
		dist_total =  sqrt(dist_x*dist_x + dist_y*dist_y);
		
		//dist_x = caught_x
		//	+(o_x-floor(o_x)) // tile fractional offset
		//	-0.5 - (gotCam_x); //- 0.5);
		//dist_y = caught_y 
		//	+(o_y-floor(o_y)) // tile fractional offset
		//	-0.5 - (gotCam_y); //- 0.5);
		//dist_total = sqrt(dist_x*dist_x + dist_y*dist_y);
				
		z =  dist_total * (float)cos(gotAngleNO_PLAYER_OFFSET);
		
		screen_ratio = (inSketch_width)* gotFocalLength;
			
		width = (tmp_width* screen_ratio)/ dist_total;
			//(tmp_width* inSketch_width)/ dist_total;

		o_angle = atan2(dist_y,dist_x);
			// these are reversed....?
		o_angle_with_camera =  (gotAngle_camera)- o_angle;
		o_angle_with_camera =(float)fmod( 
			(double)o_angle_with_camera, 
			(double)(M_PI*2) );
		if(o_angle_with_camera >= M_PI){
				o_angle_with_camera -= M_PI * 2;    }
		if(o_angle_with_camera <= -M_PI){
				o_angle_with_camera += M_PI * 2;    }
		

		camera_x_offset =  ((inSketch_width-1) / 2 ) 
			-(width/2)
			-(screen_ratio * o_angle_with_camera);
		
		x_to_draw_at= camera_x_offset ;
		
		y_to_draw_at = ceil(
		   _sketch_3d_get_scrn_y(
			inSketch_height, o_z+tmp_draw_ceil, 
			z, cam_tilt, cam_height));
		y_to_draw_at_END = 
		   _sketch_3d_get_scrn_y(
			inSketch_height, o_z+ tmp_draw_depth, 
			z, cam_tilt, cam_height);
		height = abs(y_to_draw_at_END - y_to_draw_at);
		//file_input(height);
			// in the  code this is located in, 
			//  cam_height is *100 because the other 
			// draw functions use that. 
		
		//BELOW 3 IFs ARE OPTIMIZING,
		//	THEY WORK, but I want to draw full 
		//	sprites, so scaling them down like this 
		//	seems like a bad idea... If I want to 
		//	cut them down, (gridstr operations) first, 
		//	it would work
		//if(height + y_to_draw_at < 0||
		  //  y_to_draw_at > inSketch_height){ continue;}
		//if(y_to_draw_at < 0){
		//	height += y_to_draw_at;
		//	y_to_draw_at = 0; }
		//if(height + y_to_draw_at > inSketch_height){
		//	height = inSketch_height-y_to_draw_at;}
		if(height + y_to_draw_at < 0||
		   y_to_draw_at > inSketch_height){ continue;}
		if(y_to_draw_at < 0){
			height += y_to_draw_at;
			y_to_draw_at = 0; }
		if(height + y_to_draw_at > inSketch_height){
			height = inSketch_height-y_to_draw_at;}
		
		//printf("\n %f %f %f %f\n ", x_to_draw_at, y_to_draw_at,
		//	width, height);
		 _sketch_3d_c_only__scale_n_draw_under( 
			tmp_graphic_for_lrg_obj, //o_graphic,
			(int)width, (int)height, // SCALED height/width
			dist_total, dist_max, // for fading when % below
			fade_start_precent_Default_pnt60,
			_sketch_3d_BLANK_TO_DRAW_CHAR,
			1,//o_d3simplescale,
			isShadow,
			(int)x_to_draw_at, (int)y_to_draw_at
		);
		 
	}	
	duk_pop(ctx); //_rmloaded_launch_game_objs_large
		
	
}
#undef OBJ_I

int _sketch_3d_get_scrn_y( float inSketch_height,
	float point_z, float z,//z= distance_with_anti_fisheye_z,
	float getCam_tilt, float getCam_height){

	return (inSketch_height / 2.0)	//center of screen
		+ (( point_z)/z)//height offset
		+ getCam_tilt	//tilt
		+(((getCam_height)/2.0)/z); }
//NOTE: RETURNS DIST SMALLER THAN ACTUAL DISTANCE!!! 
//	SO ONLY USE THIS FOR OPTIMIZATIONS (AS A FIRST TEST!!!
// <=0  means MIGHT intersect!
int _sketch_3d_lrgobj_diagnol__dist_to_point(
		int length, int width, int x, int y,
		int o_x, int o_y){// o = object
	//var width = o.graphic.indexOf("\n"); // getting width... 
						// not perfect
	if( width <= 0){ width = length;}
	if(width <=0){ width = 1;}
	int height = (length - 1)/width;
	if( height <=0 ){ height = 1;}
	int o_center_x = o_x - (width/2);
	int o_center_y = o_y - (height/2);

	return (int)	(sqrt(
		   pow( (double)x - (double)o_center_x,2.0)+
		   pow( (double)y - (double)o_center_y,2.0))
		- ((double)width/2.0) - ((double)height/2.0)
		-2.0);//the 2 is a bit extra, just in cast
}
	

//var _SKETCH_3DSTEP_MAX_TOP_DRAWN = 24; //should set to canvas_height
//var _SKETCH_3DSTEP_MAX_BOTTOM_DRAWN = 0;

#define _sketch_3d_rayvars__MAX_VARS 120
float _sketch_3d_rayvars__angle[ _sketch_3d_rayvars__MAX_VARS ];
float _sketch_3d_rayvars__angle_NO_PLAYER_OFFSET[_sketch_3d_rayvars__MAX_VARS];
float _sketch_3d_rayvars__x[_sketch_3d_rayvars__MAX_VARS]; 
float _sketch_3d_rayvars__x_rndNdir[_sketch_3d_rayvars__MAX_VARS]; 
float _sketch_3d_rayvars__y[_sketch_3d_rayvars__MAX_VARS];
float _sketch_3d_rayvars__y_rndNdir[_sketch_3d_rayvars__MAX_VARS];
float _sketch_3d_rayvars__x_run[_sketch_3d_rayvars__MAX_VARS];
float _sketch_3d_rayvars__y_rise[_sketch_3d_rayvars__MAX_VARS];
float _sketch_3d_rayvars__top_drawn[_sketch_3d_rayvars__MAX_VARS];
float _sketch_3d_rayvars__bottom_drawn[_sketch_3d_rayvars__MAX_VARS];
float _sketch_3d_rayvars__dist[_sketch_3d_rayvars__MAX_VARS];
float _sketch_3d_rayvars__prev_dist[_sketch_3d_rayvars__MAX_VARS];
float _sketch_3d_rayvars__PREV_X_X_PRECENT[_sketch_3d_rayvars__MAX_VARS];

int _sketch_3d_rayvars__prev_shadow[_sketch_3d_rayvars__MAX_VARS];
#undef _sketch_3d_MAX_WALLBRDR_DIST 
//for drawing textures/borders

//var _sketch_3d_MAX_WALLBRDR_DIST = 6;

	// is used in devide by, so = 0 gives Infinity...



//'s-' vars a single-ray paramiters. They are handled as 
// indexed lists. (so s_x[i] is the same ray as s_y[i]
void _sketch_3d_ray_step_1_tile( int i, float * s_x, float * s_y, 
	float * s_x_rndNdir, float * s_y_rndNdir, 
	     float * s_dist, float * s_prev_dist, 
	     float * s_x_run, float * s_y_rise,
		float * s_prev_x_precent_4border
	       	){ //s is _sketch_3dstep_vars
	s_prev_dist[i] = s_dist[i];
	
	// I think this can be used for drawing textures for walls.
	// The idea is, for a  collision with a 2d grid, the 
	// x or y will be a round number, the other will have a remainder
	// The remainder ,as it's a 1x grid, will be %!
	s_prev_x_precent_4border[i] = s_y[i] -(float)floor(s_y[i])  +
		s_x[i] - (float)floor(s_x[i]);
	//file_input(s_prev_x_precent_4border[i]);
	
	float dx; float dy;
	if(s_x_run[i] > 0){ dx = (float)floor(s_x[i]+1) -s_x[i]; 
	}else{ dx = (float) ceil(s_x[i]-1) -s_x[i]; }
	
	if(s_y_rise[i] >0){ dy = (float)floor(s_y[i]+1) - s_y[i];
	}else{ dy = (float) ceil(s_y[i]-1) - s_y[i];  }
	
	// dy = dx*rise/run;  y = y+(dx*rise/run); x = x+(dy/(rise/run))
	float dist_y_if_using_dx =  dx*(s_y_rise[i]/s_x_run[i]);
	float dist_x_if_using_dy =  dy/(s_y_rise[i]/s_x_run[i]);
	
	float len_using_dx = (float)sqrt(
		(dx*dx)+(dist_y_if_using_dx*dist_y_if_using_dx));
	float len_using_dy = (float)sqrt(
		(dy*dy)+(dist_x_if_using_dy*dist_x_if_using_dy));

	// getting the SMALLER one!
	if( len_using_dx < len_using_dy){
		s_dist[i] +=  len_using_dx;
		s_x[i] += dx;
		s_y[i] += dist_y_if_using_dx;
		
	}else{
		s_dist[i] +=  len_using_dy;
		s_y[i] += dy;
		s_x[i] += dist_x_if_using_dy;
	}
	//getting a rounded version of x and y
	if(s_x_run[i] > 0){ s_x_rndNdir[i] = (float)ceil(s_x[i]); 
	}else{ s_x_rndNdir[i] = (float)floor(s_x[i]+1); }
	
	if(s_y_rise[i] >0){ s_y_rndNdir[i] = (float)ceil(s_y[i]); 
	}else{  s_y_rndNdir[i] = (float)floor(s_y[i]+1); }
}

//NOTE: skybox was hacked together, and will NOT scale with 
//	screen size! (so scale the skybox image FIRST!) 
//
//OK< the 'sketch' bits should probably be embeded directly in 
//	the 'sketch' code!!! (most of it). 
// AAAAAND: for getting object data, should be: 
// 	getMapAt(x,y, colgroup){
// 		Test if map is 3d enabled 
// 		if not, make it so!
// 		--- catch height/depth/tilegfx!
// 			this way, only need one getMapAt}
//--- need to set x/y size for canvas. (may have alreay done this) 
//	for input. Then, for drawing, have a automatic 
//	'draw this' state, or be able to pull and use custom!
//	(same thing with drawing 2d objs. )
//---- MIGHT be able to get away with JUST doing 
//	the 3dstep bit in a seperate c function! 

// base-name: sketch_3d
// Below toggles on 1x per sketch_3d o
// BELOW adds object to stack,
// HEAVILY integrated into the game-engine
void _skech_3d__duktape_GET_OBJ( duk_context *ctx,
		int x, int y, char prop){
	//int x = duk_to_int(ctx, -3);
	//int y = duk_to_int(ctx, -2);
	//char prop= duk_char_code_at(ctx, -1, 0);

	int len = lookupbyxy__rmloaded_launch_game_objs__at_listlength(x,y);
	if(len > 0){ 
		duk_get_global_string(ctx, "_rmloaded_launch_game_objs");
		for(int i=len-1; i>= 0; i-=1){
			if( lookupbyxy__rmloaded_launch_game_objs__at( x,y,i) 
					== -1){ 
				continue; }
			//getting OBJ
			duk_get_prop_index(ctx, -1, 
				lookupbyxy__rmloaded_launch_game_objs__at(x,y,i));
			duk_get_prop_string(ctx, -1, "colgroup");
			if( strchr((const char*)duk_to_string(ctx, -1), 
					prop ) != NULL){ 
				duk_dup(ctx, -2);
				duk_insert(ctx,-4);
				duk_pop_n(ctx,3);
				 return;
			}duk_pop(ctx); duk_pop(ctx);//prop  obj
		}duk_pop(ctx); // _for__rmloaded_launch_game_objs
	}

	char tmpC[2]; 
	len = lookupbyprop__rmloaded_launch_game_objs_large__get_listlength(prop);
	if(len > 0){ 
		duk_get_global_string(ctx, "_rmloaded_launch_game_objs_large");
		for(int i=0; i< len; i+=1){
			duk_get_prop_index(ctx, -1, 
			   lookupbyprop__rmloaded_launch_game_objs_large__get_list_i( 
					prop,i));
			duk_get_prop_string(ctx, -1, "graphic");
			duk_get_prop_string(ctx, -2, "x");
			duk_get_prop_string(ctx, -3, "y");

			strcpy(tmpC, " ");
			gridstr_overlay(  
			  (char*)tmpC,	(char*)duk_to_string(ctx, -3), 
			  	//graphic
				-(x- duk_to_int(ctx, -2)), //x
				-(y- duk_to_int(ctx, -1)), //y
				0,0); //length of char to get
			
			if( 0 != strcmp(tmpC, " ")){ // not the same
				//duk_dup(ctx, -4); //obj
				//duk_insert(ctx, 4); //inputs +1
				duk_pop_n(ctx, 3);
				//duk_pop_n(ctx, 5);
				//duk_push_string(ctx, tmpC); 
				return;}
			duk_pop_n(ctx, 4);
	} duk_pop(ctx);  }

	duk_push_null(ctx); 
	return;
}

int _SKETCH_3D_MAP_NO_TILE_HEIGHT = -200;
int _SKETCH_3D_MAP_NO_TILE_DEPTH = 70;
static const char _SKETCH_3D_MAP_NO_TILE_FLOOR_TEXTURE[] = "-\n+\n+";
static const char _SKETCH_3D_MAP_NO_TILE_CIEL_TEXTURE[] = "+\n+\n-";

int _sketch_3d__caught_tile_ceilheight = 0;// define on runtime
int _sketch_3d__caught_tile_floordepth = 0; // define on runtime
char _sketch_3d__caught_tile_texture_floor[100];// define on runtime
char _sketch_3d__caught_tile_texture_ceil[100]; // define on runtime
//NOT WORKING!!!! (untested, not in use, really)
//Below is to streamline tile-reading!
//
void _skech_3d__catchMapTile_N_covert_tile( duk_context * ctx, 
		float x, float y, char *get_tag){
	//file_input(x +" " + y + " " + get_tag);
	
	// Below should be equivilent to commented out line,
	// 	adds a stack item o OR null for found nothing. 
	//var o = rmloaded_col_GET_OBJ(x, y, get_tag);
	
	_skech_3d__duktape_GET_OBJ( ctx,
		x, y, get_tag[0]);
	// currently in stack: null or obj. 

	if(duk_is_null(ctx, -1)){// obj
		_sketch_3d__caught_tile_ceilheight = 
			_SKETCH_3D_MAP_NO_TILE_HEIGHT;
		_sketch_3d__caught_tile_floordepth = 
			_SKETCH_3D_MAP_NO_TILE_DEPTH;
		strcpy(_sketch_3d__caught_tile_texture_floor, 
				_SKETCH_3D_MAP_NO_TILE_FLOOR_TEXTURE);
		strcpy(_sketch_3d__caught_tile_texture_ceil, 
				_SKETCH_3D_MAP_NO_TILE_CIEL_TEXTURE);
		//_sketch_3d__caught_tile_texture_floor= 
		//	_SKETCH_3D_MAP_NO_TILE_FLOOR_TEXTURE;
		//_sketch_3d__caught_tile_texture_ceil = 
		//	_SKETCH_3D_MAP_NO_TILE_CIEL_TEXTURE;
	}else{

		duk_get_prop_string(ctx, -1, "d3loaded");
		int is_null = duk_is_null(ctx, -1);
		duk_get_prop_string(ctx, -2, "graphic");
		int tmp_equal = duk_equals(ctx, -1,-2);
		duk_pop(ctx); duk_pop(ctx); // d3loaded, d3graphic

		if( tmp_equal ==0 || is_null){
		     duk_get_global_string(ctx, 
				     "sketch_3d__convertobj_lrg"); 
		    duk_dup(ctx, -2); // obj_large
		    // basically: sketch_3d__convertobj_lrg(obj_large)
		     _sketch_3d__duktape__pcall_error_test_n_pop(
				ctx, 1); //pops obj,sketch_3d__convertobj
		}
		duk_get_prop_string(ctx, -1, "graphic"); //object
		char* o_graphic =(char *)duk_get_string(ctx,-1); 
		int o_graphic_length = (int)duk_get_length(ctx,-1); 
		duk_pop(ctx);
		
		duk_get_prop_string(ctx, -1, "z"); //object
		float o_z =(float)duk_get_number(ctx,-1); duk_pop(ctx);

		duk_get_prop_string(ctx, -1, "x"); //object
		float o_x =(float)duk_get_number(ctx,-1); duk_pop(ctx);

		duk_get_prop_string(ctx, -1, "y"); //object
		float o_y =(float)duk_get_number(ctx,-1); duk_pop(ctx);

	
		char tmpChar[2];
		//from rmloaded_batch_n_collisions.js
		//var tmpChar = gridstr_overlay(  
		//		" ",	o.graphic, 
		//		-(x-o.x), -(y-o.y),
		//		false, 	true, null);
		gridstr_char_get( o_graphic, tmpChar, //2 chars: 'C\0'
			o_graphic_length, 
			(int)(x-o_x), (int)(y-o_y), 
			0);
		
		//printf("%i %s\n", (int)(x-o_x), 
		//		tmpChar);
		

		_sketch_3d__caught_tile_texture_floor[0] = '-';
		_sketch_3d__caught_tile_texture_floor[1] = '\n';
		_sketch_3d__caught_tile_texture_floor[2] = tmpChar[0];
		_sketch_3d__caught_tile_texture_floor[3] = '\n';
		_sketch_3d__caught_tile_texture_floor[4] = tmpChar[0];
		_sketch_3d__caught_tile_texture_floor[5] = '\0';
		//"-\n"+tmpChar+"\n"+tmpChar;
		
		_sketch_3d__caught_tile_texture_ceil[0] = tmpChar[0]; 
		_sketch_3d__caught_tile_texture_ceil[1] = '\n'; 
		_sketch_3d__caught_tile_texture_ceil[2] = tmpChar[0]; 
		_sketch_3d__caught_tile_texture_ceil[3] = '\n'; 
		_sketch_3d__caught_tile_texture_ceil[4] = '-'; 
		_sketch_3d__caught_tile_texture_ceil[5] = '\0'; 
						
		int tmp_y_ongrid; int tmp_x_ongrid;
		tmp_x_ongrid = (int)(x-o_x);
		tmp_y_ongrid = (int)(y-o_y);

		duk_get_prop_string(ctx, -1, "d3floors");
		duk_get_prop_index(ctx, -1, tmp_y_ongrid);
		

		duk_get_prop_index(ctx, -1, tmp_x_ongrid);
		float tmp_draw_depth = (float) duk_get_number(ctx, -1);
		duk_pop(ctx); duk_pop(ctx); duk_pop(ctx); //this block
	
		duk_get_prop_string(ctx, -1, "d3ceils");
		duk_get_prop_index(ctx, -1, tmp_y_ongrid);
		duk_get_prop_index(ctx, -1, tmp_x_ongrid);
		float tmp_draw_ceil = (float) duk_get_number(ctx, -1);
		duk_pop(ctx); duk_pop(ctx); duk_pop(ctx); //this block

		//= tmpChar+"\n"+tmpChar+"\n-";
		
		_sketch_3d__caught_tile_floordepth = 
			o_z + tmp_draw_depth;
		_sketch_3d__caught_tile_ceilheight = 
			o_z + tmp_draw_ceil;
	
	}
	duk_pop(ctx); // lrg_obj or Null
}



/*
function getMapFloor_Height( caught_x, caught_y, get_obj){
	// NOTE ON FUTURE EDITS:
	// I'm going to be using heightmaps, so I need to 
	// get obj.data, 
	// so...
	// 	Why not also throw in a 'z' value? 
	// 	this would allow large objects to be used,
	// 	as it could 'walk' up or down things. 
	// 	( merge) 
	var tmpChar = rmloaded_col_test_SIMPLE(caught_x, caught_y, get_tag);
	if(tmpChar  == "#"){return -100;} //2;}
	if(tmpChar  == "" ){ return 70;} // -1000;} arbitrary, should modify
	return 3;//3;
}
function getMapRoof_Depth(caught_x, caught_y,get_tag){
	// NOTE ON FUTURE EDITS:
	// I'm going to be using heightmaps, so I need to 
	// get obj.data, 
	// so...
	// 	Why not also throw in a 'z' value? 
	// 	this would allow large objects to be used,
	// 	as it could 'walk' up or down things. 
	// 	( merge) 
	var tmpChar = rmloaded_col_test_SIMPLE(caught_x, caught_y, get_tag);
	if( tmpChar == "#"){return -150;}
	if( tmpChar == "" ){ return -200;} // 1000:} arbitrary, should modify
	return -100;
}
function getMapTexture_floor(caught_x, caught_y,get_tag){ 
	var tmpChar = rmloaded_col_test_SIMPLE(caught_x, caught_y, get_tag);
	if(tmpChar == ""){ tmpChar = "-\n+\n+"; }
	return "-\n"+tmpChar+"\n"+tmpChar;
}
function getMapTexture_ceil(caught_x, caught_y,get_tag){ 
	var tmpChar = rmloaded_col_test_SIMPLE(caught_x, caught_y, get_tag);
	if(tmpChar == ""){ tmpChar = "+\n+\n-"; }
	return tmpChar+"\n"+tmpChar+"\n-";
}
*/
#define s_angle _sketch_3d_rayvars__angle
#define s_angle_NO_PLAYER_OFFSET _sketch_3d_rayvars__angle_NO_PLAYER_OFFSET
#define s_x _sketch_3d_rayvars__x
#define s_x_rndNdir _sketch_3d_rayvars__x_rndNdir
#define s_y _sketch_3d_rayvars__y
#define s_y_rndNdir _sketch_3d_rayvars__y_rndNdir
#define s_x_run _sketch_3d_rayvars__x_run
#define s_y_rise _sketch_3d_rayvars__y_rise
#define s_top_drawn _sketch_3d_rayvars__top_drawn
#define s_bottom_drawn _sketch_3d_rayvars__bottom_drawn
#define s_dist _sketch_3d_rayvars__dist
#define s_prev_dist _sketch_3d_rayvars__prev_dist
#define s_prev_x_precent_4border _sketch_3d_rayvars__PREV_X_X_PRECENT

#define s_prev_x_precent_4border _sketch_3d_rayvars__PREV_X_X_PRECENT

#define s_prev_shadow _sketch_3d_rayvars__prev_shadow

#define _sketch_3d_DIST_START 0.01

// OK, if I translate this to c, that MIGHT do it, as this is 
// some, odd, 90-99% of the code work. 
void _sketch_3d_CORE_draw_cols_n_sprites( 
		duk_context * ctx,
		float origin_x_NEED_OFFSET, float origin_y_NEEDS_OFFSET, 
		float getAngle, float cam_height, float cam_tilt,
		char* get_col_tag_for_walls, char* get_col_tag_for_sprites,
		float inSketch_width, float inSketch_height, 
		float dist_max,
		char * shadowgrid_or_null, 
		int shadowgrid_len,
		char * shadowgrid_shadow_char, 
		float shadowgrid_x, float shadowgrid_y,
		float MAX_WALLBRDER_DIST_default_6,
		float fieldOfView_Default_pnt8,
		float fade_start_precent_Default_pnt60){ 
	
	// needs to be reset 1x per turn
	//global str:
	_sketch_3d__lrgobj_sprites_1turn_catch__LOADED = 0;	

	float origin_x = -1.0+ origin_x_NEED_OFFSET; 
		// offset PROBABLY isnt accurate
	float origin_y = -1.0+ origin_y_NEEDS_OFFSET;
		// offset PROBABLY isnt accurate
	
	int HACK_MOD_fadedist_1turn_if_shadow_ends = 0;
	// think of this as having a list of structs named 's'
	// I defined these using preprocessor
	//var s_angle = _sketch_3d_rayvars__angle;
	//var s_angle_NO_PLAYER_OFFSET = 
	//	_sketch_3d_rayvars__angle_NO_PLAYER_OFFSET;
 	//var s_x = _sketch_3d_rayvars__x;
	//var s_x_rndNdir = _sketch_3d_rayvars__x_rndNdir;
	//var s_y = _sketch_3d_rayvars__y;
	//var s_y_rndNdir = _sketch_3d_rayvars__y_rndNdir;
	//var s_x_run = _sketch_3d_rayvars__x_run;
	//var s_y_rise = _sketch_3d_rayvars__y_rise;
	//var s_top_drawn = _sketch_3d_rayvars__top_drawn;
	//var s_bottom_drawn = _sketch_3d_rayvars__bottom_drawn;
	//var s_dist = _sketch_3d_rayvars__dist;
	//var s_prev_dist = _sketch_3d_rayvars__prev_dist;
	//var s_prev_x_precent_4border =_sketch_3d_rayvars__PREV_X_X_PRECENT;

	//importing inSketch_width/height
	//var inSketch_width = draw_canvas_get_width();
	//var inSketch_height = draw_canvas_get_height()
	// initializing the lists/resetting vars (top 'while' runs 1x):
	for(int i=0; i< inSketch_width; i+=1){
		float x = (float)i / inSketch_width - 0.5;
         	float angle_without_player_offset = 
			atan2(x, fieldOfView_Default_pnt8);
		
		s_angle_NO_PLAYER_OFFSET[i] = angle_without_player_offset;
		s_angle[i] = angle_without_player_offset +getAngle;
		s_x_run[i] = cos(s_angle[i]); 
		s_y_rise[i] = sin(s_angle[i]);
		
		s_prev_x_precent_4border[i] = 2.0; // high-balling it
		s_x_rndNdir[i] = origin_x-100.0; // -100 is placeholder
		s_y_rndNdir[i] = origin_y-100.0; // -100 is placeholder
		// s.x & s.y & s.dist set in .._step_1_tile below
		s_x[i] = origin_x; s_y[i] = origin_y;

		s_dist[i] = _sketch_3d_DIST_START;
		s_prev_dist[i] = s_dist[i];

		s_top_drawn[i] = inSketch_height;
		s_bottom_drawn[i] = 0.0;
		
		s_prev_shadow[i]=0;

		s_bottom_drawn[i] = 0.0;
		s_top_drawn[i] = inSketch_height;}//inSketch_height;}
	//can probably remove s.dist and s.maxdist from struct...
	float cur_dist = _sketch_3d_DIST_START; 
	

	float caught_x = (float)floor(origin_x); 
	float caught_y = (float)floor(origin_y);
	float caught_prev_x = caught_x;
	float caught_prev_y = caught_y;
		
	float roof_depth;
	float floor_depth;
	float draw_bottom_start;
	float draw_top_start;
	float z;

	char tmp_char[2]; // used with gridstr_char_get below
	
	
	//load below global vars
	_skech_3d__catchMapTile_N_covert_tile( ctx,
		caught_x, caught_y, get_col_tag_for_walls);

	float roof_depth_tile = _sketch_3d__caught_tile_ceilheight;
	float floor_depth_tile =_sketch_3d__caught_tile_floordepth;
	char * texture_char_tile_floor = _sketch_3d__caught_tile_texture_floor;
	char * texture_char_tile_ceil = _sketch_3d__caught_tile_texture_ceil;
	
	int shadowgrid_width = 0;
	if(shadowgrid_or_null != NULL){
		shadowgrid_width = 
			gridstr_0_under_50_or_width(
				shadowgrid_or_null, shadowgrid_len);
	}else{  // below will NOT actually run, it is behind the 
		// test above
		shadowgrid_width = 0;}
	int caught_istile_shadow = 0;
	/* using a singleton above
	var floor_depth_tile =  getMapFloor_Height( 
		caught_x, caught_y, get_col_tag_for_walls);
	var roof_depth_tile =  getMapRoof_Depth( 
			caught_x, caught_y, get_col_tag_for_walls);
	var texture_char_tile_floor = getMapTexture_floor( 
			caught_x, caught_y, get_col_tag_for_walls);
	var texture_char_tile_ceil =getMapTexture_ceil(
			caught_x, caught_y, get_col_tag_for_walls);
	*/
		
	while(cur_dist< dist_max){
	   for(int i = 0; i < inSketch_width; i += 1){ 
	   	_sketch_3d_ray_step_1_tile( i, s_x, s_y, 
			s_x_rndNdir, s_y_rndNdir,  
			s_dist, s_prev_dist,  s_x_run, s_y_rise,
			s_prev_x_precent_4border);
	   }
	   
	   for(int screen_x = 0; screen_x < inSketch_width;screen_x += 1){ 
	
	     if(s_bottom_drawn[screen_x] >= s_top_drawn[screen_x]){ 
		   continue; }	
	    if(s_x_rndNdir[screen_x] != caught_x 
		   || s_y_rndNdir[screen_x] != caught_y){
		
		caught_prev_x = caught_x;
		caught_prev_y = caught_y;

		// gotta handle shadowwork here
		//shadowgrid_or_null, shadowgrid_shadow_char, 
		//shadowgrid_x, shadowgrid_y, shadowgrid_width,
		    //caught_istile_shadow
		 //file_input(gridstr_char_get("",-1,-1,0) == "");

		caught_x =  s_x_rndNdir[screen_x]; 
		caught_y = s_y_rndNdir[screen_x];   
		if( shadowgrid_or_null != NULL){
			gridstr_char_get( shadowgrid_or_null, tmp_char, 
					//2 chars: 'C\0'
			shadowgrid_len, 
			(int)ceil(shadowgrid_x+caught_x), 
			(int)ceil(shadowgrid_y + caught_y), 
			shadowgrid_width);

			//if(gridstr_char_get(shadowgrid_or_null,
			//	shadowgrid_x-caught_x, 
			//	shadowgrid_y - caught_y, 
			//	shadowgrid_width) 
			//	 == shadowgrid_shadow_char){
			if( tmp_char[0] == shadowgrid_shadow_char[0]){
			//file_input(shadowgrid_or_null);
			caught_istile_shadow = 1;
			}else{ caught_istile_shadow = 0;}
		}else{caught_istile_shadow = 0;}
		//load below global vars
		//added
		if(caught_istile_shadow == 1 &&
			s_prev_shadow[screen_x] == 0){
				HACK_MOD_fadedist_1turn_if_shadow_ends=1;
		}else{HACK_MOD_fadedist_1turn_if_shadow_ends =0;}
		s_prev_shadow[screen_x] = caught_istile_shadow;


		_skech_3d__catchMapTile_N_covert_tile( ctx,
			caught_x, caught_y, get_col_tag_for_walls);
		
		roof_depth_tile = _sketch_3d__caught_tile_ceilheight;
		floor_depth_tile =_sketch_3d__caught_tile_floordepth;
		texture_char_tile_floor= 
			    _sketch_3d__caught_tile_texture_floor;
			//_sketch_3d__fade_out_txt( _sketch_3d__caught_tile_texture_floor,
			 //  s_prev_dist[screen_x] *
			 //   Math.cos(s_angle_NO_PLAYER_OFFSET[screen_x]),
			//	dist_max);
		texture_char_tile_ceil = _sketch_3d__caught_tile_texture_ceil;
			// _sketch_3d__fade_out_txt( _sketch_3d__caught_tile_texture_ceil,
			  //  s_prev_dist[screen_x] *
			  //  Math.cos(s_angle_NO_PLAYER_OFFSET[screen_x]),
				//   dist_max);
	//printf("aabbad \n");
		
		_sketch_3d_sprites_at_tile( ctx,
			caught_prev_x,caught_prev_y,
			caught_x, caught_y, screen_x,
			s_angle_NO_PLAYER_OFFSET[screen_x],
			getAngle, //s_angle[i],
			origin_x, origin_y,
			cam_height, cam_tilt, 
			inSketch_height, inSketch_width,
			get_col_tag_for_sprites[0], 
			fieldOfView_Default_pnt8,
			dist_max,
			caught_istile_shadow 
				-HACK_MOD_fadedist_1turn_if_shadow_ends,
			fade_start_precent_Default_pnt60
			  -(float)HACK_MOD_fadedist_1turn_if_shadow_ends);
	 	
	   }
	    
	     for(int i=0; i<2; i+=1){	
		if(i==0){
			z =s_prev_dist[screen_x] *
			     cos(s_angle_NO_PLAYER_OFFSET[screen_x]);
			draw_bottom_start = -10000.0;
			draw_top_start = 10000.0;}
		if(i==1){ 
			draw_bottom_start = s_bottom_drawn[screen_x];
			draw_top_start = s_top_drawn[screen_x];
			z =  s_dist[screen_x] * 
			    cos(s_angle_NO_PLAYER_OFFSET[screen_x]);}
		/////////////////////////////////////////////////
		///drawing cols/faces/////////////////////////////////////
		//////////////////////////////////////////////////////////
		 floor_depth = _sketch_3d_get_scrn_y(
			inSketch_height, floor_depth_tile, 
			z, cam_tilt, cam_height);
			//100 is just a multiplyer so cam moves faster
		
		roof_depth =_sketch_3d_get_scrn_y(
			inSketch_height, roof_depth_tile, 
			z, cam_tilt, cam_height);

		_sketch_3d__draw_col_between(
			i, s_prev_dist[screen_x], s_angle[screen_x], 
				// drawing tiles
			caught_istile_shadow -  //light-on!
				HACK_MOD_fadedist_1turn_if_shadow_ends,
			s_prev_x_precent_4border[screen_x],
			s_top_drawn[screen_x],  s_bottom_drawn[screen_x],
				// hight/bottom limit
			draw_top_start, floor_depth, // height/bottom 
			//above and the next block with this have issues
			texture_char_tile_ceil, screen_x,
			dist_max,
			MAX_WALLBRDER_DIST_default_6,
			fieldOfView_Default_pnt8,
			fade_start_precent_Default_pnt60-
			  (float)HACK_MOD_fadedist_1turn_if_shadow_ends);
		 //////////////////
		     ////////THINK I WILL ADD SPRITES ON TILE HERE!!!
		     ///////////
		
		  //DRAWING 'roof'
		 _sketch_3d__draw_col_between(
			i, s_prev_dist[screen_x], s_angle[screen_x], //drawing tiles
			caught_istile_shadow - //light-on!
				HACK_MOD_fadedist_1turn_if_shadow_ends, 
			 s_prev_x_precent_4border[screen_x], 
			 //% offset of x, 4 tile border
			// (the idea is x or y is a flat integer,
			// 	the other will be the ONLY offset)
			 s_top_drawn[screen_x],  s_bottom_drawn[screen_x],// hight/bottom limit
			 roof_depth, draw_bottom_start,
			 texture_char_tile_floor, screen_x,
		 	dist_max,
			MAX_WALLBRDER_DIST_default_6,
			fieldOfView_Default_pnt8,
			fade_start_precent_Default_pnt60-
			 (float)HACK_MOD_fadedist_1turn_if_shadow_ends);		
	

		if(roof_depth >s_bottom_drawn[screen_x]){
			s_bottom_drawn[screen_x] = roof_depth;}
		if(floor_depth <s_top_drawn[screen_x]){
			s_top_drawn[screen_x] = floor_depth;}
	     }
	  }
	//printf("11qqqbbad %f %f \n", cur_dist, dist_max );
	    
	   cur_dist +=1.0;
	}
}
#undef _sketch_3d_DIST_START

#undef s_prev_shadow

#undef s_angle 
#undef s_angle_NO_PLAYER_OFFSET 
#undef s_x 
#undef s_x_rndNdir 
#undef s_y 
#undef s_y_rndNdir 
#undef s_x_run 
#undef s_y_rise 
#undef s_top_drawn 
#undef s_bottom_drawn 
#undef s_dist 
#undef s_prev_dist 
#undef s_prev_x_precent_4border

/*
_sketch_3d_c_only__scale_n_draw_under( char *tmp_graphic_IN,
		int width, int height, // SCALED height/width
		float dist, float dist_max, // for fading when % below
		float fade_start_precent_Default_pnt60,
		char blank_to_draw_under_char,
		int gridstr_scale__use_simple_scale,
		int isShadow,
		int x_to_draw_at, int y_to_draw_at
		)
*/
// placeholder for 'filled char' 
void _sketch_3d__draw_col_between(
	int drawing_tiles_NOT_cols, 
	float getDistance, float angle, //maybe angle 4 skybox
	int istile_shadow,  //if so, lights off
	float precent_through_x_tile, //% offset of x, 4 tile border
	float height_limit,  float floor_limit,// hight/bottom limit
	float top_of_drawing, float bottom_of_drawing, // height/bottom 
	char * texture_char_IN, float get_screen_x, //scanline_x is which screen x is drawn
	float dist_max,
	float MAX_WALLBRDER_DIST_default_6,
	float fieldOfView_Default_pnt8,
	float fade_start_precent_Default_pnt60){ 
	
	//file_input( precent_through_x_tile);
	float y_top = 0.0;
	if( top_of_drawing < height_limit){
		if( top_of_drawing > floor_limit){ 
			y_top = top_of_drawing;
		}else{ y_top = floor_limit;}
	}else{ y_top = height_limit;}

	float y_bottom = 0.0;
	if( bottom_of_drawing > floor_limit){
		if( bottom_of_drawing < height_limit){
			y_bottom = bottom_of_drawing;
		}else{ y_bottom = height_limit;}
	}else{  y_bottom = floor_limit;}

	char texture_char[10]; // 10 is overkill here but it's 11 oclock
	if( y_bottom >= y_top){ return;};
	//if( y_top > height_limit){ printf("aaa");return;}
	//if( y_bottom >= y_top){ return;};
	if( istile_shadow){
		texture_char[0] = '0'; texture_char[1] = '\0';
		 _sketch_3d_c_only__scale_n_draw_under( 
			texture_char,
			1, //Scaled width, next is HIGHT 
			  (float)ceil( (float)abs(y_top -y_bottom)),
			getDistance, dist_max, // for fading when % below
			fade_start_precent_Default_pnt60,
			_sketch_3d_BLANK_TO_DRAW_CHAR,
			1, // simple scale
			istile_shadow,
			get_screen_x, y_bottom
		);
		return;
	}
	  
	 strcpy( texture_char, texture_char_IN);
	 //rendering depth
	  

	  if( getDistance < dist_max*fade_start_precent_Default_pnt60
		&& getDistance < MAX_WALLBRDER_DIST_default_6){ 
		// drawing 'border' to walls ( horizontal)
		// OK, there are a few border options:
		// draw and don't draw are two (for 'tops' of surfaces)
		//file_input(texture_char);
		float prec_thr_x_add_4_dist =  
			((getDistance / MAX_WALLBRDER_DIST_default_6) 
			  *0.16);
		//printf("%f ", prec_thr_x_add_4_dist);
		 //if(getDistance > MAX_WALLBRDER_DIST_default_6/2){
		//	prec_thr_x_add_4_dist = 0.0;}
		if(!drawing_tiles_NOT_cols ){
			if( precent_through_x_tile <
					prec_thr_x_add_4_dist ||
				precent_through_x_tile >
					1.0-prec_thr_x_add_4_dist 
			
			){
					texture_char[0]='*';
					texture_char[1]='\n';
					texture_char[2]='|';
					texture_char[3]='\n';
					texture_char[4]='*';
					texture_char[5]='\0';
					//texture_char =
					//"-\n|\n-";}
			}else{
			// for below, 2 should be texture char.
				texture_char[0]='=';
				texture_char[1]='\n';
				//texture_char[2]=texture_char[2];
				texture_char[3]='\n';
				texture_char[4]='=';
				texture_char[5]='\0';
			}
			//texture_char = "-\n"+ texture_char[2] + "\n-";
	  }	} 
	
	_sketch_3d_c_only__scale_n_draw_under( 
			texture_char,
			1, //Scaled width, next is HIGHT 
			  (float)ceil( (float)abs(y_top -y_bottom)),
			getDistance, dist_max, // for fading when % below
			fade_start_precent_Default_pnt60,
			_sketch_3d_BLANK_TO_DRAW_CHAR,
			1, // simple scale
			istile_shadow,
			get_screen_x, y_bottom
		);
	/*
	sketch_grid_DRAW_UNDER_TRANSPCHAR( gridstr_scale(//Math.floor(getDistance),
	//sketch_grid( gridstr_scale(//Math.floor(getDistance),
		texture_char,//""+drawing_tiles_NOT_cols, ////Math.floor(getDistance), 
		1,   Math.ceil(Math.abs(y_top -y_bottom)), 0),  //1,0),//
		get_screen_x, Math.ceil(y_bottom), 
		_sketch_3d_BLANK_TO_DRAW_CHAR ); //  transp_char_or_0);	


		//1,   Math.abs(y_top -y_bottom), 0),  //1,0),//
		//get_screen_x, y_bottom, " " ); //  transp_char_or_0);
	*/
}
////////////////////////////////////////////////
////////////////////////////////////////////////
////  _sketch_3d_CORE_draw_cols_n_sprites (NEED C VERSION)
////////////////////////////////////////////////
////////////////////////////////////////////////
//


#if defined(DUK_VERSION)
//gridstr_scale =function(textblock, size_x, size_y){return scaled_gridstr}
static duk_ret_t js_port_duktape__sketch_3d_ldd_catch__SETTUP(duk_context *ctx){
	//char c[ _gridstr_scale__sizeof_gen_gridstr(
	//		(int)duk_to_number(ctx,1), 
	//		(int)duk_to_number(ctx,2))];
	
	_sketch_3d_lrgobj_diagnol_dist_1turn_catch__SETTUP(
		ctx,
		(int)duk_to_number(ctx,0),
		(int)duk_to_number(ctx,1),
		(char *)duk_to_string(ctx,2),
		(int)duk_to_number(ctx,3));
		//int x, int y, char gotColgroup, int maxDist )	
	return 0;
}

static duk_ret_t js_port_duktape__sketch_3d_CORE_draw_cols_n_sprites(duk_context *ctx){
	int shadowgrid_len=0;
	if(duk_get_string(ctx,10) != NULL){
		shadowgrid_len = (int)duk_get_length(ctx, 10) ; }
	
	// so 17 inputs... Damn
  _sketch_3d_CORE_draw_cols_n_sprites( 
	ctx,
	(float) duk_get_number(ctx,0),//float origin_x_NEED_OFFSET, 
	(float) duk_get_number(ctx,1),// origin_y_NEEDS_OFFSET, 
	(float) duk_get_number(ctx,2),// getAngle, 
	(float) duk_get_number(ctx,3),// cam_height, 
	(float) duk_get_number(ctx,4),// cam_tilt,
	(char*) duk_get_string(ctx,5),// get_col_tag_for_walls, 
	(char*) duk_get_string(ctx,6), // get_col_tag_for_sprites,
	(float) duk_get_number(ctx,7),// inSketch_width, 
	(float) duk_get_number(ctx,8),// inSketch_height, 
	(float) duk_get_number(ctx,9),// dist_max,
	(char *) duk_get_string(ctx,10),// shadowgrid_or_null, 
	
	shadowgrid_len, //shadowgrid_len
	
	(char *) duk_get_string(ctx,11),// shadowgrid_shadow_char, 
	(float) duk_get_number(ctx,12),// shadowgrid_x, 
	(float) duk_get_number(ctx,13),// shadowgrid_y,
	(float) duk_get_number(ctx,14),// MAX_WALLBRDER_DIST_default_6,
	(float) duk_get_number(ctx,15),// fieldOfView_Default_pnt8,
	(float) duk_get_number(ctx,16)//fade_start_precent_Default_pnt60
  );
  return 0; 	
}
	
void sketch_3d_CORE_duktape_port_settup(duk_context *ctx){
	duk_push_c_function(ctx, 
			js_port_duktape__sketch_3d_ldd_catch__SETTUP, 4);
	duk_put_global_string(ctx, 
			"_sketch_3d_lrgobj_diagnol_dist_1turn_catch__SETTUP");
	duk_push_c_function(ctx, 
		 js_port_duktape__sketch_3d_CORE_draw_cols_n_sprites, 17);
	duk_put_global_string(ctx, 
		"_sketch_3d_CORE_draw_cols_n_sprites");
}
#endif

