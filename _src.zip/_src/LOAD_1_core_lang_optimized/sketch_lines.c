// NEEDS TO HAVE grid IMPORTED, OR THIS WON'T RUN!!!
#if defined(DUK_VERSION)	
#endif

void sketch_line( duk_context * ctx,
		float x, float y, float x_end, float y_end, 
		//WILL NEED TO ROUND DOWN x,y, etc.!
		char * rotate_FULL_QRTR_NONE, //str
		char *graphic_IN, int graphic_IN_len,
		char transparent_char, 
		int horiz_not_vertical_OR_neg_1, 
		int sketch0_draw1_coltest2,  //int
		int getLst_IN_dukstack_index_OR_neg_1, 
			//0 and 1 are caps! OVERRIDES ALL!!!
		int OPTIONAL_evenly_placed_OR_neg_1, 
		float OPTIONAL_draw_every_steps_OR_neg_1 );

float gridstr_rotate_max_diagnoal( char *getTxt_BEFORE_BORDER,
			int getTxt_length){
	 return 4.0+ (float)floor(
		sqrt(pow((float)gridstr_width(getTxt_BEFORE_BORDER,
						getTxt_length),2)+
		   pow((float)gridstr_height(getTxt_BEFORE_BORDER,
				   		getTxt_length),2)));}



//BELOW 2 FUNCTIONS ARE UNTESTED!!! (SHOULD WORK)
float gridstr_rotate_point_X( float originX, float originY, 
		float x, float y, 
		float degrees){
	float tmp_cos = .001*roundf(cos(degrees)*1000); 
	float tmp_sin = .001*roundf(sin(degrees)*1000);
	
	return (float)(originX+ (float)floor( (x-originX)*tmp_cos + 
			(y-originY)*tmp_sin));}
//BELOW 2 FUNCTIONS ARE UNTESTED!!! (SHOULD WORK)
float gridstr_rotate_point_Y(float originX, float originY, float x, float y,
	       float degrees){
	float tmp_cos = .001*roundf(cos(degrees)*1000); 
	float tmp_sin = .001*roundf(sin(degrees)*1000);
	
	return (float)(originY+ (float)floor( (-(x-originX)*tmp_sin) + 
			(y-originY)*tmp_cos));}

// us this on the base image/obj to move (translate), (to get dist
//  NOTE: I think these are untested, and I KNOW 
//  	that one was suppose to be X and wasn't...
float gridstr_rotation_ROTABLE_BORDER_X_OFFSET( char *getTxt_BEFORE_BORDER,
	       int getTxt_length	){
	float max_diagonal = 
		(float)gridstr_rotate_max_diagnoal(getTxt_BEFORE_BORDER,
					getTxt_length);
	return  (float)floor(max_diagonal - 
		(float)gridstr_width(getTxt_BEFORE_BORDER,
			getTxt_length))/2.0; }
float gridstr_rotation_ROTABLE_BORDER_Y_OFFSET( char *getTxt_BEFORE_BORDER,
	       	int getTxt_length	){
	float max_diagonal = 
		(float)gridstr_rotate_max_diagnoal(getTxt_BEFORE_BORDER,
					getTxt_length);
	return  (float)floor(max_diagonal - 
		(float)gridstr_height(getTxt_BEFORE_BORDER,
				getTxt_length))/2.0; }


//OK, need to generate string BEFOREHAND for draw line, 
//and have a function to get the desired string size!
//(roughly: rotatable border 4 FULL, other for QRTR, NONE for none)

// use above functions to account for offset.
// The reason for using this is otherwise, this WON'T 
int gridstr_rotation_SIZEOF_ROTATABLE_BORDER( char *getTxt, 
					int getTxt_length){
	float max_diagonal = gridstr_rotate_max_diagnoal(
			getTxt, getTxt_length);
	return (int)((max_diagonal * max_diagonal+2) +1);
}
void gridstr_rotation_MAKE_ROTATABLE_BORDER( char* getTxt_in,
		int getTxt_in_length,
	   char*getTxt_out, // use gridstr_rotation_SIZEOF_ROTATABLE_BORDER
	   int getTxt_out_length,
	   char* OPTIONAL_traspchar){
	if(OPTIONAL_traspchar == NULL){ OPTIONAL_traspchar=(char*)" ";}
	float g_width = (float)gridstr_width( getTxt_in,getTxt_in_length);
	float g_height = (float)gridstr_height( getTxt_in,getTxt_in_length);
	// think it might be 1 px bigger
	float max_diagonal = (float)gridstr_rotate_max_diagnoal(
				getTxt_in,getTxt_in_length);
	//file_input( max_diagonal + " "+ tmp_lines.length);
	//
	//float X_MODIFIER_TO_DEAL_WITH_GLITCHED_FUNCT=-1.0;
	gridstr_make(getTxt_out, 
		(int)
		  (max_diagonal), 
		(int)(max_diagonal ));
	//printf("\nQ%i %f\n", gridstr_height(getTxt_out, getTxt_out_length),
	//		max_diagonal);
	gridstr_fill(getTxt_out, OPTIONAL_traspchar[0], 
			(char*)"");
	gridstr_overlay(
		getTxt_out, getTxt_in,  	
		(int)(floor((max_diagonal - g_width)/2.0)), 
		(int)(floor((max_diagonal - g_height)/2.0)), 
		OPTIONAL_traspchar[0],	
		getTxt_out_length );
	//printf("%s %i %i", getTxt_out,  
	//		(int)(floor(max_diagonal - g_width)/2.0),
	//		(int)(floor(max_diagonal - g_height)/2.0));
}

//below will do NOTHING if not used with sketch_line_col_test
void (*_sketch_line_col_test_functPointer)(
		char* str, int x, int y, char trnsparent_or_0);
#if defined(DUK_VERSION)	

// BELOW IS DEFINED ELSEWARE!!!
//var _sketch_line_col_test_XYCOL_LIST=[]; 
	//3item- cycling list:goes x,y,co,  x,y,col..
char _sketch_line_col_test_COLGROUP;
duk_context *_sketch_line_col_CAUGHT_CONTEXT;
// for use with the line function as a dummy 'draw' function
// (for use with main sketch_line function!
int _sketch_line_col_test_dummydraw_LAST_X =0;
int _sketch_line_col_test_dummydraw_LAST_Y =0;
void _sketch_line_col_test_dummydraw( 
		char* graphic, int x, int y, char transparent_char){
	duk_context *ctx = _sketch_line_col_CAUGHT_CONTEXT;
	
	

	char * char_rtrn; int char_rtrn_len;
	_rmloaded_col_SIMPLE( ctx, x,y,_sketch_line_col_test_COLGROUP);
	//getting return of above!
	char_rtrn = (char *)duk_get_string(ctx, -1);
	char_rtrn_len  = (int)duk_get_length(ctx, -1);
	
	duk_pop(ctx); // return char for rmloaded_col_SIMPLE

	if( char_rtrn_len != 0){// char_rtrn != "" ){
			
		duk_get_global_string(ctx, 
				"_sketch_line_col_test_XYCOL_LIST");
		int len =  duk_get_length(ctx,-1);
		if(len >0){	
	   	   if(_sketch_line_col_test_dummydraw_LAST_X==x && 
			_sketch_line_col_test_dummydraw_LAST_Y==y){
			   duk_pop(ctx); //_sketch_line_col_test_XYCOL_LIST
			   return;}
		}
		//these should get set organically when len == 0
		_sketch_line_col_test_dummydraw_LAST_X = x;
		_sketch_line_col_test_dummydraw_LAST_Y = y;
		//_sketch_line_col_test_XYCOL_LIST.push(
		//	  x, y, char_rtrn);
		duk_push_int(ctx, x);
		duk_put_prop_index(ctx, -2, len);
	  	duk_push_int(ctx, y);
		duk_put_prop_index(ctx, -2, len+1);
		duk_push_string(ctx, char_rtrn);
		duk_put_prop_index(ctx, -2, len+2);	
		duk_pop(ctx); //_sketch_line_col_test_XYCOL_LIST
		}	}
void _sketch_line_col_test_dummydraw_FIRST_COL(  
		char* graphic, int x, int y, char transparent_char){
	duk_context *ctx = _sketch_line_col_CAUGHT_CONTEXT;
	
	//printf("\n%i %i",x,y);
	
	char * char_rtrn; int char_rtrn_len;
	_rmloaded_col_SIMPLE(ctx, x,y,_sketch_line_col_test_COLGROUP);
	//getting return of above!
	char_rtrn = (char *)duk_get_string(ctx, -1);
	char_rtrn_len  = (int)duk_get_length(ctx, -1);
	duk_pop(ctx); // return char for rmloaded_col_SIMPLE

	if( char_rtrn_len != 0){// char_rtrn != "" ){
		duk_get_global_string(ctx, 
				"_sketch_line_col_test_XYCOL_LIST");
		int len =  duk_get_length(ctx,-1);
		if( len >0){duk_pop(ctx);//_sketch_line_col_test_XYCOL_LIST
		       return;}	
		//_sketch_line_col_test_XYCOL_LIST.push(
		//	  x, y, char_rtrn);
		duk_push_int(ctx, x);
		duk_put_prop_index(ctx, -2, len);
	  	duk_push_int(ctx, y);
		duk_put_prop_index(ctx, -2, len+1);
		duk_push_string(ctx, char_rtrn);
		duk_put_prop_index(ctx, -2, len+2);	
		duk_pop(ctx); //_sketch_line_col_test_XYCOL_LIST
		}	}

void _sketch_line_col_test_SETTUP(  duk_context *ctx,
	char colgroup, int get_1_not_multi_pnts){
	
	_sketch_line_col_CAUGHT_CONTEXT = ctx;
	//_sketch_line_col_test_XYCOL_LIST=[];
	duk_push_array(ctx);
	duk_put_global_string(ctx, 
			"_sketch_line_col_test_XYCOL_LIST" );
	 
	_sketch_line_col_test_COLGROUP = colgroup;
	if( get_1_not_multi_pnts){
		_sketch_line_col_test_functPointer = 
			_sketch_line_col_test_dummydraw_FIRST_COL;
	}else{ _sketch_line_col_test_functPointer =
			_sketch_line_col_test_dummydraw;}}

//FOR USE _ONLY_ WITH DUKTAPE VERSION!!!
void sketch_line_col_test__RET1_2_DUKctx( duk_context *ctx,
		float x, float y, float x_end, float y_end,
		char *colgroup,
		int horiz_not_vertical_OR_neg_1, // OR null
		int get_1_not_multi_pnts, //1 pnt IS somewhat faster!
		int getLst_dukstack_index_OR_neg_1, // list of % (0-1.0) to check! (OPTIONAL!) 
			// for 'spot' checking. 
		float OPTIONAL_draw_every_steps_OR_neg_1){ //see main _sketch_line
//
	
	_sketch_line_col_test_SETTUP(  ctx,
		colgroup[0], get_1_not_multi_pnts);
	
	sketch_line( ctx, x, y, x_end, y_end, "NONE"," ", 1, ' ',  
		horiz_not_vertical_OR_neg_1, // can be null, and will choose 
		2, // sketch0_draw1_coltest2,  //int
		getLst_dukstack_index_OR_neg_1, //OPTIONAL_drawprcntlist_0to1_or_null, 
		-1,//OPTIONAL_evenly_placed_OR_neg_1
		(float)OPTIONAL_draw_every_steps_OR_neg_1);// int # of steps OR null
	
	duk_get_global_string(ctx, "_sketch_line_col_test_XYCOL_LIST");	
}


#endif
//
// OK... this is the core line drawing function, and it can 
// do a boatload of stuff. 
// That being said, it is not specialized. 
// So probably a good idea to write a wrapper for this 
// for specialized uses
// NOTE: draw_line is this function with a certain input!
// EG: sketch_line(x,y,x_end, y_end, "QRTR", "@", true, 1);//1 @ end!
#ifndef M_PI
#    define M_PI 3.14159265358979323846
#endif

void sketch_line( duk_context* ctx, 
		float x, float y, float x_end, float y_end, 
		//WILL NEED TO ROUND DOWN x,y, etc.!
		char * rotate_FULL_QRTR_NONE, //str
		//IMPORTANT: FULL WON'T BE 100% ACCURATE!!!
				//USE QRTR/NONE better accuracy. 
			//FOR FULL/QRTR: the 'point this way' 
			//part is to the right (eg: '-->' '>'=part!)
			//NOTE:keep width/length ODD for gridstr for "FULL"
			//'FULL' joins @ center point, so overshoots by1/2 
			// ALSO: for 'FULL', have odd # of rows/cols!!!
			//  ---place evenly works well with 'FULL'
		char *graphic_IN, int graphic_IN_len,
		char transparent_char,// USE:trans_char_4_pointer 
	       				// for pointers!!!!	
		int horiz_not_vertical_OR_neg_1, // can be null, and will choose 
				// via nearest demention on runtime. 
		int sketch0_draw1_coltest2,  //int
			//COLTEST IS 1 LINE WIDE!!!
			// USE SEPERATE COLTEST-LINE FUNCTS FOR 2
			//(they are only here to use same line funct) 
		int getLst_IN_dukstack_index_OR_neg_1, //OPTIONAL_drawprcntlist_0to1_or_null, 
			//0 and 1 are caps! OVERRIDES ALL!!!
		int OPTIONAL_evenly_placed_OR_neg_1, // NOTE: (OVERRIDES ALL!!) 	WAS 'or_null', will convert!!!
		float OPTIONAL_draw_every_steps_OR_neg_1 // int # of steps OR null
			// where the caps END (so I can draw a line 
			// between caps!!! [ x,y, y_end, x_end]	
		){ 
	//0 length lines are will draw nothing!
	if(x == x_end && y == y_end){ return; }

	char trans_char_4_pointer[3];
	strcpy( trans_char_4_pointer, " \0");
	if(transparent_char == 0){ trans_char_4_pointer[0] = '\0';
	}else{ trans_char_4_pointer[0] = transparent_char; }
//
	//adding or duplicating this list, so I can duk_pop(ctx) it at end!
	//(otherwise, it would slowly fill the stack)
	int getLst_dukindex = 0;
	if( getLst_IN_dukstack_index_OR_neg_1 == -1){
		getLst_dukindex =-1; // marks unused, so don't remove
	}else{
		duk_dup(ctx, getLst_IN_dukstack_index_OR_neg_1);
		getLst_dukindex = duk_get_top_index(ctx);
	}	//above is removed at end of function.
	
	//setting up graphic to work with!!! (needed for rotations!)
	int graphic_OUT_len = 0;
	if(rotate_FULL_QRTR_NONE[0] == 'F'){ // "FULL"
		graphic_OUT_len =  
		  gridstr_rotation_SIZEOF_ROTATABLE_BORDER( 	
		  		  graphic_IN, graphic_IN_len);	
	}else{ if(rotate_FULL_QRTR_NONE[0] == 'Q'){ //"QRTR"
		//from gridstr_transpose, is overkill
		graphic_OUT_len =  1 + 10 + graphic_IN_len  + 
			gridstr_width( graphic_IN, graphic_IN_len); 
	}else{ // "NONE"
		graphic_OUT_len = graphic_IN_len;}}
	//char graphic_OUT[graphic_OUT_len];
	char *graphic_OUT = (char*) malloc(
		( graphic_OUT_len) * sizeof(char));
	

	//I COPIED THIS 3X, CAN PROBABLY GIVE IT OWN FUNCTION!!!
	if(horiz_not_vertical_OR_neg_1 == -1){
		if(abs(x_end-x) > abs(y_end-y)){
		  horiz_not_vertical_OR_neg_1 = 1;}else{horiz_not_vertical_OR_neg_1 =0;} }
	//a few initial vars settup
	void (*getdraw)(char* str, int x, int y, char trnsparent_or_0);
	if(sketch0_draw1_coltest2 ==0){ getdraw =&sketch;
	}else{if(sketch0_draw1_coltest2 ==1){ 
		getdraw =&draw; 
	}else{if(sketch0_draw1_coltest2 ==2){ 
		getdraw = _sketch_line_col_test_functPointer; 
		//getdraw((char*)"aaaa", (int)x_end, (int)y_end,' ');
		//getdraw((char*)"aaaa", (int)x_end, (int)y_end,' ');
	}}}
	

	float step_x_dist =0.0; float step_y_dist =0.0;
	float xcenter; float ycenter;
	float g_width; float g_height;
	float xfull_w_cent_offset; float yfull_w_cent_offset;
	float lst_draw_offset =0.0;
	float rnd_off;
	float rot;
	int i;
	if(graphic_IN_len == 1){ xcenter =0.0; ycenter = 0.0;
		strcpy(graphic_OUT, graphic_IN);
		g_width = (float)gridstr_width(graphic_IN, graphic_IN_len);
	  	g_height =(float)gridstr_height(graphic_IN, graphic_IN_len);
	}else{
	
	    g_width = (float)gridstr_width(graphic_IN, graphic_IN_len);
	  g_height = (float)gridstr_height(graphic_IN, graphic_IN_len);
	  //centering line
	  xcenter = -(float)floor((g_width)/2.0); 
	  ycenter = -(float)floor((g_height)/2.0);
		//for below: center is negetive!
	  xfull_w_cent_offset = -(g_width + xcenter);
	  yfull_w_cent_offset = -(g_height + ycenter);

	  //rotate graphic here!!!
	  if(rotate_FULL_QRTR_NONE[0] == 'F'){ //"FULL"){
		//get offset FIRST!!!
		  xcenter -=
	  	  (float)( gridstr_rotation_ROTABLE_BORDER_X_OFFSET(
				  graphic_IN, graphic_IN_len));
		ycenter -=
		  (float)( gridstr_rotation_ROTABLE_BORDER_Y_OFFSET(
				  graphic_IN, graphic_IN_len));
		xcenter = ceil(xcenter); ycenter = ceil(ycenter);
		rot = (float)atan2(x-x_end, y - y_end) -(M_PI/2.0);
		

		gridstr_rotation_MAKE_ROTATABLE_BORDER( 
		    graphic_IN, graphic_IN_len,
	  	   (char*)graphic_OUT, graphic_OUT_len, 
		   (char*)trans_char_4_pointer);
		//printf("\n %i",
		//	gridstr_height(graphic_OUT, graphic_OUT_len));
		//still need to rotate graphic
		
		//char c[  graphic_OUT_len];
		//------------THIS IS FREED 10 LINES DOWN!!!!----------
		char *c = (char*) malloc(
		( graphic_OUT_len) * sizeof(char));
		
		strcpy(c, (char*)graphic_OUT);
		_gridstr_rotate( c, graphic_OUT, 
	       		rot, graphic_OUT_len, (char*)trans_char_4_pointer);
		
		free(c);
		
	  }else{ if(rotate_FULL_QRTR_NONE[0] == 'Q'){//RTR"){
		  // OK, this is all wrong. 
	  	float tmp_reverse_x_y = 1.0;
		if( horiz_not_vertical_OR_neg_1){ tmp_reverse_x_y=0;
			if(x > x_end){  rot = .6; //numbers here from 
			}else{ rot = -2.0; } 	//trail and error
		}else{  if(y > y_end){ rot = -.9; 
			}else{  rot = 1.8; }}
		
		//file_log(graphic);
		//graphic = gridstr_rotate_90_degrees(graphic, rot);
		//gridstr_rotate_90_degrees
		duk_get_global_string(ctx, "gridstr_rotate_90_degrees");
		duk_push_string(ctx, graphic_IN);
		duk_push_number(ctx, (double)rot);

		duk_int_t rc=0;
		rc = duk_pcall(ctx, 2);
		if (rc != DUK_EXEC_SUCCESS){
			printf("\nERROR IN QRTR_ROT-ing graphic in "
				" sketch_line");
		 	char garbage_char_for_error_scanf[10];
			fgets(garbage_char_for_error_scanf, 3, stdin); }
		strcpy(graphic_OUT, (char*)duk_to_string(ctx,-1));
		graphic_OUT_len = duk_get_length(ctx, -1);
		duk_pop(ctx); rc=0; //gridstr_rotate_90_return
		//file_log(graphic);
			  	
		//file_log(gridstr_rotate_90_degrees(graphic, rot));
		if( tmp_reverse_x_y){
			float tmp_var =  xcenter;
	 		g_width = (float)gridstr_width(
					graphic_OUT, graphic_OUT_len);
	  		g_height = (float)gridstr_height(
					graphic_OUT, graphic_OUT_len);
			xcenter = ycenter; ycenter = tmp_var;
			tmp_var = xfull_w_cent_offset;
			xfull_w_cent_offset = yfull_w_cent_offset;
			yfull_w_cent_offset = tmp_var; }
			
		if(horiz_not_vertical_OR_neg_1){ lst_draw_offset=  
				xfull_w_cent_offset;
		}else{ lst_draw_offset=  yfull_w_cent_offset; }
	
	  }else{ // rotate_FULL_QRTR_NONE == "NONE" (or whaterver)
		graphic_OUT_len = graphic_IN_len;
		strcpy( graphic_OUT, graphic_IN);
		if(horiz_not_vertical_OR_neg_1){ lst_draw_offset=  
				xfull_w_cent_offset;
		}else{ lst_draw_offset=  yfull_w_cent_offset; }
	  }}
	  ///////////////////
		/////////////// limiting length offset for rounding
		/// below is checking if even, basically.
	 if(rotate_FULL_QRTR_NONE[0] != 'F'){ //"FULL"){
	  if(horiz_not_vertical_OR_neg_1){ 
	    if( fmod(xcenter - lst_draw_offset,2.0) != 0.0){//% 2.0 != 0){
		rnd_off =1.0; }else{ rnd_off = 0.0;}
	  }else{ if( fmod(ycenter - lst_draw_offset, 2.0) != 0.0){ 
			  //% 2.0 != 0){
		rnd_off =1.0; }else{ rnd_off = 0.0;}}//rounding offset
	  //limiting line length based on horiz or vertical
	  if(horiz_not_vertical_OR_neg_1){
		// OK, end line alignment has a rounding errors as 
		  // well... not sure how I got a '1+' into the equasion...
		  // EDIT
		  // THE FUNCTION IS LOPSIDED!!!
		  // EG: 4 rounds to 2, which means it will fall: 
		  // 0@00 OR 00@0 depending on > or < 0!
		if( x >= x_end){
			x+= rnd_off + lst_draw_offset;
			if(rnd_off == 0.0){ x+=1.0;} //even # of xchars
			x_end -=  rnd_off +lst_draw_offset;
		}else{ x -= rnd_off+ lst_draw_offset;
			x_end += rnd_off+ lst_draw_offset;
			if(rnd_off == 0.0){ x_end+=1.0;}}//even # f xchars
	  }else{
		if( y >= y_end){
			y+= rnd_off + lst_draw_offset;
			if(rnd_off == 0.0){ y+=1.0;} //even # of yrows
			y_end -=  rnd_off +lst_draw_offset;
		}else{ y -= rnd_off+ lst_draw_offset;
			y_end += rnd_off+ lst_draw_offset;
			if(rnd_off == 0.0){ y_end+=1.0;} //even # of yrows
		}
	  }	
	}
       }
	
	
	
	float xoff= xcenter; float yoff= ycenter; 
	if(OPTIONAL_draw_every_steps_OR_neg_1 == -1.0){ 
		OPTIONAL_draw_every_steps_OR_neg_1 =0.0;}

	float x_end_lst_step = x_end;
	float y_end_lst_step = y_end;
	if( horiz_not_vertical_OR_neg_1){ 
		if(x > x_end){ x_end +=1.0;}else{x_end-=1.0;}
	}else{ if(y > y_end){ y_end +=1.0;}else{y_end-=1.0;} }

	//////////////////////////////////
	// END ROT-HANDLING, INITIAL SETTUP FOR DRAW LINE!!!
	// /////////////////////////////

	float x_dist = x - x_end;
	float y_dist = y - y_end;
	float sign_x; float sign_y;
	if(x_dist > 0.0){ sign_x = -1.0;}else{ sign_x = 1.0; }
	if(y_dist > 0.0){ sign_y = -1.0;}else{ sign_y = 1.0; }
	x_dist = abs(x_dist); y_dist = abs( y_dist);
	

	
	//NOTE: gotta convert ALL ints to floats. 
	// 	this should at least get rid of errors. 
	
	//setting the step-dist for 1 and slope...
	float max_step_x_dist =x_dist/y_dist;// divide by zero-error!!!
					//search for divide-by signs!!!
	if( max_step_x_dist < 1.0){ max_step_x_dist = 1.0;} 
	float max_step_y_dist = y_dist/x_dist;
	if( max_step_y_dist < 1.0){ max_step_y_dist =1.0; }
	
	////////////////////////////////////
	// IF getLst_dukstack_index_OR_neg_1 DEFINED: drawing list and exiting!
	// 	(AND an 'auto'-thing too, for evenly spaced!!!)
	///////////////////////////////////
	
	if( OPTIONAL_evenly_placed_OR_neg_1 == 1 ){
		//getLst_dukstack_index_OR_neg_1= [0,1];
		// //getLst_dukindex
		if(getLst_dukindex != -1){ 
			duk_remove(ctx, getLst_dukindex);   }
		duk_push_array(ctx); //removed at funct end
		getLst_dukindex = duk_get_top_index(ctx);
		getLst_IN_dukstack_index_OR_neg_1 =getLst_dukindex;	
		
		
		duk_push_number(ctx,(double)0.0);
		duk_put_prop_index(ctx, getLst_dukindex,0);
		duk_push_number(ctx,(double)1.0);
		duk_put_prop_index(ctx, getLst_dukindex,1);
	
		
		//below is to override an optimization oversight above
		// FROM JS VERSION, DON'T SEEM TO WORK HERE.
		//if(graphic_IN_len==1){
			//printf( "\n%s\n", graphic_OUT);
			//strcpy(graphic_OUT, graphic_IN);
	 	//	g_width = 0.0;
	  	//	g_height = 0.0;}
		if(rotate_FULL_QRTR_NONE[1] == 'F'){// "FULL"){
		  float total_dist = sqrt( pow((x-x_end),2) +
					pow((y-y_end),2));
		  float number_of_steps = 
				total_dist/ (g_width-1.0);
	  	  float step_dist = 1.0/number_of_steps;
		  float step_start =step_dist/(g_width-1.0);
		  for(i=0; i< number_of_steps; i += 1){
			duk_push_number(ctx,(double)(step_start+(step_dist 
						  *(float)i)));
			duk_put_prop_index(ctx, getLst_dukindex, 
				duk_get_length(ctx,getLst_dukindex));}
			  //getLst_dukstack_index_OR_neg_1.push( step_start+(step_dist *i));}
		}else{
			
			float tmp_itterator = 0.0;
			float x_target; float y_target;
			if(horiz_not_vertical_OR_neg_1){
			   tmp_itterator = g_width;
			   if(x > x_end){ 
			      x_target = x_end_lst_step+xoff;
			      for(i=x+xoff; i> x_target; 
				      i -= (int)tmp_itterator){
			   	getdraw(  graphic_OUT, i, (int)(y+yoff +  
			            ((float)floor((y_end-y)+.5)
				    *(1.0-(x_target-(float)i)/
					(x_target-(x+xoff))) )), 
				   transparent_char);}
			   }else{
			    x_target = x_end_lst_step+xoff;
			    for(i=x+xoff; i< x_target; 
				    i += (int)tmp_itterator){
				 getdraw(  graphic_OUT, i, (int)(y+yoff +  
				    ((float)floor((y_end-y)+.5)
				    *(1.0-(x_target-(float)i)/
					   (x_target-(x+xoff)) ))),
				   transparent_char);} }
			}else{
			   tmp_itterator = g_height;
			   if(y > y_end){ 
			      y_target = y_end_lst_step+yoff;
			      for(i=y+yoff; i> y_target; 
				      i -= (int)tmp_itterator){
			   	getdraw(  graphic_OUT, (int)(x+xoff +  
				   (((float)floor((x_end-x)+.5))
				  *(1.0-(y_target-(float)i)/
					  (y_target-(y+yoff)) ))), 
				  i, transparent_char);}
			   }else{
			    y_target = y_end_lst_step+yoff;;
			    for(i=y+yoff; i< y_target; 
				    i += (int)tmp_itterator){
			   	getdraw(  graphic_OUT, (int)(x+xoff +  
				  ((float)floor((x_end-x)+.5)
				  *(1.0-(y_target-(float)i)/
						(y_target-(y+yoff)) ))), 
				  i, transparent_char);} 
				} 
			} 
		}
			
	}
	
	if( getLst_IN_dukstack_index_OR_neg_1 != -1){
		float l =0.0;
		int list_len = duk_get_length(ctx, getLst_dukindex);
		for(i=0; i< list_len; i+=1){
			//l = getLst_dukstack_index_OR_neg_1[i];
			duk_get_prop_index(ctx, getLst_dukindex, i);
		        l= (float)duk_get_number(ctx,-1); duk_pop(ctx);

			if(l <=0.0){
			   getdraw(  graphic_OUT, (int)(x+xoff), 
				  (int)(y+yoff), transparent_char);
			continue;}
			if(l >=1.0){
			   getdraw( graphic_OUT, 
		 	     (int)(x_end_lst_step+xoff), 
		 	     (int)(y_end_lst_step+yoff), transparent_char);
			continue;}
			getdraw( graphic_OUT, 
			    (int)(x+ xoff +(float)(floor((x_end-x)+.5)*l)), 
		 	    (int)(y+ yoff +(float)(floor((y_end-y)+.5)*l)),
				transparent_char);  
		}
		if(getLst_dukindex != -1){ duk_pop(ctx);} //removing it
		free(graphic_OUT);
		return; 
		
	}
	
	//////////////////////////////////
	// actual stepping walk! (NOT SKIPPING STEPS ON THIS PART!
	// /////////////////////////////
	float cur_steps = 0.0;
	 getdraw(  graphic_OUT, 
		(int)(x+xoff), (int)(y+yoff), transparent_char);
	
	//stepping y first if it's greater! (HALF step first step!)
	if( !horiz_not_vertical_OR_neg_1){step_y_dist +=
		(max_step_y_dist/2.0);//halfstep!
	while(  step_y_dist >0 && y != y_end){
		 y += sign_y; step_y_dist -=1; cur_steps+=1;
		if(cur_steps >= OPTIONAL_draw_every_steps_OR_neg_1){
		   getdraw( graphic_OUT, 
			(int)(x+xoff), (int)(y+yoff), transparent_char);
		   cur_steps =0; } } 
	}else{ step_x_dist +=
		(max_step_x_dist/2.0);//halfstep!
	while(  step_x_dist >0 && x != x_end){
		 x += sign_x; step_x_dist -=1; cur_steps+=1;
		if(cur_steps >= OPTIONAL_draw_every_steps_OR_neg_1){
		   getdraw( graphic_OUT, 
			(int)(x+xoff), (int)(y+yoff), transparent_char);
		   cur_steps =0; } }
	step_y_dist +=
		(max_step_y_dist/2.0);//halfstep!
	while(  step_y_dist >0 && y != y_end){
		 y += sign_y; step_y_dist -=1; cur_steps+=1;
		if(cur_steps >= OPTIONAL_draw_every_steps_OR_neg_1){
		   getdraw( graphic_OUT, 
			(int)(x+xoff), (int)(y+yoff), transparent_char);
		   cur_steps =0; } 
	}	}
	//////////////////////////AFTER FIRST STEP//////////
	while( x != x_end || y != y_end){
		step_x_dist +=max_step_x_dist;
		while(  step_x_dist >0 && x != x_end){
		   x += sign_x; step_x_dist -=1; cur_steps+=1;
		if(cur_steps >= OPTIONAL_draw_every_steps_OR_neg_1){
		   getdraw(  graphic_OUT, (int)(x+xoff), (int)(y+yoff), 
			   transparent_char);
		   cur_steps =0; }
		}
		step_y_dist +=max_step_y_dist;
		while(  step_y_dist >0 && y != y_end){
		   y += sign_y; step_y_dist -=1; cur_steps+=1;
		   if(cur_steps >= OPTIONAL_draw_every_steps_OR_neg_1){
		      getdraw(  graphic_OUT, (int)(x+xoff), (int)(y+yoff), 
			      transparent_char);
		      cur_steps =0; }
	}	}
	// draw last place
	 //getdraw( graphic, x_end+xoff, y_end+yoff, transparent_char); 
	getdraw( graphic_OUT, 
		(int)(x_end+xoff), (int)(y_end+yoff), transparent_char);
	getdraw( graphic_OUT, 
		(int)(x_end_lst_step+xoff), (int)(y_end_lst_step+yoff), 
		transparent_char);
	if(getLst_dukindex != -1){ duk_pop(ctx);} //removing it
	
	free(graphic_OUT);
}



////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
/////////////// Ducktape Port //////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

#if defined(DUK_VERSION)
static duk_ret_t js_port_duktape___sketch_line_col_test(duk_context *ctx){

	// JS version (labeling vars-index:
	//function sketch_line_col_test(x[0, y[1, x_end[2, y_end[3,
	//	colgroup[4,
	//	horiz_not_vertical[5, // OR null
	//	get_1_not_multi_pnts[6, //1 pnt IS somewhat faster!
	//	getLst[7, // list of % (0-1.0) to check! (OPTIONAL!) 
	//		// for 'spot' checking. 
	//	OPTIONAL_draw_every_steps[8)
	// C VERSION:
	//	sketch_line_col_test__RET1_2_DUKctx( duk_context *ctx,
	//	int x, int y, int x_end, int y_end,
	//	char *colgroup,
	//	int horiz_not_vertical_OR_neg_1, // OR null
	//	int get_1_not_multi_pnts, //1 pnt IS somewhat faster!
	//	int getLst_dukstack_index_OR_neg_1, // list of % (0-1.0) to check! (OPTIONAL!) 
	//		// for 'spot' checking. 
	//	int OPTIONAL_draw_every_steps_OR_neg_1)
	int horiz_not_vertical_OR_neg_1 = -1; 
	if( !duk_is_null_or_undefined(ctx, 5)){ 
		horiz_not_vertical_OR_neg_1 = (int)duk_to_boolean(ctx, 5);}
	int get_1_not_multi_pnts =0;
	if( !duk_is_null_or_undefined(ctx, 6)){
		get_1_not_multi_pnts = (int)duk_to_boolean(ctx, 6);;}	
	int getLst_IN_dukstack_index_OR_neg_1 = -1; 
	if( !duk_is_null_or_undefined(ctx, 7)){ 
		getLst_IN_dukstack_index_OR_neg_1= 7;}
	int OPTIONAL_draw_every_steps_OR_neg_1 = -1; 
	if( !duk_is_null_or_undefined(ctx, 8)){
	  OPTIONAL_draw_every_steps_OR_neg_1 =(int)duk_to_boolean(ctx, 8);}
	
	sketch_line_col_test__RET1_2_DUKctx( ctx,
		//x,y,x_end,y_end
		(float)duk_get_number(ctx,0), (float)duk_get_number(ctx,1), 
		 (float)duk_get_number(ctx,2), (float)duk_get_number(ctx,3), 
		(char*)duk_get_string(ctx,4), //char *colgroup,
		horiz_not_vertical_OR_neg_1, // OR null
		get_1_not_multi_pnts, //1 pnt IS somewhat faster!
		getLst_IN_dukstack_index_OR_neg_1, // list of % (0-1.0) to check! (OPTIONAL!) 
			// for 'spot' checking. 
		(float)OPTIONAL_draw_every_steps_OR_neg_1);
	
	return 1;  // returns xy_cols list!
}


static duk_ret_t js_port_duktape___sketch_line(duk_context *ctx){

	// JS version (labeling vars-index:
	//sketch_line( x[0, y[1, x_end[2, y_end[3, 
	//	rotate_FULL_QRTR_NONE[4, //str
	//	graphic[5 , transparent_char[6, 
	//	horiz_not_vertical[7, // can be null, and will choose
	//	sketch0_draw1_coltest2[8,  //int
	//	getLst[9, //OR null
	//	OPTIONAL_evenly_placed_OR_null[10, 
	//	OPTIONAL_draw_every_steps[11 
	//	)
	// C VERSION:
	//	int x, int y, int x_end, int y_end, 
	//	//WILL NEED TO ROUND DOWN x,y, etc.!
	//	char * rotate_FULL_QRTR_NONE, //str
	//	char *graphic_IN, int graphic_IN_len,
	//	char transparent_char, 
	//	int horiz_not_vertical_OR_neg_1, 
	//	int sketch0_draw1_coltest2,   
	//	int getLst_IN_dukstack_index_OR_neg_1, 
	//	int OPTIONAL_evenly_placed_OR_neg_1, 
	//	int OPTIONAL_draw_every_steps_OR_neg_1 
	char transparent_char_OR_0 =0; 
	if( !duk_is_null_or_undefined(ctx, 6)){ 
	   if( duk_get_length(ctx, 6) >0){ 
	     transparent_char_OR_0 = ((char*)duk_get_string(ctx, 6))[0];}}
	int horiz_not_vertical_OR_neg_1 = -1; 
	if( !duk_is_null_or_undefined(ctx, 7)){ 
		horiz_not_vertical_OR_neg_1 = (int)duk_to_boolean(ctx, 7);}
	int getLst_IN_dukstack_index_OR_neg_1 = -1; 
	if( !duk_is_null_or_undefined(ctx, 9)){ 
		getLst_IN_dukstack_index_OR_neg_1= 9;}
	int OPTIONAL_evenly_placed_OR_neg_1 = -1; 
	if( !duk_is_null_or_undefined(ctx, 10)){
	  OPTIONAL_evenly_placed_OR_neg_1 = (int)duk_to_boolean(ctx, 10);}
	int OPTIONAL_draw_every_steps_OR_neg_1 = -1; 
	if( !duk_is_null_or_undefined(ctx, 11)){
	  OPTIONAL_draw_every_steps_OR_neg_1 =(int)duk_to_int(ctx, 11);}
	
	sketch_line( ctx,  //x,y,x_end,y_end
		(float)duk_get_number(ctx,0), (float)duk_get_number(ctx,1), 
		 (float)duk_get_number(ctx,2), (float)duk_get_number(ctx,3),
		//WILL NEED TO ROUND DOWN x,y, etc.!
		(char*)duk_get_string(ctx,4),//char * rotate_FULL_QRTR_NONE,
		(char*)duk_get_string(ctx,5), duk_get_length(ctx, 5),
		//char *graphic_IN, int graphic_IN_len,
		transparent_char_OR_0, //char transparent_char, 
		horiz_not_vertical_OR_neg_1,
			//int horiz_not_vertical_OR_neg_1, 
		(int)duk_get_number(ctx, 8), //int sketch0_draw1_coltest2,   
		getLst_IN_dukstack_index_OR_neg_1, 
		OPTIONAL_evenly_placed_OR_neg_1, 
		OPTIONAL_draw_every_steps_OR_neg_1 
		);

	return 0;  // no returns
}


void sketch_line_duktape_port_settup(duk_context *ctx){
	//placeholder
	_sketch_canvas_var_init();
	
	//intializing a var!
	duk_push_array(ctx);
	duk_put_global_string(ctx, 
			"_sketch_line_col_test_XYCOL_LIST" );


	
	duk_push_c_function(ctx, js_port_duktape___sketch_line, 12);
	duk_put_global_string(ctx, "sketch_line");
	
	duk_push_c_function(ctx, js_port_duktape___sketch_line_col_test, 9);
	duk_put_global_string(ctx, "sketch_line_col_test");
	
	
		
}

#endif

