// duktape/ javascript doesn't like functions declaired 
// in global namespace otherwise... it's wierd.
//API_TAG// 
// returns string data-type in form gridstr
var gridstr_scale =function(textblock, size_x, size_y){}
var gridstr_scale_nearest_neighbor = function(textblock, size_x, size_y){}
//API_TAG// 
////////
/////////



var _gridstr_scale_dupli_list = function(item_to_duplicate, getNumber, isStr){
	retvar = [];
	getNumber= getNumber-1;
	for(var i=0;i<=getNumber; i+=1){ retvar[i] = item_to_duplicate;}
	if(isStr){ return retvar.join("");} 
	return retvar; }
var _gridstr_scale_list_or_str = function( l, s){ //l = list, s = size
	len = l.length;
	is_a_str = (typeof l == 'string');

	if( s == 0){ return [];}
	if(s<0){ s = s*-1;
		if(is_a_str){ 
			l = l.split("").reverse().join(""); 
		}else{ l = l.reverse();}  }
	if(len ==0){ return _gridstr_scale_dupli_list(" ", s, is_a_str); }
	if(len ==1){ return _gridstr_scale_dupli_list(l[0], s, is_a_str);}
	if(len ==2){ return _gridstr_scale_dupli_list(l[0], Math.floor(s/2)+s%2, is_a_str).concat( _gridstr_scale_dupli_list(l[1], Math.floor(s/2), is_a_str));}

	outblock = []; 
	
	//original, modded 6/17/2025:
	//if(s< len){  half = s/2; 
	if(s< len){  half = Math.floor(s/2); 	
		if( s ==1){  return l.slice(0,1); }
		return l.slice(0, half).concat( l.slice(half-s ));
	}else{ 
		midpoint = Math.floor(len/2); 
		return  l.slice(0, midpoint).concat(
			 _gridstr_scale_dupli_list(l[midpoint], s- len, is_a_str)).concat( 
			  l.slice( midpoint - len ));  }
}
gridstr_scale =function(textblock, size_x, size_y){
	lines = _gridstr_scale_list_or_str( textblock.split("\n"), size_y);
	len2 = lines.length + 0;

     	outlines = [];
     	for(var i =0; i< len2;i+=1){
	   outlines[i] = _gridstr_scale_list_or_str( lines[i], size_x); }
	return outlines.join("\n");
}

/////////////////////////////////////////
//////////////////////////////////////////////
///////////////////////////////////////////////////

var gridstr_scale_nearest_neighbor = function(textblock, size_x, size_y){
	var reverse_x = false; 
	if(size_x < 0){ size_x = -size_x; reverse_x= true;}
	var reverse_y = false; 
	if(size_y < 0){ size_y = -size_y; reverse_y= true;}

	if(textblock.length ==0){ return "";}
	var txt = textblock.split("\n");
	
	var len = txt.length;
	var out = [];
	var y_txt_loc;
	var Y_TXT_COEFF = txt.length/ size_y;
	var X_TXT_COEFF = 0;
	for(var i_y =0; i_y< size_y; i_y +=1){
		out[i_y] = []
		y_txt_loc = Math.floor(i_y* Y_TXT_COEFF);
		X_TXT_COEFF = txt[y_txt_loc ].length/size_x;
		for(var i_x =0; i_x< size_x; i_x +=1){
			out[i_y][i_x] = txt[y_txt_loc ][
				Math.floor(i_x * X_TXT_COEFF)];
		}
     		if(reverse_x){ 	out[i_y] = out[i_y].reverse().join("");
     		}else{ out[i_y] = out[i_y].join(""); }
	}
     	if(reverse_y){ 	return out.reverse().join("\n");
     	}else{ return out.join("\n"); }
	
}


//gonna have this seperate

var find_char_txtgrid = function(txtGrid, getchar){
	var x_y_locs = []; var len = txtGrid.length;
	var i_x = 0; var i_y = 0;
	for(var i =0; i<len; i+=1){
		if( txtGrid[i] == '\n'){ i_x = 0; i_y +=1;
		}else{ if( txtGrid[i] == getchar ){
				x_y_locs[x_y_locs.length] = [i_x, i_y];}
			i_x +=1; }
     	}return x_y_locs; }
	
    //update_start_game();
// first, functs should be declaired like this, 
// second: file_data_eval is ran upon loading 
// this JS file (to get around async problems.);





/*
function set_textblock_x(textBlock, size_x, size_y){
	txt = txt.split("\n");
	//scaling y (  x will be below )
	len = txt.length;
	if( size_y <=1 ){  };
	}else if(size_y < txt.length){ 
		half = scale_y/2;
		txt = txt.slice(0,txt.length*half).concat(
				txt.slice(-txt.length*half)	); }
	}else{
		half = txt.length/2;

		txt = txt.slice(0, half).concat(
			_gridstr_scale_dupli_list(tmp_chars_to_add,
			  	tmp_list_to_add).join("")).concat(
			txt.slice( half));
	}
	
	//scaling x (  y will be above )
	outblock = []; len = txt.length;
	if( size_y <=1 ){  };
	}else if(size_y< txt[0].length){ 
		for(i=0; i< len; i+=1){ half = scale_x/2;
			if(half < txt[i].length){
			 outblock[i]=
			  txt[0].slice(0, (txt[0].length*half));
			}else{
			 outblock[i]=
			  txt[0].slice(0, (txt[0].length*half))+
			  txt[0].slice( (txt[0].length*half)); }}
	}else{ 
		for(i=0; i< len; i+=1){ 
			tmp_chars_to_add = txt[0].length*(scale_x-1);
			outblock[i]=
			  txt[0].slice(0, (txt[0].length/2))+
			  _gridstr_scale_dupli_list(txt[tmp_chars_to_add],
			  	tmp_chars_to_add).join("") + 
			  txt[0].slice( (txt[0].length/2)); }	
	}
}
*/

