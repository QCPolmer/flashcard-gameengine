echo  \`" > $null <# \" >NUL  " >/dev/null <<EOF \" 
:: modified https://github.com/llamasoft/polyshell
:: BAT/CMD (windows)
cd _utilitys/api_creator
m.cmd
cd ../../

GOTO :eof
#> 
# ===== PowerShell Script Begin =====
echo "... but also a PowerShell script!"
# ====== PowerShell Script End ======
exit
EOF
# bash script (sh)
cd _utilitys/api_creator
sh m.cmd
cd ../../
