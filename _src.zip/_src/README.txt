
///////////////////
//// WARNING: 
/////////////////////////
////		This engine is here mostly as a personal-backup,
////			SHOULD BE CONSIDERED PRE-ALPHA
/////	   AND PROBABLY NOT ACTIVELY DEVELOPED AT THIS TIME!!!
/////		(also, sorry about spelling errors, janky coding style,
/////			 and lack of real documentation) 
///////////////////////////
///////////////////////////
///////////////////////////
/////	PROBABLY BEST TO -NOT- USE THIS ENGINE
////////////////////////////
///////////////////////////

The idea of the engine was rapid-prototyping 
	and allow for use as teaching/training machine games. 

Engine was going to be made in 2 weeks, took 6 years+. 

As it stands, it has no sound, text only, but runs in 
	browser and windows or linux terminal 
	(uses duktape js-engine with TCC (tiny c compiler)
	-- the lack of sound/graphics was a feature:
		I didn't want anything that would slow development. 

Engine requires TCC (tiny c compiler) installed to compile/run
	(except the html-versions, which require TCC to create a 
		stand-alone bundle, but are testable without it.) 
	-- once TCC and system specific libraries are installed, 
		click on 'm.cmd' or 'm_compile.cmd' in any
		z_example files, 
		-- these 'm.cmd/m_compile.cmd' run on both windows and 
			linux. 
		-- 'm.cmd' test runs, 
		-- 'm_compile.cmd' bundles and generates an executable. 
			(bundled files should be JS and next to the 
				'm.cmd' file)
	-- there is no 'make' or other build system beyond the source
		files themselves:
		the 'm.cmd'/'m_compile.cmd' look for the 
		files above them in the source tree,
		so easiest method is to copy a file from 'z_examples'
		-- can also make a new folder in the main source directory

'dkjs' in 'z_examples' is a toy-interpreter that contains an experimental
	level editor (the 'level editor' files copied from 
	the '_level_editor' file in 'z_examples'
	-- best to compile and register the dkjs file on system, or drop in 
		the file running it in. 
		-- run level editor with '-le' in command line 
	-- only runs level editor in folders with files like the 
		ones in 'z_examples' (most of them)
	-- NO PROMISES LEVEL EDITOR WILL WORK AT ALL

AI-use: some algorithms/low level stuff was made by asking 
	various LLMs how to do certain things 
	(finding the correct escape sequence in terminal, for instance,
		is like finding a needle in a haystack without LLMs) 

----------------------------
--- IF YOU STILL WANT TO CHECK OUT ENGINE:
--------------------------------------------
-- Don't, it's probably not worth it
-- Find a better engine that is better documented, use that instead
-- Install 'TCC' (tiny c compiler)
-- Go to the z_example files 
-- click 'm.cmd' to test a file, 'm_compile.cmd' to generate a executable
-- click on 'm.html' to run browser version. 
-- the '3d' example is raycasting(think the game 'doom') 
	and experimental, most example
	files don't have the required 3d-js file imported in m.js. 
	Best to avoid using the '3d' stuff. 








