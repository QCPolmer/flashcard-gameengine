
const char * one_js_embeded_file(){
return
//INJECT_C_CODE_FROM_FILE_HERE//

""
//INJECT_C_CODE_FROM_FILE_HERE//
;
};

#if defined(DUK_VERSION)
static duk_ret_t js_port_duktape_one_js_embeded_file(duk_context *ctx) {
	duk_push_string(ctx, (char * ) one_js_embeded_file());
	return 1;  /* one return value */ 
}

void one_js_embeded_file_duktape_port_settup( duk_context *ctx){
	duk_push_c_function(ctx, js_port_duktape_one_js_embeded_file, 0);
	duk_put_global_string(ctx, "one_js_embeded_file");
}
#endif 
