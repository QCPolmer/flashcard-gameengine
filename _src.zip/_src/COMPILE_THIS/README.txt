Generally, this file will not be used, the game files can compile from 
the game files themselves.

(or a portable INTERPRETER executable)


DO NOT alter the generated _src file's tree structure for COMPILE_THIS,
m.cmd cd-s into it(even with the portable-interpreter),
so it's kindof required. 
(AND the web-html version requires it as well.)

-------------------------------------------
------------------------
EDIT: (7/20/2025):
 ONCE A GAME HAS BEEN COMPILED ON -ANY- SYSTEM:
'one_js_embeded_file.c' (no NOT delete, build system needs it))
will have the js data in it: can compile one.c directly.
method in _utilities. (its literally compiling duktape and one.c)

TODO: settup a better stand alone js-interpreter. 
current one looks like single file js loading & still uses embedded js.
