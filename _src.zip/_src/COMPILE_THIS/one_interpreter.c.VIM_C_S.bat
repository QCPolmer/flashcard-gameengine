tcc -run one_interpreter.c
