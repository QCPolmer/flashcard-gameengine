#define RUN_WITHOUT_EMBEDED_JS 1

#include "one.c"

