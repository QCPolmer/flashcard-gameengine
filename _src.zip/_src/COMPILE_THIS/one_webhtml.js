function fullscreenToggle_for_button(getElement, setScaleHeight_css){
	if (!window.screenTop &&!window.screenY){document.exitFullscreen();
	}else{ getElement.requestFullscreen(); }}
function hide_show_elements(getElementId){
	var tmpElem=document.getElementById(getElementId); 
	if(tmpElem.style.display.indexOf('none')!=-1){
	tmpElem.style.display='block';}else{tmpElem.style.display='none';}}

// loading files, 
// LOAD_1_core_lang_optimized/file.js should be loaded FIRST!!!
async function file_data_eval(){ //runs this var upon loading
await file_load_js( file_js_cd(), 
	"../LOAD_1_core_lang_optimized/gridstr.js");
await file_load_js( file_js_cd(), 
	"../LOAD_1_core_lang_optimized/gridstr_scale.js");
await file_load_js( file_js_cd(), 
	"../LOAD_1_core_lang_optimized/draw.js");
await file_load_js( file_js_cd(), 
	"../LOAD_1_core_lang_optimized/sketch.js");
await file_load_js( file_js_cd(), 
	"../LOAD_1_core_lang_optimized/sketch_3d_CORE.js");
await file_load_js( file_js_cd(), 
	"../LOAD_2_core_js/controller.js");
await file_load_js( file_js_cd(), 
	"../LOAD_1_core_lang_optimized/update_html_port.js");
await file_load_js( file_js_cd(), 
	"../LOAD_1_core_lang_optimized/rmloaded_batch_n_collisions.js")
await file_load_js( file_js_cd(), 
	"../LOAD_1_core_lang_optimized/sketch_lines.js");
await file_load_js( file_js_cd(), 
	"../LOAD_1_core_lang_optimized/progen_CORE.js");
await file_load_js( file_js_cd(),
	"../LOAD_1_core_lang_optimized/ml_CORE.js");
await file_load_js( file_js_cd(),
	"../LOAD_1_core_lang_optimized/touchscreen_HTML_ONLY.js")

document.onkeydown = function(k){ 
    k.preventDefault();
    for(i=0;i<controllers.length;i+=1){ 
      controller_interpreter(controllers[i], k.key, "DOWN"); } }
document.onkeyup = function(k){ 
    k.preventDefault(); 
    for(i=0;i<controllers.length;i+=1){ 
        controller_interpreter(controllers[i], k.key, "UP");
	}	}






////////////////////////////////////////////////////
//////////////////ADDING TOUCHPAD BELOW!
/////////////////////////////////////////////////////////
////////////////////////////////////////
//touchscreen controller handler
var touchscreen_callback_prev_pressed_keys={};
function touchscreen_callbacks_for_my_custom_gamepad(getGamepadPressedList){
    
    for(var i=0;i<controllers.length;i+=1){ 
	if(getGamepadPressedList.length != 0){
	   for(var j=0; j< getGamepadPressedList.length; j+=1){
		//gotta itterate over keypresses,it's a list!
		for(var k=0; k< getGamepadPressedList[j].length; k+=1){
		  controller_interpreter(
		   controllers[i], getGamepadPressedList[j][k],"DOWN");}}}
	// prev_key_presses
	for(var j=0;j<touchscreen_callback_prev_pressed_keys.length;j+=1){
		//gotta itterate over keypresses, it's a list!
		if(-1 == getGamepadPressedList.indexOf(
			touchscreen_callback_prev_pressed_keys[j])){
		  for(var k=0; k< touchscreen_callback_prev_pressed_keys[j]
				.length; k+=1){
		    controller_interpreter( controllers[i], 
		     touchscreen_callback_prev_pressed_keys[j][k], "UP");}}}
    }	
    touchscreen_callback_prev_pressed_keys = 
		getGamepadPressedList.concat();
}


function fullscreenToggle_for_button(){
	//checking if in fullscreen, likely not cross browser
	if (!window.screenTop && !window.screenY) {
		document.exitFullscreen();
	}else{ document.documentElement.requestFullscreen(); }}

//adding touchpad:
var tmpdiv = document.createElement('div');
tmpdiv.innerHTML =`


<div id="touchscreen_hide_show_div" >

<table style="width:100%; border: 1px solid black;">
<tr><td>

<table id="pad_1_div" style="float: left;">
<tr>
	<td><button id="up_l_div">-U/L-</button></td>
	<td><button id="up_div">-UP---</button></td>
	<td><button id="up_r_div">-U/R-</button></td>
</tr>
<tr>
	<td><button id="l_div">-LEFT-</button></td>
	<td><button id="center_div">------</button></td>
	<td><button id="r_div">-RIGHT-</button></td>
</tr>
<tr>
	<td><button id="down_l_div">-D/L--</button></td>
	<td><button id="down_div">-DOWN-</button></td>
	<td><button id="down_r_div">-D/R--</button></td>
</tr>
</table>
</td><td>

<table id="pad_2_div" style="float: right;">
<tr>
	<td><button id="esckey_div">---ESC--</button></td>
	<td><button id="____div">--------</button></td>
	<td><button id="enterkey_div">--ENTER-</button></td>
</tr>
<tr>
	<td><button id="aKey_div">---A---</button></td>
	<td><button id="sKey_div">---S---</button></td>
	<td><button id="dKey_div">---D---</button></td>
</tr>
<tr>
	<td><button id="zKey_div">---z---</button></td>
	<td><button id="xKey_div">---x---</button></td>
	<td><button id="cKey_div">---c---</button></td>
</tr>
</table>

</td></tr>
</table>

<!-- this is basically pagentry: the button just changes focus, input box is for tricking page to show keyboard, but can take no text! -->
<input type="text" placeholder="show keyboard(touchscreen)" maxlength="1" id="showkeys_div" onblur="document.getElementById('showkeys_div').value='';" />
<button onclick="document.getElementById('showkeys_div').blur()"> hide keyboard(touchscreen) </button>

</div>
<br>
<br>

<br><br>


`.trim();

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

// the list as key-values below represents simulated key presses
var myTouchscreenElements =  {  "pad_1_div":[""],
  "up_r_div":["ArrowUp","ArrowRight"], "up_div":["ArrowUp"],  "up_l_div":["ArrowUp","ArrowLeft"],
   "r_div":["ArrowRight"], "center_div":["CENTER"],  "l_div":["ArrowLeft"],  
  "down_r_div":["ArrowDown","ArrowRight"], "down_div":["ArrowDown"],  
		"down_l_div":["ArrowDown","ArrowLeft"],

      "enterkey_div":["Enter"],"____div":[""], "esckey_div":["Escape"],
  "aKey_div":["a"], "sKey_div":["s"],  "dKey_div":["d"],
   "zKey_div":["z"], "xKey_div":["x"],  "cKey_div":["c"]
};


if( document.getElementById("_draw_canvas_onscreen_ctrls") != null){
  document.getElementById("_draw_canvas_onscreen_ctrls").append(tmpdiv);

  touchscreen_SETTUP( myTouchscreenElements, 
	touchscreen_callbacks_for_my_custom_gamepad);
}

}; 


