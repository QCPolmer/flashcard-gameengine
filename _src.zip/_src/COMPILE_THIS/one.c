#include <stdio.h>
#include <string.h>

#ifdef __WATCOMC__
#include <math.h>
float roundf(float x){
   return x >= 0.0f ? floor(x + 0.5f) : ceil(x - 0.5f); }
#endif


// for newer versions of linux c compiler
#ifdef __linux__
#include <sys/ioctl.h>
#endif

//for dos, PRECOMPILE DUKTAPE!!! (DJGPP IS FUCKING SLOW!!!)
//needs to be first, or duktape specific code won't load from libs
#include "../___duktape_src_ONCE_COMPILED_CAN_OMIT/duktape.h"
//#include "dirent.h" <--- Included with 'file_dir', found in COMPILE dir

#include "../LOAD_1_core_lang_optimized/gridstr.c"
#include "../LOAD_1_core_lang_optimized/gridstr_scale.c"
#include "../LOAD_1_core_lang_optimized/file.c"
#include "../LOAD_1_core_lang_optimized/file_dir.c"

#include "../LOAD_1_core_lang_optimized/draw.c"
//sketch requires a startup and terminate function to be launched, 
//	search 'sketch' and you'll find them in main function below. 
#include "../LOAD_1_core_lang_optimized/sketch.c"

#include "../LOAD_1_core_lang_optimized/update_os_specific_port.c"

#include "../LOAD_1_core_lang_optimized/rmloaded_batch_n_collisions.c"

#define CONTROLLER_SCRIPT_DIR "../../_src/LOAD_2_core_js/"
#define CONTROLLER_SCRIPT "controller.js"


#include "../LOAD_1_core_lang_optimized/sketch_3d_CORE.c"

#include "../LOAD_1_core_lang_optimized/sketch_lines.c"

#include "../LOAD_1_core_lang_optimized/progen_CORE.c"

#include "../LOAD_1_core_lang_optimized/ml_CORE.c"

#if defined(RUN_WITHOUT_EMBEDED_JS)
#include "one_js_embeded_file_BLANK.c"
#else
#include "one_js_embeded_file.c"
#endif


// can include 'duktape.c' during compilation to not need the dll.
// It compiles faster without doing that, though. 

int main(int argc, char **argv ){ //argc = numb of args, argv= numb args


	char tmpChar[10000];
	char tmpDir[1000] = "";
	
	// original file to run, should run it via embeded as well
	sprintf(tmpDir, "%s", "m.js");
	
	int tmpFile_start_of_argv_for_js = 2;
	if(argc >2){ // ARGV 1 IS THE NAME OF PROGRAM!!!
		if (0 == strcmp(argv[1], "-run_js")){
			sprintf(tmpDir, "%s", argv[2] );
		}	}
	
	sprintf(tmpChar, 
	   

	  "file_load_js(file_js_cd()+'" CONTROLLER_SCRIPT_DIR "', '" CONTROLLER_SCRIPT "');"  
		
	  "file_load_js(file_js_cd(), '%s');"
	  ,
		tmpDir );
	
	///////////////////////////////
	///////////////// Running actual code
	////////////////////////////////////////////////////
	duk_context *ctx = duk_create_heap_default();
	//'BLANK' file for interpreter:
	one_js_embeded_file_duktape_port_settup(ctx);
	//loading modules:
	file_duktape_port_settup(ctx, 
			argc, argv );
	file_dir_duktape_port_settup(ctx);
	gridstr_duktape_port_settup(ctx);
	gridstr_scale_duktape_port_settup(ctx);
	draw_duktape_port_settup(ctx);
	sketch_duktape_port_settup(ctx);
	progen_CORE_duktape_port_settup(ctx);
	ml_CORE_duktape_port_settup(ctx);
	sketch_3d_CORE_duktape_port_settup(ctx);
	

	update_duktape_port_settup(ctx);
	
	rmloaded_batch_n_collisions_duktape_port_settup(ctx);

	sketch_line_duktape_port_settup(ctx);

	duk_push_string(ctx, tmpChar);
	duk_eval_noresult(ctx);

	duk_destroy_heap(ctx);
	
	// this is to remove a malloc-ed variable
	sketch_duktape_port_cleanup();
	
	//printf("\n\n\n\n\n test \n\n\n\n\n");
	return 0; };
