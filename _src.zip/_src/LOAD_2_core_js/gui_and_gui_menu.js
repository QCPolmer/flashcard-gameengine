/////////////////////////////////////
/////////////////////////////////////
////// GUI_MENU /////////////////////
////////////////////////////////////
// NOTE: clunky, but leave AS IS (a lot of logic here)
// 	-- see functions and data-type (at bottom!)
// 	-- shouldn't be particularly bad to config/use
/////////////////////////////////////
/////////////////////////////////////
/////////////////////////////////////
/////////////////////////////////////
var BEHAVE_GUI_DISPLAY_TEXT__KEYBOARD_CMDS = 
	{ EXIT:["ESCAPE"], //NOT SURE IF SET, look into it.  
	 BACK:["LEFT","UP"], NEXT:["DOWN","RIGHT","ENTER"]};

//used internally, not generally used beyond gui_menu
function gui_menu_autocomp(c, autocomp_for_EVERY_word_individually,
	autocomp_show_before_typed,  autocomp_one_word_at_time ){
// This is a helper funciton, USE GUI_MENU OR GUI_MENU_BLOCKING
		if(controllers[0].pressed[0]== "ESCAPE"){return -1; }
		if(controllers[0].getch == "Backspace" ){
			c.input_box_text = c.input_box_text.substr(0,c.input_box_text.length-1);}
		//delete everything with left arrow
	//	EDIT: This was a bad idea: LEFT tends to be bound to a 
	//		key like 'e' 
		//if(controllers[0].pressed[0] == "LEFT" ){
	//		c.input_box_text = "";}
		//file_log(controllers[0].getch +  "-" + c.input_box_text);
		if((controllers[0].getch == "Tab"  
			// ||	controllers[0].pressed[0] == "RIGHT"
			)	&& 
			c.cmds_list_autocomp.length!=0){
				if(autocomp_for_EVERY_word_individually){
				   c.input_box_text = (c.input_box_text.trim().split(" ")
					.slice(0,-1).join(" ") + " "
					+ c.cmds_list_autocomp[0]).trim();
				}else{
					c.input_box_text = c.cmds_list_autocomp[0];}}
		if(controllers[0].pressed[0]== "ENTER"){
			controllers_clear_pressed();
			if(c.return_text_not_index){return c.input_box_text.trim();} 
			if(c.cmds_list.indexOf( c.input_box_text.trim())!=-1){
				return  c.cmds_list.indexOf(c.input_box_text.trim());
			}else{ return -1;} } 
		c.input_box_text += controllers[0].getch_chars_only;
		if(c.input_box_text.trim() != c.input_box_text){ 
			c.input_box_text=c.input_box_text.trim() + " ";}
		if(c.input_box_text.trim() == ""){ 
			c.input_box_text=c.input_box_text.trim();}
		
		//autcomp
		if(controllers[0].getch != "" || c._first_turn){
			// pulling single words if needed
			c._first_turn = false; 
			c.cmds_list_autocomp = [];
			if( ( c.input_box_text.trim() !="" || 
				autocomp_show_before_typed ) &&
				c.input_box_text[
					c.input_box_text.length-1] !=" "
				 ){
			  if(autocomp_one_word_at_time == true && 
					!autocomp_for_EVERY_word_individually){
				len= c.input_box_text.split(" ").length;	
				for(var i=0; i< c.cmds_list.length; i+=1){
					if(c.cmds_list_autocomp.indexOf(
					    c.cmds_list[i].split(" ")
					    .slice(0,len).join(" ")) == -1){
					c.cmds_list_autocomp.push( 
						c.cmds_list[i].split(" ")
						.slice(0,len).join(" "));
					}
			  }}else{ c.cmds_list_autocomp = c.cmds_list.concat();}
			    for(var i=c.cmds_list_autocomp.length-1; 
				   i>=0; i-=1){
			    if(!autocomp_for_EVERY_word_individually){
			    if(c.cmds_list_autocomp[i].indexOf(
				    c.input_box_text)!=0){ //.trim() 
					c.cmds_list_autocomp.splice(i,1);
			    }}else{ 
				    if(c.cmds_list_autocomp[i].indexOf(
					 c.input_box_text.split(" ").slice(-1)
					    [0].trim())==-1){
					 c.cmds_list_autocomp.splice(i,1);
				}
			   }}
		} } 
		c.menu_listdisp  = c.cmds_list_autocomp.join(
			c.menu_list_divider);
		return null;
}



//used internally, not generally used beyond gui_menu
function gui_menu_list(c, split_list_menu_into_words){//config
// This is a helper funciton, USE GUI_MENU OR GUI_MENU_BLOCKING
		
	c.menu_listdisp ="";
	c.menu_listdisp_asList =[];
	  //splitting into words, and running for each word
		// (If needed)
 	  if(c.cur_input_words == null){ c.cur_input_words = "";	}
	  //below is for testing CAN DELETE
	  //c.cmds_list="1234567890abcdefghijak".split("");
	  if( c.cmds_list_CAUGHT == null){ 
		  c.cmds_list_CAUGHT = c.cmds_list.concat(); }
	  for(var i=0; i< c.cmds_list_CAUGHT.length; i+=1){
		c.cmds_list_CAUGHT[i] = c.cmds_list_CAUGHT[i].trim();}
	
	  // this block recursively calls this function 
		// until it gets a full word list.
	  if(split_list_menu_into_words == true){
	       var keys = {}; 
	       var len_words = c.cur_input_words.split(" ").length;
		    if(c.cur_input_words ==""){ len_words=0;}
		for(var i =0; i< c.cmds_list_CAUGHT.length; 
			i+=1){

			if(c.cmds_list_CAUGHT[i].split(" ").length 
				> len_words){
			  if(c.cmds_list_CAUGHT[i].
				split(" ").slice(0, len_words+1)
				.join(" ") == 
				c.cmds_list_CAUGHT[i] && (
					len_words ==0 ||
					c.cmds_list_CAUGHT[i].indexOf(
					 c.cur_input_words) == 0
				)){
				
				keys[c.cmds_list_CAUGHT[i]
				 +" (!)"] = 1;
			  }else{
			    if( c.cmds_list_CAUGHT[i].indexOf(
				c.cur_input_words) == 0 || 
				len_words == 0){
			    keys[c.cmds_list_CAUGHT[i].
				split(" ").slice(0,len_words+1)
				.join(" ")] = 1; }} } }

		    	c.cmds_list_MENU_SAVED = c.cmds_list;
		        c.cmds_list = Object.keys(keys);
		        var tmpWords= 
			  	gui_menu_list(c, false); //recusive
			c.cmds_list = c.cmds_list_MENU_SAVED;
			
		    	if(tmpWords == null){ // no input, coninue loop
				return null;
			}
			 
	
			//var tmpWords= await rmloaded_menu_disptext( 
			 //  Object.keys(keys),false);
			// esc pressed
			if(tmpWords == -1){ 
				if(c.cur_input_words == ""){
					c.cur_input_words = null;
					c.cmds_list_CAUGHT = null;
					return -1;
				}else{ //remove 1 word from end
					c.cur_input_words = 
					 c.cur_input_words.split(" ")
					 .slice(0,-1).join(" ");
				}
			}else{ 
			    if(tmpWords.split(" ").length 
				> len_words+1){
					c.cur_input_words = null;
					c.cmds_list_CAUGHT = null;
				return tmpWords.split(" ")
					.slice(0,-1).join(" ");
			    }
			    c.cur_input_words = tmpWords;}
			
			controllers_clear_pressed();
			return null;
	    }
	   
		
		// TODO: set hint_text to "LEFT MORE, RIGHT, BACK"
		//  to ONLY show those if there is space. 
		
	
		var s = c.menu_list_seperator;
		var d = c.menu_list_divider;
		for(var i=0; i<c.menu_chars.length; i+=1){
			var tmpS = "";
			if(c.item_selected== i){
				tmpS += c.menu_pointer; 
			}else{ tmpS += c.menu_pointer_empty; }
			if(i+c.offset >=c.cmds_list.length){
				break;};
			tmpS += c.menu_chars[i] 
				+ s + c.cmds_list[i+c.offset]; 
				//+ s + c.cmds_list[i+c.offset] + d; 
			c.menu_listdisp_asList.push(tmpS);
		}
		c.menu_listdisp = c.menu_listdisp_asList.join(d);
		// go up or down menu (UP or DOWN keys)
			//
		
		// for a-n (or whatever menu_chars);
		if( c.menu_chars.indexOf(controllers[0].getch) !=-1 
				&& controllers[0].getch != ""){
			var ret_i = c.offset + 
			 	c.menu_chars.indexOf(controllers[0].getch);
			if( c.cmds_list[ ret_i] != null){
			c.offset = 0; c.item_selected = 0;
			controllers_clear_pressed();
			return c.cmds_list[ret_i];}} 
		// can go backwards, check for it
			// LEFT to go back
		if(controllers[0].pressed[0]== "LEFT"){
				c.item_selected = 0;
				c.offset -= c.menu_chars.length;
			if(c.offset<0){c.offset=0;};	}
		
		// can go forwards,check for it
			// RIGHT to go forwards
		//check for press down:
		if(controllers[0].pressed[0]== "RIGHT"){
			c.item_selected = 0;
			c.offset += c.menu_chars.length;
			if(c.cmds_list[c.offset] ==null){//out of list
				c.offset -= c.menu_chars.length; }
		}
		
		if(controllers[0].pressed[0]== "DOWN"){
				c.item_selected += 1;
				controllers_clear_pressed();
			if(c.cmds_list.length-c.offset<=c.item_selected
			  || c.menu_chars.length <=c.item_selected ){
				c.item_selected=0;};	}
		if(controllers[0].pressed[0]== "UP"){
				c.item_selected -= 1;
				controllers_clear_pressed();
		     if(c.item_selected<0){
			while(c.cmds_list.length-c.offset>c.item_selected
			  && c.menu_chars.length >c.item_selected){
					c.item_selected +=1; }
			c.item_selected-=1;};	}
		if(controllers[0].pressed[0]== "ENTER"){
			var ret_i = c.item_selected + c.offset;
			c.offset = 0; c.item_selected = 0;	
			controllers_clear_pressed();
			return c.cmds_list[ret_i];}
		if(controllers[0].pressed[0]== "ESCAPE"){
			c.offset = 0; c.item_selected = 0;
			controllers_clear_pressed();
			return -1; }
		
		//mouse controls!
		//NOTE: basically reading the screen and checking 
		// for a 'hit' on the menu, so menu MUST
		// be fully visible AND duplicate items on 
		// screen COULD hit at once 
		// 	(the duplicate thing is not really an issue,
		// 		as menu items are bound to keypresses, too)
		if(controller_mouse_down){
		   var tmpCanvas = draw_canvas_get();
		   for(var i=0; i<c.menu_listdisp_asList.length;i+=1){
			var tmpLines=c.menu_listdisp_asList[i].split("\n");
		   	var tmpWidth = draw_canvas_get_width();
			var tmpLookingLine_PRE = Math.floor(
				   tmpCanvas.indexOf(tmpLines[0])/
					(tmpWidth+1));
			for(var i_l=0; i_l< tmpLines.length; i_l+=1){
				//adding 1 to 1st 'choice' line, as that
				//one is most likely unique, so 
				//this should just check subsiquent lines 
				var tmpLookingLine =tmpLookingLine_PRE+i_l;
				//checking y:
				if(tmpLookingLine == controller_mouse_y){
				//checking x:
				  var tmpXLow = -(tmpLookingLine*
					(tmpWidth+1)) + 
				      tmpCanvas.indexOf(tmpLines[i_l]);
				  
				  //still checking x...:
				  if(controller_mouse_x >= tmpXLow  &&
					controller_mouse_x < 
					   tmpXLow + tmpLines[i_l].length){
				
					controller_mouse_down = 0;
					c.offset = 0; c.item_selected = 0;
					controllers_clear_pressed();
			   		return c.cmds_list[i];
				  }
				}
			}
		   }
		} //	}		

		return null;
		
}


//API_TAG//
// while(void null == (gui_return = gui_menu(params))){ }
async function gui_menu_blocking(getDescribedText, 
		get_n, //getGui_Menu_Object_NAME__SEE_EXAMPLES_FOR_DATA, 
		getCmds_list, 	//options
		getHints_text_on_toggle_OPTIONAL,
		getReturn_AFTER_anim_done_OPTIONAL,
		bg_OPTIONAL){ //underlay_bg_gridstr_canuse__rmloaded_last_draw_OPTIONAL){ 		
// returns the returned command OR -1 if esc was pressed
//API_TAG//

	controllers_clear_pressed();
	if(bg_OPTIONAL!=null){ draw(bg_OPTIONAL, 0,0, "	" );}

	//resetting menu:
	await gui_menu( null, get_n, null,  null, null, 1); 

	var tmpRetVar = null; var i=0;
	while( void null == (tmpRetVar =  await gui_menu( 
	   getDescribedText, get_n,  
	   getCmds_list, getHints_text_on_toggle_OPTIONAL,
	   getReturn_AFTER_anim_done_OPTIONAL )) ){
		await update();
		if(bg_OPTIONAL !=null){ draw(bg_OPTIONAL,0,0,"	" ); }
	};
	controllers_clear_pressed();
	return tmpRetVar; 
}

//API_TAG//
// below tests if gui DONE and sets it to gui_return:
// if(void null == (gui_return = async gui_menu(params))){ }
async function gui_menu(
	getDescribedText, 
	getGui_Menu_Object_NAME__SEE_EXAMPLES_FOR_DATA,  
		getCmds_N_toggle_OPTIONAL, 
	getHints_text_on_toggle_OPTIONAL,
	getReturn_AFTER_anim_done_OPTIONAL, //otherwise, returns as 
			// SOON as input gotten. 
	getReset_ONLY__DONT_RUN){
	//ConfigName, (draw OR rmloaded_draw_overlay FOR IN GAME),  CmdList_OPTIONAL
// 1 size draw and returns results, AND toggles off until reset 
	// (getCmds_N_toggle not being 'null' IS reset! )
	// RETURNS: -1 or param for done, null for not done
//	
//	WARNING: this is non blocking, see anims_menu_bocking for 
	//	an example of how to run. via a behavior or 
	//	whatever
//API_TAG//
	

	var o = ml_catch_globalNamespace[ 
		getGui_Menu_Object_NAME__SEE_EXAMPLES_FOR_DATA ];
	
 
	if(getReset_ONLY__DONT_RUN){ 
		o._menu_vars_initialized_or_reset_if_null = void null; 
		return;}

	o.described_text = getDescribedText;

	//file_log(o.anim_i);
	if( o._menu_vars_initialized_or_reset_if_null == void null){
		var tmp_play_behave_at_funct_end_for_frame_1 =1;
		o._menu_vars_initialized_or_reset_if_null = 1;	
		
		if( o._status_n_times_ON_LAUNCH_BACKUP == void null){
		  o._status_n_times_ON_LAUNCH_BACKUP = 
		  o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS.concat(); 
		}else{ o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS = 
			o._status_n_times_ON_LAUNCH_BACKUP.concat(); }
		o._return = null;   o._first_turn = true;	
		o.item_selected = 0;  o.offset =0;
		o.cur_input_words = "";	o.cmds_list_CAUGHT = null;
		o.cmds_list_MENU_SAVED = null;
		o.cmds_list = getCmds_N_toggle_OPTIONAL; 
		o.menu_listdisp = "";
		//used for menus
		o.cmds_list_autocomp = [];
		o.offset =0; o.item_selected =0; 

		o.input_box_text =""; 
	}else{
		var tmp_play_behave_at_funct_end_for_frame_1 =0;
		await behav_mml_status( o);
		// NEED TO RUN BEHAV HERE SO SCREEN READER
		// CAN PICKUP THE MENU ON THE SCREEN ITSELF -AFTER- THIS
		// (for 1st frame, behav_mml_status runs at END of FUNCT
	}
		//_menu_type:"LIST", 
		// LIST, LIST_WORDS, AUTOCOMP, AUTOCOMP_SINGLE_WORDS
		// AUTOCOMP_WORDS
			
	

	if( o._return == void null ){ //pausing:
	  mml_status_set( 
	     o,  "ALL", 1,1, o.frame_to_PAUSE_anims_for_menu,
		null, //getstatus_mml_with_configs_list-not used of "ALL"
		o.frame_to_PAUSE_anims_for_menu ); 
	}else{ //if pressed b4 end of anim, jump to end-ish frames:
	  
	  if(o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS == void null){
		//returning once done:
		o._menu_vars_initialized_or_reset_if_null = void null;
		return o._return; } 
	  mml_status_set( 
	     o,  "ALLSETIFABOVE", 1,1, -1+o.frame_to_PAUSE_anims_for_menu,
		null, //getstatus_mml_with_configs_list-not used of "ALL"
		o.frame_to_PAUSE_anims_for_menu);
	  
	  return void null;
	}
	
	var tmp_menu_type = o._menu_type;
	if(tmp_menu_type == "LIST_WORDS"){ 
		var ret = gui_menu_list(o, true); }
	if(tmp_menu_type == "LIST" ){  var ret = gui_menu_list(o, false); }
	if( tmp_menu_type == "INPUT"){ 
		// config, autocomp_for_EVERY_word_individually,
		// autocomp_show_before_typed, autocomp_one_word_at_time 
		o.cmds_list = [];
		var ret = gui_menu_autocomp(o, false, false, false); }	
	if( tmp_menu_type == "INPUT_W_AUTOCOMP_WORDS"){ 
		var ret = gui_menu_autocomp(o, true, true, true); 	}
	if( tmp_menu_type == "INPUT_W_AUTOCOMP_WORDS_WAIT_TILL_TYPED"){ 
		var ret = gui_menu_autocomp(o, true, false, true); 	}
	if( tmp_menu_type == "AUTOCOMP"){ 
		var ret = gui_menu_autocomp(o, false, true, false ); 	}
	if( tmp_menu_type == "AUTOCOMP_WAIT_TILL_TYPED"){ 
		var ret = gui_menu_autocomp(o, false, false, false); 	}
	if( tmp_menu_type == "AUTOCOMP_SINGLE_WORDS"){ 
		var ret = gui_menu_autocomp(o, false, true, true); 	}
	if( tmp_menu_type == "AUTOCOMP_SINGLE_WORDS_WAIT_TILL_TYPED"){ 
		var ret = gui_menu_autocomp(o, false, false, true); 	}
	
	
	if( ret != null){	o._return = ret;
		if(getReturn_AFTER_anim_done_OPTIONAL){ ret = null;
		}else{
		  // and resetting: 	
		  o._menu_vars_initialized_or_reset_if_null = void null;
		  return  ret;
	}	}
	//drawing once here for no-gap in initial settup.
	if( tmp_play_behave_at_funct_end_for_frame_1 == 1){ 
		await behav_mml_status( o); }

	return void null;
}




//API_TAG//
async function gui_menu_mml_status_expaning_outline( o, otarget, track, magnitude, 
	list_cmds, rm_OPTIONAL, time_left_SATUS_STUFF_ONLY){
//API_TAG//
	
	// Can likely have hight/width 
	// settable via solid numbers OR
	// redirect to o_setFromVar (sets from var of 'o')
	
	var precent_done = _mml_status_precentDone__from_times_list(
		list_cmds.time_start_end_reverseStart_end, 
		time_left_SATUS_STUFF_ONLY );	
	
	//expanding width/height
	if(list_cmds.expanding_height){
		var draw_height = txttools_getheight(o[list_cmds.
			o_txt2DispVarName] );
	}else{ var draw_height = list_cmds.height;}
	if(list_cmds.expanding_width){
		var draw_width = txttools_getmax_width( o[list_cmds.
			o_txt2DispVarName] ); 
	}else{ var draw_width =  list_cmds.width;}
	

	var x = list_cmds.x_offset; 
	var y = list_cmds.y_offset;
	var draw_funct = ml_catch_globalNamespace[list_cmds.draw_funct];

	var txt_to_draw = o[list_cmds.o_txt2DispVarName];
	
	//getting frame number:
	if(  time_left_SATUS_STUFF_ONLY <
		list_cmds.time_start_end_reverseStart_end[2] ){
			var frame_number = 0; 
	}else{ 
	   var frame_number =  
		list_cmds.time_start_end_reverseStart_end[1] - 
			time_left_SATUS_STUFF_ONLY;	
	   if( frame_number <0){frame_number =0; }}
	
	

	y = y + (draw_height-(draw_height*precent_done))/2
	draw_height = draw_height*precent_done;	 
	if( list_cmds.text_type_chars_per_frame_NULL2hide != void null){
	   if(txt_to_draw.indexOf("\n") != -1){
		txt_to_draw = txt_to_draw.split("\n")
			.slice(0, draw_height).join("\n"); }
	   

	    txt_to_draw = txt_to_draw.slice(0, frame_number*
		list_cmds.text_type_chars_per_frame_NULL2hide  );
	}else{ txt_to_draw = ""; }

	var brdr_offst = list_cmds.outlineborder_size;
	draw_funct( 
	   gridstr_scale(list_cmds.outline,(2*brdr_offst)+draw_width, 
			(2*brdr_offst)+draw_height  ), x, y, "");
	if(txt_to_draw != ""){
	  draw_funct( 
		txt_to_draw, x + brdr_offst, y + brdr_offst, ""); }

	//caption
	var  tmpCaption = o[list_cmds.o_txt2DispVarName_caption];
	if(tmpCaption != void null && tmpCaption.length >0){
	  if(list_cmds.outline_caption == void null){
		var tmpOutline_caption = list_cmds.outline
	  }else{ var tmpOutline_caption = ""; }
	  draw_funct( gridstr_scale(list_cmds.outline_caption,
			(2*brdr_offst)+tmpCaption.length, 
			(2*brdr_offst)+1  ), x+1, y-2, "");
	  draw_funct(
	     tmpCaption, x+1 + brdr_offst, y-2 + brdr_offst,"");
	}
	
}

//uses MENU data type for objs, sets text to o.described_text, 
//	copy/duplicate obj on use (JSON.stringify, whatever)
//	sets itself to 'dead' when done(which if added to rmloaded, works)
//
// THIS IS USED INTERNALLY FOR:
// 	 gui_disp_txt_BLOCKING / gui_disp_txt__by_creating_satusObj
async function behav_gui_display_txt(o){
	// no -NOT- set anything in status_mmls (redifine cmd_list)
	// 	as this catches via concat(): it's a shallow copy!
	
	
	if( o._menu_vars_initialized_or_reset_if_null == void null){
		o._menu_vars_initialized_or_reset_if_null =1;
		if( o._status_n_times_ON_LAUNCH_BACKUP == void null){
		  o._status_n_times_ON_LAUNCH_BACKUP = 
		  o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS.concat(); 
		}else{ o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS = 
			o._status_n_times_ON_LAUNCH_BACKUP.concat(); }
 
		//this part is JUST for display txt:
		o._disp_text_key_pressed = void null;
		if( o._disp_text_list == void null){
			 o._disp_text_i = -1; // adds one next!
			 o._disp_text_list =
			  txttools_limit_width_n_make_heightlist(
				  o.menu_listdisp, 
			   o.gui_disp_txt_width, o.gui_disp_txt_height);}
		//runs every reset:
		if( (o._disp_text_i +=1) < o._disp_text_list.length){
		   o.menu_listdisp = o._disp_text_list[o._disp_text_i];
		}else{ o.dead = 1; }
	
	}
	if(o.dead == 1){return;}

	await behav_mml_status(o);
	

	var tmp_freez_at = o.frame_to_PAUSE_anims_for_menu;
	
	
	
	if( o.disp_text_keyboard_cmds_OPTIONAL != void null){
	   var tmpKeyCmds = o.disp_text_keyboard_cmds_OPTIONAL;
	   if(o._disp_text_key_pressed == void null){ //pausing:
	    if(-1 != tmpKeyCmds.BACK.indexOf( controllers[0].pressed[0])){ 
		if(o._disp_text_i > 0){o._disp_text_i-=2;} 
		o._disp_text_key_pressed =1; }
	    if(-1 != tmpKeyCmds.NEXT.indexOf( controllers[0].pressed[0])
	      || controller_mouse_down ){  //goto NEXT
		controller_mouse_down = 0;
		controllers_clear_pressed(); 
		o._disp_text_key_pressed =1;  }
	    if(-1 != tmpKeyCmds.EXIT.indexOf( controllers[0].pressed[0])){
		o._disp_text_i = o._disp_text_list.length;
			controllers_clear_pressed();  
		o._disp_text_key_pressed =1; 
	   } 
	   if(o._timeout_keypresses_is_on !=true){ //propping up time...
	     mml_status_set( o,  "ALL", 1,1, tmp_freez_at,
		null, //getstatus_mml_with_configs_list-not used of "ALL"
		tmp_freez_at); }
	 }else{ //if pressed b4 end of anim, jump to end-ish frames: 
	  
	    mml_status_set( //jumping to 'end'
	     o,  "ALLSETIFABOVE", 1,1, -1+tmp_freez_at,
		null, //getstatus_mml_with_configs_list-not used of "ALL"
		tmp_freez_at);
	} }
	

	//resetting if done, to itterate through long text:
	if(o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS == void null){
		o._menu_vars_initialized_or_reset_if_null = void null; 
		return; }
	
} 

//API_TAG//
// SETS TEXT IN OBJ TO: 
// 	SETS getTxt IN: menu_listdisp & 
// 		CAPTION: described_text,
// 	SO USESES -SAME- DATA AS GUI_MENU!!!
function gui_disp_txt__by_creating_satusObj(set_obj_x,set_obj_y,
	get_o_width_varname, get_o_height_varname, 
	getGui_Menu_Object_NAME__SEE_EXAMPLES_FOR_DATA,
			//should be able to make more.
	getTxt, 
	add_obj_to_rmloaded_OPTIONAL, txt_caption_OPTIONAL,
	 use_keys_OPTIONAL, //keyboard keys/mouse, or just timeout
	timeout_for_keypress_on_OPTIONAL
		//commands data type, can leave in Menu_obj data:
		 ){
//API_TAG//

	var o = JSON.parse(JSON.stringify( ml_catch_globalNamespace[ 
		getGui_Menu_Object_NAME__SEE_EXAMPLES_FOR_DATA ]));
		
	o.behavior = "behav_gui_display_txt";
	
	if(use_keys_OPTIONAL){
	  o.disp_text_keyboard_cmds_OPTIONAL = 
		BEHAVE_GUI_DISPLAY_TEXT__KEYBOARD_CMDS;
	  o._timeout_keypresses_is_on = timeout_for_keypress_on_OPTIONAL;
	}

	o.described_text = txt_caption_OPTIONAL;
	o.menu_listdisp = getTxt;
	o.x = set_obj_x; o.y = set_obj_y;
	o.gui_disp_txt_width = o[get_o_width_varname]; 
	o.gui_disp_txt_height = o[get_o_height_varname];
	
	if( add_obj_to_rmloaded_OPTIONAL == 1){
		rmloaded_room.objs.push(o);}
	
	return o;
}

//API_TAG//
function gui_draw_w_cam_offset(getTxt2draw, getX, getY, getBlankChar){ 
	draw( getTxt2draw,getX-_rmloaded_camera_x,
		getY-_rmloaded_camera_y,"	" ); }
//API_TAG//

//API_TAG//
async function gui_disp_txt_BLOCKING( 
	set_obj_x, set_obj_y,//<only relevent it used /w right disp
	get_o_max_width_varname, get_o_max_height_varname, 
	getGui_Menu_Object_NAME__SEE_EXAMPLES_FOR_DATA,
	getTxt, 
	bg_OPTIONAL,// background, mostly rmloaded_last_draw 
	txt_caption_OPTIONAL,
	 use_keys_OPTIONAL, //keyboard keys/mouse, or just timeout
	timeout_for_keypress_on_OPTIONAL){ 
//API_TAG//

	var tmpObj=gui_disp_txt__by_creating_satusObj( 
		set_obj_x, set_obj_y, 
		get_o_max_width_varname, get_o_max_height_varname, 
		getGui_Menu_Object_NAME__SEE_EXAMPLES_FOR_DATA,
		getTxt, false, txt_caption_OPTIONAL,
		 use_keys_OPTIONAL, timeout_for_keypress_on_OPTIONAL);
	if(bg_OPTIONAL !=null){ draw(bg_OPTIONAL,0,0,"	" ); }
	controllers_clear_pressed();
	while( tmpObj.dead != true){
	   await behav_gui_display_txt( tmpObj);
	   await update();
	   if(bg_OPTIONAL !=null){ draw(bg_OPTIONAL,0,0,"	" ); }	
	}
	controllers_clear_pressed();
}

//API_TAG//

var menu_test_o = {
   x:0, y:0, colgroup:"", graphic:"",
  // gui_disp_width/height do NOTHING, for manual input in gui_disp functs
  gui_disp_width:40, gui_disp_height:5, //so not to confuse /w MENU stuff
  //Menu specific vars SET on MENU run (redirect in _status_list...):
  input_box_text:"",
  hints_txt:"",
  described_text:"", 
  menu_listdisp:"",
  return_text_not_index:1, // FOR AUTOCOMP/INPUT MENUS
  _menu_type:"INPUT_W_AUTOCOMP_WORDS_WAIT_TILL_TYPED", // "LIST", "LIST_WORDS","INPUT", "INPUT_W_AUTOCOMP_WORDS", "INPUT_W_AUTOCOMP_WORDS_WAIT_TILL_TYPED","AUTOCOMP", "AUTOCOMP_WAIT_TILL_TYPED", "AUTOCOMP_SINGLE_WORDS",  "AUTOCOMP_SINGLE_WORDS_WAIT_TILL_TYPED"
  //menu-Configs:
  	menu_chars: "abcdefghijklmn", text_caption:"",
	menu_pointer : ">> ", menu_pointer_empty : " ",	
	menu_list_divider : "\n", menu_list_seperator: 	") ", 
  //Menu AND gui_disp_txt specific, frame to PAUSE animation:
  frame_to_PAUSE_anims_for_menu:5, 
  //for menu:
  _statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS:
   ["timed_countdown", 1, 100, 100, 
	  ["mml_status_run_multiple_status_as_substatus",
		// SHOULD mml-functs THAT -DRAW DIRECTLY- for MENUS
		// as OBJ WON'T BE ADDED TO SCENE!!!
	    {0:"mml_status_graphic_effect", "x_offset":3, "y_offset":5,
		"o_txt2DispVarName":"input_box_text", // "var2Mod":"",
		"time_start_end_reverseStart_end":[100,90, 20,10 ]},
	    {0:"mml_status_graphic_effect", "x_offset":4, "y_offset":11,
		"o_txt2DispVarName":"graphic", // "var2Mod":"",
		"time_start_end_reverseStart_end":[90,80, 20,10 ]},
	    {0:"mml_status_graphic_effect", "x_offset":5, "y_offset":12,
		"o_txt2DispVarName":"graphic", // "var2Mod":"",
		"time_start_end_reverseStart_end":[70,60, 20,10 ]},
	    //CAN CLONE BELOW VIA: Object.assign({}, src, {"new_vars":2})
	    {0:"gui_menu_mml_status_expaning_outline", "x_offset":10,"y_offset":10,
		"o_txt2DispVarName":"menu_listdisp",
			//var2get txt from //"var2Mod":"",
		"o_txt2DispVarName_caption":"described_text", //OPTIONAL
		"draw_funct":"draw", //"gui_draw_w_cam_offset"
		"width":20, "height":5,
		expanding_height:true, expanding_width:true,
		"time_start_end_reverseStart_end":[99,97, 3,0 ],
		"text_type_chars_per_frame_NULL2hide":30,
		"outlineborder_size":1, "outline":
`.--------------.
|               |
.LEFT------RIGHT>`, "outline_caption": //OPTIONAL
`.-.
| |
.-.`}
] ]
}
var menu_test_o__TEST = Object.assign({}, menu_test_o, 
{_menu_type:"LIST"})



// speeds up deep copy...
var menu_test_o__STRINGIFIED = JSON.stringify( menu_test_o);



// FULL COPY NEEDED, as gui_menu/etc. decays original status. 
var menu_test_o__TEST_DRAW_OVERLAY = Object.assign(
	JSON.parse(menu_test_o__STRINGIFIED),
{_menu_type:"LIST",
  _statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS:
   ["timed_countdown", 1, 100, 100, 
	  ["mml_status_run_multiple_status_as_substatus",
{0:"gui_menu_mml_status_expaning_outline", "x_offset":10,"y_offset":10,
		"o_txt2DispVarName":"menu_listdisp",
			//var2get txt from //"var2Mod":"",
		"o_txt2DispVarName_caption":"described_text", //OPTIONAL
		"draw_funct":"rmloaded_draw_overlay", //"gui_draw_w_cam_offset"
		"width":20, "height":5,
		expanding_height:true, //expanding_width:true,
		"time_start_end_reverseStart_end":[99,97, 3,0 ],
		"text_type_chars_per_frame_NULL2hide":30,
		"outlineborder_size":1, "outline":
`.--------------.
|               |
.LEFT------RIGHT>`, "outline_caption": //OPTIONAL
`.-.
| |
.-.`} ] ] });


// FULL COPY NEEDED, as gui_menu/etc. decays original status. 
var menu_test_o__FLASHCARDS = Object.assign( 
	JSON.parse( menu_test_o__STRINGIFIED ),
	{_menu_type:"LIST",
 _statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS:
   ["timed_countdown", 1, 100, 100, 
	  ["mml_status_run_multiple_status_as_substatus",
{0:"gui_menu_mml_status_expaning_outline", "x_offset":10,"y_offset":10,
		"o_txt2DispVarName":"menu_listdisp",
			//var2get txt from //"var2Mod":"",
		//"o_txt2DispVarName_caption":"described_text", //OPTIONAL
		"draw_funct":"draw", //"gui_draw_w_cam_offset"
		"width":20, "height":5,
		expanding_height:true, expanding_width:true,
		"time_start_end_reverseStart_end":[99,97, 3,0 ],
		"text_type_chars_per_frame_NULL2hide":30,
		"outlineborder_size":1, "outline":
`.--------------.
|               |
.LEFT------RIGHT>`, "outline_caption": //OPTIONAL
`.-.
| |
.-.`},
{0:"gui_menu_mml_status_expaning_outline", "x_offset":10,"y_offset":2,
		"o_txt2DispVarName":"described_text",
			//var2get txt from //"var2Mod":"",
		//"o_txt2DispVarName_caption":"described_text", //OPTIONAL
		"draw_funct":"draw", //"gui_draw_w_cam_offset"
		"width":20, "height":5,
		expanding_height:true, expanding_width:true,
		"time_start_end_reverseStart_end":[99,97, 3,0 ],
		"text_type_chars_per_frame_NULL2hide":30,
		"outlineborder_size":1, "outline":
`.--------------.
|               |
.LEFT------RIGHT>`, "outline_caption": //OPTIONAL
`.-.
| |
.-.`} ]] });

// FULL COPY NEEDED, as gui_menu/etc. decays original status. 
var menu_test_o__saveMenu = Object.assign( 
	JSON.parse( menu_test_o__STRINGIFIED ),
	{_menu_type:"LIST"});

// FULL COPY NEEDED, as gui_menu/etc. decays original status. 
var menu_test_o__disp_text = Object.assign( 
	JSON.parse( menu_test_o__STRINGIFIED ),
	{_menu_type:"LIST"});



//API_TAG//

