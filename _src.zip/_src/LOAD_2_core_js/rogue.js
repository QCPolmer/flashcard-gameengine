


//API_TAG//

var rogueGlobalThis = this;
// o.rogue_speed determines the relative speed o moves at:
// 	if between 1 and 0 (fractional) will move slower than
// 		other objs (that fraction of 1 per turn compared to
// 			 all else)
// 	if GREATER than 1, will have that number of turns compared to
// 		everything else!
//EDIT: can dynamically adjust an objects SPEED
//	(even in real time!) by adjusing o.rogue_speed
//		-- NOT fastest method, runs the behavior multiple 
//			times or frational times!
//AND: should be able to save MID-BATTLE and RETURN to SAME POINT!
//	(I made it so _rogue_player_running is saved and 
//		should block other obj's actions if they go before it
//		in room order!!!)
var _rogue_player_running =false;
async function rogue_behavior_PAUSE_UNTIL_DONE(o, getIsNOTPlayer_OPTIONAL){
	// COPY BELOW LINE TO FIRST LINE OF OBJS 
	// 	(or a toggle-on about there) TO PAUSE ALL OTHER 
	// 	OBJS, 1x PER 'MOVE'!!!
	//if(await rogue_behavior_PAUSE_UNTIL_DONE(o)){ return; }
	//	FOR NON-PLAYERS:
	//if(await rogue_behavior_PAUSE_UNTIL_DONE(o, true)){ return; }
	
//API_TAG//
	/////////////////////////////
	// IF NOT PLAYER (NO NEED TO RET 1 for BEHAV!!!)
	if(getIsNOTPlayer_OPTIONAL == true){
	    if(o.rogue_speed == void null ||_rogue_player_running== true){
		 return 0;}
	    
	    if(o._rogue_blocked != 1  ){ o._rogue_blocked =1; 
		}else{ 	return 0; } //early termination, 1 for 'done' 
	    
	    if(o._rogue_timer == null){ o._rogue_timer =o.rogue_speed; }
	    while( o._rogue_timer >=1 ){  o._rogue_timer -=1;
		await rogueGlobalThis[o.behavior](o);  }
	    o._rogue_timer += o.rogue_speed;
		
	    o._rogue_blocked =0;
	    return 1;
	}
	///////////////////////////////
	// IF PLAYER
 	if( o._rogue_timer != void null){
		if( o._rogue_timer < 1){ o._rogue_timer +=o.rogue_speed;
			return 1;} }
	if(o._rogue_blocked != 1  ){ o._rogue_blocked =1; 
		_rogue_player_running = true;
	}else{ 	return 0; } //early termination, 1 for 'done' 
	if(o._rogue_timer == void null){  
		if(o.rogue_speed == void null){ o.rogue_speed = 1; }
		o._rogue_timer =o.rogue_speed; }    
	
	if(o._rogue_timer >= 1){
	   if(await rogueGlobalThis[o.behavior](o) == 1 ){
		o._rogue_timer -=1;} }
	
 	if( o._rogue_timer >= 1 ){
	 rmloaded_paused = true;
	 var tmp_obj =null;
  	 if(o._rouge_caught_ignore_pause == void null){
		if(o.ignore_pause == null){ o.ignore_pause=false;}
		 o._rouge_caught_ignore_pause =  o.ignore_pause;
		o.ignore_pause = true; }  
   	}else{ //if( o._rogue_timer <0 ){  
	   o._rogue_timer +=o.rogue_speed;
	   rogue_behavior_END_ROGUE_BEHAVE_REVERSE_PAUSE_STATE(o);
	}
	_rogue_player_running = false;
	o._rogue_blocked = false;
}
//API_TAG//
function rogue_behavior_END_ROGUE_BEHAVE_REVERSE_PAUSE_STATE(o){
	//THIS IS FOR TOGGLING IN AND OUT OF THE BEHAVIOR,
	//	(The 'toggle-off', run this too!)
	//OTHERWISE, USE CODE UNDER rogue_behavior_PAUSE_OTHERS_TILL_DONE
	//	(it's in a comment)
//API_TAG//
	_rogue_is_running = false;
	rmloaded_paused = false;
	 if( o._rouge_caught_ignore_pause != void null){
		 o.ignore_pause= o._rouge_caught_ignore_pause;
		delete o._rouge_caught_ignore_pause; }  		
}
