
//progen.js = what other progen's depend on (txt/db/random/lists/etc.)

var progen_globalThis = this;
///////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
//API_TAG//
//JS version of progen_CORE
// (C has a version, this is a fallback so can easy 
//	use this library anywhere):
if(typeof progen_CORE_obj_join== "undefined"){
	function progen_CORE_obj_join(obj, obj_pull_vars_from){
		//C has a seperate version in progen_CORE.c
	//API_TAG//
		for( var key in obj_pull_vars_from){
			obj[key] = obj_pull_vars_from[key];} //}
		return obj;
	}//API_TAG//
	function progen_CORE_NOROLL_indefinite_shuffled_d_roll( 
		max_roll, index, number_of_decks){ 
		//rolls AS IF this # of decks
		//C has a seperate version in progen_CORE.c
	//API_TAG//
	index = Math.abs(index ); max_roll = max_roll* number_of_decks; 
	var random_deckdraw_number = Math.abs(Math.floor(index /max_roll));	    var strt_index = Math.abs( Math.floor( 
	   Math.sin( random_deckdraw_number ) * (max_roll-1)));
	
	//more randomness, going reverse order if divisible by 3
	if( random_deckdraw_number % 2 != 0){var i_draw = index % max_roll;
	}else{ var i_draw = max_roll-1 - (index % max_roll); }		

	var shuffles = 3+(random_deckdraw_number % 3);	
	for(var j=0; j< shuffles; j+=1){
	  //cutting deck, gives * max_roll to randomization multiplier
	  i_draw = i_draw + (random_deckdraw_number % max_roll );
	  if( i_draw >= max_roll){ i_draw -= max_roll;}	

	 i_draw +=1; //shuffling deck, counts up if %2, or down
	 if( i_draw % 2 ==0 ){ i_draw = strt_index + Math.floor(i_draw /2);
	 }else{  i_draw = strt_index - Math.floor(i_draw /2); }

	 if( i_draw < 0){ i_draw += max_roll;} 
	 if( i_draw >= max_roll){ i_draw -= max_roll;}
	}
	return Math.ceil((i_draw+1)/number_of_decks); 
}	}
///////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////

//API_TAG//
// this keeps redrawing a psuedo-shuffled array, 
// MAKE INDEX RANDOM INITIALLY, AND ITTERATE BY 1! 
// NOT random, LOOKS random, basically looks like draw, reshuffle, etc.
function progen_NOROLL_indefinite_shuffled_redraw( 
	getArray, index_or_objAsKeyNAutoItterate, number_of_decks){ 
		//rolls AS IF this # of decks
  return getArray[-1 + progen_NOROLL_indefinite_shuffled_d_roll(
      getArray.length, index_or_objAsKeyNAutoItterate, number_of_decks)]; }
//NOT random, better with arrays longer than 2
// see above for description (instead of array, uses possible dice vals)
var progen_NOROLL_indefinite_CATCH = {};
function progen_NOROLL_indefinite_shuffled_d_roll( 
	max_roll, index_or_objAsKeyNAutoItterate, number_of_decks){ 
	// for ...objAsKeyN... ANY key or object will do, then:
	//    this will draw a REAL random number and itterate based
	//    on that WITHOUT NEEDING TO SAVE ANY INDEX!!!
	//    SO: can call this without saving ANY vars.
	//    NOTE: saves index based on maxroll, 
	//    if same key with same max_roll is called, 
	//    	will draw from same pool and itterate. 
	//rolls AS IF this # of decks
//API_TAG//
//	(Algo isn't that complex, just power heavy, had to drop to C. )
	if(typeof index_or_objAsKeyNAutoItterate =="number"){
 	  return progen_CORE_NOROLL_indefinite_shuffled_d_roll(
	     max_roll, index_or_objAsKeyNAutoItterate, number_of_decks);
	}else{ var o = index_or_objAsKeyNAutoItterate;
	   var tmpCatch = progen_NOROLL_indefinite_CATCH[o];
	   if(tmpCatch == void null){ 
		progen_NOROLL_indefinite_CATCH[o]= {};
		tmpCatch =  progen_NOROLL_indefinite_CATCH[o]; }
	   if(tmpCatch[max_roll] == void null){ 
		tmpCatch[max_roll] = 
			Math.floor( 1000000* Math.random()); }
	   tmpCatch[max_roll] +=1;
 	   return progen_CORE_NOROLL_indefinite_shuffled_d_roll(
	     max_roll, tmpCatch[max_roll], number_of_decks); }
}
//OK, I'm NOT writing this for pass, fail, 
// just edit/ uncomment bits of the code in here and run it:
// commented sections can basically be uncommented 
// 	and exposed commented)
function progen_NOROLLS_visual_Unit_test(){ //PLAY WITH BELOW CODE 2 TEST
	var out =[]; var list = [1,2,3,4,5,6,1,1,1,1,1,1,1,1,1,1,1,1,1];
	for(var i=0; i< 100; i+=1){out.push( progen_NOROLL_indef_list_draw(
				list, i, 0)); }//looping_OPTIONAL));}
	//file_input(out);
	var numb_decks= 21;
	for(var i=0; i< 100; i+=1){ out = [];
		for(var j=0; j<list.length * numb_decks; j+=1){	
		   //progen_NOROLL_indefinite_shuffled_d_roll( 
		   //		list, j+(list.length*i),numb_decks );
		   
		   //out.push(progen_NOROLL_indefinite_shuffled_d_roll( 
		   //  list.length, j+((list.length*numb_decks)*i), 
		//	numb_decks ));
		   out.push(progen_NOROLL_indefinite_shuffled_redraw( 
		   	 list, j+((list.length*numb_decks)*i), numb_decks ));			
		   // FOR BELOW 2, BECAUSE START INDEX IS RANDOM,
		   // 	THE RESULTING NUMBERS WILL _NOT_ BE ORIGINAL LISTS!
		   // 	(theres offset & overlap btwn decks 4 these test)
		   //out.push( progen_NOROLL_indefinite_shuffled_redraw( 
		   //  list, this, numb_decks ) );
		   //out.push( progen_NOROLL_indefinite_shuffled_d_roll( 
		   //  list.length, this, numb_decks ) );
		}
		out.sort(function(a,b){return a-b;});
		file_input(out);
}	}

////////////////
/////////////////////////////////////////
///////////PROGEN_SEED sets up PROGEN enviornment 
/////////// (progen_objs functions automatically do this) 
///////////////////////////////////////////////
var _progen_seed_i = 0; // set in progen
var _progen_seed_stack = [];
//API_TAG//
// Below used for rolls, (progen_obj functs do this automatically)
// OUTSIDE OF PROGEN_OBJ: CALL ...SEED_INIT AND THEN END WITH ..SEED_END 
function progen_seed_end( ){ _progen_seed_i = _progen_seed_stack.pop();	}
function progen_get_seed(){ return _progen_seed_i; }
function progen_seed_init( get_seed_or_null){ //A stack, so can be nested
//API_TAG//
	if(_progen_seed_stack.length > 1000){ file_input(
	   "\n \n progen stack limit (1000)reached, this probably means "
	   +" a progen_seed_init without progen_seed_end!");}
	_progen_seed_stack.push(_progen_seed_i);
	if(get_seed_or_null == null){ _progen_seed_i = 
			Math.floor(Math.random()*_progen_SEEDMAX);
	}else{ _progen_seed_i = get_seed_or_null;} }
//API_TAG//
// RETURNS a random seed from multiple vars (1 could be a prev. rand seed)
// (made to generating vars rand-seed based on grid positions)
function progen_multivar_to_gen_rand_seed( getNumberList){
//API_TAG//
	rand_seed= getNumberList[0]
	for( var i=1; i< getNumberList.length; i+=1){
		rand_seed = (rand_seed*i) + Math.sin(getNumberList[i]);}
	return Math.floor(rand_seed);	}



var progen_ITTERATOR_STEP = 101;
var _progen_SEEDMAX = 900000;
////////////////
/////////////////////////////////////////
///////////PROGEN_D (think d20) rolls! & random lists!
///////////////////////////////////////////////


//functions found here: https://stackoverflow.com/questions/521295/seeding-the-random-number-generator-in-javascript
//API_TAG//
///////////// RUN WITH progen_SEED_INIT/END _OR_ INSIDE progen FUNCTION!!!
function progen_d_roll(max_roll ){ 
	var x = Math.sin(_progen_seed_i++) * max_roll;
    	return Math.abs( Math.floor(x)); }
////////////RUN WITH progen_SEED_INIT/END _OR_ INSIDE progen FUNCTION!!! 
function progen_d_roll_list(max_roll, number_of_dice, addDiceOPTIONAL){ 
	if(addDiceOPTIONAL != undefined){ var retInt= 0;
	 	for(var i=0; i< number_of_dice; i+=1){
			retInt += progen_d_roll(max_roll );}
		return retInt; }
	var retList = [];
	for(var i=0; i< number_of_dice; i+=1){
		retList.push(progen_d_roll(max_roll));}
	return retList; }
//////////// RUN WITH progen_SEED_INIT/END _OR_ INSIDE progen FUNCTION!!!
function progen_d_float_uncommonroll(){// (think Math.random())
	var x = Math.sin(_progen_seed_i++) ; return x ;	}
//////////// RUN WITH progen_SEED_INIT/END _OR_ INSIDE progen FUNCTION!!!
function progen_d_list_shuffle( arr, copy_arr_or_UNDEFINED ){
	if(copy_arr_or_UNDEFINED != undefined){ arr= arr.concat(); } 
	var tmp_card= void null; var j =0; var len = arr.length - 1;  
  	for (var i = len; i > 0; i--){ j = progen_d_roll( len );
	  tmp_card =arr[i]; arr[i] = arr[j]; arr[j] = tmp_card; }
	return arr;}
//////////// RUN WITH progen_SEED_INIT/END _OR_ INSIDE progen FUNCTION!!!
function progen_d_list_pick_from( arr, number_to_pick ){ 
	// WILL PICK SAME VAL! USE SHUFFLE FOR DRAWING FROM A SET LIST!!!
	var ret_arr=[];  var len = arr.length - 1;  
  	for (var i = 0; i < number_to_pick; i++) {
    		ret_arr.push(arr[ progen_d_roll( len )]); }
	return ret_arr; }
//API_TAG//




//API_TAG//
// :b: progen_dotnote :b:
//		EDIT: now can put RAND_SEED at start of dot-notation!
//			123124.globalvar2start.etc.
//		EDIT: SET VARS- progen_dotnote_SET!!!
//		EDIT: now can use filters (SLOW!) 
//			for pulling, say, 1 random filtered item.
// 	this allows random draws as well, if it hits a list. 
// 	(see description below)
// 	Basically, it smooths data-grabbing on global level for 
// 	--ALL OBJECTS/OBJ LISTS WITH NESTED DATA--
//	(NOT just db!)
// dot notation nodbs, gonna see if I can get it as a db
// (as db saves objs ONLY, I will need to pull a list from 
// 	db then read the tag)
// OK, should work with databases, given tag and item-name is there:
// 	db.tag.obj_param_to_grab
// 	OR
// 	obj.sub_obj.etc.
// 	(will pull random item if it finds a list!)
// 	(PROBABLY SHOULD PUT IN DB-namespace!!!)
//	EDIT: OR:
//		1231412.db.tag <-- initial number is a db-tag!
//			EDIT: looks like 'progen-init' string,
//			  so can draw the same rand val based on entry!
//		AND can now get indexes non-randomly:
//		obj.array.13.a (!) (13 is index!)
//		(no index given, it will still draw randomly!)
//			(so I can have BOTH random and indexed numbers!!)
//		NOTE: haven't tested above functions, but they should work.
//
// 	USES A RANDOM ROLL (progen_d_roll) IF HITS A LIST!!!
// 	KEEP THAT IN MIND WHEN USING IT!!!
//
// PROBABLY SHOULD _NOT_ USE ..return_DEEPCOPY ON DBs THAT ARE CHANGING,
// 	AS THE OBJ-POINTER GETTING MODIFIED WON'T UPDATE COPY-CATCH!
//
///////////// RUN WITH progen_SEED_INIT/END _OR_ INSIDE progen FUNCTION!!!
//////	//FOR SETTING VARS, CAN USE progen_dotnote_SET!!!
//		EDIT: now can use filters: STANDARD JS FILTER FUNCTIONS,
//			-- USE CATCH_FILTERED_LIST variant if reusing speed
var _progen_dotnote_catch = {}; //2d, {functname:{objname:CATCH} ... }
function progen_dotnote_catch_filtered_list( //MAIN progen_dotnote BELOW
// WARNING- once first launched, catch does NOT change-same return
// //random draws still novel
  inStr, inGetDeepCopy_OPTIONAL, inRand_numb_2_draw_OPTIONAL, 
   inFilterFunct_NAME){	
//API_TAG//
	var tmpC = _progen_dotnote_catch;
	var tmpPool = tmpC[inFilterFunct_NAME]; //now pointer to data...
	if(tmpPool == null){tmpPool = {}; 
	tmpC[inFilterFunct_NAME] = tmpPool; }
	var tmpCaught = tmpPool[inStr]; //now pointer to catch...
	if(tmpCaught== null){ tmpCaught= progen_dotnote(inStr, 
		true, null, progen_dotnote(inFilterFunct_NAME));
	   tmpPool[inStr] = tmpCaught; }
	if(inRand_numb_2_draw_OPTIONAL ==null){ var tmpOut = tmpCaught;
	}else{ var tmpOut = []; var tmpLen=tmpCaught.length -1;
	    for(var i=0; i< inRand_numb_2_draw_OPTIONAL; i+=1){
	 	tmpOut.push( tmpCaught[progen_d_roll(tmpLen)]);} }
	if(inGetDeepCopy_OPTIONAL){ 
		return JSON.parse(JSON.stringify(tmpOut)); } 
	return tmpOut;
}

//API_TAG//
function progen_dotnote( getStr, returndeepcopy_OPTIONAL,
  	 getRand_OPTIONAL,//numb rand items to get OR null,
	filter_funct_OPTIONAL){ //standard js-array filter, LISTS ONLY
//can also access non-db related variables in global namespace,//API_TAG//
	getStr = getStr.split(".");
	if(!isNaN( getStr[0])){progen_seed_init(parseInt(getStr.unshift()));
	  var tmpSeed_in_getStr = true;}else{var tmpSeed_in_getStr =false;}

	var i_obj = progen_globalThis;
	for(var i=0; i< getStr.length; i+=1){
		i_obj= i_obj[getStr[i]];
		if(Array.isArray(i_obj) ==1 && isNaN( getStr[i+1]) &&
				 getStr[i+1] != void null){
			i_obj = i_obj[ progen_d_roll(i_obj.length-1)]; }
		if(i_obj == void null){ return void null;} }
	
	if(filter_funct_OPTIONAL != null){ 
		i_obj = i_obj.filter( filter_funct_OPTIONAL );}

	// null fails the >= test, null testing here doesn't work. 
	if(getRand_OPTIONAL>=1  && Array.isArray( i_obj )){   
	      var tmp_i = i_obj;    i_obj = []; var tmpLen=tmp_i.length -1;
	      for(var i=0; i< getRand_OPTIONAL; i+=1){
		    i_obj.push( tmp_i[ progen_d_roll(tmpLen)]);} }
	if(tmpSeed_in_getStr){ progen_seed_end(); }
	if(returndeepcopy_OPTIONAL){ 
		i_obj = JSON.parse(JSON.stringify(i_obj));}
	return i_obj;
}

//API_TAG//
function progen_dotnote_SET(getStr,get_setItemToo){
// use progen_dotnote UNLESS REALLY NEED THIS
// 	(most of the times, can pull a struct and edit that)
//API_TAG//
	getStr = getStr.split(".");var tmpV=getStr.pop(); 
	getStr = getStr.join(".");
	if(getStr.trim()== ""){ var tmpObj = progen_globalThis;
	}else{tmpObj = progen_dotnote( getStr); }
	tmpObj[tmpV] = get_setItemToo; return get_setItemToo;
}




/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////// :b: progen_txt :b:
/////////////////////////////
// :b: progen_txt_preprocess (put in progen when done...) :b:
//


// Can (potentially...) add this to main- VIM-SCRIPT
// 	(it's small enough... 100 lines. )
// SECOND -IF- STATMENTS FOR PARAMS -CAN- BE STRINGS,
// 	BUT -NOT- FIRST!!!
var otxtPlayer = {}; //global vars, set and used in preprocessor
var otxtOther={};
var progen_txt_preprocess_CUTS=["####", "###", "##" ];
function progen_txt_preprocess( 
	otxtPlayer_GET, otxtOther_GET, get_mlConvo_str, bool_reset_UNUSED, rm_OPTIONAL){
	// (preprocessor, more '#' go first)    #### ### ## -> #? ;; 
	// ALL IF BLOCKS OPTIONAL, 
	// 	AND ALL params dot-note (pulls rand item from lists!) 
	// OPTIONS: 
	// ## var1 ==/!=/>= "str" && var3_bool || etc. (OPTIONAL) 
	// 	#? globalVar(dotnote, draws 1) #? globalVar2 ##
	// 	OR
	// 	## (if block_OPTIONAL) #? function ;; input1 ;; input2##
	// 	(functions are MML-style, the 'params' var is 'inputs')
	// ### LISTPROCESS;; int_0_linear_1_random_more_num2rand_draw ;;
	// 	"list_item_i_global_name__like_tmp_i" 
	//   ;;globListname ;; "txt to preprocess & add PER ##tmp_i##" ### 
	/////NOTE LISTS: if (int_0_lin...>1 && int_0_lin...<list.length),
	// 	draws from shuffled list, otherwise pure rand draws
	// (execute on run/divide by on run)    @@ -> @? ,,
	
	//global vars, so progen_dotnote can pull 'local' o,otarget vars!
	otxtPlayer = otxtPlayer_GET; otxtOther=otxtOther_GET;
	if(get_mlConvo_str.indexOf("##") == -1 ){ return get_mlConvo_str; }

	var tmpPrePros=[]; var tmpCmdNIf=[]; 
	var tmpCmds=[]; var tmpParams=[]
	for(var i_p=0; i_p<progen_txt_preprocess_CUTS.length; i_p+=1){ 
	  tmpPrePros=get_mlConvo_str.split(
			progen_txt_preprocess_CUTS[i_p]);
	  for(var i_questn=1; i_questn< tmpPrePros.length; i_questn+=2){
		//handling 'if' satement, and dividing cmd blocks...
		tmpCmdNIf = tmpPrePros[i_questn].split("#?");
		tmpPrePros[i_questn] = ""; 
		
	   	if(tmpCmdNIf.length >1){
		  if(1!= progen_txt_preprocess_param(tmpCmdNIf[0],1,2)){
			//testing it. //i_question+=1;
			 continue;} 
	     	     tmpCmds = tmpCmdNIf; tmpCmds.shift();  
	   	}else{tmpCmds = tmpCmdNIf;}
		
		//running cmd blocks, first into params...
		for(var i=0; i< tmpCmds.length; i+=1){
		   tmpParams= tmpCmds[i].split(";;");
			
		   if(tmpParams[0].indexOf("LIST") != -1 &&
				tmpParams[0].trim() == "LISTPROCESS"){ 
			var tmp_0_1_more=
			    //tmp_0_linear_1_random_more_num2rand_draw = 
			    progen_txt_preprocess_param(tmpParams[1],1);
			var tmpList= //for:0 ==tmp_0_1_more 
			    progen_txt_preprocess_param(tmpParams[3],0);
			if(tmp_0_1_more > 0){ var tmpList=
			  progen_d_list_shuffle(tmpList ,1);
			}if(tmp_0_1_more > 1){ 
			 if( tmpList.length > tmp_0_1_more){
			  	tmpList.splice(tmp_0_1_more);
			 }else{ var tmpList = progen_d_list_pick_from( 
				tmpList, tmp_0_1_more);} }

			 var tmpItemGlobName = 
			   progen_txt_preprocess_param( tmpParams[2], 1);
			var tmpTxt_to_use = 
			  progen_txt_preprocess_param( tmpParams[4], 1);
			for(var i_l =0; i_l<tmpList.length; i_l+=1){
				progen_globalThis[
					tmpItemGlobName]= tmpList[i_l];
			  tmpPrePros[i_questn] +=progen_txt_preprocess( 
			    otxtPlayer_GET, otxtOther_GET, tmpTxt_to_use, 
				bool_reset_UNUSED, rm_OPTIONAL);}
			continue;	}
		   
		   var tmpFunct = 
			progen_txt_preprocess_param( tmpParams[0], 1, 1);
		   if(typeof tmpFunct == "function"){
			for(var j=1; j<tmpParams.length; j+=1){
			  tmpParams[j]=
			    progen_txt_preprocess_param(tmpParams[j],1);}
		     	tmpFunctOut = tmpFunct( 
				otxtPlayer_GET, otxtOther_GET,
				 null, null, tmpParams, rm_OPTIONAL);
			if(tmpFunctOut != null){
				tmpPrePros[i_questn] += tmpFunctOut;}
		   }else{ //is data, not function, add accordingly
			tmpPrePros[i_questn] += 
			  progen_txt_preprocess_param( tmpParams[0], 1); }
		}
		//preprocessing result, so can be recursive...
		tmpPrePros[i_questn] = progen_txt_preprocess( 
			otxtPlayer_GET, otxtOther_GET, 	
			tmpPrePros[i_questn], 
			bool_reset_UNUSED, rm_OPTIONAL);
	   }
	   //joining back the blocks, so can do it for other cuts...
	   get_mlConvo_str =  tmpPrePros.join("");
	}
	return get_mlConvo_str;
}

// :b: progen_txt_preprocess_param :b:
//
// get from global namespace
// for funct, gets global var. 
// 	-- IF STAMENTS: FIRST VAL (prior to ==) MUST -NOT- BE A 
// 		STRING WITH '/"!!! (so vars or ints, a var-str works!)
// 	-- INITIAL 'IF' CAN BE 1 or var OR LIST_VAR 2 DRAW RAND FROM
// 		 representing it, just fyi :/
function progen_txt_preprocess_param( getStr, getRandDrawIfList_OPTIONAL, 
		getTyp_1funct_2ifStatement_3dataDEFAULT_4set_OPTIONAL,
		getValToSetIfTooIfData_OPTIONAL){
	// last 2 options, getRand... and getTyp ARE OPTIONAL, 
	// 	defaults
	// bracketed str: "string goes here"
	//
	getStr = getStr.trim();
	if(getTyp_1funct_2ifStatement_3dataDEFAULT_4set_OPTIONAL
			== void null){
		getTyp_1funct_2ifStatement_3dataDEFAULT_4set_OPTIONAL = 3;}
	if(getTyp_1funct_2ifStatement_3dataDEFAULT_4set_OPTIONAL ==1){
	  if( getStr.indexOf('"') != -1){ return getStr.split('"')[1];}
	  return progen_dotnote( getStr, 0, getRandDrawIfList_OPTIONAL );

	}if(getTyp_1funct_2ifStatement_3dataDEFAULT_4set_OPTIONAL ==2){
		if(getStr.trim() ==""){ return 1;}
		//handling ands and ifs
		if(getStr.indexOf("&&") != -1){
		  var tmpAnds = getStr.split("&&");
		  for(var i2=0; i2< tmpAnds.length; i2+=1){
		   if( 1 != progen_txt_preprocess_param( 
			   tmpAnds[i2], getRandDrawIfList_OPTIONAL, 2)){
		     return 0;}} return 1; }
		if(getStr.indexOf("||") != -1){
		  var tmpIfs = getStr.split("||");
		  for(var i2=0; i2< tmpIfs.length; i2+=1){
		   if( 1 == progen_txt_preprocess_param( 
			tmpIfs[i2], getRandDrawIfList_OPTIONAL, 2)){
		     return 1;}} return 0; } 
		//zzz NEED TO TEST ABOVE!!! (just run a few ifs/ands!)
		
		if(getStr.indexOf("==")!=-1){	var tmpIf_1 = "==";
		}else if(getStr.indexOf("!=")!=-1){ var tmpIf_1 = "!=";
		}else if(getStr.indexOf(">=")!=-1){ var tmpIf_1 = ">=";
		}else if(getStr.indexOf("<=")!=-1){ var tmpIf_1 = "<=";
		}else if(getStr.indexOf(">")!=-1){ var tmpIf_1 = ">";
		}else if(getStr.indexOf("<")!=-1){ var tmpIf_1 = "<";
		}else{if(progen_txt_preprocess_param( 
				getStr, getRandDrawIfList_OPTIONAL)){
			return 1; } return 0;}

		var tmpIf = getStr.split(tmpIf_1);		
		var tmpIf_0 =  progen_txt_preprocess_param( 
				 tmpIf.shift(), 0, 3);
		var tmpIf_2 =  progen_txt_preprocess_param( 
				 tmpIf.join(tmpIf_1), 0, 3);
		if(tmpIf_1=="=="){ return tmpIf_0 == tmpIf_2;}
		if(tmpIf_1=="!="){ return tmpIf_0 != tmpIf_2;}
		if(tmpIf_1==">="){ return tmpIf_0 >= tmpIf_2;}
		if(tmpIf_1=="<="){ return tmpIf_0 <= tmpIf_2;}
		if(tmpIf_1==">"){ return tmpIf_0 > tmpIf_2;}
		if(tmpIf_1=="<"){ return tmpIf_0 < tmpIf_2;}
		return 0;
	}if(getTyp_1funct_2ifStatement_3dataDEFAULT_4set_OPTIONAL ==3){
	   if(getStr == "null"){return null; }
	   if(getStr == "true"){return true; }
	   if(getStr == "false"){return false; }
	   if(getStr.indexOf('"')==0){return getStr.split('"')[1];}
	   if(getStr.indexOf("'")==0){return getStr.split("'")[1];}
	   if(getStr.indexOf("=")!=-1 || getStr.indexOf(">")!=-1 ||
		getStr.indexOf("<")!=-1 ){ 
		   return progen_txt_preprocess_param( 
			getStr, getRandDrawIfList_OPTIONAL, 2);} 
	   if(isNaN(parseInt(getStr)) != true){
		if(getStr.indexOf(".")!=-1){ return parseFloat(getStr); }
		return parseInt(getStr); }

	  return progen_dotnote( getStr, 0, getRandDrawIfList_OPTIONAL);
	}if(getTyp_1funct_2ifStatement_3dataDEFAULT_4set_OPTIONAL ==4){
		if(getStr.trim() ==""){ return 1;}
		if(getStr.indexOf("+=")!=-1){	var tmpIf_1 = "+=";
		}else if(getStr.indexOf("-=")!=-1){ var tmpIf_1 = "-=";
		}else if(getStr.indexOf("=")!=-1){ var tmpIf_1 = "=";
		}else{ return 0;}

		var tmpIf = getStr.split(tmpIf_1);
		var tmpIf_out_name = tmpIf.shift().trim();	
		var tmpIf_out =  progen_txt_preprocess_param( 
				 tmpIf_out_name, 0, 3);
		var tmpIf_mod =  progen_txt_preprocess_param( 
				 tmpIf.join(tmpIf_1), 0, 3);
		if(tmpIf_1=="+="){ tmpIf_out += tmpIf_mod;}
		if(tmpIf_1=="-="){ tmpIf_out -= tmpIf_mod;}
		if(tmpIf_1=="="){ tmpIf_out = tmpIf_mod;}
		   
		return progen_dotnote_SET(tmpIf_out_name, tmpIf_out);
		return 0;
	}	
}

