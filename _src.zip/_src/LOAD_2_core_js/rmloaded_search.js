


//API_TAG//
// USE: below auto-gets & stores list of links to objs(small & large) with 
// 	  obj:{linklazy:['tag']}
// 	(the tag is the key for below), 
// 	updated by calling it's update(FULL update),changing rooms(FULL..), 
// 	 or 10 objs per turn (NOT updated FULLY per frame!) 
var rmloaded_search_lazylink= {}; // auto-updates, 
 //-----USE: rmloaded_search_lazylink['tag'] == null or LIST of objs in rm!
 //--------- tag objs with: obj:{linklazy:['tag']}
var _rmloaded_search_lazylink_struct = {
	i:0, numb_search_per_turn:10, SEARCHINGOBJS:[], 
	rmloaded_caught:void null, PRESEARCH:{} };
//WARNING: updates 10 objs/turn unless 'doFullSearch' or room change,
//	so should work great for players (always in room) or bosses
// THIS RUNS IN MAIN-ROOM LOOP! USE OTHERWISE IF A FULL-PING IS NEEDED!
function rmloaded_search_lazylink_update( get_bool_doFullSearch ){
	//------------GET DATA FROM: rmloaded_search_lazylink!!!
//API_TAG//
	var tmpS = _rmloaded_search_lazylink_struct;
	
	if(tmpS.rmloaded_caught != rmloaded_room){
		tmpS.rmloaded_caught = rmloaded_room;
		get_bool_doFullSearch = true; }

	if(get_bool_doFullSearch == true ){
		tmpS.i= 0;
		tmpS.PRESEARCH= {};
		tmpS.SEARCHINGOBJS= 
		   rmloaded_room.objs.concat( rmloaded_room.objs_large); 

		var i = 0; var i_end = tmpS.SEARCHINGOBJS.length;
		var objs = tmpS.SEARCHINGOBJS;
		var presearch = tmpS.PRESEARCH;
		while(i< i_end){ 
		  if(objs[i]["lazylink"]!= void null){
			var obj =objs[i]; var lazylinks= obj["lazylink"];
			for(var j=0;j<lazylinks.length; j+=1){
			  if( presearch[lazylinks[j]] ==void null){
				presearch[lazylinks[j]] = [obj];
			  }else{ presearch[lazylinks[j]].push(obj); } } }
		  i+=1; }

		rmloaded_search_lazylink= tmpS.PRESEARCH;
		tmpS.PRESEARCH= {};
		return;
	}

	if(tmpS.i >= tmpS.SEARCHINGOBJS.length ){
	   rmloaded_search_lazylink = tmpS.PRESEARCH;
	   tmpS.PRESEARCH = {};
	   tmpS.i = 0;
	   tmpS.SEARCHINGOBJS = 
		   rmloaded_room.objs.concat( rmloaded_room.objs_large); }
	
	var objs = tmpS.SEARCHINGOBJS;
	var presearch = tmpS.PRESEARCH;
	var i = tmpS.i; tmpS.i += tmpS.numb_search_per_turn;
	var i_end = tmpS.i;
	if(i_end >= objs.length){  i_end = objs.length;}

	while(i< i_end){ 
	  if(objs[i]["lazylink"]!= void null){
		var obj =objs[i]; var lazylinks= obj["lazylink"];
		for(var j=0;j<lazylinks.length; j+=1){
		  if( presearch[lazylinks[j]] ==void null){
			presearch[lazylinks[j]] = [obj];
		  }else{ presearch[lazylinks[j]].push(obj); } } }
	  i+=1; }
}



///////////////////////////
// rmloaded_searchUpdate() - 
// 
// 	AND can store ANYTHING, so it's versitile. 
// 	HOWEVER: no 'distance', this hits everything 'listening'
// rmloaded_search_FAST_GET(getEcho)
// rmloaded_search_FAST_SEND(getEcho, getEcho_data )
//

//OK, I'd like to first isolate these functions a bit. 

// :b: fast-searches_other_FRONTEND :b:
// 	--ECHO engine, I've used it before,
// 	it's 'one sends signal, a few frames later any obj. can 
// 	'see' the signal sent. This is super-efficient, super-simple 
// 	to code (basically relaying 'signal), optimizable:
// 		(one broadcast every frame, recievers can look 
// 			every x frames to see if triggered)
//API_TAG//
function rmloaded_search_FAST_GET(getEcho){ 
	return _rmloaded_search_struct.echos[getEcho]; }
function rmloaded_search_FAST_SEND(getEcho, getEcho_data ){
//API_TAG//
  // 	signals last 1 frame: 
  //RUN IMPORTANT SIGNALS 2+FRAMES, AS WILL GET DEL WHEN CHANGING RMS
  //	SHOULD MAKE AN OBJ TO LEAVE IN ROOM FOR ON_DEATH BROADCASTS!
   _rmloaded_search_struct.echos_pre_broadcast[getEcho] = getEcho_data;  }
// :b: obj-specefic_search_near:b:
// 	---RUN -EVERY- FRAME FOR SEARCHES!!! It's lazy,
// 		so takes a frame to 'get-back-results' anyway!!!
// NOTE: gets 1 obj! Stores a backup-obj in case 
// 	object retrieved is ObjToIgnore. 
//objToIgnore is for if obj==self!
//API_TAG// 
//zzz- needs testing, can put in own obj as well!
function rmloaded_search_near_spawn_searchloc( //makes blank obj. 
	getX, getY, str_term_to_search_for, 
		last_turns_before_dead_0_FOR_infinite){ 
	//basically for moving large objs and search_near, as it only 
	//	searches small objs
//API_TAG// 
	var tmpO = {x:getX, y:getY, behavior:"b_none",
		ignore_pause:true, dead:0, 
		graphic:" ", draw_1late_2last:0, colgroup:"" }
	tmpO[str_term_to_search_for] = 1;
	if(last_turns_before_dead_0_FOR_infinite !=0){ tmpO.behavior = 
		 	"rmloaded_search_spawn_dead_turnend";
			tmpO.turns_before_dead =
				last_turns_before_dead_0_FOR_infinite;}
	rmloaded_room.objs.push(tmpO);
}
function rmloaded_search_spawn_dead_turnend(o){ //behavior
  if(o.turns_before_dead <=0){o.dead=1;}else{o.turns_before_dead-=1;}}

//API_TAG// 
//	//SMALL OBJS SEARCH ONLY, NOT LARGE OBJS (1 point loc is easier)
//	(call rmloaded_search_near_spawn_searchloc 4 moving lrg_objs)
function rmloaded_search_near( //getSearchTerms = space-separated-str,
			// looking for obj-keys, gets 1 obj!
		getSearchTerms, //"grid_size 12 obj_key obj_key2..." 
		getObjToIgnore,  //so no finding self
		x_if_near, y_if_near){ //this is VERY rough 'grid estimate' 
			// and 'lazy': takes few frames to work.
			// WARNING: ONLY RUN THIS FUNCTION IN SCENES
			// THAT NEED IT, AS IT INITIALIZES NEAR_SEARCHES
//API_TAG//
	// registering searches, ALL registered to terms_nxt FIRST!
	_rmloaded_search_struct.near_nxt[ getSearchTerms] =1;

	var tmpSearches = _rmloaded_search_struct.near_prev.searches;	
	
	if( tmpSearches[ getSearchTerms] != void null ){
		var tmpWidth = tmpSearches[getSearchTerms].grid_width;
		//file_log(tmpWidth + "-----!");
		var gridLoc = Math.floor(x_if_near/tmpWidth) + 
			(50000 * Math.floor(y_if_near/tmpWidth))
		
		var foundObj = tmpSearches[getSearchTerms].found[gridLoc];
		if(foundObj == void null){ return null;}
		if(foundObj != getObjToIgnore){ return foundObj;}
		//searching 2knd found item!
		var foundObj = tmpSearches[getSearchTerms].found_prev[
			gridLoc ];
		if(foundObj != void null){ return foundObj; }
	}		
	return void null;
}

var _RMLOADED_SEARCH_CONSTANTS = {
	NEAR_FRAMES_TOTAL:5, //for each stage: nxt, terms, terms_expanding, and prev
		//readable from 'prev'
		// 'total' times 3 is time needed to leave a 'mark' 
		// that can be read! (like an 'oder')
	NEAR_LOC_CHART_2D_OFFSET:[ -49999,  -50000, -50001,
					-1,  		1,
					50001,  50000, 49999 ]
};
//API_TAG//
// This resets on changing rooms!
var _rmloaded_search_struct__BASE = JSON.stringify(
	{
	caught_room_loaded:void null,
	
	 on_first_frame_catchup:1, //this allows 'full' searches frame 2!
		// (frame 1 allows setting up searches!)
		// so search changing rooms diff should be minimal.

	//terms are used by 'slow' searches 
	near_looping_frame:0, 
	near_stage1:{objs_catch:[], searches:{}}, // term - key
	near_stage2_expanding:{objs_catch:[], searches:{}}, // term - key
	near_prev:{objs_catch:[], searches:{}},
	near_nxt:{}, // this one just adds terms!
	
	//just added below (5/5/2024) should disable code till used
	// (THIS IS IN 1 PLACE, DELETE IT THERE IF GIVES PROBLEMS)
	near_nxt_DISABLE_SRCH_TILL_ADDED_OPTIMIZER:true, 

	// simple echo functions (broadcasts by objs, instead of 'signals')
	echos:{},
	echos_pre_broadcast:{}
	 }
);
//API_TAG//

// SEARCH (see above) DATA:
// { 		{ search_terms_list:tmpSearch_terms, 
	//			grid_width:tmpGrid_width,
	//			count:0, prev_frame:0,
	//			//for simple find cmds (another option
	//			// FOR GRIDS: index will be loc location!
	//			found:[],
	//			found_prev:[] //NOT always used!
	//	}
var _rmloaded_search_struct = JSON.parse(_rmloaded_search_struct__BASE);

//API_TAG//
//////////////////
// RAN 1x/frame FROM rmloaded_launch_game! (is faster than it looks)
// 	NOT super fast, could optimize parts of it.
function rmloaded_searchUpdate(){
//API_TAG//
	var tmpRunning_2knd_frame = false;
	if(rmloaded_room != _rmloaded_search_struct.caught_room_loaded){
		rmloaded_search_struct = 
			JSON.parse(_rmloaded_search_struct__BASE);
		_rmloaded_search_struct.caught_room_loaded=rmloaded_room;
	}else{ 
	  if( _rmloaded_search_struct.on_first_frame_catchup == 1){ 
		_rmloaded_search_struct.on_first_frame_catchup = 0;
		tmpRunning_2knd_frame = true;
	} }
	_rmloaded_searchUpdate_near( tmpRunning_2knd_frame);
	
	//echos, don't need anything more complex than this
	_rmloaded_search_struct.echos= 
		_rmloaded_search_struct.echos_pre_broadcast;
	_rmloaded_search_struct.echos_pre_broadcast = {};	

	rmloaded_search_lazylink_update( 0 ); 
}

/////////////////////////////
/////////////////////////////
/////////////////////////////
/////////////////////////////
/////////////////////////////
/////////////////////////////
//// BELOW ARE 'HELPER-FUNCTIONS MOSTLY
////////////////////////////////
/////////////////////////////
/////////////////////////////
/////////////////////////////

//helper functions, see top of page
function _rmloaded_searches_near__register_search(
		getSearchTerms, pool_to_add_too){
	//FIRST FRAMES ARE ADDED TO 'rmloaded_room._search.terms_nxt
	//	(as in [term] = 1!!!)
	//	pool_to_add_too_OPTIONAL IS TYPICALLY:
	//_rmloaded_search_buffer OR _rmloaded_search_buffer_PREV
	
	var tmpSearch_terms = getSearchTerms.split(" ");
	tmpSearch_terms.shift(); //near (grid_size)
	var tmpGrid_width = parseInt(tmpSearch_terms.shift());
	
	//_rmloaded_search_buffer OR _rmloaded_search_buffer_PREV
	pool_to_add_too.searches[getSearchTerms] = 
		{ 		search_terms_list:tmpSearch_terms, 
				grid_width:tmpGrid_width,
				count:0, prev_frame:0,
				//for simple find cmds (another option
				// FOR GRIDS: index will be loc location!
				found:[],
				found_prev:[] //NOT always used!
		};
	
}


//this is a helper function
/////
//RUNS A FEW TIMES UPON CHANGING ROOMS, _NOT_ FAST, BUT 
//AS IT'S USED UPON ENTERING ROOMS, DON'T NEED TO BE.
function _rmloaded_searchUpdate_near__rmchange_register_ALL(
	s, // SEARCHBUFFER // like _rmloaded_search_buffer
	getRmSearches, //rmloaded_room._search.terms_prev, etc.
	LOC_CHART_2D_OFFSET, getRunSearch, getRunExpander){
		s.searches = {};
		s.objs_catch = rmloaded_room.objs.concat();
	
		var tmpKeys = Object.keys( getRmSearches );
		for(var i=0; i<tmpKeys.length; i+=1){
		  _rmloaded_searches_near__register_search( tmpKeys[i], s);
				
		   var b_search = s.searches[tmpKeys[i]];
		   if(getRmSearches){
		   _rmloaded_search_list__objs2foundGRID_IF_searchmatch(
			b_search.search_terms_list, b_search, 
			s.objs_catch, 0, s.objs_catch.length, 
			b_search.grid_width);
		   }if(getRunExpander){		
		    _rmloaded_search_list__objs2foundGRID_EXPANDER(
			b_search, 0, LOC_CHART_2D_OFFSET.length, 
			LOC_CHART_2D_OFFSET);
		 } }
}	


//helper functions, see top of page//			
function _rmloaded_searchUpdate_near( getOn2kndFrame){
// on 2knd frame to give time for searches to be broadcast on frame1
	var tmp_b = _rmloaded_search_struct;
	
	// added 5/5/2024, this optimizer is JUST used herea
	// (THIS OPTIMIZATION+OPTIMIZATION VAR IS ONLY HERE, DELETE IF 
	// 	HAS PROBLEMS)
	if(tmp_b.near_nxt_DISABLE_SRCH_TILL_ADDED_OPTIMIZER == 0){
		if(Object.keys(tmp_b.near_nxt).length ==0){ return; } 
		tmp_b.near_nxt_DISABLE_SRCH_TILL_ADDED_OPTIMIZER =1; }
	
	
	var LOC_CHART_2D_OFFSET =
		_RMLOADED_SEARCH_CONSTANTS.NEAR_LOC_CHART_2D_OFFSET;

	//giving 1 frame to settup searches, so ready on enter room...
	if(getOn2kndFrame){
		_rmloaded_searchUpdate_near__rmchange_register_ALL(
			tmp_b.near_prev, tmp_b.near_nxt, 
			LOC_CHART_2D_OFFSET, 1,1);
		_rmloaded_searchUpdate_near__rmchange_register_ALL(
			tmp_b.near_stage2_expanding, tmp_b.near_nxt, 
			LOC_CHART_2D_OFFSET, 1,0);
		_rmloaded_searchUpdate_near__rmchange_register_ALL(
			tmp_b.near_stage1, tmp_b.near_nxt, 
			LOC_CHART_2D_OFFSET, 0,0);
	}
	
	///////////////////
	// resetting frames@max! Dealing with max-frames and frame-shift 
	tmp_b.near_looping_frame +=1;
	var curFrame = tmp_b.near_looping_frame;
	if(curFrame > _RMLOADED_SEARCH_CONSTANTS.NEAR_FRAMES_TOTAL){ 
		tmp_b.near_looping_frame = 0;    curFrame = 0;
	
		tmp_b.near_prev = tmp_b.near_stage2_expanding;
		tmp_b.near_stage2_expanding = tmp_b.near_stage1;
		tmp_b.near_stage1 =  { 
		     objs_catch:rmloaded_room.objs.concat(), searches:{} };
		
		//adding 'term_nxt'
		var tmpKeys = Object.keys(tmp_b.near_nxt);
		for(var i =0; i< tmpKeys.length; i+=1){
			_rmloaded_searches_near__register_search(tmpKeys[i],
				tmp_b.near_stage1);	}
		
		tmp_b.near_nxt = {};	
	}
		
	var TOTAL_FRAMES  = _RMLOADED_SEARCH_CONSTANTS.NEAR_FRAMES_TOTAL;
	
	//////
	// handling searches:stage 1: looking up objs! 
	var tmpSearches = tmp_b.near_stage1.searches;
	var keys = Object.keys( tmpSearches);
	var tmpObjs = tmp_b.near_stage1.objs_catch;
	var i_max = (tmpObjs.length);
	var i_end = Math.floor( (curFrame/TOTAL_FRAMES) * i_max);
	// for tmpSearches 
	for(var b=0; b< keys.length; b+=1){
		var b_search = tmpSearches[ keys[b] ];
		var i_strt = Math.floor(
			(b_search.prev_frame/TOTAL_FRAMES) * i_max);
		
		_rmloaded_search_list__objs2foundGRID_IF_searchmatch(
 			b_search.search_terms_list, b_search, 
			tmpObjs, i_strt, i_end, b_search.grid_width);
			
		b_search.prev_frame = curFrame;
	}

	//////
	// handling searches:stage 2: expanding found locs!
	// 	(so edges of grid won't matter at all!)
	var tmpSearches = tmp_b.near_stage2_expanding.searches;
	var keys = Object.keys( tmpSearches);
	var tmpObjs = tmp_b.near_stage2_expanding.objs_catch;
	var i_max = (LOC_CHART_2D_OFFSET.length);
	var i_end = Math.floor( (curFrame/TOTAL_FRAMES) * i_max);
	//for expanding stuffs!
	for(var b=0; b< keys.length; b+=1){
		var b_search = tmpSearches[ keys[b] ];
		var i_strt = Math.floor(
			(b_search.prev_frame/TOTAL_FRAMES) * i_max);

		_rmloaded_search_list__objs2foundGRID_EXPANDER(
			 b_search,  i_strt,  i_end, LOC_CHART_2D_OFFSET);
		
		//file_input(b_search.prev_frame , curFrame);		
		b_search.prev_frame = curFrame;
	}

}

////
/// USED TAGS FOR ACTUAL SEARCH
// search_buff_stuct= [found[],  fournPrv[], count[], globPoolFoundIn];
// 	... {found:[], foundprv:[], count:0, globPoolFoundIn:null}
//
function _rmloaded_search__obj_has_searchterms(o, termslist){
	for( var i=0; i< termslist.length; i+=1 ){
		if( o[termslist[i]] == void null){ return false; } } 
	return true;
};
//used to 'expand' existing grids
function _rmloaded_search_list__objs2foundGRID_EXPANDER(
	rmloaded_search_buffer__search, 
	start_i, end_i, //<- are 0 to LOC_CHART_2D_OFFSET.length
	LOC_CHART_2D_OFFSET){ //see 
	
	if(rmloaded_search_buffer__search.ret_keys_CATCH == void null){
		rmloaded_search_buffer__search.ret_keys_CATCH = 
			Object.keys(rmloaded_search_buffer__search.found);
	}
	  var ret_keys_CATCH = 
		rmloaded_search_buffer__search.ret_keys_CATCH;
	
	  var ret_list = rmloaded_search_buffer__search.found;
	  var ret_list_prev = rmloaded_search_buffer__search.found_prev;
	  var count =0;
		
	  // pre-calculating offsets! (1 +5000 (x off + y Off!)
	  // none for the center, as it's already defined!
	  for( var i = 0; i< ret_keys_CATCH.length; i+=1){
		for(var off = start_i; off <end_i; off+=1){
			var new_off = 
				parseInt(ret_keys_CATCH[i]) 
				  +LOC_CHART_2D_OFFSET[off];
			
			// cur obj adding (and prev item, if available)
			if(ret_list[new_off] == void null){ 
				ret_list[new_off] = ret_list[
					ret_keys_CATCH[i]];
				ret_list_prev[new_off] = ret_list_prev[
					ret_keys_CATCH[i]];
			// adding to 'prev' frame...
			}else{ ret_list_prev[new_off] = ret_list[
					ret_keys_CATCH[i]];
			}			
		} 
	  }
	  return;
}

// a generator, really, but as I can set start/end itterator, I 
// 	can spread out search over course of a second
function _rmloaded_search_list__objs2foundGRID_IF_searchmatch(
 	getTagsList, rmloaded_search_buffer__search, 
	objs_list, start_i, end_i, getWidth){ 
	
	  var ret_list = rmloaded_search_buffer__search.found;
	  var ret_list_prev = rmloaded_search_buffer__search.found_prev;
	  var count =0;
	  
	  for( var i = start_i; i< end_i; i+=1){
		var o = objs_list[i];
		
		if( !_rmloaded_search__obj_has_searchterms( o, 
			getTagsList )){ continue;}
		var loc = Math.floor(o.x / getWidth) 
			+ (Math.floor(o.y /getWidth) * 50000);
		
		ret_list_prev[ loc ] = ret_list[ loc ];  
		ret_list[ loc ] = o; 
		
		count+=1;
	  }
	  rmloaded_search_buffer__search.count+= count;
	  return;
}

