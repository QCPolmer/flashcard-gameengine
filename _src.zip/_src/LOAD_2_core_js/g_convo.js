
var g_convo_run__4_LEVEL_EDITOR_TEMPLATE_LIST = "alphabet".split(""); 
var g_convo__4_LEVEL_EDITOR_PREPROCESSOR_TEST_A = 
	"g_convo__4_LEVEL_EDITOR_PREPROCESSOR_TEST_B";
var g_convo__4_LEVEL_EDITOR_PREPROCESSOR_TEST_B = " read from: g_convo__GLOBAL_PREPROCESSOR_TEST_B";

async function g_convo_test_behav(o){
 	progen_seed_init();


	gGlobalThis.bb23="testzzz";
	gGlobalThis.testzzz= ["testA","testB","testC"];

// NOTE: if (int_0_lin...>1 && int_0_lin...<list.length),
// 	draws from shuffled list, otherwise 
// 	just random draws, so will get repeats.
// ## LISTPROCESS;; int_0_linear_1_random_more_num2rand_draw;;
// 		"name_of_itterated_item_in_list_sets_global" 
	// 	;; globListname ;; txt to preprocess & add PER item ## 
	gGlobalThis.if_var=0; 
	gGlobalThis.if_var2 =1;
	gGlobalThis.tmpTestListProcess = "alphabet".split("");
	gGlobalThis.tmpy_list = [];

	gGlobalThis.tmp_global_convo_test = " Hello Navada,  @@!!a @@ I wanna see ## testzzz ##!!!";
	gGlobalThis.tmp_global_convo_test_funct = "should have seen several inputs and the term 'waffles2', and soon 'waffles' @@file_input,, 'waffles'@@ ##file_input;; 'waffles2'##";

	o.playerX = 4;
	await g_convo_run_BLOCKING(
		o, {}, 
`
a ('RIGHT' is as of writing this the 'goto-next' thing in the text!
  'LEFT' goes back if in same txt-block!)
## 0#? THIS IS HOW TO DO A COMMENT, QUESTION BLOCK (#?) == 0!!! ##
@@ display ,,caption,, TESTzzz@@ 

@@ set,, TESTING_IT_SET = 0 @@
@@ !!start @@
one
@@ goto_menu,, false,, "testing goto_menu... ",, 
		"Goto sub-convo :tmp_global_convo_test",,
		"Goto sub-convo funct :tmp_global_convo_test_funct",,	
		 "question1 gotoEnd :gotoEND
		   --run a testroll 'if' statement script :goto_testRoll
		   --ask1 goto1(run normally):goto1
		   --ask2 goto2(run normally2):goto2"  @@ 

@@ !!goto_testRoll@@
@@ ROLL ,, 1,, 50,, "otxtPlayer.y otxtPlayer.playerX",, 
 "testing ROLL(should file_input on PASS)" 
@? file_input,,"PASS" @@

@@ ROLL_SAVING ,, 1,, 50,, "otxtPlayer.y otxtPlayer.playerX",, 
 "testing ROLL_SAVING(should file_input on FAIL)" 
@? file_input,,"FAIL" @@

@@ !!goto1@@
@@ !!goto2@@

@@ set_list_item,, tmpy_list ,, 1,, "this set list item" @@
@@ display ,,"text",, tmpy_list.1@@ 

@@ !!block @@

@@ 0@? THIS IS HOW TO DO A COMMENT, QUESTION BLOCK (@?) == 0!!! 
	NOTE: BELOW FOR PREPROCESSING-LIST LIKE THIS -PULLS RANDOM ITEM-@@

testing prerprocess ## ### bb23 ### ## aaaaaaaaaaaaaa ## testzzz ## aaaaaaaaaaaaaaaa- ## testzzz ## aaaaaaaaaaaaaa- ## testzzz ## aaaaaaaaaaaaaaaaa ## testzzz ## aaaaaaaaaaaaaaaaaaaaaaaaaaaaa 

list linear ( param 2 ==0):
### LISTPROCESS;; 0;; "tmp_i";; tmpTestListProcess ;; "
     Give me a : -- ##tmp_i## -- " ###

list Random ( param 2 ==1):
### LISTPROCESS;; 1;; "tmp_i";; tmpTestListProcess ;; "
     Give me a : -- ## tmp_i## -- " ###

list Random with Number drawn 
( param 2 ==4,<list.len, so draw from shuffled list: ):
### LISTPROCESS;; 4;; "tmp_i";; tmpTestListProcess ;; "
     Give me a : -- ## tmp_i## -- " ###

list Random with Number drawn 
( param 2 ==30; > listlength, purely random):
### LISTPROCESS;; 30;; "tmp_i";; tmpTestListProcess ;; "
     Give me a : -- ## tmp_i## -- " ###

@@ @? display ,,text,, 27,, "= JOOOY, to the world!"@@ 

@@ TESTING_IT_SET <= 1 @? goto_next,, "!!block" @@

@@  display ,,caption,, 'WORLDS'@@ 

@@ !!block @@

string 
@@ set,, TESTING_IT_SET += 1 @@
@@ TESTING_IT_SET <= 2 @? goto ,, 1,, "start" @@

@@ !!gotoEND@@

`

, null, {});
	
	//oplayer, o_other, get_mlConvo_str, bool_reset_UNUSED, rm_OPTIONAL){

	//testing no_show rolls
	var tmpWinCount=0; 
	for(var i=0; i< 100; i+=1){
		tmpWinCount +=  await g_convo_Roll_CORE_sets_LASTROLL( 
   		{x:2,y:10},{z:10},//get_oroller_sets_global, 
		//get_orollerTarget_sets_global, 
			//sets->global vars 4 funct use,see above 
		3, //is_1playerVisible_2npcVisible_3hidden,
		50,  //getTargetNumbRoll, //can be dotnote str or int, 
			// 'oroller/Target' work in dotnote here! 
		100,
		["oroller.x","oroller.y","oroller.z"],
		"rolling for test!!!",
		1); // getHideRollVals_OPTIONAL  
		//getRolls, getStartTxt ));
	}
	file_input("Number of winning rolls (should be ~50):", tmpWinCount);


	file_input( progen_txt_preprocess( 
	{}, {}, "testing prerprocess ### file_input ;; 'type something' ### string", null, {}));

	file_input( progen_txt_preprocess( 
	{}, {}, "testing prerprocess ## if_var #? 1 < 2## ## if_var2 #? 'gonads'##  ## bb23 == 'testzzz' ##  ## ### bb23 ### ## string", null, {}));
	
	file_input( progen_txt_preprocess( 
	{}, {}, "testing prerprocess ## ### bb23 ### ## string", null, {}));
	
	
	//oplayer, o_other, get_mlConvo_str, bool_reset_UNUSED, rm_OPTIONAL)
	progen_seed_end();
}





//	@@ ROLL/ROLL_SAVING ,, 
//		int_is_1playerVisible_2npcVisible_3hidden,,
//		int_target_roll_numb,,
//		str_rolls_space_separated,, ("otxtPlayer.y varB etc")
//		str_start_txt @? ACTUAL STUFF @@
//--- try out below:
//	NOTE: by default, most dotnote/getparam that is pointing 
//			to a list will DRAW RANDOMLY FROM THE LIST!!!
//			(this allows RANDOM ENTRY PULLING!)
//		-- LOOPS: can make manually, like a while 
//			loop or for cmd, with gotos as brackets.
//		-- @@ !!tagname@@
//		-- @@ 0@?  comment, say whatever here! @@
//		-- @@ return,, 2/dotnote@@ -- return == 1 BREAKS!!!
//		-- @@ test == 1 @? ..CMD below... @@ WORKS!!!
//			-- IF statement (above!)
//			-- WILL -ALSO- SKIP NEXT BLOCK OF TEXT IF FALSE!
//		-- @@ set,, oplayer.blabla +=/=/-= "4" @@
//		-- @@ set_list_item;; list2set ;; itterator;; var2set2 @@
// 		-- @@ goto,, bool_reroll_script_for_new_convo_mid_convo,,  
// 			,,dot_not_tagname/!!dot_note_tagname(both work)@@
//			-- CAN USE TO REROLL SCRIPT MID SCRIPT!!!
//			-- CAN goto (run) global-cmd convoStrs from here
//		-- @@ goto_next,,
//			dot_not_tagname/!!dot_note_tagname(both work)@@
//			-- NO REROLLING WITH THIS ONE, USE 'goto'
//			-- CAN goto (run) global-cmd convoStrs from here
// 		-- @@ goto_prev,,
//			dot_not_tagname/!!dot_note_tagname(both work)@@
//			-- NO REROLLING WITH THIS ONE, USE 'goto'
//			-- CAN goto (run) global-cmd convoStrs from here
//		-- @@ goto_menu,, bool_rerollOnGoto,, describedtxt,, 
//		 	dotNoteMenuA(nxt 4 format),,
//		      	"ask1:goto1--ask2:goto2" etc. @@ 
//		      	<---- VIARDIC: will keep reading any # of entries 
//			---CAN goto (run) global-cmd convoStrs from here
//			---DEFAULT (esc pressed) == ENTRY 0!!!!
// 		--@@ display,,
//		     text/bg/bg_as_lastdraw/caption/clear/clear2strtbg,,
//		     	txt1,txt2(optional, added to txt1),txt3(optnl)...@@
//		-- @@ externalfunction @@<- ONLY USE IF ABSOLUTELY NEEDED!
//			(most control flow should be done internally
//				or via mml!

// :b: g_convo_run_BLOCKING :b:
// NOTE: for txt-blocks, LEFT/RIGHT goes to NEXT BLOCK!!!
async function g_convo_run_BLOCKING(
	oplayer, o_other, //set to: otxtPlayer & otxtOther (for dotnote)
	get_convo_str, bool_reset_UNUSED, rm_OPTIONAL){
	//setting global vars, also set in preprocessor 
	//	otxtPlayer=oplayer; otxtOther = o_other;
	//preprocess here
  try{
	get_convo_str = get_convo_str.trim();
	var tmpCaugth_convo_str = get_convo_str;
	
	get_convo_str = progen_txt_preprocess( 
 	  oplayer, o_other, get_convo_str, 
		bool_reset_UNUSED, rm_OPTIONAL);
	
	var tmpDispVars = { bg:rmloaded_last_draw,
		start_bg:rmloaded_last_draw, text_caption:"", timeout:null};
	//capture results, put them here... I think? 
	//	Not sure if I will use this...
	var tmpGenTextFromConversationToReturn = "";
	
	var tmpCmds = get_convo_str.split("@@");
	for(var i_c=0; i_c< tmpCmds.length; i_c+=1){
	 //////////DISPLAY STRS (every other @@ block! start:0)
	 if( i_c % 2 == 0){//even==string2disp(starts at 0, 1st==0)
		tmpCmds[i_c] = tmpCmds[i_c].trim()
		if(tmpCmds[i_c]==""){continue;}
		
		await gui_disp_txt_BLOCKING( 
			oplayer.x, oplayer.y,
				//<only relevent it used /w right disp
			"gui_disp_width", "gui_disp_height",  
			gConf.textMmlGui, //see docs, are global vars
			tmpCmds[i_c], //display
			tmpDispVars.bg,// background,
			tmpDispVars.text_caption, //caption
	 		true, //keyboard keys/mouse, or just timeout
			false); //timeout_for_keypress_on_OPTIONAL
		  //phraseTimeout_OPTIONAL);		
		
	 //////////RUN CMD (every other @@ block! start:1)
	 }else{ // is not an even cmd: so must be control flow!
	   if(tmpCmds[i_c].indexOf("!!") == 0||
			tmpCmds[i_c].indexOf("!!") == 1){ 
		continue;}// a TAG to goto!!!
	   var tmpCmdNIf = tmpCmds[i_c].split("@?");
	   //starting from 0 ONLY if there is only 1 item, else run 'if'
	   var i_c2 =0;
	   // IF TESTING (ROLL is an option for this...
	   if(tmpCmdNIf.length >1){
	     // test if A roll... then run it? (it's another 'if' test)
	     //@@ ROLL/ROLL_SAVING ,, 
	     //	   int_is_1playerVisible_2npcVisible_3hidden,,
	     //	   int_target_roll_numb,,
	     //	   str_rolls_space_separated,,("otxtPlayer.y varB etc.")
	     //	   str_start_txt @@
	     if(tmpCmdNIf[0].indexOf("ROLL")!= -1 ){
		var tmpDONTRollPassIf= false;
		if(tmpCmdNIf[0].indexOf("ROLL_SAVING") != -1){
			var tmpDONTRollPassIf= true; }
		tmpCmd = tmpCmdNIf[0].split(",,");
		if(await g_convo_Roll_CORE_sets_LASTROLL( oplayer, o_other, 
			//sets->global vars 4 funct use,see above 
		  progen_txt_preprocess_param( tmpCmd[1], 1),
			//is_1playerVisible_2npcVisible_3hidden,
		  progen_txt_preprocess_param( tmpCmd[2], 1),
			//getTargetNumbRoll, 
		  gConf.txtMmlGui_stnd_roll_max,
		  progen_txt_preprocess_param( 
			tmpCmd[3], 0).trim().split(" "), //getRolls, 
		  progen_txt_preprocess_param( tmpCmd[4], 1),
			//getStartTxt,
		  gConf.txtMmlGui_hide_roll_numbers)==tmpDONTRollPassIf){ 
			continue;}
	     //actual if test:
	     }else if(1!= progen_txt_preprocess_param(
		tmpCmdNIf[0],0,2)){continue;} 
	     		i_c2+=1; }
	   for(var i_c2=i_c2; i_c2 < tmpCmdNIf.length; i_c2 +=1){
	     var tmpCmd = tmpCmdNIf[i_c2].split(",,");
	     var tmpCmd_0_Trim = tmpCmd[0].trim();
	     if( -1 == " goto goto_menu goto_next goto_prev display set return set_list_item ".indexOf(tmpCmd_0_Trim )){
		if(tmpCmd_0_Trim ==""){ continue;}
		//run external cmd!
	   	for(var j =1; j< tmpCmd.length; j+=1){
			tmpCmd[j] = progen_txt_preprocess_param(tmpCmd[j],1); }
		await progen_txt_preprocess_param( tmpCmd[0], 0, 1)( //1== get funct
			oplayer, o_other, null, null, tmpCmd, rm_OPTIONAL);
	   	otxtPlayer = oplayer;	
		otxtOther = o_other;//restoring if changed
		continue;
	     }
	     var tmpGoto_tag = null; 
	     if(tmpCmd_0_Trim =="return"){
		return progen_txt_preprocess_param( tmpCmd[1]);
	     }else if(tmpCmd_0_Trim =="goto_menu"){ 
	     //processing Convo-specific cmds!!!
	     // gConf.textMmlGui, gConf.txtMmlGui_menu,
	     //
	     // @@ goto_menu,, bool_rerollOnGoto,, describedtxt,, 
	     // 	dotNoteMenuA(nxt 4 format),,
	     // 	"ask1:goto1,,ask2:goto2" etc. @@ 
	     // 	<-- VIARDIC: will keep reading any # of entries 
	     ///////////////////
	     /////////
	       var tmpQuestions =[]; var tmpGoToPerQuestion=[];
	       for(var i=3; i<tmpCmd.length; i+=1){
		 var tmp_QnAs = progen_txt_preprocess_param( 
			tmpCmd[i],1).split("--");
		 for(var i_q=0; i_q<tmp_QnAs.length; i_q+=1){
		    tmpQuestions.push(tmp_QnAs[i_q].split(":")[0].trim());
		    tmpGoToPerQuestion.push(
			tmp_QnAs[i_q].split(":")[1].trim());}}
	       //if( tmpCmd[1] =="MENU") //DEFAULT, could be blank
	       var tmpMenuConf2Use =gConf.txtMmlGui_menu; 
	       var tmpGotQ= await gui_menu_blocking(
			progen_txt_preprocess_param( tmpCmd[2], 1), 
			tmpMenuConf2Use, 
			tmpQuestions, 	//options
			null,
			null,
			tmpDispVars.bg); 
		//underlay_bg_gridstr_canuse__rmloaded_last_draw_OPTIONAL) 
	       if(tmpQuestions.indexOf(tmpGotQ) == -1){
			tmpGotQ =tmpQuestions[0];}
	       tmpGoto_tag =  '"' + tmpGoToPerQuestion[
				tmpQuestions.indexOf(tmpGotQ)] + '"';
	       tmp_goto_next_prev = 0;
	       tmpReroll_on_goto =progen_txt_preprocess_param( 
				tmpCmd[1], 1); 	
	    }else if(tmpCmd_0_Trim.indexOf("//") ==0 ){ continue;
	    }else if(tmpCmd_0_Trim == "goto" ){
		tmpReroll_on_goto = await progen_txt_preprocess_param( 
					tmpCmd[1],1);
		tmpGoto_tag=tmpCmd[2];  tmp_goto_next_prev = 0;
	    }else if(tmpCmd_0_Trim == "goto_next" ){tmpReroll_on_goto =0;
		tmpGoto_tag=tmpCmd[1];  tmp_goto_next_prev = 1;
	    }else if(tmpCmd_0_Trim == "goto_prev" ){tmpReroll_on_goto =0;
		tmpGoto_tag=tmpCmd[1];   tmp_goto_next_prev = -1;
	    }else if(tmpCmd_0_Trim == "set_list_item" ){
		progen_txt_preprocess_param( tmpCmd[1],0)[
		 progen_txt_preprocess_param( tmpCmd[2],1)] = 
			progen_txt_preprocess_param( tmpCmd[3],1);
	    }else if(tmpCmd_0_Trim == "display"){
		// gConf.textMmlGui, gConf.txtMmlGui_menu,
		//@@ display,,
		// text/bg/bg_as_lastdraw/caption/clear/clear2strtbg,,txt@@
		//
		var tmpDispCmd = tmpCmd[1].trim(); 
		var tmpTxt = "";
		for(var i_3=2; i_3<tmpCmd.length; i_3+=1){
			tmpTxt += await progen_txt_preprocess_param( 
					tmpCmd[i_3],1); };
		if(tmpDispCmd == "bg"){ tmpDispVars.bg = tmpTxt;
		}else if(tmpDispCmd == "text"){ 
		   await gui_disp_txt_BLOCKING( 
			oplayer.x, oplayer.y,
				//<only relevent it used /w right disp
			"gui_disp_width", "gui_disp_height",  
			gConf.textMmlGui, //see docs, are global vars
			tmpTxt, //display
			tmpDispVars.bg,// background,
			tmpDispVars.text_caption, //caption
	 		true, //keyboard keys/mouse, or just timeout
			false); //timeout_for_keypress_on_OPTIONAL
		  //phraseTimeout_OPTIONAL);
		}else if(tmpDispCmd == "bg_as_lastdraw"){ 
			tmpDispVars.bg = rmloaded_last_draw;
		}else if(tmpDispCmd == "caption"){ 
		    tmpDispVars.text_caption = tmpTxt;
		}else if(tmpDispCmd == "timeoutSet"){ 
			tmpDispVars.timeout = tmpTxt;
		}else if(tmpDispCmd == "clear" ||
		   tmpDispCmd == "clear2strtbg"){ 
			tmpDispVars.bg = ""; tmpDispVars.text_caption ="";
			tmpDispVars.timeout = null
			
			if(tmpDispCmd == "clear2strtbg"){
			 tmpDispVars.bg = tmpDispVars.rmloaded_last_draw;}}
	     }else if(tmpCmd_0_Trim =="set"){
		// Full- (oplayer.x = 23) Statements used, so one input...
		progen_txt_preprocess_param( tmpCmd[1], 1, 4); continue; }	
	     //handling if a goto was done!
	     if(tmpGoto_tag != null){
		var tmp_cmds_caught= tmpCmds;
		if(tmpReroll_on_goto){
			get_convo_str = progen_txt_preprocess( 
 	  			oplayer, o_other, tmpCaugth_convo_str, 
				bool_reset_UNUSED, rm_OPTIONAL);
			tmpCmds = get_convo_str.split("@@");
		}
	       //OK, gonna pull dot-note of it.
	         tmpGoto_tag = (await progen_txt_preprocess_param( 
				tmpGoto_tag, 1) + "").trim();
	       if(tmpGoto_tag.indexOf("!!") != 0){
			tmpGoto_tag = "!!" + tmpGoto_tag;}
	       tmpIndex=-1;
		for(var j2 =0; j2<tmpCmds.length; j2+=1){
			var j2_prime = j2;
			if(tmp_goto_next_prev == 1){ //goto next
				j2_prime = i_c + j2;
				if( j2_prime >= tmpCmds.length){
					j2_prime -= tmpCmds.length } }
			if(tmp_goto_next_prev == -1){ //goto next
				j2_prime = i_c - j2;
				if( j2_prime >= tmpCmds.length){
					j2_prime -= tmpCmds.length } }
			//file_input("TRACCCCCEEEE: ", 
			//	j2, tmpCmds[j2], tmpGoto_tag);
			if(tmpCmds[j2_prime].trim() == tmpGoto_tag){
				tmpIndex = j2_prime; break;} }
		if(tmpIndex!=-1){ i_c = tmpIndex;
		}else{
		 /////////////////////////////
		 //goto external cmd... RUN IT as a sub-cmd!
		 tmpGoto_tag = tmpGoto_tag.split("!!")[1];
		 var tmpSubConvoStr=
		      progen_txt_preprocess_param( tmpGoto_tag,1);
		 if( tmpSubConvoStr != null){
		   var tmpC1 = otxtPlayer; var tmpC2 = otxtOther;
		   await g_convo_run_BLOCKING(oplayer, o_other, 
			tmpSubConvoStr, bool_reset_UNUSED, rm_OPTIONAL);
		   otxtPlayer = tmpC1;	otxtOther = tmpC2;
		 }else{
		///////////////////////////TODO
		 file_input("goto tag in the following string not found in convo:" + tmpGoto_tag);} tmpCmds = tmp_cmds_caught; }
		} }
	}
    }
 }catch(e){
	file_input("ERROR IN g_convo_run_BLOCKING, PRESS ENTER TO SEE "
		+"ERROR-OUT (not super helpful) and again TO SEE CONVO!" );
	file_input( e);
	file_input(get_convo_str);
 }

}


// :b: convo_Roll_CORE :b:
var convoLASTROLL = false; //previous roll, fo

var oroller={}; var orollerTarget={}; //set on _convo_roll
var convo_roll_txt_divider= " ---- ";
var convo_roll_txt_dotNote_dot_divider= " -> ";
// NO STRUCT NEEDED FOR BELOW!!!
//
// NOT TESTED NON-PLAYER ROLLS... 

// WARNING: rmloaded MUST be loaded and a frame processed, or this 
// will NOT display anything.
async function g_convo_Roll_CORE_sets_LASTROLL( 
   get_oroller_sets_global, get_orollerTarget_sets_global, 
			//sets->global vars 4 funct use,see above 
		is_1playerVisible_2npcVisible_3hidden,
		getTargetNumbRoll, //can be dotnote str or int, 
			// 'oroller/Target' work in dotnote here! 
		getStandardRollMax,// 100, or 20, basically
			// the typicall roll amount! 
			// JUST ADDED THIS!!!
		getRolls, getStartTxt,
		getHideRollVals_OPTIONAL ){ 
	// SETS GLOBAL convo_Roll_LASTROLL TO PASS/FAIL!!!
	// 	RETURNS PASS/FAIL:
	oroller = get_oroller_sets_global; 
	orollerTarget = get_orollerTarget_sets_global;
	
	if(typeof getTargetNumbRoll == "string"){ getTargetNumbRoll =
		 progen_dotnote(getTargetNumbRoll); } 

	var tmpStdRoll=progen_d_roll(99);
	var tmp_no_available_rolls=false;

	// generating rolls/rollnames
	var tmpUsableRolls=[]; var tmpUsableRolls_names = [];
	for(var i=0; i< getRolls.length; i+=1){
		var tmpRollVal =progen_dotnote(getRolls[i]);
		//below will work for obj + inv name!
		if(tmpRollVal !=void null){tmpUsableRolls.push(tmpRollVal);
		  if(3 != is_1playerVisible_2npcVisible_3hidden){ 
			tmpUsableRolls_names.push(
			getRolls[i].split(":").pop()
			.split("oroller.").join("")
			.split("orollerTarget.").join("other.")
			.split(".").join(
				convo_roll_txt_dotNote_dot_divider) + 
			convo_roll_txt_divider + tmpRollVal 
			);
			if(getHideRollVals_OPTIONAL){
			  tmpUsableRolls_names[
				tmpUsableRolls_names.length-1]=
			  tmpUsableRolls_names[
				tmpUsableRolls_names.length-1]
				.split(convo_roll_txt_divider)[0];
			}
			} } }
	
	// getting chosen roll (NPC, player does not choose roll...)
	if(2 == is_1playerVisible_2npcVisible_3hidden){
		if(tmpUsableRolls.length ==0){
			tmp_no_available_rolls = true;
		     tmpUsableRolls_names.unshift("No available rolls!");
			 tmpUsableRolls.unshift(-99999); }
		var tmpChosenRoll =tmpUsableRolls[
			progen_d_roll(tmpUsableRolls.length-1)];  
		//test to see if roll is good enough..
		if(  tmpChosenRoll + tmpStdRoll >= getTargetNumbRoll ){ 
		   var tmp_passed = true; }else{ var tmp_passed = false;}}
	 
		

	
	 //getting roll if player...
	 if(3 != is_1playerVisible_2npcVisible_3hidden){
		//if non-pc drawing one roll, 
		if(2 ==is_1playerVisible_2npcVisible_3hidden){
		  var tmpRoll_i = progen_d_roll(tmpUsableRolls.length-1);
		  tmpUsableRolls_names=[tmpUsableRolls_names[ tmpRoll_i]];
		  tmpUsableRolls=[tmpUsableRolls[ tmpRoll_i]];  
		//if player:
		}else{
		  if(tmpUsableRolls.length ==0 ){
			tmp_no_available_rolls = true;
		     tmpUsableRolls_names.unshift("No available rolls!");
			 tmpUsableRolls.unshift(-99999);
		  }else{ 	
		   tmpUsableRolls_names.unshift("Don't Roll");
		    tmpUsableRolls.unshift(-99999);  }	
		}
		//roll menu (1 item if non-player)
		var tmpDispTxt__ = getStartTxt;
		if(getHideRollVals_OPTIONAL != true){	
		   tmpDispTxt__ = tmpDispTxt__ //descr text
			+"\n Roll Target: "+ getTargetNumbRoll; }
		

		//below is for disp pass/fail.
 		
		//tmpRoll_Name = await gui_menu_blocking( tmpDispTxt__ +
		//	+"\n Roll Target: "+ getTargetNumbRoll,
		//	 gConf.menu, ["a", "b", "c"] );


		//getHints_text_on_toggle_OPTIONAL,bg_OPTIONAL
		

	
		// LOOKS LIKE NEED TO PRE-LOAD ROOM...
		// SHOULD MODIFY FUNCT SO NOT NEEDED...
		var tmpRoll_Name = await gui_menu_blocking(
			tmpDispTxt__, 
			gConf.menu, 
			 //getGui_Menu_Object_NAME__SEE_EXAMPLES_FOR_DATA, 
			tmpUsableRolls_names, 	//options
			"",
			null,
			rmloaded_last_draw);	
			//using last draw...
		if(tmpRoll_Name ==-1){//don't roll
			tmpRoll_Name = tmpUsableRolls_names[0];}
		var tmpChosenRoll= tmpUsableRolls[
			tmpUsableRolls_names.indexOf(tmpRoll_Name)];
		
		//test to see if roll is good enough..
		var tmpRandRoll_amount = tmpChosenRoll + tmpStdRoll;
		if(  tmpChosenRoll + tmpStdRoll >= getTargetNumbRoll ){ 
		   var tmp_passed = true; }else{ var tmp_passed = false;}
	
		if(tmpUsableRolls_names.indexOf(tmpRoll_Name) ==0
			&& is_1playerVisible_2npcVisible_3hidden == 1 ||
			tmp_no_available_rolls){
		//auto-failed roll (didn't roll OR no rolls)
		    var tmpDispText ="Roll Failed"; 
		}else{ 
		   var tmpDispText =  "";
		   if(getHideRollVals_OPTIONAL != true){	
		      var tmpDispText ="Rolled " + tmpRandRoll_amount; }
		   if(tmp_passed == 1 ){ var tmpDispText =
			tmpDispText + "\nSuccess!"
		   }else{ var tmpDispText = tmpDispText + "\nRoll Failed"; }
		}
		
		//below is for disp pass/fail.
		await gui_disp_txt_BLOCKING( 
			0, 0,//<only relevent it used /w right disp
			"gui_disp_width", "gui_disp_height",  
			gConf.textMmlGui, //see docs, are global vars
			tmpDispText, 
			rmloaded_last_draw,// background,
			"", //caption
	 		true, //keyboard keys/mouse, or just timeout
			false); //timeout_for_keypress_on_OPTIONAL
	}
	//hidden roll (drawn randomly from rolls!
	if(3 ==is_1playerVisible_2npcVisible_3hidden){
	   if(tmpUsableRolls[ progen_d_roll(tmpUsableRolls.length -1 )]
		 + tmpStdRoll >= getTargetNumbRoll){
			tmp_passed= true;}else{tmp_passed =  false;};}
	convoLASTROLL = tmp_passed;
	return tmp_passed;
}

