//below is an example of what the data would look like, _rand_seed_int
// can be defined, dont_mod_vars sets vars to no be changed 
// groups are to set for the 
// 	'progen_list_all' --- WILL PROBABLY REDFINE NAME, /
// 		AS IT WORKS WITH ANY LISTS WITH obj[i].progen IN IT!
// 	Groups are single chars, a list of them(a-z, etc.) NO SPACES!


//API_TAG//
var _testproc_genable_data = [
	{ p_int__qqq:[1,100],
		qqq:0,
	  p_randseed:null }
];
	
//API_TAG//

// see example above to see how groups/etc. work.
//API_TAG//
//this one progens all OBJECTS/LARGE OBJECTS in room!
// EDIT: can now join rooms objs as well... tags: join_rooms rmloaded_join
function progen_obj_room(getRoom, 
	advance_or_reverses_c_by, /// advance or reverse random seeds by...
	progen_group_char_to_launch_OPTIONAL,
	getRoom_to_add_Room_too_OPTIONAL, noprogen_just_add_OPTIONAL,
	x_off_OPTIONAL, y_off_OPTIONAL ){ 
	
	//see progen_list_all
	if( noprogen_just_add_OPTIONAL == void null){
	    progen_obj_list( getRoom.objs, advance_or_reverses_c_by, 
		progen_group_char_to_launch_OPTIONAL, getRoom);
  	    progen_obj_list( getRoom.objs_large, advance_or_reverses_c_by, 
		progen_group_char_to_launch_OPTIONAL, getRoom); }
	if(x_off_OPTIONAL != void null){ 
	   var os = getRoom.objs_large; 
		for(var i=0; i< os.length; i+=1){o=os[i];
	       		o.x += x_off_OPTIONAL; o.y += y_off_OPTIONAL; }
	   var os = getRoom.objs; 
		for(var i=0; i< os.length; i+=1){o=os[i];
	       		o.x += x_off_OPTIONAL; o.y += y_off_OPTIONAL; } }
	if( getRoom_to_add_Room_too_OPTIONAL != void null){
	   Array.prototype.push.apply(
		getRoom_to_add_Room_too_OPTIONAL.objs, getRoom.objs);
	   Array.prototype.push.apply( 
	    getRoom_to_add_Room_too_OPTIONAL.objs_large, getRoom.objs_large);
	} return getRoom; }
//uses standard colgroups: NOT needed, can run on generic lists
function progen_obj_list( get_list,
	advance_or_reverses_c_by, progen_colgroup_char_to_launch_OPTIONAL,
	get_roomOptional){
	
	// returns nothing (TENDS TO MODIFY LIST, SO POSSIBLY COPY FIRST?)
	// runs 'progen' for every object in a list 
	// ( in a rmloaded_room, will do the same) 
//API_TAG//
	//catching in case room is modified
	var caught_objs = get_list.concat();

	var len = caught_objs.length;
	if(progen_colgroup_char_to_launch_OPTIONAL != void null){
		for(var i=0; i< len; i+=1){ 
		  var tmp_obj = caught_objs[i];
		  if(tmp_obj.colgroup == void null){continue;}
	   	  if(tmp_obj.colgroup
		   .indexOf(progen_colgroup_char_to_launch_OPTIONAL)==-1){ 
			continue;}	 	
	  	  progen_obj(tmp_obj, tmp_obj, get_roomOptional,
			  advance_or_reverses_c_by);
		}
	}else{
	for(var i=0; i< len; i+=1){
	  progen_obj(caught_objs[i], caught_objs[i], get_roomOptional,
		  advance_or_reverses_c_by);
	} }
	return get_list;
}

//API_TAG//
// --- Below allows gridstrs of OBJs to be used to spawn objs
// 	based on chars in 'graphic' locations, and progens spawned objs. 
// --- this is an EASY way to procedurally generate crap in room locs
// 	(combines with rmwarp for big rooms, or thow an obj with 
// 		this in room!) 
function p_map2d( //OBJS_LARGE -ONLY- !!!! USES GRIDSTR AS MAP!!!
  obj_running, o, o_var2mod, time_UNUSED, cmd_params, getRoom){
	// cmd_params: {"a":[objGlobName_2gen1of], 
	// 		"b":[objsGlobName_2gen1of], etc.}
	// 	-- basically, a mml-style map generator. 
	//  GENERALLY USES GRIDSTER: p_map2d__graphic
	//  -- PROGENS -ALL- SUB-GRID OBJS!!!
	//progen_seed_init(rand_seed); <-- done in progen!
	var tmpMap_gridstr = o[o_var2mod];
	var tmpChars = Object.keys(cmd_params).join("");
	o[o_var2mod] = tmpMap_gridstr.replace(
		new RegExp("[" + tmpChars + "]", "g"), 	" ");

	var tmpWidth_pls_1 = gridstr_width( tmpMap_gridstr) + 1; 
			//pls_1 for linebreak
	for( var i_c = 0; i_c < tmpChars.length; i_c+=1){
		var tmpC = tmpChars[i_c];
		var tmpLast_i = tmpMap_gridstr.indexOf(tmpC);
		while(tmpLast_i != -1){
		   var tmpY_off = Math.floor( tmpLast_i/ tmpWidth_pls_1);
		   var tmpX_off = tmpLast_i - (tmpY_off * tmpWidth_pls_1); 

		   var tmp_o = JSON.parse( JSON.stringify( 
			  rmloaded_b_globalThis[ cmd_params[tmpC][ 
			    progen_d_roll(cmd_params[tmpC].length-1)]]));
			//make obj from list
		   tmp_o.x = tmpX_off + o.x; tmp_o.y = tmpY_off + o.y;
		   if(tmp_o.graphic.length ==1){ getRoom.objs.push( tmp_o);
		   }else{getRoom.objs_large.push( tmp_o);  }
			
		   progen_obj(  tmp_o, tmp_o, getRoom );

		   var tmpLast_i=tmpMap_gridstr.indexOf(tmpC, tmpLast_i+1);
	}	}
	//progen_seed_end(rand_seed);
}
//API_TAG//

//for customizing motifs, that 
//really should do with seperate observers, 
//not different functions!
//API_TAG//
var progen_obj_globalThis=this;
// now in global namespace, use p_FUNCTNAME to avoid namespace cols. 
function p_int(
  obj_running, o, o_var2mod, time_UNUSED, cmd_params, rm_OPTIONAL){
	// cmd_params: 0= min,1=max
	// 	( TAKES LIST OR OBJ: {0:120, 1:200} or [120,200])
	//progen_seed_init(rand_seed); <-- done in progen!
	o[o_var2mod] =cmd_params[0]+progen_d_roll(cmd_params[1]);
	//progen_seed_end(rand_seed);

}
/*
 = {
	// Can use:'l' to run a progen function later than others:
	// 	'p_l_funct__var'(late) , 
	// or 'p_l_l_l_funct__var', etc. 
	"int":function( 
		
		// 	LOOKS LIKE: cmd_params  CAN BE lists OR objs!
	obj_running, o, o_var2mod, time_UNUSED, cmd_params, rm_OPTIONAL){
		// cmd_params: 0= min,1=max
		// 	( TAKES LIST OR OBJ: {0:120, 1:200} or [120,200])
		//progen_seed_init(rand_seed); <-- done in progen!
		o[o_var2mod] =cmd_params[0]+progen_d_roll(cmd_params[1]);
		//progen_seed_end(rand_seed);
	}

};
*/
var progen_obj_ITTERATOR_STEP = 101;
// VAR FORMAT: p_u_int__varname ( p then l/u or function name, double __ 
// 		and varname (varname can contain _)
// 		'u' is for if 'undefined', then runs, 
// 		'u' MUST be after 'l's!
var _progen_obj_cmds_catch = {"p_randseed":0,"p_objname":0};//0 means ignore, 
	// typically, it would be a list of commands to launch 
	// [0:late_depth, 1:full_varname, 2:pgen_cmd_name, 3:var_2_mod,
// 		4:only_run_if_var_undef ]
//


////////////////////
// like Object.assign, (shallow copy)
////////////// (reflects from _update_os_obj_join, as I can make c-specific 
//////////////////////
//function progen_obj_join( obj, obj_pull_vars ){
//
// Object.assign NOW SHOULD WORK, see below (added it to C)
// 	It's more versitile and likely very close to this in speed. 
// 	-- Object.assign CAN MERGE MULTIPLE OBJS AT ONCE, 
// 		LIKELY FASTER THAN THIS!!!
var progen_obj_join = progen_CORE_obj_join;


// MY OWN OBJECT.ASSIGN ( performs SHALLOW COPY): 
// 	Object.assign( obj_to_set, obj_get_vars_from)
// -- "progen_obj_join" is -slightly- faster, 
// 	THIS CAN HANDLE MERING ONE OBJ WITH MULTIPLE!!!
if(Object.assign == void null){  //for duktape/C version!
	Object.assign = progen_CORE_obj_ASSIGN; }


////SHALLOW COPIES obj_pull_vars from!
//	(basically, applys obj_pull_vars to all objs in a list!
//	(returns list)

//	------------------------------------
//	WORKS WITH ROOMS AS LIST ITEMS, TOO!!!
function progen_mix_list(  tmp_list, recipe){ //obj/rmsList
// for LIST, rms/objs can be stringified, will mix then be re-stringified
//	CAN ADD OBJS TO RMLIST WITH THIS!!! (put rms in recipe!)
//API_TAG//
	for(var i=0; i< tmp_list.length; i+=1){
		var tmpStrify = false;
		if(typeof tmp_list[i] == "string"){
			var tmpStrify = true;
			tmp_list[i] = JSON.parse(tmp_list[i]); }
		progen_mix(tmp_list[i], recipe );
		if(tmpStrify){ tmp_list[i] =JSON.stringify(tmp_list[i]);}
	}
}

//convenient method of 'JSON.stringify', MODIFIES LIST!!!
function progen_mix_stringify( getObj_or_ObjList){
	if(Array.isArray(getObj_or_ObjList)){
	  for(var i=0; i< getObj_or_ObjList.length; i+=1){
	    getObj_or_ObjList[i] = JSON.stringify( getObj_or_ObjList[i]);
	  } return getObj_or_ObjList;
	}else{ return JSON.stringify( getObj_or_ObjList)};
}

// put in a global var to pull from, so can 'pre-mix' 
function progen_mix_pregen_list_from_recipe( 
		recipe, numb_items, rand_seed_OPTIONAL){
	progen_seed_init(rand_seed_OPTIONAL); 
	var retList = [];
	for(var i = o; i< numb_items; i+=1){
		retList.push( progen_mix( {}, recipe)); }
	progen_seed_end();  
	return retlist
}

// NOT for progen_mix-ing with p_mix in progen!
// 	this is ONLY if I need to merge 2 objs (NOT fastest method!)
// 	see main progen_mix for faster method!
function progen_mix_join_obj(obj, objpullvarsfrom, copy_original_OPTIONAL){
	if(copy_original_OPTIONAL){
		obj = JSON.parse(JSON.stringify(obj));}
	progen_CORE_obj_join( obj, objpullvarsfrom);
	return obj; }
// this just reflexts p_mix
// ALL MIX-ITEMS SHOULD BE EITHER NAMES FOR GLOBAL NAMESPACE TO 
// 	OTHER ITEMS/LISTS, OR STRINGIFIED OBJS! (can just write them out!)
// 	It's important because I join the objs. and split them appart
// 	via .join().split("}{").join(","), so '}' and '{' need to be at 
// 		ends of objects!
// 	(modifies existing obj, returns nothing!)
// OK, current incarnation:
// 	pulls from global vars or lists. (lists:pulls rand item)
// 	(dot notation works, but is slower):
// 	"obj1 db.tag.obj_str_param obj2 ..."
// 	NOTE: the data format it's looking for is Stringified objs
// 		(can write by hand, if desired, or use JSON.stringify.. )
// 	BE SURE TO START/END TARGET DATA-STRINGS WITH '{' and '}',
// 	IT USES STRING OPERATIONS TO MERGE!!!
// NOTE: progen_mix_join_objs is for a simple obj-join, not super fast!
// --------------------------------------
// 	------------USE :      progen_mix_stringify()--- 
// 	TO CREATE GLOBAL OBJ-LISTS FOR MIXING!!! (RECIPE INGREDIENTS!!!)
// 	----WILL MIX ROOMS!!! (combines objs/any lists in rm!!!)
function progen_mix( obj, recipe, _DONTSET_recursive_retlist){
	if(_DONTSET_recursive_retlist == void null){ 
	  if(obj.objs_large!=void null){return 
		progen_mix_obj_joinlistvars(obj,recipe);}
	  var retList= [];
	}else{ retList = _DONTSET_recursive_retlist; } //pointer intact

	recipe= recipe.split(" ");
	for(var i=0; i< recipe.length; i+=1){
		
		var ingredient = p_mix_globalThis[ recipe[i] ];
		//if none found, try dot notation
		if( ingredient == void null){
		   ingredient =progen_dotnote( recipe[i]);
		   if( ingredient == void null){ continue;} }
		
		while( typeof ingredient != "string"){
		   while(typeof ingredient == "object"){ //ONLY takes lists
			var ingredient = 
			  ingredient[progen_d_roll( ingredient.length-1)]; }
		   if(ingredient == void null){ continue;}
		}
		
		//ingredient is now found string!	
		if(ingredient[0] == "{"){
			retList.push(ingredient);
			continue;	}
		// it's something else, try running this on list-i!
		progen_mix( obj, ingredient, retList);
	}
	//ONLY setting up list if from non-recursive call!
	if(_DONTSET_recursive_retlist == void null){
		if(retList.length ==0){ return void null;}
		if(retList.length ==1){ 
			progen_obj_join(obj, JSON.parse(retList[0]));
			return obj; }
		progen_obj_join( obj,
		    JSON.parse( retList.join("").split("}{").join(",")));
		return obj;
	}
}




// 	combines ANY lists in obj! (probably not super fast)
// FOR ROOMS: progen_mix redirects to THIS if objs_large var detected 
function progen_mix_obj_joinlistvars(tmp_rm, recipe){
	var tmpKeys= Object.keys( tmp_rm);
	var caught_lists = {};
	for(var i =0; i< tmpKeys.length; i+=1){
	  var tKey = tmpKeys[i];
	  if(Array.isArray( tmp_rm[tKey]) == 1 ){
		caught_lists[tKey] =  tmp_rm[tKey];
		tmp_rm[tKey] = void null; }	}
	
	progen_mix(tmp_rm, recipe); 
	
	var tmpKeys= Object.keys( caught_lists);
	for(var i =0; i< tmpKeys.length; i+=1){
	  var tKey = tmpKeys[i];
	  if(tmp_rm[tKey] == void null ){tmp_rm[tKey] = caught_lists[tKey];
	  }else{ tmp_rm[tKey] = tmp_rm[tKey].concat(caught_lists[tKey]);
	}	}
}

var p_mix_globalThis = this;
var p_mix_CATCH ={}; //data type:
// cmd_params is the string 'recipe'  
function p_mix( obj_running, o, o_var2mod, 
		time_UNUSED, cmd_params, rm_OPTIONAL){ //standard object 
//cmd_params=str:"100 {a:123, b:460, c:900} objName1 objName2 objName3 ..."
	progen_mix( o, cmd_params);
}

// optional_hist_neg1or1 : go forward to next ( use 1 ), or last history
// 	( use -1 ). This give an indefinite history/advance for progen.
//-------------------------------------------------------------------
// -------------- TRY TO KEEP PROGEN AND SIMILAR FUNCTIONS DOWN TO 
// ------------------ ONE OR TWO FUNCTIONS PER GEN_THING, 
// ------------------ (one funct is settup data) EVEN IF I HAVE TO CRAM 
// ------------------ A LOT INTO THOSE FUNCTIONS 
// ------------------ (this will cut down on API-digging and figuring 
// ------------------------- stuff out!!!) 
// ----------------------------------------------------------------- 
// BELOW rmloaded_room IS A DUMMY ROOM INCASE FUNCTIONS DON"T USE ROOMS!!!
if( typeof rmloaded_room != "undefined"){ rmloaded_room = {};}
function progen_obj(  o, o_apply_progen_too,  // o is ANY object data
	rm_optional_or_null, optional_hist_neg1or1, optional_time ){ 
	
	if(rm_optional_or_null == void null){ 
		rm_optional_or_null = rmloaded_room;}
	
	if(optional_hist_neg1or1 == void null){ optional_hist_neg1or1=0;}
	
	if(o.p_randseed == null){
		o.p_randseed = Math.floor( Math.random() *100000 );}	
	o.p_randseed += optional_hist_neg1or1 * progen_obj_ITTERATOR_STEP;
	progen_seed_init(o.p_randseed); 	

	//run p_mix FIRST if available:
	if(o.p_mix != void null){
		progen_obj_globalThis["p_mix"]( o, o_apply_progen_too, 
		   void null, void null, o.p_mix, rm_optional_or_null  );
		var keys = Object.keys(o); 
		keys.splice(keys.indexOf("p_mix"),1);
	}else{  var keys = Object.keys(o); }
	//before above was: 
	//var keys = Object.keys(o);

	var list3d_late_cmdslist_cmds = [[]];
	for( var i =0; i< keys.length; i+=1){ 
		var cmds_i = _progen_obj_cmds_catch[ keys[i]];
		if( cmds_i == void null){
			var tmp_words = keys[i].split("_");
			if(tmp_words[0] != "p"){ 
				_progen_obj_cmds_catch[ keys[i]] = 0;
				continue;}
			
			var tmp_cmds = [0]; //late depth [0]
			var j=1; 
			while( tmp_words[j] == 'l'){ tmp_cmds[0]+=1; j+=1;}
			//NEW
			var run_only_if_undef= 0;
			if( tmp_words[j] == 'u'){j+=1; run_only_if_undef=1;}

			tmp_cmds.push(keys[i]); // full varname [1]
			tmp_cmds.push("p_"+tmp_words[j]);//command_name [2]
			tmp_cmds.push(tmp_words.slice(j+2).join("_"));
			tmp_cmds.push(run_only_if_undef);
				//var to modify. [3]
			if(progen_obj_globalThis[tmp_words[j]] == void null){
				/////////////////////////////////////
				///COMMAND NOT FOUND!!!
				///////////////////////////////////////
			}
			
			_progen_obj_cmds_catch[ keys[i]] = tmp_cmds;
			cmds_i = tmp_cmds; 
		}

		if( cmds_i == 0){ continue; } 
		while( cmds_i[0] >= list3d_late_cmdslist_cmds.length){
			// cmds_i[0] == late_depth
			list3d_late_cmdslist_cmds.push([]);} 
		list3d_late_cmdslist_cmds[cmds_i[0]].push(cmds_i);
	}
	
	// tmp_cmds == _progen_obj_cmds_catch[varname]:
	// [0:late_depth, 1:full_varname, 2:pgen_cmd_name, 3:var_2_mod]	
	for(var i=0; i< list3d_late_cmdslist_cmds.length; i+=1){
		var cmdslist_i = list3d_late_cmdslist_cmds[i];
		for(var j =0; j<cmdslist_i.length; j+=1){
			var tmp_cmds = cmdslist_i[j]; 
			//NEW
			if( tmp_cmds[4] == 1){ //run if var undef; 'u'
				if(o[tmp_cmds[3]] != void null){
					_progen_seed_i++; continue; }}

			progen_obj_globalThis[tmp_cmds[2]]( //pgen_cmd_name
			    o, o_apply_progen_too, tmp_cmds[3], //var_2_mod
				optional_time, 
			    o[tmp_cmds[1]], //full_varname
				rm_optional_or_null  ); 
			_progen_seed_i++;
	}	}
	
	progen_seed_end();
}


function progen_obj_ml(o, o_a,//o_apply_progen_too,  // o is ANY object data
   r,h,t){//rm_optional_or_null, optional_hist_neg1or1, optional_time){
	progen_obj(o.mml, o_a.mml, r, h, t); 
	progen_obj(o.mml.cmds, o_a.mml.cmds, r, h, t);
}

