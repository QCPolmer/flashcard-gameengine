//requires rmloaded_search.js!!!


//API_TAG//
var rmloaded_enter_allrms_behavs = void null;//= []; //RUNS IN -ALL- ROOMS
var rmloaded_update_allrms_behavs = void null; //= [];//RUNS IN -ALL- ROOMS
var rmloaded_leave_allrms_behavs = void null; //= []; //RUNS IN -ALL- ROOMS

var rmloaded_room= {objs:[], objs_large:[], //next params are optional!!!
	enter_behavs:[],update_behavs:[],leave_behavs:[], room_type:"_2d"};
  // above -IS- running room. Unless loading full room, can edit. 
  // 'behavs' above = lists of behavior names (uses same behavpool as objs)
var rmloaded_firstRmLoaded_stringified = void null; //for g_gamereset()
var _rmloaded_signal_sets_with_loadroom = null;

//frames don't end on rmload_loadroom, runs till end of frame, this 
//	see if as of running, WILL loadroom next frame
function rmloaded_loadroom_is_loading_right_now(  ){
	if(_rmloaded_queue.length ==0){ return false;}
	var tmp_rmloaded_queue_i = _rmloaded_queue[0];
	if(tmp_rmloaded_queue_i.delay == 0){ return true; } 
	if(tmp_rmloaded_queue_i.delay == null){ return true; } 
	return false;
}

// signal can be ANYTHING, STAYS SET UNTIL SET on RMLOAD (below!)
// 	(so transfers between rooms (assuming not set in rmloaded))
function rmloaded_signal_sets_with_loadroom__get( 
		getBoolReset_signal,	getSetToo_OPTIONAL ){
	var tmpR = _rmloaded_signal_sets_with_loadroom;
	if( getBoolReset_signal){_rmloaded_signal_sets_with_loadroom=null;}
	if(getSetToo_OPTIONAL!= null){ _rmloaded_signal_sets_with_loadroom=
		getSetToo_OPTIONAL;}
	return tmpR;}

//mostly for level editor
var rmloaded_IS_LEVEL_SWITCHING_DISABLED = false;
function rmloaded_DISABLE_SWITCHING_LEVELS( 
		getBool_Set_is_level_switching_disabled ){
	rmloaded_IS_LEVEL_SWITCHING_DISABLED = 
		getBool_Set_is_level_switching_disabled;
}

var _rmloaded_queue = [];
// loads at END of frame, can test with:
// 	 rmloaded_loadroom_is_loading_right_now
function rmloaded_loadroom( getRoom_OR_NEXT_RM, //ussually, only need this
	   // "NEXT_RM" for 'goto nxt room in queue'(skip delay)... 
	OPTIONAL_dontRunEnterLeaveBehavs,
	getF_OPTIONAL,//frames delay_till_run_loadroom_neg1_for_indefinite
	   //getF_OPTIONAL == null- CLEARS STACK(breaks chain), LOADS RM!
	   // // can chain these together, and runs one after another
	getS_OPTIONAL){ //_rmloaded_signal setsOnLoadroom(signal==anything)
		// signal remains set until set to anything but 'null'
		// get/unset with:rmloaded_signal_sets_on_loadroom__get
	//sets up for running at END of game loop, SEE BELOW,
	if(rmloaded_IS_LEVEL_SWITCHING_DISABLED){ return;}
	if(getRoom_OR_NEXT_RM =="NEXT_RM"){ if(_rmloaded_queue[0]==null){
	    file_input("ERROR with rmloaded_loadroom('NEXTRM')que empty");}
	   _rmloaded_queue[0].delay =null; return; }
	if(getF_OPTIONAL == null){ _rmloaded_queue=[];}
	_rmloaded_queue.push({room:getRoom_OR_NEXT_RM, 
		delay:getF_OPTIONAL,
		dontRunEnterAndLeave: OPTIONAL_dontRunEnterLeaveBehavs,
		rmloaded_signal_sets_on_loadroom: getS_OPTIONAL});}

async function _rmloaded_loadroom_CORE( ){ 
	//UPDATED 1/21/2026- now has a queue-room delayed - 
	//		chaining option & can send signals 2 nxt rm
	var tmp_rmloaded_queue_i = _rmloaded_queue[0];
	if(tmp_rmloaded_queue_i.delay != 0 
	   && tmp_rmloaded_queue_i.delay != null){
		tmp_rmloaded_queue_i.delay -=1; return;}
	_rmloaded_queue.shift();

	if(tmp_rmloaded_queue_i.rmloaded_signal_sets_on_loadroom != null){
		_rmloaded_signal_sets_with_loadroom = 
		  tmp_rmloaded_queue_i.rmloaded_signal_sets_on_loadroom;}

	 //returns nothing //API_TAG//	
	if(rmloaded_firstRmLoaded_stringified == void null){
	    rmloaded_firstRmLoaded_stringified = 
		JSON.stringify(tmp_rmloaded_queue_i.room);}

	await _rmloaded_runrmbehavs(rmloaded_room, 
		rmloaded_leave_allrms_behavs);
	if(1 != tmp_rmloaded_queue_i.dontRunEnterAndLeave){
	   await _rmloaded_runrmbehavs(rmloaded_room, 
		rmloaded_room.leave_behavs);}
	controllers_clear_pressed();
	_rmloaded_launch_game_obs = []; 
	_rmloaded_launch_game_large_objs =[]; 

	rmloaded_room = tmp_rmloaded_queue_i.room;
	
	_rmloaded_overlay_buffer = [];
	_rmloaded_draw_last_buffer = [];
	_rmloaded_draw_first_buffer = [];
	await _rmloaded_runrmbehavs(rmloaded_room, 
		rmloaded_enter_allrms_behavs);
	if(1 != tmp_rmloaded_queue_i.dontRunEnterAndLeave){ 
	 await _rmloaded_runrmbehavs(rmloaded_room, 
		rmloaded_room.enter_behavs);}
	
}
async function _rmloaded_runrmbehavs( rm, bhvs ){ // bhvs = behavs_list_or_NULL
	if( bhvs == void null){ return;}
	for(var i=0; i <bhvs.length; i+=1){
		await rmloaded_b_globalThis[bhvs[i]](rm);}
}
 
function rmloaded__update_cols__SLOW_4_USE_B4_RMFULLYLOADED(){
	//---TYPICALLY, collision testing SETTUP IS HANDLED IN UPDATE-LOOP!
	// 	I made this for before room fully loaded for warping. 
	// 	Probably will work if an update REALLY needed, but SLOW.
//API_TAG//
	rmloaded_col_test_settup_xy_n_lrg_list();//reset lookup
 	rmloaded_settup_lookup_props_obj(rmloaded_room.objs_large);
	rmloaded_settup_lookup_props_lrg(rmloaded_room.objs);
}


//API_TAG//
//	EDIT: rmloaded_get is no longer used... I think...
// USE BELOW AS rmloaded_get(), for loading a room, use rmloaded_loadroom
// (can edit data in this object. ) 
//
// EXAMPLE OF OBJ_LARGE: (obj small would have single char graphic)
//{x:14, y:20, behavior:"b_none", graphic:"######\n0000###", 
//	colgroup:"z0", ignore_pause:false, draw_1late_2last:2, dead:0,
//		progen:{ // progen can be undefined 
//			recipe:"gen_anim -anim_name test -anims_to_use test_anim2||test_anim2 -max_min_len 4||2", 
//		_rand_seed_int:null, dont_mod_vars:"x", groups:"!" } 
//API_TAG//

//behaviors, now at global namespace,
// SHOULD START BEHAVIORS WITH 'b_FUNCTNAME', TO AVOID NAMESPACE COLS!!
var rmloaded_b_globalThis =this;
async function b_none(obj){};
async function b_test_NULL(getObj){ //API_TAG//
		file_input("Balls");
		//getObj.y +=1;
		//file_input(_rmloaded_lookup_xlocs[10]);
		//return;
		//file_input(rmloaded_col_test1( getObj.x, getObj.y+1, "0").length);
		//file_input(rmloaded_col_test2( getObj.x, getObj.y+1, "0"));
		
	};
async function b_test2(getObj){
		//getObj.y +=1;
		//file_input(_rmloaded_lookup_xlocs[10]);
			getObj.y +=1;
		rmloaded_draw_overlay("testroom_objs.len"+testRoom.objs.length,0 ,2, "");
		rmloaded_draw_overlay("fps :"+(1000/_update_delta),0 ,3, "");
	};
///////////////////////////////////////////////
////////////////////////
///////////////////////////////////////////
//API_TAG//
/*
 *
TODO: delete below, probably, this is old and no longer used,
		I think. I think this is added to global namespace
		
var rmloaded_b_globalThis = { //add new behaviors to this 	
	//EG:rmloaded_b_globalThis.EXAMP= async function(o){ ... }
	// NOTE one bahavior can run inside another as a funct(eg:behav(o)) 
	//, runs every rmloaded_launch_game
	"test_NULL": async function(getObj){ //API_TAG//
		file_input("Balls");
		//getObj.y +=1;
		//file_input(_rmloaded_lookup_xlocs[10]);
		//return;
		//file_input(rmloaded_col_test1( getObj.x, getObj.y+1, "0").length);
		//file_input(rmloaded_col_test2( getObj.x, getObj.y+1, "0"));
		
	},
	"test2": async function(getObj){
		//getObj.y +=1;
		//file_input(_rmloaded_lookup_xlocs[10]);
			getObj.y +=1;
		rmloaded_draw_overlay("testroom_objs.len"+testRoom.objs.length,0 ,2, "");
		rmloaded_draw_overlay("fps :"+(1000/_update_delta),0 ,3, "");
	},
	"b_none": async function(obj){}
};
*/

// this should be how I declare behaviors: it's portable, AND 
//  it allows the debugger to work. 
async function behav_test( o ){
	//if( rmloaded_col_GET_OBJ( o.x, o.y+1, "0")==null){
	//rmloaded_draw_last(o);
	if( rmloaded_col_test_SIMPLE( o.x, o.y+1, "0")==""  ){
			o.y +=1;	}
} 
async function behav_test3( o ){
			o.y +=.1;
	rmloaded_camera_focus(o.x,o.y, 3, 3);
	//rmloaded_draw_last(o);
		//o.y-=1;
} 

//
var _rmloaded_launch_game_objs=[];  // will be set to room val per-turn
	// clear when changing rooms
var _rmloaded_launch_game_objs_large=[]; // will be set to room val per-turn
	


var rmloaded_camera_offset_x = 30;
var rmloaded_camera_offset_y = -9;

//API_TAG//
function rmloaded_room_destroy_objs_with_prop(get_room, get_propName){
// see rmloaded_filter_list_objs below
//API_TAG//
	var tmpObjs = rmloaded_room_get_filtered_objs(get_room, get_propName);
	for(var i=0; i<tmpObjs.length; i+=1){
		tmpObjs[i].dead = true; 
		//not sure if below is needed, but I figure, why not?
		tmpObjs[i].behavior = "b_none";
		tmpObjs[i].colgroup = ""; }	}
//API_TAG//
function rmloaded_filter_list_objs(a){ return a[this] != void null; }
// 'this' = get_propName
// 	examples: objs_list.filter(rmloaded_filter_list_objs, "prop_name")
// get_game.objs.filter(rmloaded_filter_list_objs,  get_propName )
function rmloaded_room_get_filtered_objs(get_room, get_propName){
	//filter by prop name
//API_TAG//
	return get_room.objs.filter(rmloaded_filter_list_objs, get_propName)
	 .concat( get_room.objs_large.filter(
		 rmloaded_filter_list_objs, get_propName));}



//API_TAG//
function rmloaded_camera_focus(x,y, x_limit, y_limit){ //returns nothing
	//focuses (moves) camera to location, x_limit and y_limit are a 
	// 'box' around camera that the 'x/y' will stop at. 
	//
	// rmloaded_camera_offset_x and rmloaded_camera_offset_y
	// can be set to offset camera (move focus to left/right/up/down)
//API_TAG//
	// FOR DEBUGGING: this should NOT move the camera if in limit
	x = Math.floor(x); y = Math.floor(y);
	_rmloaded_camera_x_FOCUS = x; _rmloaded_camera_y_FOCUS = y;	
	x=x-rmloaded_camera_offset_x; y = y+rmloaded_camera_offset_y;
	
	if(x + _rmloaded_camera_x > x_limit){ 
		_rmloaded_camera_x = -(x - x_limit);
	}else{ if(x + _rmloaded_camera_x < -x_limit){
			 _rmloaded_camera_x = -(x + x_limit);   }	}
	if(y + _rmloaded_camera_y > y_limit){ 
		_rmloaded_camera_y = -(y - y_limit);
	}else{ if(y + _rmloaded_camera_y < -y_limit){
			 _rmloaded_camera_y = -(y + y_limit);  }	}
}
// to center 'view' area/dist! (shadow shit)
var _rmloaded_camera_x_FOCUS =0;
var _rmloaded_camera_y_FOCUS =0;

var _rmloaded_camera_3d_tilt = .2;
var _rmloaded_camera_3d_x =0; 
var _rmloaded_camera_3d_y =0; 
var _rmloaded_camera_3d_z =.2; 
var _rmloaded_camera_3d_rot = .2; 
//API_TAG//
function rmloaded_camera_3d_set(x,y, z, rot, tilt ){ //returns nothing
	//the above is self explanitory, the one thing that isn't is:
	// rot left/right, tilt is up/down
//API_TAG//
	// FOR DEBUGGING: this should NOT move the camera if in limit
	_rmloaded_camera_3d_x = x;_rmloaded_camera_3d_y = y ;_rmloaded_camera_3d_z = z; 
	_rmloaded_camera_3d_tilt = tilt; _rmloaded_camera_3d_rot = rot;
	//OK, now shifting 'camera' bit, EG: focusing on 
	// area, so IF using shadows, screen will be centered!
	rmloaded_camera_focus(x,y, 1, 1);

	//_rmloaded_camera_x_FOCUS = _rmloaded_camera_3d_x;
	//_rmloaded_camera_y_FOCUS = _rmloaded_camera_3d_y;
	// NEEDED for 3d-shadow-renderer!
	//_rmloaded_camera_x = _rmloaded_camera_x_FOCUS + draw_canvas_get_width()/2;
	//_rmloaded_camera_y =  _rmloaded_camera_y_FOCUS - draw_canvas_get_height()/2;
}
// UNTESTED!!! shoud 'zoom' camera to location (with offset) 
// 	//this will bounce back and forth from around the target location
//  and return true once there.
//  (should be run 1x per frame)

//API_TAG//
function rmloaded_camera_zoom_too( x, y,  speed){ 
	// UNTESTED zooms with limit speed towards location 1x per frame
	// returns true when at location. //API_TAG// 
	x = Math.floor(x); y = Math.floor(y);	
	x = x-rmloaded_camera_offset_x; y = y+rmloaded_camera_offset_y;
	_rmloaded_camera_x_FOCUS = x; _rmloaded_camera_y_FOCUS = y;
	var ret_me = 0;
	if(Math.abs(x - _rmloaded_camera_x) < Math.abs(speed)){ 
		_rmloaded_camera_x = x; ret_me+=1;
	}else{
		if(x + _rmloaded_camera_x > 0){ 
			_rmloaded_camera_x -= speed; 
		}else{ if(x + _rmloaded_camera_x < 0){
			 _rmloaded_camera_x += speed;    }	} }
	if(Math.abs(y - _rmloaded_camera_y) < Math.abs(speed)){ 
		_rmloaded_camera_y = y; ret_me+=1;
	}else{
		if(y + _rmloaded_camera_y > 0){ 
			_rmloaded_camera_y -= speed; 
		}else{ if(y + _rmloaded_camera_y < 0){
			 _rmloaded_camera_y += speed; }	} }
	if( ret_me ==2){ return true;}
	return false;
}

//API_TAG// 
// DO NOT REDEFINE!!!
// use: rmloaded_camera_focus or rmloaded_camera_zoom_too
var _rmloaded_camera_x = 3;
var _rmloaded_camera_y = 5;
// below is a continuation, for 3d,
// DO NOT REDEFINE!!! USE rmloaded_camera_3d_set!
var _rmloaded_camera_tilt = 0;
var _rmloaded_camera_z =0; 
var _rmloaded_camera_rot = 0; 
//API_TAG//

//API_TAG//
var rmloaded_paused = false;  // pauses objects that dont ignore 
var rmloaded_last_draw = "";

var _rmloaded_overlay_buffer=[]; // b= "" or transp_char, t = txt_grid
//API_TAG//

//API_TAG//
function rmloaded_draw_overlay( t, x,y, b){ //returns nothing
	//runs a draw call AFTER game draw call, on t (text) //API_TAG//
	_rmloaded_overlay_buffer.push( t, x,y,b);	}
// Draws lower than normal draw
//API_TAG//
function rmloaded_draw_overlay_lower( t, x,y, b){ //returns nothing
	//see rmloaded_draw_overlay for descript
	_rmloaded_overlay_buffer.unshift( t, x,y,b);	}
// for drawing objects FIRST, (basically just large ones) 
//  add them to the front of the 'obj-list-large' 
//  As it's rendered in order.
//API_TAG//

//API_TAG//
// same as below function, but defines room (and injects draw-last)
//  ALSO: no need to async!
//  (should be easy enough to copy below and 'async' it for 
//  sub-rooms.
function rmloaded_sketch_all_objs_SEPARATE_ROOM(  //NO ASYNC!!!
	int_sketch_0_objs_1_lrg_objs_2_both, getRoom, camx, camy){
	// SEE BELOW FUNCTION FOR SAME-ROOM MINI-MAP-THING!!!
//API_TAG//
	camx = -camx; camy = -camy;
	// running behaviors 
	if(int_sketch_0_objs_1_lrg_objs_2_both != 0){
	   batch_SKETCH_n_updateloc_obj_LRG_list( 
		getRoom.objs_large, rmloaded_b_globalThis,
		camx, camy, true,// dont_UPDATE_any_objs
		_rmloaded_sketch_after_lrgobjs_buffer,_rmloaded_sketch_last_buffer);
	// for drawing lrg objs 'on top' of others. 
		batch_sketch_obj_list(_rmloaded_sketch_after_lrgobjs_buffer, 
			camx,camy); }
	_rmloaded_sketch_after_lrgobjs_buffer = [];
	// OK, should have an override for this ( for the drawing)
	if(int_sketch_0_objs_1_lrg_objs_2_both != 1 ){
	  batch_SKETCH_n_updateloc_obj_list( 
	      getRoom.objs,  rmloaded_b_globalThis,
	      camx, camy, true,// dont_draw_any_objs EDIT: dont_UPDATE_...?
	     _rmloaded_sketch_after_lrgobjs_buffer,_rmloaded_sketch_last_buffer); }
	// last minute drawing
	batch_sketch_obj_list( _rmloaded_sketch_last_buffer, camx, camy );
	_rmloaded_sketch_last_buffer = [];
	_rmloaded_sketch_after_lrgobjs_buffer = [];
}


//API_TAG//
//
//This is basic, doesn't include shadow or overlays,
//but DOES include draw_1late_2last handling.
//so will work for a mini-map.
//NOTE
//there is a place place below where it is possible to update 
//objs, so it should be possible to rework this to draw a different room. 
// ----------------IMPORTANT: use 'await rmloaded_sketch_all_objs(...)!'
// --------------------------- no 'await', no run right!
async function rmloaded_sketch_all_objs( camx, camy){ //CENTERED on camx camy
	//SEE ABOVE FUNCTION FOR NO-ASYNC N SEPERATE ROOM!
//API_TAG//
	var w_half = sketch_get_width()/2; 
	var h_half = (sketch_get().length/(w_half*2))/2;
	camx = -camx+ w_half; camy = -camy+ h_half;
	// running behaviors 
	await batch_SKETCH_n_run_behave_n_updateloc_obj_LRG_list( 
		_rmloaded_launch_game_objs_large, rmloaded_b_globalThis,
		camx, camy,
		true,// dont_UPDATE_any_objs
		_rmloaded_sketch_after_lrgobjs_buffer,_rmloaded_sketch_last_buffer);
	// for drawing lrg objs 'on top' of others. 
	batch_sketch_obj_list( _rmloaded_sketch_after_lrgobjs_buffer,
		camx, camy);
	_rmloaded_sketch_after_lrgobjs_buffer = [];
	
	// OK, should have an override for this ( for the drawing)
	await batch_SKETCH_n_run_behave_n_updateloc_obj_list( 
		_rmloaded_launch_game_objs,  rmloaded_b_globalThis,
		camx, camy,
		true,// dont_draw_any_objs
		_rmloaded_sketch_after_lrgobjs_buffer,_rmloaded_sketch_last_buffer); 
	// last minute drawing
	batch_sketch_obj_list( _rmloaded_sketch_last_buffer,
		camx, camy );
	_rmloaded_sketch_last_buffer = [];
	_rmloaded_sketch_after_lrgobjs_buffer = [];
}

var _rmloaded_draw_after_lrgobjs_buffer = [];
//function rmloaded_draw_after_lrgobjs( obj ){ 
//	_rmloaded_draw_after_lrgobjs_buffer.push( obj); } 
var _rmloaded_draw_last_buffer=[];
//function rmloaded_draw_last( obj ){ _rmloaded_draw_last_buffer.push( obj); } 
 
function rmloaded_standard_draw_3d( view_dist){
	//for shadow-grid placement (IF it is defined via shadows_on)
	// LOOKS like it will be: _rmloaded_camera_x - _rmloaded_ 
	

	if(_rmloaded_shadow_buffer == ""){ _rmloaded_shadow_buffer= void null;}
	//file_input( _rmloaded_shadow_buffer);
	draw_grid( sketch_3d_FULL_SCREEN_DEFAULT( 
		_rmloaded_camera_3d_x, _rmloaded_camera_3d_y, 
		_rmloaded_camera_3d_rot,
		_rmloaded_camera_3d_z, _rmloaded_camera_3d_tilt,
		"0", "d",//< = colgroups walls/ sprites.
		rmloaded_room.skybox3d,//"  ---  ",//skybox_gridstr,
		_rmloaded_shadow_buffer, " ", 
			//shadow_gridstr, shadow_grid_trasparent_char?,
		_rmloaded_camera_x, _rmloaded_camera_y,
		//-14,7,
		view_dist),
		//angle,cam_height,cam_tilt),
		   0, 0, ""	);
}
function rmloaded_standard_settup_shadows_buffer_3d(  ){
	//I guess shadow dist ain't used...
	_rmloaded_shadow_buffer= _sketch_rays_multi_main( 
		_rmloaded_camera_x_FOCUS, _rmloaded_camera_y_FOCUS,
		"",// colgroup that light 'bounces' against
		_rmloaded_camera_x, _rmloaded_camera_y, false); 
}
function rmloaded_standard_settup_shadows_buffer_2d( get_wall_colgroup,
	x_offset, y_offset, get_no_shadows_viewDist_only){
	//I guess shadow dist ain't used...
	_rmloaded_shadow_buffer= _sketch_rays_multi_main( 
		_rmloaded_camera_x_FOCUS, _rmloaded_camera_y_FOCUS,
		get_wall_colgroup,//colgroup that light 'bounces' against
		//_rmloaded_camera_x, _rmloaded_camera_y);
		_rmloaded_camera_x + x_offset, _rmloaded_camera_y +y_offset,
		get_no_shadows_viewDist_only); 
}

//API_TAG//
// room_type -s (add 'room_type:' to room data, or change it. 
// THIS IS HOW TO ADD SHADOWS TO ROOMS BY CHANGING 1 VARIABLE!!!
var _rmloaded_launch_game_DISP_PARAMS = { // NOTE: the '_n_' paramiters: 0= OFF
   null:{  draw_2d:true, draw_3d_n_viewdist:0,
   	shadows_on: 0, shadow_wall_colgroup:"0", no_lights:true },
   undefined:{  draw_2d:true, draw_3d_n_viewdist:0,
   	shadows_on: 0, shadow_wall_colgroup:"0", no_lights:true },
  _2d:{draw_2d:true, draw_3d_n_viewdist:0,
   	shadows_on: 0, shadow_wall_colgroup:"0", no_lights:true },
   shadows:{ draw_2d:true, draw_3d_n_viewdist:0,
   	shadows_on: 1, shadow_wall_colgroup:"0", no_lights:false},
  shadows_no_lights:{ draw_2d:true, draw_3d_n_viewdist:0,
   	shadows_on: 1, shadow_wall_colgroup:"0", no_lights:true},
   shadows_ignore_walls:{ draw_2d:true, draw_3d_n_viewdist:0,
   	shadows_on: 1, shadow_wall_colgroup:"", no_lights:false},
   shadows3d:{  draw_2d:false, draw_3d_n_viewdist:10,
   	shadows_on: 1, shadow_wall_colgroup:"", no_lights:true  },
  _3d:{ draw_2d:false, draw_3d_n_viewdist:10,
   	shadows_on: 0, shadow_wall_colgroup:"", no_lights:false  }};
//API_TAG//

var _rmloaded_camera_x_PREV =0; var _rmloaded_camera_y_PREV=0;
var _rmloaded_shadow_buffer = "";
var _rmloaded_sketch_last_buffer =[];
var _rmloaded_sketch_after_lrgobjs_buffer = [];
// optimizing : https://wiki.duktape.org/performance
async function rmloaded_launch_game(){
   var rm_disptype = {};
   while(1){
	rm_disptype = _rmloaded_launch_game_DISP_PARAMS[
		rmloaded_room.room_type];

	if(rm_disptype.draw_3d_n_viewdist != 0){ 
		if( rm_disptype.shadows_on ){
			rmloaded_standard_settup_shadows_buffer_3d(  );
		}else{ _rmloaded_shadow_buffer = void null;} 
		rmloaded_standard_draw_3d( rm_disptype.draw_3d_n_viewdist );
		_rmloaded_shadow_buffer = ""; }
	_sketch_light_pool_1d__x_y_width_gfx = [];
	rmloaded_col_test_settup_xy_n_lrg_list();
   
	//rmloaded_room.objs[rmloaded_room.objs.length-1].dead = true;
	
	batch_objlist_remove_dead(rmloaded_room.objs_large );
	batch_objlist_remove_dead(rmloaded_room.objs );

	_rmloaded_launch_game_objs_large =rmloaded_room.objs_large.concat();
	_rmloaded_launch_game_objs = rmloaded_room.objs.concat();

	rmloaded_settup_lookup_props_obj(_rmloaded_launch_game_objs);
	rmloaded_settup_lookup_props_lrg(_rmloaded_launch_game_objs_large); 
	
	//updating searches (found in rmloaded_search.js):
	rmloaded_searchUpdate();

	  // running behaviors
	await _rmloaded_runrmbehavs(rmloaded_room, 
		rmloaded_update_allrms_behavs);
	await _rmloaded_runrmbehavs(rmloaded_room, 
		rmloaded_room.update_behavs);
	await batch_draw_n_run_behave_n_updateloc_obj_LRG_list( 
	   _rmloaded_launch_game_objs_large, rmloaded_b_globalThis,
	   _rmloaded_camera_x, _rmloaded_camera_y,
	   !rm_disptype.draw_2d,// dont_draw_any_objs
	   _rmloaded_draw_after_lrgobjs_buffer, _rmloaded_draw_last_buffer); // dont_draw_any_objs
	// for drawing lrg objs 'on top' of others. 
	batch_draw_obj_list( _rmloaded_draw_after_lrgobjs_buffer,
		_rmloaded_camera_x, _rmloaded_camera_y, 
		!rm_disptype.draw_2d);//dont_draw_any_objs
	_rmloaded_draw_after_lrgobjs_buffer = [];
	
	// OK, should have an override for this ( for the drawing)
	await batch_draw_n_run_behave_n_updateloc_obj_list( 
		_rmloaded_launch_game_objs,  rmloaded_b_globalThis,
		_rmloaded_camera_x, _rmloaded_camera_y,
		!rm_disptype.draw_2d,// dont_draw_any_objs
		_rmloaded_draw_after_lrgobjs_buffer, 
		_rmloaded_draw_last_buffer); 
	
	// last minute drawing
	batch_draw_obj_list( _rmloaded_draw_last_buffer,
		_rmloaded_camera_x, _rmloaded_camera_y, 
		!rm_disptype.draw_2d ); //dont_draw_any_objs
	_rmloaded_draw_last_buffer = [];
	
	if(rm_disptype.shadows_on &&  rm_disptype.draw_2d){ 
	  rmloaded_standard_settup_shadows_buffer_2d(
		  rm_disptype.shadow_wall_colgroup,
	  	_rmloaded_camera_x_PREV - _rmloaded_camera_x,
	  	_rmloaded_camera_y_PREV - _rmloaded_camera_y,
	  	rm_disptype.no_lights);
	  draw(_rmloaded_shadow_buffer, 0, 0,"&"); 
	  _rmloaded_camera_x_PREV = _rmloaded_camera_x;
	 _rmloaded_camera_y_PREV = _rmloaded_camera_y;
	}   

	var c = _rmloaded_overlay_buffer;
	var l = c.length;
	for( var i=0; i< l; i+=4){ draw( c[i], c[i+1], c[i+2], c[i+3] ); }
	_rmloaded_overlay_buffer = [];

	// catches canvas state before update.
	rmloaded_last_draw = draw_canvas_get() + "";

	await update();
	//ADDED 5/30/2025 UPDATED 1/21/2026
	if( _rmloaded_queue.length != 0 ){
		await _rmloaded_loadroom_CORE( ); }	

   }	}


//API_TAG//
function rmloaded_addObjGrid( getX, getY, getRoom, getGrid, getObjs_key, getObjs_large_key){
	// fractal functions:looks like adds objs in gridstr-grid formation?
	// they do their thing, and can call other fractal functions...
	// or be recursive. 
//API_TAG//
	//gridstr_scale("a", 10,100); for a block of objs. 
	var x=getX+0; var y = getY;
	for(var i=0; i< getGrid.length; i+=1){
		var c = getGrid[i];
		if( c == "\n"){	x=getX+0;	
			y+=1;
		}else{
		  if( getObjs_key[c] != void null){
			getRoom.objs.push(
				rmloaded_copyobj(getObjs_key[c],x,y));
		  }if( getObjs_large_key[c] != void null){
			getRoom.objs_large.push(
				rmloaded_copyobj(getObjs_large_key[c],x,y));			  	}}	
		x+=1;	}
}
//API_TAG//
// copys a object and adds keys from getModObj
function rmloaded_copyobj(getObj, x, y,  getModObj_OPTIONAL){
//API_TAG//
	getObj = JSON.parse(JSON.stringify(getObj));
	if(getModObj_OPTIONAL != void null){
		var keys = Object.keys(getModObj_OPTIONAL );
		for(var i=0; i< keys.length; i+=1){
			getObj[keys[i]] = getModObj_OPTIONAL [keys[i]];}
		getObj= JSON.parse(JSON.stringify(getObj));	}
	getObj.x = x; getObj.y = y;
	return getObj;		}
//API_TAG//
// getListCopy = [ obj,x,y, getModObj_or_null, ...(loops)... etc.]
function rmloaded_copyobj_batchlist( getListCopy){
//API_TAG//
	for(var i=0; i< getListCopy.length; i+=4){
		rmloaded_copy_obj( getListCopy[i], getListCopy[i+1], 
			getListCopy[i+2], getListCopy[i+3]);	}	}




// cycles through objs. in room, removing the ones out of bounds
// only removes/tests 3 at a time! 
var rmloaded_delbox_lazy_i = 0;
var rmloaded_delbox_lazy_i_lrg = 0;
var rmloaded_delbox_STEP = 10; // tests this many objs/lrg per tern
var rmloaded_delbox_STEP_MAX_REPEAT_DELS = 35; //if find a del, greater 'step'
function rmloaded_delbox_lazy_del_out_bound_chars( 
	get_rm, x,y, x_end,y_end, colgroup_to_ignore ){ 
	var tmp_o = null;
	// COLGROUPS SHOULD BE SINGLE CHARS, SO 'indexOf' below 
	// should give no matches!!!
	if(colgroup_to_ignore == ""){colgroup_to_ignore = "ZZZZ";}
	//objs
	
	var tmp_repeat_dels=0;
	rmloaded_delbox_lazy_i = 
		rmloaded_delbox_lazy_i +rmloaded_delbox_STEP;
	for(var i = rmloaded_delbox_lazy_i-rmloaded_delbox_STEP; 
			i< get_rm.objs.length && 
		rmloaded_delbox_lazy_i > i; i+=1){
		tmp_o = get_rm.objs[i];
		//get_rm.objs.splice(i,1);
		if( tmp_o.x <= x ||  tmp_o.x >= x_end
			|| tmp_o.y <= y ||  tmp_o.y >= y_end ){
				if( tmp_o.colgroup.indexOf(
					 	colgroup_to_ignore)==-1){
				   tmp_o.dead=true;
				   rmloaded_delbox_lazy_i+=1

				   if(rmloaded_delbox_STEP_MAX_REPEAT_DELS
						<tmp_repeat_dels){ break;}
				}	//above allows focusing on blocks
	}	}
	if(rmloaded_delbox_lazy_i >= get_rm.objs.length){ 
		rmloaded_delbox_lazy_i =0; }
	
	//objs_lrg
	rmloaded_delbox_lazy_i_lrg = 
		rmloaded_delbox_lazy_i_lrg +rmloaded_delbox_STEP;
	for(var i = rmloaded_delbox_lazy_i_lrg-rmloaded_delbox_STEP; 
			i< get_rm.objs_large.length && 
		rmloaded_delbox_lazy_i_lrg > i; i+=1){
		tmp_o = get_rm.objs_large[i];
		if( tmp_o.x <= x ||  tmp_o.x >= x_end
			|| tmp_o.y <= y ||  tmp_o.y >= y_end){
				if( tmp_o.colgroup.indexOf(
					 	colgroup_to_ignore)==-1){
					tmp_o.dead = true;
					rmloaded_delbox_lazy_i_lrg+=1;
				}
	}	}
	if(rmloaded_delbox_lazy_i_lrg >= get_rm.objs_large.length){ 
		rmloaded_delbox_lazy_i_lrg =0; }
}



//API_TAG//
//saves all global vars with 'rmloaded' in name
// (probably going to removes some, like no functions,
// 	and 'exclude' list and 'extra-vars' list should be expanding)
function rmloaded_saveState(  //low level, use gFiles_ functions (in g.js)
	  bool_dontSaveRmloaded_vars_OPTIONAL, 
	  tmp_exclude, tmpVars2copy,//OPTIONAL lists strs(global varnames)
	  //excludeNames_list_OPTIONAL, include_globalNamesList_OPTIONAL
	  tmp_StrList_RmObjRemoveWkey){// OPTIONAL 'remove rmObjs/w Key'
//API_TAG//
	if(tmp_exclude == void null){ tmp_exclude =[];}
	tmp_exclude.push("rmloaded_b_globalThis");
	if(tmpVars2copy == void null){ tmpVars2copy =[];}
	
	if(bool_dontSaveRmloaded_vars_OPTIONAL !=1 ){
	  var tmpKeys = Object.keys(rmloaded_b_globalThis);
	  for(var i=0; i<tmpKeys.length; i+=1){
		if(typeof rmloaded_b_globalThis[tmpKeys[i]]==="function"){
			continue;}
		if(tmp_exclude.indexOf(tmpKeys[i]) != -1){ continue;}
		if(tmpKeys[i].indexOf("rmloaded") == -1 &&
			tmpKeys[i].indexOf("rmloaded") != 1 ){ continue;}
		tmpVars2copy.push(tmpKeys[i])}}
	var tmpRetState={}
	for(var i=0; i< tmpVars2copy.length; i+=1){
		tmpRetState[tmpVars2copy[i]]= 
			rmloaded_b_globalThis[tmpVars2copy[i]];}
	if(tmp_StrList_RmObjRemoveWkey != void null){
		tmpRetState = JSON.parse(JSON.stringify(tmpRetState));
		for(var i=0; i< tmp_StrList_RmObjRemoveWkey.length; i+=1){
		  rmloaded_room_destroy_objs_with_prop(
		   tmpRetState.rmloaded,tmp_StrList_RmObjRemoveWkey[j]);}}
	return JSON.stringify(tmpRetState);}
//API_TAG//
function rmloaded_saveState_load( s){ //low level, use gFile_ functions
//API_TAG//
   var s = JSON.parse(s);  var k = Object.keys(s);
   for(var i=0; i< k.length; i+=1){rmloaded_b_globalThis[k[i]] =s[k[i]];}
   //'reloading' room! (above should 'load' it!)
   rmloaded_loadroom( rmloaded_room, true);
}

//API_TAG//
function rmloaded_bounding_box_test_n_deloutbounds_n_limit_cam(
//cam=camera,col=collision,multiplier is *width/heigh, OFF=0 or null
	  rm, getCentered, del_multiplier, cam_multiplier, col_multiplier,
		  colgroup_to_NOT_del_str, colgroups_to_coltest_str,//list 
		  x, y, tile_x, tile_y, tile_height, tile_width){
	//OK, not sure about boxtypes... should define those
	// COLLISION RETURNS: null, or 'up/left/right/down' or 
	// 	colgroup of collision! (or 'NULL')
//API_TAG//
	if(getCentered == 1){ 	//centered version
	  width_plus = tile_width/2;     width_minus = -tile_width/2;
	  height_plus = tile_height/2;   height_minus = -tile_height/2;
	}else{  width_plus = tile_width;      width_minus = 0;
		height_plus = tile_height;  height_minus = 0; }
	
	if( cam_multiplier > 0 ){ //supress camera moving outside
	  var cam_width = DRAW_CANVAS_DFLT_WIDTH;
	  var cam_height = DRAW_CANVAS_DFLT_HEIGHT;
	  if( -_rmloaded_camera_x + cam_width  >
		tile_x + (cam_multiplier * width_plus)){ 
			_rmloaded_camera_x = -( -cam_width+
				tile_x + (cam_multiplier * width_plus)); }
	  if( -_rmloaded_camera_y + cam_height  >
		tile_y + (cam_multiplier * height_plus)){ 
			_rmloaded_camera_y = -( -cam_height+
				tile_y + (cam_multiplier * height_plus)); }
	  if( -_rmloaded_camera_y< tile_y +(cam_multiplier *height_minus)){
	   _rmloaded_camera_y =-(tile_y + (cam_multiplier *height_minus));}
	  if( -_rmloaded_camera_x< tile_x +(cam_multiplier *width_minus)){
	   _rmloaded_camera_x =-(tile_x + (cam_multiplier *width_minus));}
	}
	//file_log(_rmloaded_camera_x +" " + _rmloaded_camera_y);
	if( del_multiplier > 0 ){ //delete if out of edges
		//expanding border by 1 pix
		rmloaded_delbox_lazy_del_out_bound_chars(rm,
		  -1 + tile_x + (del_multiplier * width_minus),
		  -1 + tile_y + (del_multiplier * height_minus),
		  1 + tile_x + (del_multiplier * width_plus),
		  1 + tile_y + (del_multiplier * height_plus),
		   colgroup_to_NOT_del_str);
		//rm, l[0],l[1], l[2], l[3], //x,y, x_end,y_end, 
		//vars.del_outbond_colgroup2ignore
	}
	//testing for collisions, and with sides
	for( var i=0; i< colgroups_to_coltest_str.length; i+=1){
		if("" != rmloaded_col_test_SIMPLE(x,y,
			colgroups_to_coltest_str.charAt(i))){
			  return colgroups_to_coltest_str.charAt(i); } }
	if( col_multiplier > 0){ //side-collisions
	  if( x > tile_x + (col_multiplier * width_plus)){ return "right";}
	  if( x < tile_x + (col_multiplier * width_minus)){ return "left";}
	  if( y > tile_y + (col_multiplier * height_plus)){ return "down";}
	  if( y < tile_y + (col_multiplier * height_minus)){ return "up";}
	}return null;
}

