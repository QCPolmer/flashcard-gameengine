IMPORTANT:
The idea here ( and with the engine ) is to reuse and generate 
data...
SO...
The key to this one is simple:
Have one pool of data that works for MANY different games!
Possibly catch movement patterns/etc. that can be treated 
differently based on context (system running)

EXAMPLE: 2d platformer: chars walk back and forth, sprint when close
	2d top-down: chars walk up/down. Sprint when close. 
	RPG : close distance, speed up when get close. 
	Racing: a 'ramming' vehicle. 
( if I can get this all done with the same 'character sheet', 
	It will be golden! )
