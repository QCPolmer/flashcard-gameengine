
// txttools
//API_TAG//
//EDIT: below is functional, but should use gridstr_height!
function txttools_getheight(get_txt){ return get_txt.split("\n").length; }
//EDIT: below is good, for simple width check (checks 1 line):gristr_width
function txttools_getmax_width(get_txt){
// in a multiline get_text, returns max line width (int)   //API_TAG//
	var txt_list = get_txt.split("\n");
	var tmp_maxwidth = 0;
	for(var i=0; i< txt_list.length; i+=1){
		if( txt_list[i].length>tmp_maxwidth){ 
			tmp_maxwidth = txt_list[i].length; 
	} } return tmp_maxwidth; }

//API_TAG//
function txttools_limit_width_n_make_heightlist_NO_CATCH(
		get_txt, width, height){
//API_TAG//
	var get_txt_mod = txttools_limit_width(get_txt, width).split("\n");
	var retlist=[];
	for(var i=0; i< get_txt_mod.length; i+= height){ 
	    retlist.push( get_txt_mod.slice(i, i+height).join("\n"));}
	return retlist; }

var txt_l_w_h_CATCH = {};
var txt_l_w_h_COUNT = 0;
//API_TAG//
function txttools_limit_width_n_make_heightlist(get_txt, width, height){
// breaks lines greater than 'width' up to two or more lines, 
//  AND returns the string as a list broken up by 'height' //API_TAG//
	if(txt_l_w_h_CATCH[width] == void null){ txt_l_w_h_CATCH[width]={};}
	if(txt_l_w_h_CATCH[width][height] == void null){ 
		txt_l_w_h_CATCH[width][height]={};}
	if(txt_l_w_h_CATCH[width][height][get_txt] != void null){
		return txt_l_w_h_CATCH[width][height][get_txt];}
 	txt_l_w_h_COUNT +=1;
	if(txt_l_w_h_COUNT > 100){ txt_l_w_h_COUNT =0; txt_l_w_h_CATCH={};
	 return txttools_limit_width_n_make_heightlist(
		get_txt, width, height);}	

	//getting actual stuff, the rest is catch cause this is expensive
	var get_txt_mod = txttools_limit_width(get_txt, width).split("\n");
	var retlist=[];
	for(var i=0; i< get_txt_mod.length; i+= height){ 
	    retlist.push( get_txt_mod.slice(i, i+height).join("\n"));}
	
	txt_l_w_h_CATCH[width][height][get_txt] = retlist;
	return retlist;	}
//API_TAG//
function txttools_limit_width(get_txt, getwidth){
// returns the string with lines greater than width broken into 2+ lines
//API_TAG//
	var txt_list = get_txt.split("\n");
	var out_list= [];
	for(var i=0; i< txt_list.length; i+=1){
		if( txt_list[i].length < getwidth){
			out_list.push(txt_list[i]); 
		}else{
			// tmp_words_long marks possible 'LONG' words
			var tmp_words_long = txt_list[i].split(" ");
			var tmp_words = [];
			for(var j =0; j< tmp_words_long.length; j+=1){
				var word = 
					tmp_words_long[j].split("");
				while(word.length > 0){
				  //file_input( getwidth);
				  tmp_words.push( 
				    word.splice(0,getwidth-1).join(""));} }
			var tmp_sentence = "";
			for( var j=0; j< tmp_words.length; j+=1){
				if((tmp_sentence + tmp_words[j]).length 
						>=getwidth){
					out_list.push(tmp_sentence); 
					tmp_sentence = tmp_words[j];
				}else{tmp_sentence += tmp_words[j] +" ";}}
			if(tmp_sentence != ""){ 
				out_list.push(tmp_sentence);  }
		}
	}
	return out_list.join("\n"); }


