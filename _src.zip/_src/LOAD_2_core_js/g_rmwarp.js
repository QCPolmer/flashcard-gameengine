

////API_TAG//
var g_rmwarp_stack_DEFAULT = {  //zzz
 moveObjsBox:{ objs_large:[], objs:[], 
	lazylinktag_player:"lazylink_player",  //ALWAYS warps this!
	lazylinktag_warpWith:"lazylink_player_warpWith",
	lazylinktag_warpIfNextToo:"lazylink_player_warpIfNextToo"},
	//4 btwn rms copy
 _justWarped: null, //{direction_or_custCmd:"", rtrnFromLower:false}
	//use : g_rmwarp_stack_getNset2NULL_justWarped()
 enter_avoid_colgroup:"#",  //ALSO: wall characters for Univ2d/BIGROOM
 stack:[//all values set in room on entry/exit EXCEPT seed/
	//_prev2UnivExitRmShape (use g_rmwarp_univ2d_grabRmLoaded_shape()
  {tileX:0, tileY:0, x:0, y:0, _seed:1, 
	//_prev2UnivExitRmShape:["left","right","up","down"],
	_rmName:"G_RESET_GAME", _dir_leftFrom:"",
	_rmUpdateBehavs:[],  _rmEnterBehavs:[], _rmLeaveBehavs:[] } ]};

//THIS-STACK IS SAVED WITH STANDARD g.js SAVES (gFiles prefix!)!!!
var g_rmwarp_stack= JSON.parse( JSON.stringify(g_rmwarp_stack_DEFAULT) );

//see above for datatype! (pointer, can modify)
// --- BELOW PULLS LAST STACK ENTRY!
function g_rmwarp_stack_getCurStack(){ return g_rmwarp_stack.stack[0]; }
////API_TAG// 

 
//////API_TAG// 
// use with rmbehavs, g_rmwarp_stack_getCurStack() Has other vars!!!
// // resets g_rmwarp_stack._justWarped, 
function g_rmwarp_stack_getNset2NULL__justWarped(){ 
//API_TAG//
	//{direction_or_custCmd:"", rtrnFromLower:false}
	if(g_rmwarp_stack._justWarped == void null){ return void null;}
	var tmpRet = g_rmwarp_stack._justWarped;
	g_rmwarp_stack._justWarped = void null;
	return tmpRet;
}








////API_TAG//
// --- this is how to handle rm-warps IN ROOM!
async function g_rmwarp_room_behav__handle_warps__example(o){//o is 'room'
//{tileX:0, tileY:0, x:0, y:0, _seed:1,_rmName:"", _dir_leftFrom:""}
	var curStack = g_rmwarp_stack_getCurStack();

	var tmpJustWarped = g_rmwarp_stack_getNset2NULL__justWarped();
	//{direction_or_custCmd:"", rtrnFromLower:false}
	// above is good, but now got 'enter-room' behavs working 
	if(tmpJustWarped != void null){
		//just warped, set crap up!!!
		//g_rmwarp_moveObjsBox_drop_objs( getx, gety,
		//  getDirEntryStr, g_rmwarp_stack.enter_avoid_colgroup );
	}else{ //NOT just warped:
		//var tmpWallWrps = 
		//	g_rmwarp_sideWalls__detect_wall_crossed_or_null();
		// check if 'lazylink_player' lazytagged cross wall-lines
		//  (lazytagged: lazylink_g_rmwarpExitLeft, 
		//  		lazylink_g_rmwarpExitRight, 
		//  		lazylink_g_rmwarpExitUp, 
		//  		lazylink_g_rmwarpExitDown
		//returns ['direction', obj_collided_w_wall]


	}
	//g_rmwarp( getRmName, getDirection,(many OPTIONAL ones, see API) 
	//getRmName =="G_RESET_GAME"/"G_PREV_ROOM"/"G_PREV_ROOM.5"-5 up
	//	  "G_PREV_ROOM.PART_ofPrevRmName_nearestInStack" works
	//  //  progen_dotnote, beyond that
}

//API_TAG//




////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////API_TAG//
// g_rmwarp sideWalls!!!
// (character to represent these by is typically "#", colgroup 
// 	in gConf, typically '0')
// //API_TAG//
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////

//API_TAG//
////////////////////////////////
// SIDE-WALLS & HOW TO USE::::
// OK, lazylink_g_rmwarpExitLeft/etc. are o.lazylinktag_player-s that "MARK" the edges 
// of the room!
// (g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav generates them
// 	typically, see g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav 
// 	for details)
// Long and short: objs marked with this in rooms with
// 	g_rmwarp_sidewalls_rtrnUpOnCross_FOR_rmUpdate_behav 
// 			running in room-update
// 	will return to previous rooms when go 'beyond' the 
// 	given direction of the objects! (eg: left-> less than negetive o.x)
// 	--- This makes it very easy to auto-gen walls and such
// 		(the g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav
// 			can generate walls, see it)
// 	--check 'example' rooms in g_rmwarp for a better idea
// 		of how to use in practice, 
// 		they should run in BIGROOMS AND univ2d (similar data!)
//API_TAG//


//API_TAG//
// use lazylinked objs: lazylink_g_rmwarpExitLeft, lazylink_g_rmwarpExitRight, 
// 			lazylink_g_rmwarpExitUp, lazylink_g_rmwarpExitDown
// 	in upto 4 objs in room!
function g_rmwarp_sideWalls__detect_wall_crossed_or_null( ){ 
		//returns null OR ['direction', obj_collided_w_wall]
	//API_TAG//
	var tmpPs = rmloaded_search_lazylink[
		g_rmwarp_stack.moveObjsBox.lazylinktag_player];
	var tmpLz = rmloaded_search_lazylink;
	if(tmpPs == void null){ return;}
	for(var i=0; i< tmpPs.length; i+=1){ var tmp_P =tmpPs[i];
	  if(void null != tmpLz['lazylink_g_rmwarpExitLeft'] && 
	    tmp_P.x <=tmpLz['lazylink_g_rmwarpExitLeft'][0].x){ 
			return ["left", tmp_P];}
	  if(void null != tmpLz['lazylink_g_rmwarpExitRight'] && 
	    tmp_P.x >=tmpLz['lazylink_g_rmwarpExitRight'][0].x){ 
			return ["right", tmp_P];}
	  if(void null != tmpLz['lazylink_g_rmwarpExitUp'] && 
	    tmp_P.y <=tmpLz['lazylink_g_rmwarpExitUp'][0].y){ 
			return ["up", tmp_P];}
	  if(void null != tmpLz['lazylink_g_rmwarpExitDown'] && 
	    tmp_P.y >=tmpLz['lazylink_g_rmwarpExitDown'][0].y){ 
			return ["down", tmp_P];} }
	return null; }

//API_TAG//
async function g_rmwarp_sidewalls_rtrnUpOnCross_FOR_rmUpdate_behav( o){ //o is 'room'
//{tileX:0, tileY:0, x:0, y:0, _seed:1,_rmName:"", _dir_leftFrom:""}
//API_TAG//
	var curStack = g_rmwarp_stack_getCurStack();
	var tmpJWarped = g_rmwarp_stack_getNset2NULL__justWarped();
	
	if(tmpJWarped != void null){ 
		var tmpDir = tmpJWarped.direction_or_custCmd;
		var tmpO = _g_rmwarp_sideWalls_ENTERRm_getDirLoc(tmpDir);
		var caughtF = _g_rmwarp_sideWalls_ENTERRm_getDirLoc;
		
		if(tmpO==null){ tmpDir =  "up"; tmpO = caughtF(tmpDir);}
		if(tmpO==null){ tmpDir =  "down"; tmpO = caughtF(tmpDir);}
		if(tmpO==null){ tmpDir =  "left"; tmpO = caughtF(tmpDir);}
		if(tmpO==null){ tmpDir =  "right"; tmpO= caughtF(tmpDir);}
		if(tmpO==null){ file_input("ERROR IN: g_rmwarp_sidewalls_rtrnUpOnCross_FOR_rmUpdate_behav, NO lazylink_g_rmwarpExitLeft/Right/etc. lazy-linked objs-in room!");}
		g_rmwarp_moveObjsBox_drop_objs( tmpO.x, tmpO.y, tmpDir, 
          	    g_rmwarp_stack.enter_avoid_colgroup );
	}else{ //NOT just warped:
		var tmpWallWrps =
		     g_rmwarp_sideWalls__detect_wall_crossed_or_null();
		if( tmpWallWrps != void null){
			g_rmwarp( "G_PREV_ROOM", tmpWallWrps[0]); }
	}
}
//API_TAG//
var _G_RMWARP_SIDEWALLS_SPAWNER_RMENTER_BEHAV_STRUCT = {
 	wall_choices: {"left":"lazylink_g_rmwarpExitLeft",
			"right":"lazylink_g_rmwarpExitRight",
			"down":"lazylink_g_rmwarpExitDown",
			"up":"lazylink_g_rmwarpExitUp"},
	XY_mods: {"lazylink_g_rmwarpExitLeft":[0, 0.5], 
		 "lazylink_g_rmwarpExitRight":[1, 0.5],
		"lazylink_g_rmwarpExitUp":[0.5, 0], 
		"lazylink_g_rmwarpExitDown":[0.5, 1] },
	//1st 2 numbers are scaling, 2knd 2 are x/y offset!
	XY_scaleUp_mods :{"lazylink_g_rmwarpExitLeft":[0, 1, 0,0], 
		"lazylink_g_rmwarpExitRight":[0, 1, -1,0 ],
		"lazylink_g_rmwarpExitUp":[1, 0, 0, 0], 
		"lazylink_g_rmwarpExitDown":[1, 0, 0, -1] }
};
//API_TAG//
//
//API_TAG//
// generates walks/edge warps based on o.rmsize AND 
// 	o.gen_exits(see below comment) (if o.gen_exits== void,
// 		will default to g_rmwarp_univ2d_grabRmLoaded_shape(),
// 		grabbing higher room shape based on wall chars ('#'),
// 		HIGHER LEVEL ROOM, IN THIS CASE, SHOULD BE univ2d/BIGROOM
// 		(and 'higher' means above in rmwarp-stack,
// 			meaning previous 'warped-too' room!)
async function g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav(o){
	//requires rm:  rmSizeXY:100, 
	//	 gen_exits=["left","right","up","down"],
	//		o.wall_graphic(or NULL),
	//--- USES g_rmwarp_univ2d_grabRmLoaded_shape to generate
	//		'o.gen_exits' if not found!
	//	//left/right/up/down, CAN HAVE FEWER LETTERS!!!
	// WILL ALSO:
	// 	generate 'walls' for blocked paths from
	// 	o.wall_graphic!!! (if null, no walls!)
	// USE progen_spawner_warp_walls_BIGRMEnter_subrm FOR
	// 	BIG-RMS/SUBROOMS!!!
	// 	
	//API_TAG//
	if(o._spawned_walls_behav_run ==1){ return;
	}else{ o._spawned_walls_behav_run = 1; }
	
	if(o.gen_exits == void null){
		o.gen_exits =  g_rmwarp_univ2d_grabRmLoaded_shape();}  

	var tmpStruct = _G_RMWARP_SIDEWALLS_SPAWNER_RMENTER_BEHAV_STRUCT;
	var tmp_XY_scaleUp_mods = tmpStruct.XY_scaleUp_mods;
	var tmp_rmSizeXY = o.rmSizeXY +1; // '+1' needs to sync right
				// with BIGROOMS (or walls too small)
	
	 rmloaded_search_lazylink_update(true); 
	// updating all so can see what exits currently exist
	// PROBABLY redundant, but leaving it here, just in case!	
	var tmp_allwalls = ["left","right","up","down"];	
	for(var i=0; i< tmp_allwalls.length; i+=1){
	  
	  var tmp_wall_name = tmpStruct.wall_choices[tmp_allwalls[i]];
	  
	  var tmp_x_multi = tmpStruct.XY_mods[tmp_wall_name][0];
	  var tmp_y_multi = tmpStruct.XY_mods[tmp_wall_name][1];
	  if(o.gen_exits.indexOf( tmp_allwalls[i]) == -1){
		//generate a 'wall'
		if(o.wall_graphic == void null){ continue;}		
		
		var tmpWidth = (tmp_rmSizeXY *
			  tmp_XY_scaleUp_mods[tmp_wall_name][0]);
		if( tmpWidth == 0){ tmpWidth = 1;}
		var tmpHeight = (tmp_rmSizeXY *
			  tmp_XY_scaleUp_mods[tmp_wall_name][1]);
		if( tmpHeight == 0){ tmpHeight = 1;}
		o.objs_large.push(
	  	{   x:Math.floor(tmp_x_multi) * tmp_rmSizeXY +
			tmp_XY_scaleUp_mods[tmp_wall_name][2],
		    y:Math.floor(tmp_y_multi) * tmp_rmSizeXY +
			tmp_XY_scaleUp_mods[tmp_wall_name][3], 
		    dead:0, graphic:
		      gridstr_scale(o.wall_graphic, tmpWidth, tmpHeight),
		    colgroup:gConf.player_wall_colgroup,
		    draw_1late_2last:0,  behavior:"b_none" });
		
		// EDITED 1/27/2026
		//uncomment to avoid making exits for all
		//continue;
	  }
	  
	if(rmloaded_search_lazylink[tmp_wall_name] != void null){
	  	continue; }
	  o.objs.push(
	  {   x:Math.ceil(tmp_x_multi*tmp_rmSizeXY), 
		y:Math.ceil(tmp_y_multi*tmp_rmSizeXY), 
		 dead:0, graphic:" ", colgroup:"",
		draw_1late_2last:0,  behavior:"b_none", 
		lazylink:[tmp_wall_name]  });
	}
}


//API_TAG//
function g_rmwarp_moveObjsBox_add_objs__run_pre_g_rmwarp( //ADDED 1/27/2026
   getObjsList, getObjsLargeList){
//API_TAG//
	for(var i=0; i<getObjsList.length; i+=1){ 
		g_rmwarp_stack.moveObjsBox.objs.push( getObjsList[i]);}
	for(var i=0; i<getObjsLargeList.length; i+=1){  
		g_rmwarp_stack.moveObjsBox.objs_large.push( 
			getObjsLargeList[i]);}	}
//API_TAG//
//// this is used directly via rmwarp on room itself
function g_rmwarp_moveObjsBox_pull_objs_with_tag( 
		getTag_Player, getTag_WarpWith, getTag_WarpNextToo, 
		getWarpX, getWarpY, maxDist_or_0 ){ //tag==obj-key
		
//API_TAG//

	if(maxDist_or_0 == void null){maxDist_or_0 ==0;};

	var tmpOs = [rmloaded_room.objs,
		rmloaded_room.objs_large];
	var tmpS = [g_rmwarp_stack.moveObjsBox.objs,
	    g_rmwarp_stack.moveObjsBox.objs_large];
	for(var i_2=0; i_2<2; i_2+=1){
	 var o = tmpOs[i_2]; var s = tmpS[i_2]; //s=list2dump_in
	 for(var i=o.length-1; i>=0; i-=1){ 
	   if(o[i]["lazylink"]!= void null){
	     if(o[i]["lazylink"].indexOf(getTag_Player)!=-1){
		s.push( o.splice(i,1)[0]);
		continue; }
	     if(o[i]["lazylink"].indexOf(getTag_WarpWith)!=-1){
		s.push( o.splice(i,1)[0]);
		continue; }
	     if(o[i]["lazylink"].indexOf(getTag_WarpNextToo)!=-1 && 
		  (maxDist_or_0 ==0 || maxDist_or_0>= 
		   _g_rmwarp_objdist(o, getWarpX, getWarpY))){
		  s.push( o.splice(i,1)[0]);
		continue; }
	 }	} }

	_g_rmwarp_sort_obj_dist_x = getWarpX;
	_g_rmwarp_sort_obj_dist_y = getWarpY;
	g_rmwarp_stack.moveObjsBox.objs.sort( _g_rmwarp_sort_obj_dist);
	g_rmwarp_stack.moveObjsBox.objs_large.sort( 
		_g_rmwarp_sort_obj_dist); 
}


//API_TAG//
// for use on entering room, after pulling objs ( g_rmwarp does this
// 	to lazylink_player taged OBJS!)
// basically, drops objs near an 'exit' (lazylink_g_rmwarpExitLeft, etc) tagged obj!
// 	(so I don't need to hard-code a bunch of crap :/)
function g_rmwarp_moveObjsBox_drop_objs( 
          getx, gety, getDirEntryStr, getColgroup2avoid,
	  OPTIONAL_reverse_entry_dir,
	  OPTIONAL_dont_offset_drops_by_1_on_strt_based_on_dir ){
//API_TAG//
	if(OPTIONAL_reverse_entry_dir ==1){
	  if(getDirEntryStr == "left"){ getDirEntryStr = "right";
	  }else if(getDirEntryStr == "right"){getDirEntryStr ="left";
	  }else if(getDirEntryStr =="up"){getDirEntryStr="down";
	  }else if(getDirEntryStr =="down"){getDirEntryStr="up";}}
	if(OPTIONAL_dont_offset_drops_by_1_on_strt_based_on_dir ==1){
	  if(getDirEntryStr == "left"){ getx -=1;
	  }else if(getDirEntryStr == "right"){getx +=1;
	  }else if(getDirEntryStr =="up"){gety +=1;
	  }else if(getDirEntryStr =="down"){gety -=1;}
	}	
	
	var tmp_drop_places= [];var tmpP=_g_warp_moveObjs_drop_obs_places;
	if(getDirEntryStr=="left"){ 
	  for(var i=0; i<tmpP.length; i+=1){
	    tmp_drop_places[i]=[getx - tmpP[i][0], gety + tmpP[i][1]];}
	}else if(getDirEntryStr=="right"){
	  for(var i=0; i<tmpP.length; i+=1){
	    tmp_drop_places[i]=[getx + tmpP[i][0], gety + tmpP[i][1]];} 
	}else if(getDirEntryStr=="up"){
	  for(var i=0; i<tmpP.length; i+=1){
	    tmp_drop_places[i]=[getx + tmpP[i][1], gety - tmpP[i][0]];} 
	}else if(getDirEntryStr=="down"){
	  for(var i=0; i<tmpP.length; i+=1){
	    tmp_drop_places[i]=[getx + tmpP[i][1], gety + tmpP[i][0]];} 
	}

	var tmpP = tmp_drop_places;
	rmloaded__update_cols__SLOW_4_USE_B4_RMFULLYLOADED();	
	var p_i = 0; // tmpP _i (drop places)
	
	var o =  g_rmwarp_stack.moveObjsBox.objs;
	for(var i=o.length-1; i>=0 && p_i< tmp_drop_places.length; i-=1){ 
		while("" != rmloaded_col_test_SIMPLE(
			tmp_drop_places[p_i][0],tmpP[p_i][1],getColgroup2avoid)
				&& p_i< tmpP.length){ p_i +=1; }
		if(p_i< tmpP.length){
		  o[i].x = tmpP[p_i][0]; o[i].y = tmpP[p_i][1]; }
		p_i +=1;}

	rmloaded_room.objs = rmloaded_room.objs.concat(
		g_rmwarp_stack.moveObjsBox.objs);

	g_rmwarp_stack.moveObjsBox.objs = [];

	var o = g_rmwarp_stack.moveObjsBox.objs_large;
	for(var i=o.length-1; i>=0 && p_i< tmpP.length; i-=1){ 
		while("" != rmloaded_col_test_SIMPLE(
			tmpP[p_i][0],tmpP[p_i][1],getColgroup2avoid)
				&& p_i< tmpP.length){ p_i +=1; }
		if(p_i< tmpP.length){
		  o[i].x = tmpP[p_i][0]; o[i].y = tmpP[p_i][1]; }
		p_i +=1;}
	rmloaded_room.objs_large = rmloaded_room.objs_large.concat(
		g_rmwarp_stack.moveObjsBox.objs_large); 
}

var g_rmwarp_levels_quickcopy_CATCH = {};

//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
/////////////g_rmwarp() AND stack AND dropbox (for 
////			moving objs. between rooms!
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

//API_TAG//
// NOTE: g_rmwarp_stack_getNset2NULL__justWarped(), (for entering room)
// NOTE: getRmName can be JSON.stringified or STATIC room!!!
// 	ALSO: the dotnotation allows drawing from db... can be random.
// MINIMAL: g_rmwarp( getRmName(dotnotation), getDirection);
// 		OR
//      g_rmwarp( getRmName, getDirection, 
//		OPTIOANLgetInject_EnterRmBehaviors, 
//		OPTIONALgetInject_UpdateRmBehaviors, 
//		OPTIONALgetInject_LeaveRmBehaviors
//      	OPTIONAL_custCmd4_justWarped);
//      --- ABOVE -WILL- pull and store 
//      	lazylinktag_player/lazylinktag_warpWith and 
//      	the other one (if close to warp point) to moveObjsBox,
//      	they can be dropped with g_rmwarp_moveObjsBox_drop_objs.
//      		(or not, for stand alone rooms!)
function g_rmwarp( getRm_ORobj_Name_OR_stackCmd, // progen_dotnote  --- BEST TO USE 'obj_name' FOR ONLY BIGROOMS!!! 
	// 			OR:
	//getRmName_...=="G_RESET_GAME"/"G_PREV_ROOM"/"G_PREV_ROOM.5"-5 up
	//	 "G_PREV_ROOM.PART_ofPrevRmName_nearestInStack" works
	//	 NOTE: -CAN- WARP TO SAME ROOM WITH G_PREV_ROOM!!!
	//	 	(if I wrote this right...)
	getDirection, //"left"/"right"/"up"/"down"  
	//   ( getDirection STILL needed with OPTIONAL_custCmd4_justWarped)
	OPTIOANLgetInject_EnterRmBehaviors,  //NOT for going to PREV rooms
	//ADDED TO STACK /w REDIRECT BEHAV OR RM DIRECTLY IF rtrn_rm_ONLY
	OPTIONALgetInject_UpdateRmBehaviors, //NOT for going to PREV rooms
	//ADDED TO STACK /w REDIRECT BEHAV OR RM DIRECTLY IF rtrn_rm_ONLY
	OPTIONALgetInject_LeaveRmBehaviors, //NOT for going to PREV rooms
	//ADDED TO STACK /w REDIRECT BEHAV OR RM DIRECTLY IF rtrn_rm_ONLY
	OPTIONAL_custCmd4_justWarped, // DESTINATION ROOM SPECIFIC:
		//ABOVE param IDK what it does, but not getting rid of.
	OPTIONAL_NOprogen_room, 	
	 // replaces getDirection in _justWarped.direction_or_custCmd
	 //	for g_rmwarp_stack_getNset2NULL__justWarped()
	OPTIONAL_usePurelyRandomSeed,
	OPTIONAL_MaxDist_obsMove2room,//for pulling objs, null ignore dist
	// x/y set from stackXY! so pulls objs dist based on that!
	OPTIONAL_objsList_2Move2room, OPTIONAL_objsLrglist_2move2rm,
	OPTIONAL_rtrn_rm_ONLY_no_load_or_stackupdate ){
		//LAST PARAM -IS STRINFIFED g_rmwarp_stack-
	//API_TAG//
	 
	//mostly for level editor
	if( rmloaded_IS_LEVEL_SWITCHING_DISABLED ){ return; }

	//////////////////////////////////////////////
	//setting '_justWarped', g_rmwarp_stack._justWarped
	//	-NOT- for returning room ONLY(no warp!)
	if(getRm_ORobj_Name_OR_stackCmd.indexOf("G_PREV_ROOM")==0 ){

	  g_rmwarp_stack._justWarped={direction_or_custCmd:getDirection, 
		rtrnFromLower:true};
	}else if(OPTIONAL_rtrn_rm_ONLY_no_load_or_stackupdate==void null){
	  g_rmwarp_stack._justWarped={
	  direction_or_custCmd:getDirection, rtrnFromLower:false}; }
	
	//////////////////////////////////////
	// catching current g_rmwarp_stack, 
	// 	will restore @ end if RETURNING RM ONLY!
	if(OPTIONAL_rtrn_rm_ONLY_no_load_or_stackupdate ==1){
	  //OPTMIZE_A (TESTING for ONLY adding a single element
	  if(getRm_ORobj_Name_OR_stackCmd.indexOf("G_PREV_ROOM") != 0){
		 var tmpCaughtLowestStack_1ENTRY = JSON.parse(
			JSON.stringify( g_rmwarp_stack_getCurStack() ));
		  var tmpCaughtStack_list_1ENTRY = g_rmwarp_stack.stack;
		  g_rmwarp_stack.stack = null;
		  var tmpCaughtStack_1ENTRY_CORE = 
			JSON.parse(JSON.stringify(g_rmwarp_stack));
		  g_rmwarp_stack.stack = tmpCaughtStack_list_1ENTRY;
	  }else{
	    var tmpCaughtStack =
		JSON.parse(JSON.stringify(g_rmwarp_stack));}
	}else{ var tmp_RmShape=g_rmwarp_univ2d_grabRmLoaded_shape();}
	
	///////////////////////////////////////////////
	// Setting up various vars in g_rmwarp_stack
	//	IF returning_rm ONLY, 
	//	   CAUGHT g_rmwarp_stack is restored @ end,
	//	    	AND MOST CODE HERE DOES NOTHING
	var smbox = g_rmwarp_stack.moveObjsBox;

	if( OPTIONAL_objsList_2Move2room != void null){
	   smbox.objs= smbox.objs.concat(OPTIONAL_objsList_2Move2room);}
	if( OPTIONAL_objsLrglist_2move2rm != void null){ smbox.objs_large= 
		smbox.objs_large.concat(OPTIONAL_objsLrglist_2move2rm);}
	
	var tmpStackPrev = g_rmwarp_stack_getCurStack();
	tmpStackPrev._dir_leftFrom = getDirection;

	var tmpJustWarpedStruct = {};
	if(OPTIONAL_custCmd4_justWarped != void null){
	  tmpJustWarpedStruct.direction_or_custCmd =  
		OPTIONAL_custCmd4_justWarped
	}else{ tmpJustWarpedStruct.direction_or_custCmd = getDirection; }
	tmpJustWarpedStruct.rtrnFromLower = false;

	/////////////////////////////////////////
	// new rooms seed (if not going up a room, or whatever!)
	if( OPTIONAL_usePurelyRandomSeed == 1){ progen_seed_init( );
	}else{	progen_seed_init( tmpStackPrev._seed); }
	var tmpSeed = _g_warp_gen_seed( tmpStackPrev._seed, gRandom_seed, 
	   getRm_ORobj_Name_OR_stackCmd, 
		tmpStackPrev.tileX, tmpStackPrev.tileY, 
	   g_rmwarp_stack.stack.length);	
	progen_seed_end();
	
	/////////////////////////////////////////////////
	//gen new stack entry, or going back, etc.
	if(getRm_ORobj_Name_OR_stackCmd == "G_RESET_GAME"){  
		OPTIOANLgetInject_EnterRmBehaviors = void null;
		OPTIONALgetInject_UpdateRmBehaviors = void null; 
		OPTIONALgetInject_LeaveRmBehaviors = void null;
		g_gamereset(); return; 
	}else if(getRm_ORobj_Name_OR_stackCmd.indexOf("G_PREV_ROOM")==0 ){
		OPTIOANLgetInject_EnterRmBehaviors = void null;
		OPTIONALgetInject_UpdateRmBehaviors = void null; 
		OPTIONALgetInject_LeaveRmBehaviors = void null;
		//fetching dot-notation prev room, if it's there
		var tmpNames = getRm_ORobj_Name_OR_stackCmd.split(".");
		var tmpWentBackAlready = false;
		if(tmpNames.length >1){ tmpNames.shift(); 
			var tmpName= tmpNames.join(".");
			var tmpSpliceAtNumber = 0;
			var tmpStack = g_rmwarp_stack.stack;
			//if a number, will warp-up this many rooms!
			if( parseInt(tmpName) != NaN){
			   tmpSpliceAtNumber = parseInt(tmpName);
			   tmpWentBackAlready = true;
			}else{ // for 'previous rmname' Names!!!
			  for(var i=tmpStack.length-1; i<=0; i-=1){
				if(tmpStack[i]._rmName.indexOf(tmpName)!=
						-1){
					tmpWentBackAlready = true;
					tmpSpliceAtNumber = 
					   1 + tmpStack.indexOf(tmpName)
					break;  }  }}
			g_rmwarp_stack.stack.splice(0, tmpSpliceAtNumber);
		}if(tmpWentBackAlready == false){ //going to prev entry
	             g_rmwarp_stack.stack.shift(); 
		}
		tmpSeed = g_rmwarp_stack_getCurStack()._seed;
		getRm_ORobj_Name_OR_stackCmd = g_rmwarp_stack_getCurStack()
			._rmName;	
		
		tmpJustWarpedStruct.rtrnFromLower = true;
		//need to custom-load room here.
	}else{
		//gen new stack location
		g_rmwarp_stack.stack.unshift(_g_rmwarp_stack_itemGen());
		g_rmwarp_stack_getCurStack()._seed = tmpSeed;
		g_rmwarp_stack_getCurStack()._rmName = 
			getRm_ORobj_Name_OR_stackCmd;
	}
	
	/////////////////////////////////////
	//  generating/fetching room!
	progen_seed_init( tmpSeed );
	var tmpRm =progen_dotnote( 
		getRm_ORobj_Name_OR_stackCmd,
		null, true ); //getting rand item if ending in list!

	progen_seed_end();
	if(tmpRm== void null){ //setting tmp
			file_input("ERROR IN: g_rmwarp, room not found:"+
				getRm_ORobj_Name_OR_stackCmd );  }	
	if(typeof tmpRm == "string"){ 
		tmpRm = JSON.parse(tmpRm);
	// for level generated rooms:
	}else if( tmpRm.rmwarp_use_a_deep_copy_per_spawn == true){
		if(tmpRm._level_name == null){
			tmpRm = JSON.parse(JSON.stringify(tmpRm));
		}else{
			var tmpRm_stringed=g_rmwarp_levels_quickcopy_CATCH[
				tmpRm._level_name];
			if(tmpRm_stringed == null){
				tmpRm_stringed = JSON.stringify(tmpRm);
				g_rmwarp_levels_quickcopy_CATCH[
					tmpRm._level_name]=tmpRm_stringed;}
			tmpRm = JSON.parse(tmpRm_stringed);
	}	}
	
	// ADDED- 1/20/2026
	// if mml_wrldMap is a string, for bigrms/universe, 
	// 	pull it via dotenote. (
	if(typeof tmpRm.mml_wrldMap == "string"){
	    tmpRm.mml_wrldMap = progen_dotnote( tmpRm.mml_wrldMap ); 
	    // copying... (JSON works too...), 
	    // 		room functions modify this, clean copy needed. 
	    if(typeof tmpRm.mml_wrldMap != "string"){
		tmpRm.mml_wrldMap = JSON.stringify(tmpRm.mml_wrldMap);}
	   tmpRm.mml_wrldMap = JSON.parse(tmpRm.mml_wrldMap);
	} 	

	
	///////////////////////////////////////
	//if room_link is a obj with a graphic, adds it to a room, 
	// and uses that (for p_map2d__graphic style objs!
	if(tmpRm.graphic != void null && tmpRm.x != void null){
	   if(tmpRm.graphic.length >1){
		tmpRm = progen_obj_room({ objs:[], objs_large:[tmpRm]});
	   }else{tmpRm = progen_obj_room({ objs:[tmpRm], objs_large:[]});}
	}

	if(OPTIONAL_NOprogen_room != 1){
		progen_seed_init(tmpSeed);
		progen_obj_room(tmpRm, 0 );
		progen_seed_end(); }

	//////////////////////
	//returning room IF that is all that is needed!!!
	if(OPTIONAL_rtrn_rm_ONLY_no_load_or_stackupdate){
		if(getRm_ORobj_Name_OR_stackCmd.indexOf("G_PREV_ROOM")==0){
			g_rmwarp_stack = tmpCaughtStack;
		}else{  //ADDED 5/30/25, prev was just above line
			tmpCaughtStack_list_1ENTRY.shift();
			tmpCaughtStack_list_1ENTRY.shift();
			tmpCaughtStack_list_1ENTRY
				.unshift(tmpCaughtLowestStack_1ENTRY);
			g_rmwarp_stack =tmpCaughtStack_1ENTRY_CORE;
			g_rmwarp_stack.stack = tmpCaughtStack_list_1ENTRY;
		}
		if(OPTIOANLgetInject_EnterRmBehaviors != void null){
		   _g_rmwarp_inject_rm_behavs(tmpRm, "enter_behavs",
			OPTIOANLgetInject_EnterRmBehaviors); }
		if(OPTIONALgetInject_UpdateRmBehaviors !=void null){
		  _g_rmwarp_inject_rm_behavs(tmpRm, "update_behavs",
			OPTIONALgetInject_UpdateRmBehaviors); }
		if(OPTIONALgetInject_LeaveRmBehaviors !=void null){	
			_g_rmwarp_inject_rm_behavs(tmpRm, "leave_behavs",
			OPTIONALgetInject_LeaveRmBehaviors); }
		return tmpRm; 
	}else{ g_rmwarp_stack.stack[0]._prev2UnivExitRmShape = 
		tmp_RmShape;
		if(OPTIOANLgetInject_EnterRmBehaviors != void null){
		   g_rmwarp_stack_getCurStack()._rmEnterBehavs = 
			OPTIOANLgetInject_EnterRmBehaviors; }
		// ZZZZ ERROR INJECTED HERE
		if(OPTIONALgetInject_UpdateRmBehaviors !=void null){
		  g_rmwarp_stack_getCurStack()._rmUpdateBehavs =
			OPTIONALgetInject_UpdateRmBehaviors; }
		if(OPTIONALgetInject_LeaveRmBehaviors !=void null){
		  g_rmwarp_stack_getCurStack()._rmLeaveBehavs =
			OPTIONALgetInject_LeaveRmBehaviors; }
		_g_rmwarp_inject_rm_behavs(tmpRm, "enter_behavs",
			["_behav_rmwarp_run_stack_enter"]);
		
		// ZZZZ ERROR INJECTED HERE
		_g_rmwarp_inject_rm_behavs(tmpRm, "update_behavs",
			["_behav_rmwarp_run_stack_update"]);		

		_g_rmwarp_inject_rm_behavs(tmpRm, "leave_behavs",
			g_rmwarp_stack_getCurStack()._rmLeaveBehavs); 
	}
	///////////////////////////////////////////
	//loading generated room!!!
	if( OPTIONAL_MaxDist_obsMove2room == void null){
		OPTIONAL_MaxDist_obsMove2room = 0;}
	g_rmwarp_moveObjsBox_pull_objs_with_tag( 
		smbox.lazylinktag_player,  smbox.lazylinktag_warpWith, 
			smbox.lazylinktag_warpIfNextToo,
		tmpStackPrev.x, tmpStackPrev.y, 
		OPTIONAL_MaxDist_obsMove2room );
	rmloaded_loadroom( tmpRm );
	// in case needed by a function, or whatever. (used in 2dUniv)
	return tmpRm;
}


////////////////////////////////////////////////
/////////////// HELPER FUNCTIONS //////////////////
/////////////////////////////////////////
/////////////////////////////////////////
function _g_rmwarp_stack_itemGen(){ return {
  //_prev2UnivExitRmShape:["left","right","up","down"],
  tileX:0, tileY:0, x:0, y:0, _seed:0, _rmName:"", _dir_leftFrom:"",
  _rmUpdateBehavs:[],  _rmEnterBehavs:[], _rmLeaveBehavs:[] }; }; // 
function _g_warp_gen_seed( getPrevStackSeed, getG_seed, 
	getRmName, getPrevStackTileX, getPrevStackTileY, getStackDepth ){
  return  progen_multivar_to_gen_rand_seed( [getPrevStackSeed, 
	getG_seed, Math.abs(getPrevStackTileX)+41, //41/32 are RANDOM #s
	Math.abs(getPrevStackTileY)+34, (getStackDepth+1)]); }
function _g_rmwarp_objdist(o, x, y){
	Math.sqrt( Math.pow(o.x - x, 2) + Math.pow(o.y - y,2) ); }
var _g_rmwarp_sort_obj_dist_x = 0; var _g_rmwarp_sort_obj_dist_y = 0;
function _g_rmwarp_sort_obj_dist(a,b){ //above 2 vars should be set FIRST
  var x = _g_rmwarp_sort_obj_dist_x; var y = _g_rmwarp_sort_obj_dist_y;

  var distA = _g_rmwarp_objdist(a, x, y);
  var distB = _g_rmwarp_objdist(b, x, y);
  if(distA < distB){ return -1;} if(distA > distB){ return 1;}
  return 0; 
}

//this is from left-hand side (x growing) perspective
var _g_warp_moveObjs_drop_obs_places=[
	[1,0], [1,1], [1,-1],  [1,2],[1,-2], 
	[2,0],[2,1],[2,-1],  [2,2],[2,-2],  [1,3],[1,-3],
	[3,0],[3,1],[3,-1],  [3,2],[3,-2],  [1,4],[1,-4],
	[4,0],[4,1],[4,-1],  [4,2],[4,-2],  [2,4],[2,-4],  [1,5],[1,-5] ];

// this redirects to run rmStack current commands (added automatically)
async function _behav_rmwarp_run_stack_enter(o){
	var tmp_behavs = g_rmwarp_stack_getCurStack()["_rmEnterBehavs"];
	for(var i=0; i<tmp_behavs.length; i+=1){
		await rmloaded_b_globalThis[tmp_behavs[i] ](o);   }}

async function _behav_rmwarp_run_stack_update(o){
	//////////////////////////////////
	// this function would fire once rmwarp_stack was settup
	// 	for NEXT room before room transtion
	if(rmloaded_loadroom_is_loading_right_now()){ return;};
	var tmp_behavs = g_rmwarp_stack_getCurStack()["_rmUpdateBehavs"];
	for(var i=0; i<tmp_behavs.length; i+=1){
		await rmloaded_b_globalThis[tmp_behavs[i] ](o); }  }
// _behav_rmwarp_run_stack_leave(o){--UNUSED causes enter/leave room issues

function _g_rmwarp_inject_rm_behavs(getRm, getBehaveKey,
		//"enter_behavs/update_behavs"
	getBehavesTo_inject){ // LIST, see below for 2 values,
   //["_behav_rmwarp_run_stack_enter"]/["_behav_rmwarp_run_stack_update"]
	if(getBehavesTo_inject.length ==0){ return;}
	if(getRm[getBehaveKey]==null){ getRm[getBehaveKey]=[]; } 
	for(var i=0; i<getBehavesTo_inject.length; i+=1){
	   if(-1 == getRm[getBehaveKey].indexOf(getBehavesTo_inject[i])){
		    getRm[getBehaveKey].push( getBehavesTo_inject[i]); }}}

function _g_rmwarp_sideWalls_ENTERRm_getDirLoc(inD){ // inDirection
   //inDirection ="up"/"left"/"down"/"right", out->reverse directions
   //returns link marker for direction!(a object!)or null //API_TAG//
   rmloaded_search_lazylink_update(true); var tmpD = null;
   if(inD== "up"){tmpD="lazylink_g_rmwarpExitDown";}  
   if(inD== "right"){tmpD="lazylink_g_rmwarpExitLeft";}
   if(inD== "left"){tmpD="lazylink_g_rmwarpExitRight";}  
   if(inD== "down"){tmpD="lazylink_g_rmwarpExitUp";}
   if( rmloaded_search_lazylink[ tmpD ] == void null){return void null;}
   return rmloaded_search_lazylink[ tmpD ][0]; }

