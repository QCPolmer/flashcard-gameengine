file_check_loaded("rmloaded.js");
file_check_loaded("progen.js"); //basically, everything needs it. 

//API_TAG//
var _behavior_progen_char4_call_all ="!";
// behaviors saved to global namespace, typically start with 'b_'
async function behav_progen_room_controller(){
// EDIT: not sure if this is still used...
// 
// returns nothing (it's a behavior), but can be used to advance or reverse 
// procedural generation, or set the target char to use
//  (control keys: .,@) 
	//  ---Can save room as file here too. //API_TAG//
	// can use file_input for getting key to look for 
	// THEN I do 'advance operation' or 'advance last operation' 
	if( controllers[0].getch == "."){
	  progen_obj_room(rmloaded_room, 1, _behavior_progen_char4_call_all); }
	if( controllers[0].getch == ","){
	  progen_obj_room(rmloaded_room, -1, _behavior_progen_char4_call_all); }
	if( controllers[0].getch == "@"){ 
		var caught_str = 
			file_input( "input char to target objs with "+
			"char in obj.progen.group string\n" +
"OR sv FILENAME(filename is optional) to save room(json) to file... \n" + 
			"CONTROLS 4 progen:\n"+
	"'!' default char, ',' run and itterate to prev randseed\n,"+
			"'.' same as ',' but itterates next,\n" + 
			"(think of them as 'back' and 'forward'\n");
		if(caught_str.trim().split(" ")[0] == "sv"){
			
			if( caught_str.trim().split(" ").length==1 ||
				 caught_str.split(" ")[1] == "m.js"){
				//save room as progen save
				file_save( file_dir_cd(), 
				  "progen_rm_json_save.json", 
				  JSON.stringify(rmloaded_room, 
					  null, 2));
			}else{
				//save room as filename
				file_save( file_dir_cd(), 
				  caught_str.trim().split(" ")[1] , 
				  JSON.stringify(rmloaded_room, 
					  null, 2));
			}
		}else{
		 _behavior_progen_char4_call_all = caught_str.trim("");
	} }
}
/*
function behavior_progen_anim(o, anim_name, 
		numb_of_config_rands, anim_names_to_use){
	numb_of_config_rands= parseInt(numb_of_config_rands);
	anim_names_to_use = anim_names_to_use.split("||"); }

*/
