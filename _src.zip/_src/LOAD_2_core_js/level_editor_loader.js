

/////////////////////////////////
// for use in game itself, in editor version is below
// 	(this one just makes objs)
// 	// MAKES ALL OBJS EVERY TIME RUN, should still be fast, though...
async function level_editor_loader__room_on_enter_behav( getRm ){
	// level_editor
	//file_input(JSON.stringify(getRm));
	//file_input(111111);
	//
	// resetting room, so if other behavs mod it:
	
	// for use in g_rmwarp_univ2d /bigroom
	if( getRm._level_editor_loader__room_on_enter_behav_RAN ==1){
		return;}
	
	// for use in g_rmwarp_univ2d /bigroom
	if(getRm._level_editor_loader__room_on_enter_SEED != null){
		progen_seed_init(
		  getRm._level_editor_loader__room_on_enter_SEED); 
		level_editor_loader__gen_items__n_progen( getRm, 
			getRm._level_editor_data );
		progen_seed_end();
		// don't think needed, can set in room itself? 
		//getRm._level_editor_loader__room_on_enter_SEED= null;
	}else{
		//file_input(getRm.enter_behavs);
		level_editor_loader__gen_items__n_progen( getRm, 
			getRm._level_editor_data );
	}

	getRm._level_editor_loader__room_on_enter_behav_RAN = 1;

	
	//file_input(JSON.stringify(getRm));
		}


var level_editor_loader__get_global_objs_named_like_CATCH={};
function level_editor_loader__get_global_objs_named_like( 
		getTextToLookFor, useCatched_results_OPTIONAL){	
		//updates CATCH if not useCatched_results_OPTIONAL
	
	if(level_editor_loader__get_global_objs_named_like_CATCH[
		getTextToLookFor ] != null && 
		useCatched_results_OPTIONAL == true){
	   return level_editor_loader__get_global_objs_named_like_CATCH[
			getTextToLookFor ].concat(); } 

	var tmpKeys = Object.keys(rmloaded_b_globalThis);
	var tmp_out = [];
	for(var i=0; i< tmpKeys.length; i+=1){
		if( tmpKeys[i].indexOf(getTextToLookFor) != -1){
			tmp_out.push( rmloaded_b_globalThis[tmpKeys[i]]);
	}	}
	level_editor_loader__get_global_objs_named_like_CATCH[
			getTextToLookFor ] = tmp_out.concat();
	
	return tmp_out;
}

// NOTE: assumes objName (dotnote) ALWAYS points to same root object!
var _level_editor_loader__dotnote__items_CATCH = {};
// cleared in level_editor_loader__is_dotnote_progenable__reset_CATCH()
function level_editor_loader__dotnote__items_CATCH(getObjName){
	var tmpOut=_level_editor_loader__dotnote__items_CATCH[getObjName];
	if( tmpOut == null){
	  if(progen_dotnote(getObjName)  == null){
		file_input("Error in "+ 
			"level_editor_loader__dotnote__items_CATCH"+
			"\n  object with dotnote-name: '"+getObjName+
			"'\n NOT FOUND: maybe renamed obj-name?");}
	   _level_editor_loader__dotnote__items_CATCH[getObjName] =
	  	JSON.stringify( progen_dotnote(getObjName) ); 
	   tmpOut=_level_editor_loader__dotnote__items_CATCH[getObjName];}
	return JSON.parse(tmpOut);
}

// NOTE: THIS ASSUMES 'getDotNoteStrOfObj' -ALWAYS- POINTS TO SAME OBJECT
var level_editor_loader__is_dotnote_progenable_CATCH = {};
// needs for reloading data in level-editor:
function level_editor_loader__is_dotnote_progenable__reset_CATCH(){
	_level_editor_loader__dotnote__items_CATCH = {};
	level_editor_loader__is_dotnote_progenable_CATCH = {}; }
function level_editor_loader__is_dotnote_progenable_OPTIMIZER(
	getObj, getDotNoteStrOfObj){
	// using catch to test, MUCH MUCH faster. 
	var tmpRet = level_editor_loader__is_dotnote_progenable_CATCH[
				getDotNoteStrOfObj ];
	if(tmpRet != undefined){ return tmpRet;}
	
	var tmpKeys = Object.keys(getObj );
	level_editor_loader__is_dotnote_progenable_CATCH[
				getDotNoteStrOfObj ] = false;
	for(var i=0; i< tmpKeys.length; i+=1){
		if( tmpKeys[i].indexOf("p_") ==0){ 
			level_editor_loader__is_dotnote_progenable_CATCH[
				getDotNoteStrOfObj ] = true; break;} }
	return level_editor_loader__is_dotnote_progenable_CATCH[
				getDotNoteStrOfObj ];
}

// does NOT progen for level editor,
// 	this uses catching to-pre-stringify-objs for quick copy/clone
async function level_editor_loader__gen_items__n_progen(  
	getRm, get_level_editor_data,
	getNullifyBehaviors_for_NotRunningInEditor_N_add_obj_marker){
		//obj_marker == now just adding to list above 
		//	this function, so can clear with one funct call 
	// {x:?, y:?, obj_dotnote_name:?}
	
	for(var i=0; i<get_level_editor_data.length; i+=1){
	 
	 var tmp_leve_editor_data_i = get_level_editor_data[i];
	 //should probably put a CATCH here?
	  var tmpObj = level_editor_loader__dotnote__items_CATCH(
				tmp_leve_editor_data_i.obj_dotnote_name);
	  if(getNullifyBehaviors_for_NotRunningInEditor_N_add_obj_marker){
		//_level_editor_gen_items__objs_gen__IN_EDITOR_ITSELF
		//	.push(tmpObj);
		if( tmpObj.graphic_frames__dotnote != null &&
			tmpObj.graphic_frames__delay_between_frames!=null){
				tmpObj.behavior = 
			  "level_editor_loader__draw_animation__behav";
		}else{ tmpObj.behavior = "b_none"; } 
	  // this part progens IF IT CAN BE DONE (optimized, prechecked) 
	  }else	if(level_editor_loader__is_dotnote_progenable_OPTIMIZER(
		tmpObj, tmp_leve_editor_data_i.obj_dotnote_name )){
			if(tmpObj.p_randseed == null){
			    tmpObj.p_randseed = progen_d_roll(1000000 );}
			progen_obj(tmpObj,tmpObj); }

	  tmpObj.x = tmp_leve_editor_data_i.x; 
	  tmpObj.y = tmp_leve_editor_data_i.y;
	  tmpObj._level_editor_data_dotnote_name = 
			tmp_leve_editor_data_i.obj_dotnote_name;
	  if(tmpObj.graphic.length ==1){ getRm.objs.push(tmpObj);
	  }else{ getRm.objs_large.push(tmpObj); }	}	

}

var level_editor_loader__load_autoload__with_NO_EMBED = false;
// for reloading the 'schema' from local files in level editor
// (otherwise, catches files and loads from them, so will load from caught)
// 	(uses "m._autoload_n_configs_n_start_level.js")
function level_editor_loader__load_m_autoload__NO_EMBED( ){
	level_editor_loader__load_autoload__with_NO_EMBED= true;
	file_load_js_noembed( file_dir_cd(), 
		["m._autoload_n_configs_n_start_level.js"]);
	level_editor_loader__load_autoload__with_NO_EMBED= false; }
//this is in "m._autoload_n_configs_n_start_level.js"
//	(here so I can use above and rework here vs editing every file)
function _level_editor_loader__load_m_autoload( getAutoloadNamesList ){
	// for if running from 
	if(level_editor_loader__load_autoload__with_NO_EMBED){
		file_load_js_noembed( file_js_cd(),  getAutoloadNamesList);
	}else{ file_load_js( file_js_cd(),  getAutoloadNamesList); } 
}


// uses file: "m._autoload_n_configs_n_start_level.js"
function level_editor_loader__update_autoload_files_if_available(){
// below is for html version, which doesn't do file-operations!
 if(typeof file_dir_search != "undefined"){
    var tmpFILENAME= "m._autoload_n_configs_n_start_level.js";


    if(1 == file_dir_search( file_dir_cd_js(),0,[tmpFILENAME+"$"]).length){
	var TMPFILENAMES_DIVIDER= "//AUTO_ADDS_FILES_BTWEEN_HERE//";
	
	var tmp_search = file_dir_search(
		file_dir_cd_js() ,5, ["js$"], ["m.js$", "m.loadLate.js$", 
			tmpFILENAME +"$"]);
	
	for(var i=0; i< tmp_search.length; i+=1){ 
	  tmp_search[i] = tmp_search[i].split(file_dir_cd_js())[1]; }
	var tmp_outStr = "";
	for(var i=0; i< tmp_search.length; i+=1){
		tmp_outStr += '"' + tmp_search[i]+ '", '; }

	var tmpFileData = file_load_noembed( file_dir_cd_js(), tmpFILENAME);
	tmpFileData = tmpFileData.split(TMPFILENAMES_DIVIDER);
	tmpFileData[1] = "\n\n" + tmp_outStr + "\n\n";
	tmpFileData = tmpFileData.join(TMPFILENAMES_DIVIDER);
	file_save( file_dir_cd_js(), tmpFILENAME, tmpFileData);
}	} 

}



///////////////////////////////////////////////////
//below uses file: 'm._autoload_n_configs_n_start_level.js' (near m.js)
// level_editor_loader__in_autoload__load_init_tag --- data
// { 
//    room_name_dotnote:"", 
//    default_player_obj_dotnote:"", // or null, only works if warpInPL...
//    					// is defined, OR rmwarp is. 
//    warpInPlayerXY_overrides_rmwarp:{x:23, y,23}, // or null
//    use_rmwarp:false, 
//    use_rmwarp_direction:"left", //or null
// }
//
// uses file: 'm._autoload_n_configs_n_start_level.js' (near m.js)
var level_editor_loader__in_autoload__load_init_tag = 
    "//level_editor_loader__in_autoload__load_init_rm_player_etc_data//";
function level_editor_loader__in_autoload__load_init_rm_player_etc( getD){
		//getData, see above
	
	if(getD == null){ return;}
	if(getD.room_name_dotnote == null){return;}

	// getting player...
	if(getD.default_player_obj_dotnote != null){
		var tmpPlayer = 
		progen_dotnote(getD.default_player_obj_dotnote, true);
		if(getD.warpInPlayerXY_overrides_rmwarp != null){
		    tmpPlayer.x = getD.warpInPlayerXY_overrides_rmwarp.x;
		    tmpPlayer.y = getD.warpInPlayerXY_overrides_rmwarp.y;
	}	}
	

	// if NOT rmwarp -ing (just loading room. 
	if(getD.use_rmwarp != true){
		var tmpRm = rmloaded_b_globalThis[getD.room_name_dotnote];
		//add player to warp-obj-pool
		if(getD.default_player_obj_dotnote != null){
			if(tmpPlayer.graphic.length ==1){
				tmpRm.objs.push(tmpPlayer);
		}else{ tmpRm.objs_large.push(tmpPlayer);}}	
		rmloaded_loadroom(tmpRm);
		return; }

	//next, rmwarp, 
	if(getD.default_player_obj_dotnote != null){
		g_rmwarp_moveObjsBox_add_objs__run_pre_g_rmwarp( 
			[tmpPlayer], []);}	
	
	g_rmwarp( getD.room_name_dotnote, getD.use_rmwarp_direction);

	//updating player loc (if modded...)
	if(getD.warpInPlayerXY_overrides_rmwarp != null &&
			getD.default_player_obj_dotnote != null){
		 tmpPlayer.x = getD.warpInPlayerXY_overrides_rmwarp.x;
		 tmpPlayer.y = getD.warpInPlayerXY_overrides_rmwarp.y;}
}

// LOAD VIA level_editor__load_saved_mjs_vars_obj FIRST
//  (saves in 'm._autoload_n_configs_n_start_level.js'(near m.js) between:
//   '//level_editor_loader__in_autoload__load_init_rm_player_etc_data//')
function level_editor_loader__in_autoload__save_obj_data(getVarsObj){
	var tmpMjsTxt = file_load_noembed( file_dir_cd(), 
		"m._autoload_n_configs_n_start_level.js");
	if(tmpMjsTxt == null){ 
	   file_input("No m._autoload_n_configs_n_start_level.js found!");
	   return;}
	tmpMjsTxt = tmpMjsTxt.split(
		level_editor_loader__in_autoload__load_init_tag);
	tmpMjsTxt[1] = '\n' + JSON.stringify(getVarsObj,null,2)
			+'	\n	';
	tmpMjsTxt = tmpMjsTxt.join(
		level_editor_loader__in_autoload__load_init_tag);
	file_save( file_dir_cd(), 
		"m._autoload_n_configs_n_start_level.js", tmpMjsTxt);
}
// gets from 'm._autoload_n_configs_n_start_level.js' (near m.js)
// '//level_editor_loader__in_autoload__load_init_rm_player_etc_data//'
function level_editor_loader__in_autoload__load_obj_data(){
	var tmpMjsTxt = file_load_noembed( file_dir_cd(), 
		"m._autoload_n_configs_n_start_level.js"); 
	if(tmpMjsTxt == null){ 
		file_input("No m.load_configs_n_start_level.js found!");
		return {};}
	return JSON.parse( 
	  tmpMjsTxt.split(
		level_editor_loader__in_autoload__load_init_tag)[1]);
	
	
}
function level_editor_loader__draw_animation__play(
	o, get_graphic_frames__DOTNOTE_NAME, get_frames_per_new_frame,
		get_set_animation_frame_number_OPTIONAL,
		get_reverse_animation_OPTIONAL ){
		
	if(o._graphic_frames__dotnote_CAUGHT != 
			get_graphic_frames__DOTNOTE_NAME){
	  o._graphic_frames__dotnote_CAUGHT = 
		get_graphic_frames__DOTNOTE_NAME;
	  var tmpFrames =  progen_dotnote( 
			get_graphic_frames__DOTNOTE_NAME);
	  if(tmpFrames == null){
	    file_input("Error in finding object.graphic_frame__dotnote:", 
		get_graphic_frames__DOTNOTE_NAME,
		"in function 'level_editor__draw_animation__play'"); }
	 
	  o._graphic_frames__CAUGHT = tmpFrames;
	  o._graphic_frames__on_frame= 0;
	  o._graphic_frames__on_delay_countup = 0;
	}
	if(get_set_animation_frame_number_OPTIONAL!= null){
	 	o._graphic_frames__on_frame= 
			get_set_animation_frame_number_OPTIONAL;
	  	o._graphic_frames__on_delay_countup=0;
	}else{
		// if graphic is static...
		if(o._graphic_frames__CAUGHT.length ==1){
			o.graphic = o._graphic_frames__CAUGHT[0];}

		//counting down frames...
		o._graphic_frames__on_delay_countup +=1;
		if(o._graphic_frames__on_delay_countup > 
				get_frames_per_new_frame){
			o._graphic_frames__on_delay_countup=0;
			if(get_reverse_animation_OPTIONAL){
				o._graphic_frames__on_frame-=1;
				if(o._graphic_frames__on_frame<0){
				   o._graphic_frames__on_frame=
				     o._graphic_frames__CAUGHT.length-1; }
			}else{ o._graphic_frames__on_frame +=1;
				if(o._graphic_frames__on_frame >=
					o._graphic_frames__CAUGHT.length){
				   o._graphic_frames__on_frame =0; }
	}	}	}

	//displaying animation frame:
	o.graphic = 
		o._graphic_frames__CAUGHT[o._graphic_frames__on_frame ];
}

//required to play an animation
async function level_editor_loader__draw_animation__behav(o){
	// REQUIRES:
	// o.graphic_frames__dotnote -> graphics list 
	// o.graphic_frames__delay_between_frames -> animation speed
	level_editor_loader__draw_animation__play(
		o, o.graphic_frames__dotnote, 
		o.graphic_frames__delay_between_frames );
}


