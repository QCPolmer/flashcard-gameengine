//API_TAG//

// FOR LIGHT: set room_type room var to "shadows" ( or variations)
// ADD LIGHTS: with small-objects, just add: 
// 	light_width:5, light_gfx:gridstr (or null, I think)
// 	light_gfx draws a shape out of the light

//API_TAG//

var lightgrid={};
var lights_added_to_lightgrid=[]; 
//var room_light_type = "SEE_ALL"; // see_all, cave, day_view_limit. 
//phases: 1-8, clockwise 

//OK...
// need to create/draw/etc. 
// lines( and variations (line clusters,etc) )
// circles
// rays
// (boxes are a gimme)
// http://www.roguebasin.com/index.php/Dijkstra_Maps_Visualized
// http://www.roguebasin.com/index.php?title=The_Incredible_Power_of_Dijkstra_Maps
// https://ondras.github.io/rot.js/manual/#path

//http://www.adammil.net/blog/v125_Roguelike_Vision_Algorithms.html#mycode
//http://www.roguebasin.com/index.php?title=Digital_lines
//
//https://www.albertford.com/shadowcasting/
// OK, don't have to worry about the map as much, 
// as one map will overlay the others! 
// Soooo... if bottom map has a wall, top doesn't, it won't show. 
function make_light_col_map( points, see_through_char, originX, originY ){
	var return_map = gridstr_scale(" ", 200,200);
	// points is 1d array, x then y
	for( var i=0; 
		(tmp_colobj_lrg= rmloaded_lookupprop_getlrgobjs_i(LIGHT_PROP, i)
			&& tmp_colmap != null); i+=1){
		//painting all the maps together. 
		return_map = gridstr_overlay( 
			return_map, tmp_colobj_lrg.graphic,
			originX, originY, see_through_char);	}	
	return point_len; }

// probably easier to use x,y, x', y', as it would allow 
// EASY placing of lines!
// ( if I do [x-x' +" "+ y-y'] and fetch a line recipe with that, 
// 	I can catch the recipes and not calculate every line!) 
function lightOverlay_gen(){
	var LIGHT_PROP = "l";
	var len = rmloaded_lookupprop_getlrgobjs_len( LIGHT_PROP);

	var tmp_canvas = " ";
	for(var i=0; i < LIGHT_PROP; i+=1){
		rmloaded_lookupprop_getlrgobjs_i(LIGHT_PROP, i)

		draw_1_8th_circle( tmp_canvas, x, y, o_clock, 
				length  );

		draw_line( tmp_canvas, "X", x, y, angle,
			line_length_collision_free( //length
				prop, x,y, angle, length));

		rmloaded_lookupprop_getlrgobjs_i(LIGHT_PROP, i);

	}

}

/*
	duk_put_global_string(ctx, "rmloaded_lookupprop_getlrgobjs_i"); //2
	duk_put_global_string(ctx, "rmloaded_lookupprop_getlrgobjs_len"); //1
	duk_put_global_string(ctx, "rmloaded_lookupxy_getobjs_len");// 2
	duk_put_global_string(ctx, "rmloaded_lookupxy_getobjs_at"); //3
*/
function draw_line_W_PATH(graphic, x_start, y_start, x_end, y_end){
// This is not used, but could use as an example in future. 
	// setting 5 to 'no-movement', 4 to negetive, etc.
	var draw_path = "6556565665454656565454";
	//file_input( x_start + " "+ y_start);
	draw(graphic, x_start, y_start,"");
	for(var i=0; i< draw_path.length; i+=2){
		x_start = x_start + parseInt(draw_path[i])-5;
		y_start = y_start + parseInt(draw_path[i+1])-5;
		draw(graphic, x_start,
				y_start);
	}

}



// CAN optimize this with a catch or 2
// draw_link_points_a_n_b_with_gridstr == just change last paramiter!!!
function sketch_link_points_a_n_b_with_gridstr__NOT_USING_AND_UNFINISHED( getGridstr,
	a_x, a_y,  a2_x, a2_y, // a is on getGridstr!!! line goes a to a2!
	b_x, b_y,  b2_x, b2_y, //b IS ON SKETCH!! Line goes b to b2!
		// a-a2 is 1 line, b-b2 is another line!
	  OPTIONAL_draw_dont_sketch ){ //allows drawing vs sketching!!!
	//offsets
	var offX = gridstr_rotation_ROTABLE_BORDER_X_OFFSET( getGridstr );
	a_x += offX; a2_x += offX;
	var offY =gridstr_rotation_ROTABLE_BORDER_Y_OFFSET( getGridstr );
	a_y += offY; a2_y += offY;

	var rot_diff=  Math.atan2(a2_x-a_x, a2_y - a_y)
		- Math.atan2( b2_x - b_x, b2_y - b_y);

	var tmp_border = gridstr_rotation_MAKE_ROTATABLE_BORDER(
		getGridstr, transparent_char);
	
	var getGridstr = gridstr_overlay(
		tmp_border, getGridstr, offX, offY);

	getGridstr = gridstr_rotate( getGridstr, rot_diff, 
				 transparent_char); 
	
	file_log( getGridstr  + "pbs");

	// can optimize this EASILY, but still...
	// from _gridstr_rotate (in gridstr.js
	var arr2d = getGridstr.split("\n");
	var x_origin = (arr2d[0].length-1)/2; 
	var y_origin = (arr2d.length-1)/2;
	/// continued to above... 
	var tmp_x =0;
	tmp_x = 
	  gridstr_rotate_point_X( x_origin, y_origin, a2_x, a2_y, rot_diff);
	a2_y = 
	  gridstr_rotate_point_Y( x_origin, y_origin, a2_x, a2_y, rot_diff);
	a2_x = tmp_x;
	tmp_x = 
	  gridstr_rotate_point_X( x_origin, y_origin, a_x, a_y, rot_diff);
	a_y = 
	  gridstr_rotate_point_Y( x_origin, y_origin, a_x, a_y, rot_diff);
 	a_x = tmp_x;
	//OK, got rot/ points rot/ offset with points!
	// now just need scale and translation. 
	// translation SHOULD be batched. (add 2 offsets, one for scaling!)
	
	// OK, getting distance precent from a to b. 
	var scale_x =  Math.abs((a2_x - a_x)/(b2_x - b_x));
	var scale_y =  Math.abs((a2_y - a_y)/(b2_y - b_y));
	
	var offset_x = a_x - b_x; var offset_y = a_y - b_y;

	if(OPTIONAL_draw_dont_sketch){
	   file_log( gridstr_scale_nearest_neighbor( getGridstr, 20,20
		   		//arr2d[0].length * scale_x,
		   		//arr2d.length * scale_y
	   			) + 
		   	"" + scale_x + " -scalex " + 
		   	scale_y + " -scaley " +
		   	offset_x * ( scale_x) + " "
		   	+offset_y * ( scale_y));	
	   draw( gridstr_scale( getGridstr, scale_x, scale_y), 
		offset_x * ( scale_x), 
		offset_y * ( scale_y),
		"");
	}else{
	    sketch( gridstr_scale( getGridstr, scale_x, scale_y), 
		offset_x * ( scale_x), 
		offset_y * ( scale_y),
		"");
	}

	// OK, first scale, then add offset + (scale_x/y *offset)

}


//API_TAG//
//NOTES TO BELOW: for the 'graph_mid_list'- if the lines should be 
//	aligned, have them be the same width/height (also:
function sketch_capped_line( x, y, x_end, y_end,
	graph_start, graph_mid_list, //mid_list is a list of 'middle' 					 //graphics, can be any #
		graph_end, transparent_char,
	rotate_FULL_QRTR_NONE, //FULL here draws on center is wonky. 
	caps_rotate_FULL_QRTR_NONE, //FULL for this not accurate: don't use
	horiz_not_vertical, 
	sketch0_draw1_coltest2, //use 0 or 1, NOT 2 or 3
	OPTIONAL_evenly_placed_OR_null, // for center, overrides below!
	OPTIONAL_draw_every_steps
	){
//API_TAG//
	//I COPIED THIS 3X, CAN PROBABLY GIVE IT OWN FUNCTION!!!
	if(horiz_not_vertical == void null){
	  if(Math.abs(x_end-x) > Math.abs(y_end-y)){
	     horiz_not_vertical = 1;}else{horiz_not_vertical =0;} }
	var START_cap_offsets = _sketch_line_get_cap_offset( 
		x, y, x_end, y_end, horiz_not_vertical,
		graph_start, caps_rotate_FULL_QRTR_NONE );
	var END_cap_offsets = _sketch_line_get_cap_offset( 
		x, y, x_end, y_end, horiz_not_vertical,
		graph_end, caps_rotate_FULL_QRTR_NONE );
	for(var i=0; i< graph_mid_list.length; i+=1){
	  //drawing center first, drawing other over it
	  sketch_line( START_cap_offsets[0], START_cap_offsets[1], 
		END_cap_offsets[2], END_cap_offsets[3], 
		rotate_FULL_QRTR_NONE, //str
		graph_mid_list[i], transparent_char, 
		horiz_not_vertical,
		sketch0_draw1_coltest2,  //bool
		null, //getlist
		OPTIONAL_evenly_placed_OR_null, 
		OPTIONAL_draw_every_steps ); }
	sketch_line( x, y, x_end, y_end, caps_rotate_FULL_QRTR_NONE, 
		graph_start, transparent_char, horiz_not_vertical,
		sketch0_draw1_coltest2, [0]); // Draw start!
	sketch_line( x, y, x_end, y_end, caps_rotate_FULL_QRTR_NONE, 
		graph_end, transparent_char, horiz_not_vertical,
		sketch0_draw1_coltest2, [1]); // Draw start!
		
}
// returns [startX, startY, endX, endY]
function _sketch_line_get_cap_offset( x, y, x_end, y_end,
		horiz_not_vertical, graphic, rotate_FULL_QRTR_NONE ){ 
			//full returns x,y, x_end, y_end
			// because anti-atalizing ain't precise!
	//I COPIED THIS 3X, CAN PROBABLY GIVE IT OWN FUNCTION!!!
	if(horiz_not_vertical == void null){
		if(Math.abs(x_end-x) > Math.abs(y_end-y)){
		  horiz_not_vertical = 1;}else{horiz_not_vertical =0;} }
	if(graphic.length == 0 || rotate_FULL_QRTR_NONE == "FULL"){ 
		return [x, y, x_end, y_end]; }

	var tmp_reverse_x_y = false;
	if(rotate_FULL_QRTR_NONE == "QRTR"){
		if( !horiz_not_vertical){ tmp_reverse_x_y=true;}}
	//file_input( graphic);
	var g_width = gridstr_width(graphic);
	var g_height = gridstr_height(graphic);
	
	if(tmp_reverse_x_y != true){
	  var x_len = g_width-1; var y_len = g_height-1;
	}else{ 
	 var x_len = g_height-1;var y_len = g_width-1; }
		
	if(horiz_not_vertical){
		if(x > x_end){ return [x - x_len, y, x_end + x_len, y_end];
		}else{ return [ x + x_len, y, x_end- x_len, y_end]; }
	}else{
		if(y > y_end){ return [x, y - y_len, x_end, y_end + y_len];
		}else{ return [ x, y + y_len, x_end, y_end - y_len]; }
}	}



//BELOW ONLY WORKS IN 1-CHAR LINES, NOT CAPPED ONES!!!
// returns _sketch_lines_col_d_xycol_list!!!
// 	(the above is goes: x,y,col_char,  x2, y2, col_char2 ...
// 	 	so testing (return).length ==0 for no collisions!)
// 	 WILL NEED TO ADD ANOTHER COLTEST PER POINT TO GET OBJS!!!, 
// 	 	BUT WITH THIS HAVE X,Y!!!
// 	 	EG:
// 	 var cols = sketch_line_coldetect(o.x, o.y, o.x-10, o.y,
//		"z", true, //horiz_not_vertical, 
//		false);//get_1_not_multi_pnts, //1 pnt IS somewhat faster!
//	for(var i =0; i< cols.length; i+=3){
//	 file_log( cols[i] + " " +cols[i+1] + " " +cols[i+2] + " "); }




//https://www.redblobgames.com/grids/line-drawing.html
//IF I can get it so I can draw lines, then shift them 1 pix in 
//whatever the tangent direction is, I SHOULD be able to draw 
//lines OR waves of pixels!
//EDIT:
//why not just draw the graphic? It can be a wider graphic!
//// 	NOTE: probably should make a 'sketch' type, or optional var. 
//	draw_line( see below, same function!
function _sketch_line_CORE_UNUSED( //use sketch_line or ''_coltest
			graphic, transparent_char, 
		x, y, x_end, y_end, 
		// BELOW IS UNTESTED, SHOULD TEST IT AT SOME POINT!!!
		OPTIONAL_draw_instead_of_sketch, //bool 
		//OPTIONAL_startcap_graphic, //null for don't use
		//OPTIONAL_endcap_graphic, //null for don't use
		OPTIONAL_draw_every_steps){ //int # steps or null
	
	//OK, can scale FIRST then scan center 
	//	
	//
	//graphic =gridstr_rotation_MAKE_ROTATABLE_BORDER(graphic);

	if(OPTIONAL_draw_instead_of_sketch){ var getdraw = draw;
	}else{ var getdraw = sketch; }

	var x_dist = x - x_end;
	var y_dist = y - y_end;
	if(x_dist > 0){ var sign_x = -1;}else{ var sign_x = 1; }
	if(y_dist > 0){ var sign_y = -1;}else{ var sign_y = 1; }
	x_dist = Math.abs(x_dist); y_dist = Math.abs( y_dist);
	
	//setting the step-dist for 1 and slope...
	var max_step_x_dist = x_dist/y_dist;
	if( max_step_x_dist < 1){ max_step_x_dist = 1;} 
	var max_step_y_dist = y_dist/x_dist;
	if( max_step_y_dist < 1){ max_step_y_dist =1; }
	
	//if( OPTIONAL_startcap_graphic != void null){
	 //   var caught_start_x = x; var caught_start_y = y;}
	
	//centering line
	var step_x_dist =0; var step_y_dist =0;
	var g_width = gridstr_width(graphic);
	var g_height = gridstr_height(graphic);
	
	var xoff = -Math.floor(g_width/2); 
	var yoff = -Math.floor(g_height/2)
	//////////////////////////////////
	// actual stepping walk! (NOT SKIPPING STEPS ON THIS PART!
	// /////////////////////////////
	if(OPTIONAL_draw_every_steps == void null){ 
		OPTIONAL_draw_every_steps =0;}
	var cur_steps = 0;
	//stepping y first if it's greater! (HALF step first step!)
	if( y_dist > x_dist){ step_y_dist +=max_step_y_dist/2;//halfstep!
	while(  step_y_dist >0 && y != y_end){
		 y += sign_y; step_y_dist -=1; cur_steps+=1;
		if(cur_steps >= OPTIONAL_draw_every_steps){
		   getdraw(  graphic, x+xoff, y+yoff, transparent_char);
		   cur_steps =0; } } 
	}else{ step_x_dist +=max_step_x_dist/2;
	while(  step_x_dist >0 && x != x_end){
		 x += sign_x; step_x_dist -=1; cur_steps+=1;
		if(cur_steps >= OPTIONAL_draw_every_steps){
		   getdraw(  graphic, x+xoff, y+yoff, transparent_char);
		   cur_steps =0; } }
	step_y_dist +=max_step_y_dist/2; // halfstep!
	while(  step_y_dist >0 && y != y_end){
		 y += sign_y; step_y_dist -=1; cur_steps+=1;
		if(cur_steps >= OPTIONAL_draw_every_steps){
		   getdraw(  graphic, x+xoff, y+yoff, transparent_char);
		   cur_steps =0; } 
	}	}
	//////////////////////////AFTER FIRST STEP//////////
	while( x != x_end || y != y_end){
		step_x_dist +=max_step_x_dist;
		while(  step_x_dist >0 && x != x_end){
		   x += sign_x; step_x_dist -=1; cur_steps+=1;
		if(cur_steps >= OPTIONAL_draw_every_steps){
		   getdraw(  graphic, x+xoff, y+yoff, transparent_char);
		   cur_steps =0; }
		}
		step_y_dist +=max_step_y_dist;
		while(  step_y_dist >0 && y != y_end){
		   y += sign_y; step_y_dist -=1; cur_steps+=1;
		   if(cur_steps >= OPTIONAL_draw_every_steps){
		      getdraw(  graphic, x+xoff, y+yoff, transparent_char);
		      cur_steps =0; }
	}	}
	// draw last place
	 getdraw( graphic, x_end+xoff, y_end+xoff, transparent_char); 
	
	//////////////////////////////////////////////////
	// end steps!
	///////////////////
	
	/*
	if( OPTIONAL_startcap_graphic != void null){
	    //centering line
	  OPTIONAL_startcap_graphic =gridstr_rotation_MAKE_ROTATABLE_BORDER(
		OPTIONAL_startcap_graphic);
		
 	    var tmpArr = OPTIONAL_startcap_graphic.split("\n");
	    var xoff2 = -Math.floor(tmpArr[0].length/2); 
	    var yoff2 = -Math.floor(tmpArr.length/2)
	
	    getdraw(  OPTIONAL_startcap_graphic, 
		    caught_start_x+xoff2, caught_start_y+yoff2, 
		    transparent_char);} 
	if( OPTIONAL_endcap_graphic != void null){
	   //centering line
	   OPTIONAL_endcap_graphic=gridstr_rotation_MAKE_ROTATABLE_BORDER(
		   OPTIONAL_endcap_graphic);
	    var tmpArr = OPTIONAL_endcap_graphic.split("\n");
	    var xoff2 = -Math.floor(tmpArr[0].length/2); 
	    var yoff2 = -Math.floor(tmpArr.length/2)
	
	   getdraw( OPTIONAL_endcap_graphic, 
		   x_end+xoff2, y_end+yoff2, transparent_char);
	}else{ 
	  // rubbish from when part of sketch_line
	 getdraw( graphic, x_end+xoff, y_end+xoff, transparent_char); 
	}*/
	
}


function sketch_init__screensize( string_to_scale){
  	sketch_init( gridstr_scale(string_to_scale,
		draw_canvas_get_width(),draw_canvas_get_height())); }
function sketch_obj_cam_offset(o ){
	sketch(o.graphic, o.x+_rmloaded_camera_x, o.y+sketch_offset_y);}
function sketch_obj(o, sketch_offset_x, sketch_offset_y){
	sketch(o.graphic, o.x+sketch_offset_x, o.y+sketch_offset_y);}
function sketch_draw_as_overlay(get_transp_char){
	draw(sketch_get(), 0,0,get_transp_char); }


//OK, I need to have a 'convert ALL CHARACTERS NOT A to B'
// this will be able to screen : 1110022003300 -> 1110011001100
// which I can then screen overlay. 
//
//function gridstr_replace_allchars_EXCEPT(
//	getStr, getChar_dont_replace, getChar_replace){

// oclock is 0-7 OR 8  for ALL!
function _sketch_join_light_maps(){
	sketch_init();
	for( var i=0; i< light_maps.length; i+=1){
		sketch( light_maps[i],
			light_map_x_offset - cur_map_x_offset,
			light_map_y_offset - cur_map_y_offset, "&" );
	
	}
	sketch_get()

}

var _sketch_light_pool_1d__x_y_width_gfx=[]; //   3
//outliner
var _sketch_rays_multi_wallsstr = ""; // gridstr
var _sketch_rays_multi_lightsstr = ""; //gridstr
var _sketch_rays_multi_viewstr = ""; //gridstr
var _sketch_rays_black_screen = ""; //gridstr
var _sketch_rays_x = 0; _sketch_rays_y = 0;
// full size... may need to optimize more, but good for now.
var _sketch_view_depth = 45;

var _clock_step = 8;
function sketch_o_clock_step_set(getStep){
	sketch_rays_reset();
	o_clock_start_next = 0;
	_clock_step = getStep;}
function sketch_rays_reset(){
	//file_input(draw_canvas_get_width()+"  "+draw_canvas_get_height());
	if( _sketch_rays_black_screen == ""){
		_sketch_rays_black_screen = gridstr_scale(" ", 
			draw_canvas_get_width(), draw_canvas_get_height());}
	_sketch_rays_multi_lightsstr =   _sketch_rays_black_screen;
	_sketch_rays_multi_viewstr =  _sketch_rays_black_screen;
	_sketch_rays_multi_wallsstr =  _sketch_rays_black_screen; }
function sketch_rm_lrgobj_group(group, x_offset,y_offset){
	var len = rmloaded_lookupprop_getlrgobjs_len(group);
	//file_log(len);
	for(var i=0; i< len; i+=1){
		sketch(rmloaded_lookupprop_getlrgobjs_i(group, i).graphic,
		   rmloaded_lookupprop_getlrgobjs_i(group, i).x+x_offset,
		   rmloaded_lookupprop_getlrgobjs_i(group, i).y+y_offset,
			" "); //transp. character(see through)
	}
}
function sketch_rays_add_1turn_light( x,y,width, force_full_speed){
	_sketch_light_pool_1d__x_y_width_gfx.push(
		Math.floor(x),Math.floor(y),width,""); }
//requires obj has 'light_width' property 
// only usable if using lighting function. 
// ...
// I should have a sweep to rest lights otherwise... 
// Probably should bundle lights in the game loop. 
//API_TAG//
//see: _sketch_rays_multi_main below for how to use. 
// 	THIS IS A BEHAVIOR
function ray_light_width(o){ //BEHAVIOR
	if(o.light_gfx == void null){  o.light_gfx = ""; }
	_sketch_light_pool_1d__x_y_width_gfx.push(
	  Math.floor(o.x), Math.floor(o.y), o.light_width, o.light_gfx);}
//API_TAG//


function _sketch_rays__HELPER_listdraw( 
	xyWidGfx, // _sketch_light_pool_1d__x_y_width_gfx
	   // (see _sketch_rays_multi_main 4 details & drawing shadows)
	cam_x, cam_y,
	get_sketch_rays_multi_wallsstr, // a gridstr of ALL walls. 
	o_clock_start_N_DRAW, o_clock_end,
	geto_clock_start_next
){
	var geto_clock_start_next_CHAR = ""+geto_clock_start_next;
	var o_clock_start_N_DRAW_CHAR = ""+o_clock_start_N_DRAW;
	
	var len = xyWidGfx.length;
	for(var i =0; i< len; i+=4){
	  if(xyWidGfx[i+3] == ""){ //Gfx, not sure why...
		  _sketch_draw_shadows_ray( 
  			0,8,	//oclock_start - end 
			xyWidGfx[i+2], 
			//_rmloaded_camera_x, _rmloaded_camera_y, 
			xyWidGfx[i]+ cam_x,
				xyWidGfx[i+1]+cam_y, 
			get_sketch_rays_multi_wallsstr,
			0, 0, 
			xyWidGfx[i+3],geto_clock_start_next_CHAR );
		  		//""+o_clock_start_next );
			 //uses o_clock_start_next to insure nxt turn del.
		 continue;	}
		//still lights, above is for /fullspeed obj paramiter
		// OK, for hiding lights, I should use a seperate
		  // behavior to 'store' and 'retrieve' objects
		  // based on a grid, which will be 100x faster! 
		  _sketch_draw_shadows_ray( 
  			o_clock_start_N_DRAW, o_clock_end,
			xyWidGfx[i+2], 
			//_rmloaded_camera_x, _rmloaded_camera_y, 
			xyWidGfx[i]+ cam_x, xyWidGfx[i+1]+cam_y, 
			get_sketch_rays_multi_wallsstr,
			0, 0, 
			xyWidGfx[i+3], o_clock_start_N_DRAW_CHAR, true );
				//""+o_clock_start_N_DRAW, true );
		  	//gridstr_screen_light, screen_light_char )
	}

}

var o_clock_start_next =0;
//API_TAG//
function _sketch_rays_multi_main( view_x, view_y,  col_group_char,
		get_cam_x, get_cam_y, no_light ){ //no_light=see-to-walls
// This is the standard 'draw shadows' function.
	//  	(base colgroup is:'0' for walls!)
	//  (to see how it works, I recommend looking it here). 
//	ALSO:See how it's used in 'rmloaded.js' for examples...
// USE INSTEAD IF POSSIBLE: just change the 'room.room_type' (rmloaded_room)  
// 	to 'shadows' etc. (use 
	// 	o.light_width =12; ray_light_width(o);
	// 	o.light_gfx = "  oo   ";(optional)
	// 	to add lights, to room, otherwise,will just be black screen
//API_TAG//
	if(_sketch_rays_black_screen == ""){ sketch_rays_reset(); }
	
	//var view_x = obj.x; var view_y = obj.y;	
	var o_clock_start_N_DRAW = o_clock_start_next+0;
	var o_clock_prev_DELETE_CHAR = ""+o_clock_start_N_DRAW;
	var o_clock_end = o_clock_start_N_DRAW  + _clock_step;
	if(o_clock_end >= 8){o_clock_end = 8;}
	o_clock_start_next += _clock_step;
	if(o_clock_start_next >=8){ o_clock_start_next =0;}
	
	var x_offset =  get_cam_x - _sketch_rays_x;
	var y_offset = get_cam_y- _sketch_rays_y;
	_sketch_rays_x = get_cam_x; _sketch_rays_y = get_cam_y;
	
	//walls
	sketch_init(_sketch_rays_black_screen);	
	sketch_rm_lrgobj_group( col_group_char, 
		get_cam_x, get_cam_y);
	_sketch_rays_multi_wallsstr = sketch_get();
	sketch_end();

	//lights
	if(no_light != 1){
	  sketch_init(
		gridstr_overlay(
			_sketch_rays_black_screen,
			_sketch_rays_multi_lightsstr,
		 x_offset, y_offset,
		o_clock_prev_DELETE_CHAR ));
	
	   _sketch_rays__HELPER_listdraw( 
		_sketch_light_pool_1d__x_y_width_gfx,
		get_cam_x, get_cam_y,
		_sketch_rays_multi_wallsstr,
		o_clock_start_N_DRAW, o_clock_end,
		o_clock_start_next);

	_sketch_light_pool_1d__x_y_width_gfx= [];
	_sketch_rays_multi_lightsstr = sketch_get();	
	sketch_end();
	}
	// actual draw circle
	//then draw 'view'
	sketch_init(
		gridstr_overlay(
			_sketch_rays_black_screen,
			_sketch_rays_multi_viewstr,
		 x_offset, y_offset,
		o_clock_prev_DELETE_CHAR ));
	
		  // below is 'spreading the rays':oclock is 2 part-loops
		 // can probably use this as an option by 
		// rewiring _ray_oclock var.  
		//EDIT: not perfect.. still need to see about 
		//	'flashlight' objects. 
		//if(j  >3){ var tmp_clock = j*2-7;
		  //}else{var tmp_clock = j*2;}	
	//file_input(_sketch_rays_multi_viewstr);
	// DRAWING- the 'view-circle'...I think...	
	_sketch_draw_shadows_ray( 
			o_clock_start_N_DRAW, o_clock_end,
  			 _sketch_view_depth, 
			view_x +get_cam_x, view_y+get_cam_y, 
			_sketch_rays_multi_wallsstr, 
			0,0,
			"", ""+o_clock_start_N_DRAW, true); 
	_sketch_rays_multi_viewstr = sketch_get();
	
	//file_input( _sketch_rays_multi_viewstr);
	if(no_light != 1){
	   var retStr = gridstr_overlay(
			sketch_get(),
			gridstr_replace_allchars_EXCEPT(
				_sketch_rays_multi_lightsstr," ", "&"),
			 0,0, "&");
	}else{
		var retStr = sketch_get()
	}
	//file_input(gridstr_replace_allchars_EXCEPT(
	//		"------ ----- ---", " ","&"));
	sketch_end();
	//retStr= gridstr_replace_allchars_EXCEPT(
	//		retStr, " ","&");
	//file_input(retStr);
	//return _sketch_rays_black_screen;
	//return retStr;
	
	return 	gridstr_replace_allchars_EXCEPT(
			retStr, " ","&");	
	
}





//1d list, 3 vals, this is 'draw light'
var draw_shadows_ray = []
//API_TAG//
function draw_shadows( x, y, wall_map_gfx, wall_x, wall_y){
// I don't think I actually am using this. The shadows things 
	//  are (mostly) hard coded. Can check sketch_rays.js 
	//  for how to get it to work. 
//API_TAG//
  sketch_init__screensize(" ");  
  //sketch_init( gridstr_scale(" ",90,80));
	
  //file_log( gridstr_width(sketch_get()));
  var max_depth = 40;
  var min_len =0;  max_len=1;
	
  // need gridstr_pix_get (and probably set as well!)
	
	//ok, need prev. block: 
	//Looks like: turn it into a %, then multiply:
	//	prev_j = Math.floor(((j)/(i))*(i-1))
	//	(solved from (j/i) = (prev_j)/(i-1) )
    sketch_rays_reset();
    sketch_init(_sketch_rays_multi_wallsstr);
    sketch_rm_lrgobj_group( "0", _rmloaded_camera_x,_rmloaded_camera_y);
    var tmp_walls = sketch_get();
    sketch_end();	 
	
    _sketch_draw_shadows_ray( 
		//o_clockstr, oclock_end, max_depth, x_offset, y_offset, 
	   //			wall_map_gfx, wall_x, wall_y )
   	   0, 11, 
	    11, x,y,//x-_rmloaded_camera_x, y-_rmloaded_camera_y,  
		//gridstr_scale(" ",80,80), 0,0);}
			tmp_walls,
			0,
			0,
		"", "&");
    sketch_char("M", 2,6);
    //sketch_draw_as_overlay(" ");
    sketch_draw_as_overlay("&");
    //draw(sketch_get(), 0,0,"&"); // this is actual map.
    //draw(sketch_get(), x-40,y-20," ");
    //file_input("---"+sketch_char_get(2,6)+ "-----");
    sketch_end();
}

// ---- shadowcasting looks MUCH faster
// http://www.roguebasin.com/index.php/FOV_using_recursive_shadowcasting
// https://www.youtube.com/watch?v=7veaq9gULfA
// --- narrow rays
// https://gist.github.com/370417/59bb06ced7e740e11ec7dda9d82717f6
// http://www.adammil.net/blog/v125_Roguelike_Vision_Algorithms.html#shadowcast
// http://roguebasin.com/?title=FOV_using_recursive_shadowcasting_-_improved
// http://www.roguebasin.com/index.php?title=Bresenham%27s_Line_Algorithm

