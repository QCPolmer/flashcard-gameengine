//OUTLINE:
update_controller = function(){} //for 'update'
//API_TAG//
// BELOW NEVER WORKED PERFECT: I'M LEAVING IT HERE AS A WARNING: 
// 	DO NOT TRY TO MAKE DIAGNOLS WORK WITH KEY COMBOS!
// 	JUST CODE THEM AS KEYPRESSES (aswd + qezc for diagnols)
//controller_getpress_move_with_diagnol = function(c){} //controller
	// above is for single presses.
controller_getpress = function(c){};
	//can use controllers[0].pressed[0]; 
var CONTROLLERS_DIRS = ["UP","DOWN","LEFT","RIGHT"];
var CONTROLLERS_DIAG =["UP_LEFT","UP_RIGHT","DOWN_LEFT","DOWN_RIGHT"]
controllers = []; //list of controllers
	//controller_interpreter to bind
//// BELOW IS INTERNAL! USED BASICALLY BY UPDATE
controller_interpreter = function(c, key){}// controller, key
/// ABOVE IS INTERNAL!
//API_TAG//

//API_TAG//
// 	CONTROLLER: BASIC USE: (UPDATES DURING UPDATE, 
// 	  and see 'cntrls' BELOW FOR 'key-options' (it's like a controller)
//	USE FILE_LOG_INPUT OR FILE_INPUT FOR C-OUT_OF_GAME INPUT!
//
//	FOR GETTING GAMEPAD-STYLE KEYPRESSES:
//	controllers[0].isdown["GAMEPAD_STYLE_KEY_NAME"] 
// 	controllers[0].pressed[0] (this is a list of recently pressed 
// 		keys(in gamepad_style-key format. 
// 	-------------------------\
// 	FOR GETTING ACTUAL KEY-INPUT: 
// 	controllers[0].getch:"", 
// 		WILL RETURN: ArrowDown, ArrowLeft, ArrowRight,
// 			ArrowUp, Enter, Backspace, Tab, Escape 
// 			NOT: Delete, which getch seems to
// 				throw a fit about getting. 
// 				(use Escape instead, or something)
// 	------------SINGLE CHARACTER get key(caps too) pressed type of thing
//	controllers[0].getch_chars_only:"",
//	------------SINGLE CHARACTER get key(caps too) NO
//
		// cntrls: UP/DOWN/LEFT/RIGHT
// 		//	(for upleft/upright, the aswd keys
// 		//		extend to:qezc, and press: up AND left)
// 				(see behavior_basic_movement_cols_w_0)
		// 	A/B/C/D/ENTER/ESCAPE
		// 	SEARCH/SEARCH_NEXT/SEARCH_PREV
// 								//
//
// 		(SEE how controller is defined in controller.js,
// 			look for controller_1.controller
// 			the dictionary key is key to detect, then 
// 			 the list is a 2 word pattern:
// 			 	["press", "key"     ,  "release", "key"]
// 			The ones with a U_ or D_ prefix are HTML ONLY.
////API_TAG//

update_controller = function(){};
///////////////////////////////////////////////
////////////////////////////// MOUSE:
////////////////////////////////////

// these are pre-controller setting: for internal use (OS specific, 
// 	THIS is what gets set!)
var _controller_mouse_x_OS_SETS=0; var _controller_mouse_y_OS_SETS=0;
var _controller_mouse_up_OS_SETS=0; var _controller_mouse_down_OS_SETS=0;
//in case it wasn't settup, a fallback
if(typeof update_controller_mouse_OS_SPECIFIC == "undefined"){
var update_controller_mouse_OS_SPECIFIC = function(){}; }


//API_TAG// 
//main mouse-getters... do NOT redefine!
////-----------------------
// -----------------------------------------
// ----------WARNING FOR MOUSE-------------
// ----------- TERMINAL LIMITATIONS (SOLVED?------------
// ----------------------------------------
//  PREVIOUSLY there were issues with linux terminal.
//  	(presses threw signals other than mouse-presses) 
//  	Now... I think they are solved. 
//  MouseX and MouseY -SHOULD- update on -ANY- movement. 
//  	(tested on linux for windows, HTML and windows)
// -------------------------------------------------------
var controller_mouse_x = 0; var controller_mouse_y = 0;
var controller_mouse_down = 0; var controller_mouse_up = 0;
var controller_mouse_held = 0;;

// this all versions use
function update_controller_mouse(){
//API_TAG// 
	update_controller_mouse_OS_SPECIFIC( );

	controller_mouse_up = 0; controller_mouse_down = 0; 	
	if(controller_mouse_held !=1){
		controller_mouse_down = _controller_mouse_down_OS_SETS; 
	}else{   controller_mouse_up = _controller_mouse_up_OS_SETS; }
	if(controller_mouse_down){ controller_mouse_held = 1;}
	if(controller_mouse_up){ controller_mouse_held = 0;}
	if(controller_mouse_held || controller_mouse_up){
		_controller_mouse_down_OS_SETS =0; 
		_controller_mouse_up_OS_SETS =0;
	}
	//this 'if' disables win/html mouse-hover, as linux xterm 
	// it won't work for. Remove the 'if' will allow mouse hover.	
	if(1 || controller_mouse_up || controller_mouse_down || 
			controller_mouse_held){
	   controller_mouse_x = _controller_mouse_x_OS_SETS; 
	   controller_mouse_y = _controller_mouse_y_OS_SETS; 	
	   if(_controller_mouse_x_OS_SETS > draw_canvas_get_width()){
		controller_mouse_x = draw_canvas_get_width(); }
 	   if(_controller_mouse_y_OS_SETS > draw_canvas_get_height()){
		controller_mouse_y = draw_canvas_get_height();  }
	}
} 

//API_TAG// 
function controller_mouse_button_draw(getTxt, getX, getY, 
		getTransparentChar, 
		getDontDrawJustDetect_OPTIONAL,
		getDontBlinkOnClick_OPTIONAL ){
	//returns if mouse clicked (1 for click, 0 for no-click)
	//DRAWN TO rmloaded_draw_overlay!!!
//API_TAG// 
	var tmp_return=0; 
	if(controller_mouse_down == 1){ 
		getTxt = getTxt.split("\n");
		var tmpY = getY-1; 
		for(i=0; i< getTxt.length; i+=1){ tmpY +=1;
		   if(controller_mouse_y == tmpY){
			if(controller_mouse_x >= getX && 
			   controller_mouse_x < getX+getTxt[i].length){
				
				tmp_return =1; break;
	}	}	}	}
	if(!getDontDrawJustDetect_OPTIONAL){
	   if(getDontBlinkOnClick_OPTIONAL || tmp_return==0){
		if(typeof getTxt != "string"){getTxt = getTxt.join("\n");}
		rmloaded_draw_overlay(
			getTxt, getX, getY, getTransparentChar); }}
	return tmp_return;
}

///////////////////////////////////////////////
////////////////////////////// 
////////////////////////////////////


_controller_1 = {
	_PRESSED_TIMEOUT_MAX:4, // gonna redefine 
	_pressed_timeout:0,
	_WAITING:"...",
	_PRESSED_MAX:6,
	_pressed_buffer:[], // internal tracker
	_PRESSED_DEFAULT:["...","...","...","...","...","..."],
	
	_timed_press:{},
	//set below to to 'TIME...MAX val to make ONLY dash movements.
	// REPEAT is for if a button is HELD, so releasing it will 
	// immediately stop it. 
	_TIMED_PRESS_REPEAT: 2, //repeated presses set it to this
	_TIMED_PRESS_MAX: 16, // first press
	_TIMED_PRESS__SINGLE_PRESS_MAX:2, // for single keypress detection, 
		// vs 'holding' 

	_keyboard_getch:[], 
	getch:"",
	getch_chars_only:"",
	pressed:[], // for fighting game moves,  this is a 
	isdown:{}, // gonna set to 'down for how long' 
	//_timer_controller_getpress_move_with_diagnol  :0,
		//just added, may delete. EDIT: didn't fucking work!
	
	controller:{
		// cntrls: UP/DOWN/LEFT/RIGHT/UP_RIGHT/UP_LEFT
		// 	DOWN_RIGHT/DOWN_LEFT 
		// 	A/B/C/D/ENTER/ESCAPE
		// 	SEARCH/SEARCH_NEXT/SEARCH_PREV
		//
		// 	Technically, this system can use any 
		// 	'keys' on controller, as it just checks a
		// 	dictionary object. 

		// "KEYCODE(S)":{toggle;press/on/off, "button","UP" } 
		// 'press' auto-releases, PRESS_HOLD presses,
		//  gotta remove double presses. 
		"D_ArrowUp":["PRESS_HOLD", "UP",  "RELEASE", "DOWN" ], 
		// "DOWN RIGHT":["PRESS", "DOWN", "PRESS","RIGHT"],
		"D_ArrowDown":["PRESS_HOLD", "DOWN",  "RELEASE", "UP" ],  
		"D_ArrowLeft":["PRESS_HOLD", "LEFT", "RELEASE", "RIGHT" ],  
		"D_ArrowRight":["PRESS_HOLD", "RIGHT","RELEASE", "LEFT" ],
	
		"U_ArrowUp":["RELEASE", "UP", "RELEASE", "DOWN" ], 
		// "DOWN RIGHT":["PRESS", "DOWN", "PRESS","RIGHT"],
		"U_ArrowDown":[ "RELEASE", "UP", "RELEASE", "DOWN" ],  
		"U_ArrowLeft":[ "RELEASE", "RIGHT", "RELEASE", "LEFT" ],  
		"U_ArrowRight":["RELEASE", "RIGHT", "RELEASE", "LEFT" ],
		
		"D_Escape":["PRESS", "ESCAPE"],
		"D_Enter":["PRESS", "ENTER"],

		"D_H":[	"PRESS_TOGGLE", "LEFT", 
			"IF_NOT_PRESSED_BREAK", "RIGHT",
			"RELEASE", "RIGHT",
			"RELEASE", "LEFT"], 
		"D_L":["PRESS_TOGGLE", "RIGHT", 
			"IF_NOT_PRESSED_BREAK", "LEFT",
			"RELEASE", "RIGHT",
			"RELEASE", "LEFT"], 

		// this is for curses, as it doesn't 
		// use 'U_KEY' naming. 
		"ArrowLeft":["RELEASE_DIAGNOLS","-",
			"RELEASE","RIGHT", "PRESS_TIMED_HOLD", "LEFT"],
		"ArrowRight":["RELEASE_DIAGNOLS","-",
			"RELEASE","LEFT", "PRESS_TIMED_HOLD","RIGHT"],
		"ArrowUp":["RELEASE_DIAGNOLS","-",
			"RELEASE","DOWN", "PRESS_TIMED_HOLD", "UP"],
		"ArrowDown":["RELEASE_DIAGNOLS","-",
			"RELEASE","UP", "PRESS_TIMED_HOLD", "DOWN"],
	
		"Escape":["PRESS", "ESCAPE"],
		"Enter":["PRESS", "ENTER"],

		// running and stepping
		"a":["RELEASE_ALL_DIRECTIONS_EXCEPT","-", "PRESS", "LEFT"],
		"d":["RELEASE_ALL_DIRECTIONS_EXCEPT","-", "PRESS", "RIGHT"],
		"w":[ "RELEASE_ALL_DIRECTIONS_EXCEPT","-", "PRESS", "UP"],
		"s":["RELEASE_ALL_DIRECTIONS_EXCEPT","-", "PRESS", "DOWN"],
		// running and stepping.
		"A":[ "RELEASE_DIAGNOLS","-",
			"RELEASE","RIGHT", "PRESS_TIMED_HOLD", "LEFT"],
		"D":["RELEASE_DIAGNOLS","-",
			"RELEASE","LEFT", "PRESS_TIMED_HOLD","RIGHT"],
		"W":["RELEASE_DIAGNOLS","-",
			"RELEASE","DOWN", "PRESS_TIMED_HOLD", "UP"],
		"S":["RELEASE_DIAGNOLS","-",
			"RELEASE","UP", "PRESS_TIMED_HOLD", "DOWN"],
		
		"q":["RELEASE_ALL_DIRECTIONS_EXCEPT","-",
			"PRESS", "UP_LEFT" ],
		"e":["RELEASE_ALL_DIRECTIONS_EXCEPT","-",
			"PRESS", "UP_RIGHT" ],
		"z":["RELEASE_ALL_DIRECTIONS_EXCEPT","-",
			"PRESS", "DOWN_LEFT" ],
		"c":["RELEASE_ALL_DIRECTIONS_EXCEPT","-",
			"PRESS", "DOWN_RIGHT" ],
		// hold diagonals
		"Q":[ "RELEASE_ALL_DIRECTIONS_EXCEPT","UP_LEFT",
			"PRESS_TIMED_HOLD", "UP_LEFT" ],
		"E":["RELEASE_ALL_DIRECTIONS_EXCEPT","UP_RIGHT",
		   	"PRESS_TIMED_HOLD", "UP_RIGHT" ],
		"Z":[ "RELEASE_ALL_DIRECTIONS_EXCEPT","DOWN_LEFT",
		   "PRESS_TIMED_HOLD", "DOWN_LEFT" ],
		"C":[ "RELEASE_ALL_DIRECTIONS_EXCEPT","DOWN_RIGHT",
		   "PRESS_TIMED_HOLD", "DOWN_RIGHT"]
		

		/*
		"LEFTARROW":[	"PRESS_TOGGLE", "LEFT", 
			"IF_NOT_PRESSED_BREAK", "RIGHT",
			"RELEASE", "RIGHT",
			"RELEASE", "LEFT"], 
		"RIGHTARROW":["PRESS_TOGGLE", "RIGHT", 
			"IF_NOT_PRESSED_BREAK", "LEFT",
			"RELEASE", "RIGHT",
			"RELEASE", "LEFT"], 
		"UPARROW":[	"PRESS_TOGGLE", "UP", 
			"IF_NOT_PRESSED_BREAK", "DOWN",
			"RELEASE", "DOWN",
			"RELEASE", "UP"], 
		"DOWNARROW":["PRESS_TOGGLE", "DOWN", 
			"IF_NOT_PRESSED_BREAK", "UP",
			"RELEASE", "UP",
			"RELEASE", "DOWN"]
		*/

	}
		//2 key combos are read first. 
		/*
		"SHIFT UP":["TOGGLE", "UP"],
		"SHIFT DOWN":["TOGGLE", "DOWN"],
		"SHIFT RIGHT":["TOGGLE", "RIGHT"],
		"SHIFT LEFT":["TOGGLE", "LEFT"],
		"SHIFT A":["TOGGLE", "A"],
		"SHIFT B":["TOGGLE", "B"],
		"SHIFT C":["TOGGLE", "C"],
		"SHIFT D":["TOGGLE", "D"]
		*/
}
//API_TAG// 
// clears the pressed keys ( for shifting scenes/blocking pauses n whatnot) 
var controllers_clear_pressed = function(){
//API_TAG//
	
	for(var c=0; c< controllers.length; c+=1){
		controllers[c].getch_chars_only = "";
		controllers[c].getch="";
		controllers[c].isdown={};
		controllers[c]._timed_press = {};
		controllers[c].pressed = [];
		controllers[c].
			_timer_controller_getpress_move_with_diagnol  =0;
		controllers[c]._pressed_buffer= []; } }

_controller_mv_helper = function(c, key){
	c.pressed[0] = c._WAITING; c.pressed[1] =key;
	return key; }
/*
//
//BELOW FUNCT IS A PROBLEM THAT DOESN"T WORK PEREFECT!!!
	// LEAVING IT HERE AS A REMINDER: KEY COMBOS MIGHT WORK FOR 
	// 	SPECIAL MOVES, BUT SINGLE KEYS WORK BETTER FOR DIAGNOLS!
controller_getpress_move_with_diagnol = function(c){ //controller
	//checking next frame, to see if movement works 
	// SHOULD BE USED IN A FRAME BY FRAME LOOP, (limit 1)
		if(c._timer_controller_getpress_move_with_diagnol >1){	
			c._timer_controller_getpress_move_with_diagnol -=1;}
	

	if( c.isdown["LEFT"] || c.isdown["UP"] || 
	   c.isdown["RIGHT"] || c.isdown["DOWN"]){
		//maxing it out at 4 ticks till can take single keypresses
		c._timer_controller_getpress_move_with_diagnol  = 4;}
	if(c._timer_controller_getpress_move_with_diagnol <= 1){
	  if(c.pressed[0] != c._WAITING){
	 	c._timer_controller_getpress_move_with_diagnol = 0;}}
	if( c.pressed[1] == c._WAITING || 
		c._timer_controller_getpress_move_with_diagnol   != 0){
			return c._WAITING;}
	
	if(c.pressed[1] == "RIGHT"){
		if(c.pressed[0] == "DOWN"){ 
			return _controller_mv_helper(c, "DOWN_RIGHT");}
		if(c.pressed[0] == "UP"){ 
			return _controller_mv_helper(c, "UP_RIGHT");};
		return "RIGHT"; }
	if(c.pressed[1] == "LEFT"){
		if(c.pressed[0] == "DOWN"){
			return _controller_mv_helper(c, "DOWN_LEFT");}
		if(c.pressed[0] == "UP"){
			return _controller_mv_helper(c, "UP_LEFT");};
		return "LEFT"; }
	if(c.pressed[1] == "UP"){
		if(c.pressed[0] == "RIGHT"){
			return _controller_mv_helper(c, "UP_RIGHT");}
		if(c.pressed[0] == "LEFT"){ 
			return _controller_mv_helper(c, "UP_LEFT");};
		return "UP"; }
	if(c.pressed[1] == "DOWN"){
		if(c.pressed[0] == "LEFT"){ 
			return _controller_mv_helper(c, "DOWN_LEFT");}
		if(c.pressed[0] == "RIGHT"){ 
			return _controller_mv_helper(c, "DOWN_RIGHT");};
		return "DOWN"; }
	return c.pressed[1];
}*/
controller_getpress = function(c){ return c.pressed[0];}//controller

controllers = [_controller_1];
controller_interpreter = function(c, key, UP_DOWN_OTHER){// c=controller
	
	if(UP_DOWN_OTHER == "UP"){	key = "U_" + key;
	}else{  
		c._keyboard_getch.unshift(key); 
		if(UP_DOWN_OTHER == "DOWN"){key = "D_" + key;
		}else{  key =  key;} }
	if(c.controller[key] != undefined){
		var cmd = c.controller[key];
		for(i=0; i< cmd.length; i+=2){
			if(cmd[i] == "PRESS_TIMED_HOLD"){
				if(c._timed_press[cmd[i+1]] != undefined){
					c._timed_press[cmd[i+1]] = 
					c._TIMED_PRESS_REPEAT;
					continue;
				}
				c._pressed_buffer.unshift(cmd[i+1]);
				c.isdown[cmd[i+1]] = true;
				c._timed_press[cmd[i+1]] = 
					c._TIMED_PRESS_MAX;
				continue;
			}
			if(cmd[i] == "RELEASE_DIAGNOLS"){
				//requires no following command, just blank
			   for(var j=0; j<CONTROLLERS_DIAG.length;j+=1){
			     	c.isdown[CONTROLLERS_DIAG[j]]= false;
			      	c._timed_press[CONTROLLERS_DIAG[j]]=0;}	
				   continue;
			}
			if(cmd[i] == "RELEASE_ALL_DIRECTIONS_EXCEPT"){
				//requires no following command, just blank
			   for(var j=0; j<CONTROLLERS_DIAG.length;j+=1){
			     if(cmd[i+1] != CONTROLLERS_DIAG[j]){
			     	c.isdown[CONTROLLERS_DIAG[j]]= false;
			      	c._timed_press[CONTROLLERS_DIAG[j]]=0;}}
			    for(var j=0; j<CONTROLLERS_DIRS.length;j+=1){
			     if(cmd[i+1] != CONTROLLERS_DIRS[j]){
			     	c.isdown[CONTROLLERS_DIRS[j]]= false;
			      	c._timed_press[CONTROLLERS_DIRS[j]]=0;}	}
				   continue;
			}
			if(cmd[i] == "RELEASE"){
				//delete c.isdown[cmd[i+1]];
				c.isdown[cmd[i+1]] = false;
				c._timed_press[cmd[i+1]]=0;
				continue;}	
			if(cmd[i] == "PRESS_HOLD"){
				if(c.isdown[cmd[i+1]] != 1){
				    c._pressed_buffer.unshift(cmd[i+1]); }
				c.isdown[cmd[i+1]] = true;
				continue;}
			if(cmd[i] == "PRESS"){
				//if(c.isdown[cmd[i+1]] != 1){
				 //   c._pressed_buffer.unshift(cmd[i+1]); }
			
				//to allow use of 'isdown', I rewired this
				// so it's a 'press and hold' for  1 frame. 
				if(c._timed_press[cmd[i+1]] != undefined){
					c._timed_press[cmd[i+1]] = 
					   c._TIMED_PRESS__SINGLE_PRESS_MAX;
					c._pressed_buffer.unshift(cmd[i+1]);
					c.isdown[cmd[i+1]] = true;
					continue;}
				c._pressed_buffer.unshift(cmd[i+1]);
				c.isdown[cmd[i+1]] = true;
				c._timed_press[cmd[i+1]] = 
					c._TIMED_PRESS__SINGLE_PRESS_MAX;
				continue;}
			if(cmd[i] == "PRESS_TOGGLE"){
				if(c.isdown[cmd[i+1]] != 1){
				    c._pressed_buffer.unshift(cmd[i+1]); 
				    c.isdown[cmd[i+1]] = true;
				}else{ //maybe "delete c.isdown[cmd..."?
					c.isdown[cmd[i+1]] = false; }
				continue;}
			if(cmd[i] == "IF_NOT_PRESSED_BREAK"){
				if(c.isdown[cmd[i+1]] != 1){ break;}	}
			if(cmd[i] == "IF_PRESSED_BREAK"){
				if(c.isdown[cmd[i+1]] == 1){ break;}	}
		}
			c._pressed_timeout = 0;
			c._pressed_buffer = 
			      c._pressed_buffer.slice( 0, c._PRESSED_MAX);
}	}


//};
update_controller = function(){
	for(var i=0; i< controllers.length; i+=1){
		var c = controllers[i];
		

		var t_p = Object.keys(c._timed_press);
		//console.log( c.t_p);
		for(var j=t_p.length-1; j>= 0; j-=1){
			c._timed_press[t_p[j]] -=1;
			if(c._timed_press[t_p[j]] <= 0){
				delete c.isdown[t_p[j]];
				delete c._timed_press[t_p[j]]; }	}

		c.getch = ""; c.getch_chars_only = "";
		if( c._keyboard_getch.length !=0){
			tmpC = c._keyboard_getch.pop();
			if(tmpC.length ==1){ c.getch_chars_only = tmpC; }
			c.getch = tmpC; }

		if(c._pressed_timeout == 0 ){
			//was pressed THIS frame (or last)
			c.pressed = c._pressed_buffer;
		}else{ c.pressed = c._PRESSED_DEFAULT; } 
		while( c._pressed_buffer.length < c._PRESSED_MAX){
			c._pressed_buffer.unshift(c._WAITING); }
		if( c._pressed_timeout < c._PRESSED_TIMEOUT_MAX){
			c._pressed_timeout +=1;
		}else{  c._pressed_timeout = 0;
			c._pressed_buffer.unshift( c._WAITING);
			c._pressed_buffer = 
			  c._pressed_buffer.slice(
				  0, c._PRESSED_MAX);}

		
	}
	//update_keyboard_pressed= _update_keyboard_pressed_buffer;
	//_update_keyboard_pressed_buffer = {};
};
