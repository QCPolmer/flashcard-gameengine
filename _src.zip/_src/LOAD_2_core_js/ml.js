/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////
///////////////////////////////
///////////// ML BASIC FUNCTIONS!!!
//////////////// (these are NOT the actual 'ml()'
///////////////// type of thing, those are below (search CORE FUNCTIONS)
/////////////////	(MAY move this SECTION TO OWN JS FILE!!!
//
//	EDIT: now requires progen.js, to allow ## preprocessing ##
////////////////////////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////

//API_TAG//
// requires obects with mml:{mml:"txt", cmds:{a:["funct","param2"...]}}
async function ml_looping_behavior(o){
	ml_loop(o, o, o.mml, 0, rmloaded_room);	}
//API_TAG//

//API_TAG//
async function ml_move( 
o, otarget, track, magnitude, list_cmds, rm_OPTIONAL){
	//list_cmds: [functname, x_or_y_or_number_based_var, float_to_move]
	o[list_cmds[1]] += list_cmds[2];}
async function ml_break_test( //pausing blocking, breaks if on 1st track!
				// NOT that practical, more an example 
o, otarget, track, magnitude, list_cmds, rm_OPTIONAL){
	return 1;}
//API_TAG//


//API_TAG//
function ml_draw(
o, otarget, track, magnitude, list_cmds, rm_OPTIONAL){
//cmds:funct_name, 1 var_name_to_draw, 2 x, 3 y, 4 transpchar_or_0,
//	5 bool_center,
//API_TAG//
	if(list_cmds[5] == 1){//center
		var gfx = o[list_cmds[1]];
		draw(gfx, //var to draw
			list_cmds[2] - txttools_getmax_width( gfx )/2, //x
			list_cmds[3] - txttools_getheight(gfx)/2, //y
			list_cmds[4]); //trnsp car or 0
	}else{ //no center
		draw(o[list_cmds[1]], //var to draw
			list_cmds[2], //x
			list_cmds[3], //y
			list_cmds[4]); //trnsp car or 0
	}
	 
}


//API_TAG//
// ml_blockingtimer_init_n_end()
// 	--- can be used as a ml-function, no paramiters
// 	--- for using ml_blockingtimer, an easy 
// 		method to do intervals or timed commands

// EXAMPLE
//var mix_walk_in_square = progen_mix_stringify(/
//	I THINK >/< "<" ">" change magnitude ("=" also resets it AND 't'
//		(t changes 'tempo')!!!)
//	{behavior:"ml_looping_behavior", 
//		mml:{mml:"a,a#1b3?d25 24d?c 24?c 20Qa??? 24?b 24?d ", cmds:{
//			//CAN WRITE OUT AS OBJS, FOR EASIER FUNCT USE!!!! 
//			a:{0:"ml_test_move", 1:"x", 2:0.2},
//			//a:["ml_test_move", "x", 0.2],
//			b:["ml_test_move", "x", -0.2],
//			c:["ml_test_move", "y", 0.2],
//			d:["ml_test_move", "y", -0.2],
//			Q:["ml_break_test"]
//			}} });
//API_TAG//

//API_TAG//
function ml_interpolate_var(
o, otarget, track, magnitude, list_cmds, rm_OPTIONAL){
	//cmds: funct_name, var_name 1, end_val 2, move_var_Positive_only 3
	// OK, I can get time by checking how close start is to end
	// value and use the itterstep to calculate place from A to B
//API_TAG//
	if(typeof o[list_cmds[1]] == "string"){ //var_name
	   var o_start = o[list_cmds[1]].length; 
	   var o_end = o[list_cmds[2]].length;
	   
	   //setting it up so start is always greater than end;
	   o_move = o[list_cmds[3]];  //add to var
	   if(Math.abs(o_start - o_end) > o_move ){ 
		//set to full, exit w/o break!
	        //o[list_cmds[1]] = o_end.substr(" ");
		return 0; //no pause
	   }else{
		o[list_cmds[1]] = o_end;
		return 1; //return pause (not done)
	   }
	}
	if(typeof o[list_cmds[1]] == "number"){ //var_name
		var o_start = o[list_cmds[1]]; var o_end = o[list_cmds[2]];
	   	
	   //setting it up so start is always greater than end;
	   if(o_start > o_end){ o_move = o[list_cmds[3]]; //add to var
	   }else{ o_move = -o[list_cmds[3]]; } //add to var
	   if(Math.abs(o_start - o_end) > Math.abs(o_move) ){ 
		//set to full, exit w/o break!
	        o[list_cmds[1]] += o_move; // var_name 
		return 0; //no pause
	   }else{
		o[list_cmds[1]] = o_end; //var_name
		return 1; //return pause (not done)
	   }
	}
		
}


/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////
///////////////////////////////
///////////// ML() AND OTHER CORE FUNCTIONS!
////////////////////////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////
/////////////////////////////////////////////////

///GENERALLY, see ml/ml_blocking and the 
//	data (ml_struct) 

var ml_catch_globalNamespace = this;

var ML_CATCHES_MAXSIZE = 1000;
var ml_CATCHES_deepcopy = {size:0};
//this is a helper-function, so I don't need progen_catch_deepcopy!
//--------------------
//--------- THIS SHOULD NOT WORK, I THINK IT'S ONLY 
//--------- WORKING AS LIST INPUTS CONTAINING STRINGS 
function ml_catch_deepcopy( getObj ){ // ACTUALLY, INPUT IS LIST(SEE ABOVE)
	if( ml_CATCHES_deepcopy[ getObj ] == void null){
	  if(ml_CATCHES_deepcopy.size==ML_CATCHES_MAXSIZE){
		 ml_CATCHES_deepcopy = {size:0}; }
	  ml_CATCHES_deepcopy.size +=1;
	  ml_CATCHES_deepcopy[ getObj ] = JSON.stringify( getObj);}
	return JSON.parse( ml_CATCHES_deepcopy[ getObj ] ); 
}
//API_TAG//
////////////////////////////////////////
////// ml_blocking functions (here because they are core 
//		ml-functions!
////////////////////////////////

// FOR BLOCKING ML FUNCTIONS (handled per TACK)
// Settup: this is like draw/sketch. Run before/after ml_blocking cmds.
// 	(runs as ml-cmd, AND a function before breaking blockingtimer cmds) 
// 	if ran at end of ml_blocking cmd, no need to reeuse before nxt cmd!
function ml_blockingtimer_init_n_end( 
	//have before ml_tracktimer functs AS A ML_FUNCT in!
o, oPUT_ANYTHING_HERE, track){//, magnitude, c, rm_OPTIONAL){
	if(o.mml_tracktimers_INIT_N_END_FIRST == void null){ 
		o.mml_tracktimers_INIT_N_END_FIRST= [];
		o.mml_tracktimers_interval= []; }
	o.mml_tracktimers_interval[track]=0;
	o.mml_tracktimers_INIT_N_END_FIRST[track] = void null;  }
// FOR BLOCKING ML FUNCTIONS (handled per TRACK)
// --run AFTER running ml_blocking_init_n_end,auto-sets, returns count down 
// FOUND IN PROGEN.js!!!
function ml_blockingtimer( o, track, maxTime ){
	if( o.mml_tracktimers_INIT_N_END_FIRST[track] == void null){
		
		 o.mml_tracktimers_INIT_N_END_FIRST[track] = maxTime; 
	}else{ o.mml_tracktimers_INIT_N_END_FIRST[track] -= 1; }
	//file_log( o.mml_tracktimers_INIT_N_END_FIRST[track]	);
	return o.mml_tracktimers_INIT_N_END_FIRST[track]; }
//for multiple-part timers, for use in ml_functs with multiple parts
//	(like 'laps' with timers)
//	THESE ARE OPTIONAL, ONLY init_n_end AND ml_blo..timer ARE NEEDED!
// FOUND IN PROGEN.js!!!
function ml_blockingtimer_nxt_interval(o,track ){
	o.mml_tracktimers_INIT_N_END_FIRST[track] = void null;
	o.mml_tracktimers_interval[track] +=1; }
function ml_blockingtimer_prev_interval(o,track ){
	o.mml_tracktimers_INIT_N_END_FIRST[track] = void null;
	o.mml_tracktimers_interval[track] -=1;
	if(o.mml_tracktimers_interval[track] <0){ 
		o.mml_tracktimers_interval[track] = 0;} }
function ml_blockingtimer_get_interval(o,track ){
	return o.mml_tracktimers_interval[track]; }

////////////////////////////////////////////
/////// Progen_ML!!!!
//////////////////////////////////////////////////
// ML data: (see struct example below, cmds are 'letter' functs!)
// 	"a,ccd,b,aab# 12a?bb,c22c 1a 1?ccd,a"
// 	-OPTIONAL-before "#" macro-expansions: char,expand, char,expand
// 	  modifies rest of statement by replacing chars with expansion
// 	-for statement: they are in this order: 12aasd?ab,ab
// 		-12 (repeats (NEEDED), can be canceled by first 'track')
// 		   w/o # OF REPEATS, THE WORD WON'T RUN!!! (1 is OK!)
// 		-aasd (followed by " " or " ", first 'track', runs every 
// 		  frame, a returning '1' from these goes to next word
// 		  CAN DO PER-LETTER REPEATS: c22, or whatever!
// 		  FOR LETTERS, THEY COME AFTER THE LETTER!
// 		- ? (can use comma, first seperator to next 'track'
// 		- ab,ab (next 2 'tracks', these can stop by 
// 		   a statement returning 1
// 	-NOTE: most of the stuff (_ml_preprocessor, repeats, etc) 
// 		IS OPTIONAL: it gets pre-processed to a simple text format.
// ///////////////////////////////////////////
//o,otarget, track_index, magnitude,  cmds, room_optional
// TRACK_COMMA_INDEX = int indicating 'word' comma location: 0?1,2,etc.
// 	this should allow setting insturments/code per 'track_comma'
// MAGNITUDE =  adding customization to cmds, so can run some 'harder'
// CMDS = (FOR SIMPLE COMMANDS, USE A LIST CAUSE LIKE FUNCTION, 
// 		FOR COMPLEX COMMANDS, USE AN OBJ!!! (IT TAKES EITHER)) 
// 	{a:["functglobalName", "param1" ....] etc.}
// 	OR CAN USE OBJECTS--- HUGE:
// 	 a:{0:"functglobalname", ... (now it's an obj, it works!)
//    NOTE: These WILL take obj-behaviors AND progen function names,
//      (as well as ML functions! GHEEE!!!!) 
//    	given they all are on the global namespace (and they will be)
//    	the inputs are all close enough. (actual behaviors may vary) 

//zzz gotta add API tags and go through all this one more time. 

var ml_struct = 
{
	cmds:{a:["functname", "param1" ]},
	mml:"",
	mml_loop_resets_preproces:null, //OPTIONAL Only use if 
	   //using progen_txt_preprocess(##) AND want resets to reroll!
	   //(just '##' style preprocess will be handled on first run)
// }
// generally, objs-data: o:{mml:{ml_struct}} 
//API_TAG// 
	///////BELOW IS DEFINED ON RUNTIME!!!
	_mml_pre_preprocessor_caught:void null, // ONLY for if rerolling
	_mml_pre_preprocessor_last_gen:void null, // ONLY for if rerolling
		// ABOVE is the results of preprocessor, so can 'look' 
		// 	at it if so desire!
		// with progen_txt_preprocess "##' preprocessor for above.
	_mml_caught:void null,//"",
	_mml_preprocessed:void null,//"",
	_mml_word_locs:void null,// [], (undef= reset) misnomer, 
			// its: [loc, mag, loc2, mag2,etc.]
			// :"|,asd,dddd,qqdsd," - locs are after ','s
	_mml_word_repeats:void null,//0
	_mml_cur_word_start:void null, // 0
	_mml_word_loc1_start:void null 
		//first entry start, as it's reset per-frame 
}
//API_TAG//
// returns 'null' if no progen_txt_preprocess ran!
// 	NOTE: run BEFORE ml_resetStruct, progen_txt_preprocess runs there
function ml_getlast___progen_txt_preprocess(get_ml_struct){
	return get_ml_struct._mml_pre_preprocessor_last_gen; }
////API_TAG//
//API_TAG//
function ml_resetStruct(o, otarget, get_ml_struct, rm_OPTIONAL){//typically,ml_struct=obj.mml
	//generally used by ml.js as helper function
//API_TAG//
//	EDIT: recently added to allow progen_txt_preprocess & rerolling
	if( get_ml_struct.mml_loop_resets_preprocess ==1||
	  get_ml_struct.mml.indexOf("##") != -1){
		if(get_ml_struct._mml_pre_preprocessor_caught == void null){
		    get_ml_struct._mml_pre_preprocessor_caught=
			get_ml_struct.mml; }
		  get_ml_struct.mml = progen_txt_preprocess( o, otarget, 
			get_ml_struct._mml_pre_preprocessor_caught, 
			null, rm_OPTIONAL);
		get_ml_struct._mml_pre_preprocessor_last_gen=
			get_ml_struct.mml; }
	get_ml_struct._mml_word_locs = void null;
	get_ml_struct._mml_word_repeats = void null;
	get_ml_struct._mml_cur_word_start = void null;
	_mml_word_loc1_start=void null; 	
}
//API_TAG//
async function ml_BLOCKING( //typically, ml_struct is obj.mml 
	o, otarget, get_ml_struct, bg_to_draw_OPTIONAL,// rmloaded_last_draw
		 rm_OPTIONAL ){	  
//API_TAG//

	  var first_frame =1;
	  
	  var caught_BG = "";
	  if(draw_canvas_get() == ""){draw_settup_canvas(); } 
   
	 if(bg_to_draw_OPTIONAL != void null){
			draw(" "+bg_to_draw_OPTIONAL,0,0,"");};
	  while(1 != await ml(o, otarget, get_ml_struct, 
		first_frame, rm_OPTIONAL)){
		  first_frame =0;
		
		  await update();
		  if(bg_to_draw_OPTIONAL != void null){
			draw(" "+bg_to_draw_OPTIONAL,0,0,"");};}
 	 return;	 }

//API_TAG//
//no exit, used for behaviors
async function ml_loop(o, otarget, get_ml_struct, 
	bool_reset, rm_OPTIONAL){  
//API_TAG//
	var done = ml(
		o, otarget, get_ml_struct, bool_reset, rm_OPTIONAL);
	if(done == 1){ 
		ml_resetStruct(o, otarget,get_ml_struct,rm_OPTIONAL);} 
}

//API_TAG//
// ml functions (see below)
//returns 1 for 'ml sentence done!'
// ML FUNCTIONS TYPICALLY ASYNCRO ... so are behaviors...
// 	So the one-man out is progen... which is OK, I can 
// 	live without using them in these. (they might work, though...)
// NOTE: keep BLOCKING FUNCTIONS to 2knd track!!!
// 	They work beyond that, but other functions in front of them 
// 	will continue to run!
// NOTE: BLOCKING/TRACK-BY-TRACK ONLY WORKS ON TRACK #2+!!!! 
// 	1 WILL RUN ALL STATEMENTS AS FAST AS POSSIBLE!
// NOTE: HAVE REPEATS (even 1) AT THE START OF EVERY 'WORD',
// 	OR THAT WORD WON'T RUN!!! (the nxtword search uses a simple scan
// 		which pretty much needs that repeat number,
// 		I could alter it, but it would likely slow stuff down
// 		to make a good system that works)
async function ml(
		o, otarget, get_ml_struct, bool_reset, rm_OPTIONAL){
	//setting up preprocessed mml, IF UNSETTUP OR CHANGED
//API_TAG//

	if(get_ml_struct._mml_caught != get_ml_struct.mml){
		ml_resetStruct(o, otarget, get_ml_struct, rm_OPTIONAL);
		get_ml_struct._mml_caught = get_ml_struct.mml;
		get_ml_struct._mml_preprocessed = 
			_ml_preprocessor(get_ml_struct.mml); }
	var sentence = get_ml_struct._mml_preprocessed;
	
	//going to next word if 1st run, finishing sentence will reset runs
	if(get_ml_struct._mml_word_locs == void null ){
		get_ml_struct._mml_cur_word_start =
			_ml_nextword( sentence, 0);
		if(get_ml_struct._mml_cur_word_start == -1){ return 1; }
		_ml_settup_word( get_ml_struct._mml_cur_word_start, 
			sentence, get_ml_struct);
	} 
	//running commands
	//var word_done = await _ml_runword_cmds(o,otarget,sentence,
	var word_done = await _ml_CORE_runword_cmds(
		o,otarget, sentence, get_ml_struct, rm_OPTIONAL);
	//early termination current word
	if(word_done ==2){ word_done=1; get_ml_struct._mml_word_repeats=0;}
	 
	//handling repeats and going to next word OR end of sentence
	if(word_done){ var wordLoc1 = get_ml_struct._mml_word_locs[0];
		if( get_ml_struct._mml_word_repeats>1){
		   var caught_repeats = get_ml_struct._mml_word_repeats;
		   _ml_settup_word(  
		      get_ml_struct._mml_cur_word_start, 
			sentence, get_ml_struct);
		  get_ml_struct._mml_word_repeats = caught_repeats -1;
		}else{// goto next word
		  get_ml_struct._mml_cur_word_start=
		     _ml_nextword(sentence, wordLoc1);
		  if(get_ml_struct._mml_cur_word_start == -1){ 
		     get_ml_struct._mml_word_locs= void null; return 1; 
		  }else{  _ml_settup_word( 
		     get_ml_struct._mml_cur_word_start, 
			sentence, get_ml_struct);} 
		}
	 return ml(
		o, otarget, get_ml_struct, bool_reset, rm_OPTIONAL);
	}
	return 0;
}

////////////////////////////////////////
/// Progen_ML_ helper functions!!!
//////////////////////////////////////////////////

// NOTE: '=' resets tempo/magnitude!
//IN DATA (preprocessed): 
//  ", |12,asdf, |123,a, |1,as,dddddddddddddddddd,fffffffffffff, |"
function _ml_nextword( sentence, startLoc){
	//word start i, or -1 for end of statement. 
	//var startLoc =0; 
	while(1){ startLoc = sentence.indexOf("|", startLoc+1);
		if(startLoc ==-1 || startLoc == sentence.length-1){
			return -1; } //reached end of statement
		startLoc +=1; //below is 'found!'
		if( " ,".indexOf(sentence.charAt(startLoc)) ==-1 ){break;}}
	return startLoc;
}
//modifies repeats, modifies loc_mod list!
var _ml_settupwrd_CATCH = {};
var _ml_settupwrd_REPEATS_CATCH = {};
function _ml_settup_word( 
		wordstart_i, sentence, get_ml_struct){
	//CATCHING
	var catch_ID =sentence + wordstart_i;
	if( _ml_settupwrd_CATCH[catch_ID]!= void null){
	  get_ml_struct._mml_word_locs=  ml_catch_deepcopy(
		_ml_settupwrd_CATCH[catch_ID]);
	  get_ml_struct._mml_word_loc1_start  = 
		get_ml_struct._mml_word_locs[0];
	  get_ml_struct._mml_word_repeats = 0 + 
		_ml_settupwrd_REPEATS_CATCH[catch_ID];
	  return; }

	//zzz - at 439, it's not handling undefined stuff well...
	//	like where tracks are itentionally left empty.
	//	(particularlly, the first one!
	var i_comma1 = wordstart_i; 
	var i_comma2 = sentence.indexOf(",", wordstart_i);
	//for multi-char repeats
	if( i_comma1 + 1 != i_comma2){ //setting up repeats:
		if( !isNaN(sentence.charAt(i_comma1)) ){
		   get_ml_struct._mml_word_repeats = parseInt(
			sentence.substring(i_comma1, i_comma2));
		   
		   i_comma1 = i_comma2; }  //wordstart_i = i_comma2;
	//below is for single-char repeats 
	}else{if(!isNaN(sentence.charAt(i_comma1))){
		get_ml_struct._mml_word_repeats = 
			parseInt(sentence.charAt(i_comma1)); }  }

	// getting phrase positions
	get_ml_struct._mml_word_locs = [];
	var i_comma1 = sentence.indexOf(",", i_comma1)+1;
	var i_comma2 = i_comma1;
	while( sentence[i_comma2 +1] != " " ){
	  i_comma1 = i_comma2; 
	  i_comma2 = sentence.indexOf(",", i_comma1)+1;
	  if(sentence.charAt(i_comma1) == " "){ break;}
	  //Adding locs_mag block!
	  get_ml_struct._mml_word_locs.push(i_comma1, 0);  
	} 	
	//CATCHING
	_ml_settupwrd_CATCH[catch_ID]=
	     ml_catch_deepcopy( get_ml_struct._mml_word_locs);
	_ml_settupwrd_REPEATS_CATCH[catch_ID] = 
		get_ml_struct._mml_word_repeats;
	get_ml_struct._mml_word_loc1_start=get_ml_struct._mml_word_locs[0];
	
}

//THIS NEED TO BE MODIFIED SO IT'S MORE LIKE MML STYLE!!!
function ml_preprocessor_char_expansion(getChar, getTempo){
	if(getTempo == 0){return getChar;}
	return new Array(getTempo+1).join(getChar) }
var _ml_preprocessor_CATCH = {};
function _ml_preprocessor(getStr){
	//CATCHING
	if(_ml_preprocessor_CATCH[getStr] != void null){
		return _ml_preprocessor_CATCH[getStr]; }
	
	//char expansion:"a,asdfadsf,b,ccddcc,c,asf# a b(normal commands)"
	//	expands chars to expaned chars, in linear order!
	  //it's binary list: a,<EXPANSION>,b,<EXPANSION> etc...
	if(getStr.indexOf("#")!= -1){ getStr= getStr.split("#");
	  var expand_macro=getStr[0].split(",");  getStr = getStr[1];
	  for(var i=0; i< expand_macro.length; i+=2){ getStr=
	    getStr.split(expand_macro[i]).join(expand_macro[i+1]);
	}}	
	// NOTE: '=' resets tempo/magnitude!
	// NOTE: NEED the repeats# as 1st part of word, 
	// 	or that word won't RUN!!! (a repeat of 1 works)
	// EG: "12asdf 123a 1as?t21df" ->
	//  ", |12,asdf, |123,a, |1,as,dddddddddddddddddd,fffffffffffff, |" 
	//split digits from other characters, '?'to',' removing linebreaks
	//	exapands char times AND (t)tempo char expansion, removes't'
	//	(ONLY NUMBERS SHOULD BE AFTER ', ,'! SO EASY TO CHECK 
	//	FOR REPEATS!!! 
	var arr = (" "+ getStr+" ").split(" ").join(", |")
		 .split("?").join(",").split("\n").join("")
			.split(/(\d+)/);
	// arr is currently [txt,digits,txt,digits,...]	

	// I NEED TO REWRITE THIS!!!
	// I need to do a 2 pass run: split by numbers starting with a 
	// 't' and ones not!
	// (2 sweeps: one with t, and one with no t or |!!!)

	var tempo =0; 
	for(var i= 0; i< arr.length; i+=1){
		if(isNaN(arr[i]) ){ //not a number
		   if(tempo >0){ //text expansion for tempo 
			var comma_cut = arr[i].split(",")[0]
					.split("=")[0].split("");
			//case next char is a number in sequence:
			// (NO '=' OR ',' FOUND!!!) 
			if(comma_cut.length == arr[i].length){
				comma_cut.pop(); 
				var reset_tempo = false;
			//and reset tempo IF '=' or ',' were found!
			}else{ var reset_tempo = true; } 
			for(var j =0; j< comma_cut.length; j+=1){
			  if( "<>".indexOf(comma_cut[j])==-1 ){
			   comma_cut[j] = 
			    ml_preprocessor_char_expansion(
				comma_cut[j],tempo);
			 }  }
		     
		     
		     arr[i] = comma_cut.join("")+
			 arr[i].substring(comma_cut.length); }
		    if(reset_tempo){ tempo =0;}
		    continue;} 
		var char_before_numb = arr[i-1].charAt( arr[i-1].length-1 );
		if( "|" == char_before_numb ){ 
			arr[i] = arr[i]+",";
			continue;
		}else{
		 //SINGLE character expansion/tempo shift(replace numb)
		 // WILL NEED TO REWORK,
		 	if(char_before_numb =="t"){
				tempo = parseInt(arr[i]);
				arr[i] = "";
			}else{  arr[i] = 
			  ml_preprocessor_char_expansion(
			    char_before_numb, -1+parseInt(arr[i]));
		}  } 
	}
	_ml_preprocessor_CATCH[getStr] = arr.join("").split("t").join("");
	return _ml_preprocessor_CATCH[getStr];
}


//API_TAG//
///////////////////////////////////////////
//////////  MML_STATUS   /////////////////////////////////
/////////////// (game engine specific) 
//////////////// see 'gui_menu_blocking(...)' for 
////////////////// running without game engine
/////////////////////////////////////////
///////
//	--- USE mml_status_set(...) to set on ANY obj, 
//		(needs it's main behavior to run behav_mml_status(o)
//			or does nothing, behav_mml_status(o)
//			executes the statuses, can simulate by using it)
//		can run multiple statuses at a time,
//		runnning SET again on same one can reset it. 
//	--- basically, decaying 'behaviors', 
//		run with behav_mml_status(o) as a sub-behavior
//	--- set via 
//	--- can take ANY behavior or mml cmd, 
//	--- special mml_status_functions can be used, 
//		sends an extra 'time-left' var back to function
//		(see below) 
////////////////////////////////////////

//status function example
async function mml_status_graphic_effect( o, otarget, track, magnitude, 
	list_cmds, rm_OPTIONAL, time_left_SATUS_STUFF_ONLY){
	//same params as mml, ONLY has time_left

	var tmpGraphic = o[list_cmds.o_txt2DispVarName];
	var tmpPrecent_Done = _mml_status_precentDone__from_times_list(
		list_cmds.time_start_end_reverseStart_end, 
		time_left_SATUS_STUFF_ONLY );

	draw(tmpGraphic + tmpPrecent_Done, 
		list_cmds.x_offset,list_cmds.y_offset, "");
}
	
var  mml_status_manually_setting_example__SHOULD_USE__SET__INSTEAD = { 
	// should use this instead: mml_status_set, this for manually
   x:0, y:0, colgroup:"", graphic:"",
  //NOTE: status mmls have 1 extra param, for TIME till done,
  _statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS:
   [	"stat1", 1, 100, 100,
	     ["mml_to_run_as_status", "params"],
	     //regular mml-functs or too, or...
	"stat2_behavs_also_work", 1, 100, 100, 
		["behave_to_run_as_status"],
	// below is optional, can add as many satuses as wanted.
	"run_multiple_in_one_status", 1, 100, 100, 
	  ["mml_status_run_multiple_status_as_substatus",
		// SHOULD mml-functs THAT -DRAW DIRECTLY- for MENUS
		// as OBJ WON'T BE ADDED TO SCENE!!!
	   ["mml_funct_name","params"],
	    ["mml_funct_name2","params"]]
  ]
};

// CAN SETTUP MANUALLY VIA: 
// [statusName, getMagMax, curTime, maxTime, mml_status_data, ...
// 	(then repeats, basically adding those 5 elements works) ]
// -- OR
// Just run this on the data 
//
///////////////////////
// o's NEED 'behav_mml_status(o)' in MAIN BEHAV, OR THESE WON'T RUN!!
// 	HOEVER:
// 	using this function sets up the behavior in 'o' fully. 
function mml_status_set(   
	 o,  getS, //getStatusName_or_null2Use_cmdName_or_ALL_ALLRESET,
		// 'statusName' is ANY unique per 'o' status... 
		//      for mag/time change: mml_with_configs_list also OK
		// "ALL",sets ALL status times, 
		// "ALLRESET" resets all times
		// "ALLADD", ADDS time to all statuses,
		// "ALLSUBTRACT", REMOVES time from all statuses
		// "ALLSETIFABOVE" - sets for EACH status 'time' ABOVE
		// 	"getT" TOO "getTimeDecay_max_neg_for_reduce"
	  //for setting/ resetting time, getS can be mml_with_cmds pointer
		getMagMax, getMag2Add, getTimeDecay_max_neg_for_reduce,
		getstatus_mml_with_configs_list, //unused with "ALL..."
		getT ){ //getSetTime_ifBelow_intOPTIONAL CAN BE -1 to LOOP!
			//behaviors deleted at 0,so -1 means delete/restore
	// getstatus_mml_with_configs_list -SHOULD- be POINTER to LIST,
	//	this way it just copies the pointer.(it's mml-cmds)
	if(o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS == void null){ 
		if(getS.charCodeAt(0) == 65 // "A"s charcode, optimizing
			&& getS.indexOf("ALL") ==0){ return;}
		o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS=[]; }
	var tmpStats = o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS;
//API_TAG//
	//setting times for "ALL": 
	if(getS.charCodeAt(0) == 65){ // "A"s charcode
	 if(getS.charCodeAt(3) != 83){ //"S" charcode, otptimizing
	   if(getS == "ALL"){ for(var i=0; i<tmpStats.length; i+=5){
		if(getT == void null || tmpStats[i+2]< getT){
		   tmpStats[i+2] = getTimeDecay_max_neg_for_reduce;  
		   if(tmpStats[i+2] > tmpStats[i+3]){ //if over MAX...
			 tmpStats[i+2]=tmpStats[i+3];} } } return;}
	   if(getS == "ALLRESET"){ for(var i=0; i<tmpStats.length; i+=5){
		if(getT == void null || tmpStats[i+2]< getT){
			tmpStats[i+2] = tmpStats[i+3];} } return; } 
	   if(getS == "ALLADD"){ for(var i=0; i<tmpStats.length; i+=5){
		if(getT == void null || tmpStats[i+2]< getT){
		   tmpStats[i+2] += getTimeDecay_max_neg_for_reduce; 
		   if(tmpStats[i+2] > tmpStats[i+3]){ //if over MAX...
				tmpStats[i+2]=tmpStats[i+3];} } }return;}
	   } //end optimization
	 if(getS == "ALLSETIFABOVE"){for(var i=0; i<tmpStats.length; i+=5){
		if(getT == void null || tmpStats[i+2]> getT){
		   tmpStats[i+2] = getTimeDecay_max_neg_for_reduce; 
		   if(tmpStats[i+2] > tmpStats[i+3]){ //if over MAX...
				tmpStats[i+2]=tmpStats[i+3];} } }return;}
	 if(getS == "ALLSUBTRACT"){ for(var i=0; i<tmpStats.length; i+=5){
		if(getT == void null || tmpStats[i+2]> getT){
		   tmpStats[i+2] -= getTimeDecay_max_neg_for_reduce; } } 
			return;}
	}

	////setting status if unset
	var tmp_i = tmpStats.indexOf( getS);
	if(tmp_i == -1 ){ 
	   //NOTE: keep all vars as SIMPLE VARS/POINTERS,
	   //		as this allows CONCAT, which should be 
	   //		degrees faster than other methods. 
	   tmpStats.push(getS, getMag2Add, getTimeDecay_max_neg_for_reduce,
		getTimeDecay_max_neg_for_reduce, //MAX time
	     getstatus_mml_with_configs_list);
	   
	////below handles modding existing entries, so 1 funct does-it-all
	}else{ 
	     tmp_i = tmp_i - (tmp_i % 5); //so can use mml_cmds data
	     getMag2Add = getMag2Add + tmpStats[tmp_i+1];
	     if( getMag2Add > getMagMax){ getMag2Add  = getMagMax;}
	     tmpStats[tmp_i+1] =getMag2Add;
	  if(getTimeDecay_max_neg_for_reduce >0){
		if(getT == void null || tmpStats[i+2]< getT){
	     	  tmpStats[tmp_i+2] = getTimeDecay_max_neg_for_reduce;}
	  }else{ tmpStats[tmp_i+2] -= getTimeDecay_max_neg_for_reduce;
		if( tmpStats[tmp_i+2] < 0){ tmpStats[tmp_i+2] = 1;}
		// above reduces to 0 on first loop-run
}	}	return; }

//API_TAG//
function mml_status_get_index_of_status(
		o, getStatus_name_OR_list_cmds_pntr){
	var tmp_i = o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS.indexOf(
		getStatus_name_OR_list_cmds_pntr);
	if(tmp_i == -1){ return -1;}
	return tmp_i - (tmp_i % 5 );// 5 items in each 'status'
} 
//API_TAG//
//API_TAG//
async function mml_status_run_multiple_status_as_substatus( 
	o, otarget, track, magnitude, 
	list_cmds, rm_OPTIONAL, time_left_SATUS_STUFF_ONLY){
//API_TAG//
	//TODO: store sub-cmds in list_cmds:
	//	["cmd", ["sub_cmd1", ""], ["sub_cmd2", ""]]
	var tmp_one_NOT_done_running = 0;
	for(var i=1; i< list_cmds.length; i+=1){
		//mml's return 1 for early break, checking all...
		if(1 != (await rmloaded_b_globalThis[list_cmds[i][0] ]( 
		   o,otarget, track, magnitude, 
		   list_cmds[i], rm_OPTIONAL, 
		   time_left_SATUS_STUFF_ONLY)) ){ 
			tmp_one_NOT_done_running = 1; } }
	if(!tmp_one_NOT_done_running){ return 1; } //early termination. 
}

//API_TAG//
// THIS SHOULD -NOT- BE MAIN BEHAVIOR, LEST THE 
// 	OBJ IS BEING ACTED UPON BY OUTSIDE OBJECT
// 	-OR- HAS PRESET STATUSES AS -ONLY- BEHAVIORS!!!
// 		(like a projectile, or something)
// USE:
// o._statuses_list_NAME_MAG_TIME_TIMEMAX_MMLCMDS == null to see if out of ALL statuses. 
/////////////////////////////////////////
// USE THINS -INSIDE- MAIN o BEHAVE, NOT -AS- IT 
// 	ALSO: mml_status_set(...) is for SETTING UP BEHAVS
// 		(can check obj-example for how to do it by hand) 
//
// MAIN BEHAVIOR FOR THIS, see SET and EXAMPLES FOR HOW TO USE
// 	(this optimization is mostly for c, 
// 		JS VERSION IS READABLE!!!)
var behav_mml_status = _behav_mml_status_CORE;


//API_TAG//
// getL_SE_rSE == [start,end,  reverseStart, reverseEnd]
// 	(countdown, so 'start' is higher than 'end', 
// 		between 'end' and 'reverseStart' returns 100% (to pause), 
// 		'reverse' start can be negetive to stop at 100% ) 
function _mml_status_precentDone__from_times_list(
		getL_SE_rSE, // [start, end, startreverse, endreverse] 
		  //ussually stored in:cmds.time_start_end_reverseStart_end
		  // this way, it's a pointer, (fast
		time_left_SATUS_STUFF_ONLY){
//API_TAG//
	//end
	if(time_left_SATUS_STUFF_ONLY >  getL_SE_rSE[0] ){
			return 0; }// 0%
	if(time_left_SATUS_STUFF_ONLY >=  getL_SE_rSE[1]  ){ //[1]==end
	   return (getL_SE_rSE[0] - time_left_SATUS_STUFF_ONLY )
		  / ( getL_SE_rSE[0]-getL_SE_rSE[1]);} // %start- 0-to-100
	if(time_left_SATUS_STUFF_ONLY > getL_SE_rSE[2] ){//[2]==startRevrse
	   return 1;} // 100%
	if(time_left_SATUS_STUFF_ONLY >= getL_SE_rSE[3]){//[3]==endRevrse
	   return (time_left_SATUS_STUFF_ONLY - getL_SE_rSE[3])
		/ (getL_SE_rSE[2] -getL_SE_rSE[3]); }// %revrse- 0-to-100
	return 0; // < getL_SE_rSE[3], at end of reverse, 0%
}


