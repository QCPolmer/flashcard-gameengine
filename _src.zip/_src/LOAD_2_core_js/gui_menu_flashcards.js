//////////////////////////////////////
//// GUI_MENU_FLASHCARDS: ///////////
///////////////////////////////////////////
////////////////////////////////////

//API_TAG//
//	EDIT: still exhausted working on this again,
//		but I did get it running, at least...
//		see the BLOCKING and _data to get an idea 
//		on how to use.
//	ALSO: can just pretty much 
// I was feeling under the weather when writing this 
//  The long and short of it is: 
//  use gui_menu_flashcard_statemachine_BLOCKING (or the non 
//  	blocking function used in there) to launch test, 
//  	(returns % correct)
//  generate tests with gui_menu_gen_builtin_test

//
// this is mostly used internally.
//  gui_menu_gen_builtin_test is probably a easier funct. to use. 
function gui_menu_flaschards_genQuestions_BASIC( getTxt, getSplit_txt_by, 
		MIN_SENTENCE_WORDS_OPTIONAL, 
		getAsk_Qs_4_all_words_OPTIONAL, 
			//basically the above is 'reciting' all txt.
		get_QS_show_prev_QA_OPTIONAL, getQ_A_SplitBy_OPTIONAL){

//API_TAG//
	var qs_out = [];
	var lines = getTxt.trim().split(getSplit_txt_by);
	for(var i= lines.length-1; i>0; i-=1){ lines[i] = lines[i].trim();}
	if(MIN_SENTENCE_WORDS_OPTIONAL == null){
		var MIN_SENTENCE_WORDS_OPTIONAL = 1;}
	if(MIN_SENTENCE_WORDS_OPTIONAL <=1){MIN_SENTENCE_WORDS_OPTIONAL=2;} 
	
	if(getQ_A_SplitBy_OPTIONAL != undefined){
		for(var i= lines.length-1; i>=0; i-=1){
			var tmp_QA =lines[i].split(getQ_A_SplitBy_OPTIONAL);
			if(tmp_QA.length ==1){ 
				if(i!=0){ lines[i-1] += lines[i];
				}else{tmp_QA[0].Q= lines[i] + tmp_QA[0].Q;}
				continue; }
			qs_out.unshift({Q:tmp_QA[0], A:tmp_QA[1]});	}
	}else{ // getQ_A_... undefined, so splitting by words
		for(var i= lines.length-1; i>=0; i-=1){
			var tmp_QA =lines[i].split(" ");
			if(tmp_QA.length <MIN_SENTENCE_WORDS_OPTIONAL && 
			  (lines.length-1) > i && i != 0){ 
				 lines[i-1] += getSplit_txt_by + lines[i];
				continue;
			}if( i == (lines.length-1) && tmp_QA.length ==1){
				tmp_QA.unshift( lines[i-1].split(" "));
				lines[i-1] = "";}
			var tmpLen = tmp_QA.length;
			
			if(getAsk_Qs_4_all_words_OPTIONAL ==true 
				&& qs_out.length!=0 ){
			   qs_out.unshift({ 
			       Q:tmp_QA.slice(tmpLen/2, tmpLen).join(" "),
			       A:qs_out[0].Q});	
			}
			qs_out.unshift({ 
			   Q:tmp_QA.slice(0, tmpLen/2).join(" "),
			   A:tmp_QA.slice(tmpLen/2, tmpLen).join(" ")}); }
		if(get_QS_show_prev_QA_OPTIONAL == true){
		   //joining previous 3 questions to this one
		   var COPY_qs_out =JSON.parse(JSON.stringify(qs_out));
		   var Q_SPACING = 1; 
		   if( getAsk_Qs_4_all_words_OPTIONAL == true){
			   Q_SPACING =2;}
		   for(var i=1; i<qs_out.length; i+=1){
			if(i==1 && getAsk_Qs_4_all_words_OPTIONAL == true){
				qs_out[i].Q = COPY_qs_out[i-1].Q 
					+getSplit_txt_by+ qs_out[i].Q;
				continue;}
			qs_out[i].Q =
			    COPY_qs_out[i-Q_SPACING].Q + 
				" "+COPY_qs_out[i-Q_SPACING].A + 
				   getSplit_txt_by+
				   qs_out[i].Q; }
		}
	}
	return qs_out;
}

//API_TAG//
// 	example of flashcard data, 
// 	gui_menu_gen_builtin_test
// 	is probably a better method to use to generate test-data. 
// 	(this is here to show how to modify the returned data-struct. 
var gui_menu_flashcards_data_example = {
	name:"",
	/// 

	////////////////////////////
	//MODIFY THIS:
	gui_menu_config:"menu_test_o__FLASHCARDS",
	
	genQuestions_function:"", // needs seperate function to interpret
	split_txt_by:"\n", //char to split text by INITIALLY
			//probably should have seperate function.
	// BELOW SHOULD BE A LIST OF POSSIBLE Q_N_As,
	// FOR DIFFERENT Q_N_A VARIATIONS
	qs_n_as:null, //Typically, gui_menu_gen_builtin_test will 
			// build this PRIOR to running test.
			//	(below are 2 UNTESTED alternatives. ) 
			// FORMAT: {Q:"", A:""}	
	quizFunction:null,	//UNTESTED
		// 	PROBABLY this or below var can be set instead 
	// 			of generating qs_n_as questions beforehand.
		//	DEBUGGING NOTE: this nd below are only found at:
	//			"2_gen_question_n_load_it" "1_init_reset"
		//  above should be a function taking no inputs
		//  	and return  a block of questions
		// 	(qs_n_as datatype: [{Q:"", A:""}, ...]
		// runs initially, then every full run through 
	// 		question block
	quizFunction_RUN_EVERY_Q:null, //	UNTESTED
		//same format as above, generate enough questions 
		// to produce randomly drawn, unique answers. 	
		

	cur_loaded_question:"",	
	cur_loaded_answers_possible_list:[],
	cur_loaded_answer:"",

	cur_correctPoints:0, // cur= current 
	max_correctPoints:4,
	
	cur_1block_correct:0,	
	cur_Spot:0,
	cur_scambled_answers:[],
	cur_1block_questions_asked:0, // for 1 question block  
	cur_state:null, //settup by state machine (for flashcard function) 

	max_questions_asked:4, // for 1 block of questions
	number_of_possible_answers:2, 	
	shuffle_questions:false,
	
	//the following will merge the ask-know-it into 1 block!
	// (OTHERWISE: asks if I know if first)
	ask_questions_instead_of_know_it_1_block:true,//false,
	ask_questions_instead_of_know_it_1_block_DNTKNW_TXT: 
		"DON'T KNOW--(see answer,go prev)-(ESC/UP)",
	//question order(below) generally won't change 
	ask_knows_answer:[
		"KNOW IT---------------------(+1 if right)", 
		"DON'T KNOW---(see answer, go to previous)",
		"ENOUGH--------(back 10 questions, exits )", ], 
	ask_knows_answer_FULL:[
		"KNOW IT-------(+1 if right,-ALL if wrong)", 
		"DON'T KNOW---(see answer, go to previous)",
		"CASH OUT-------(-ALL, see answer, exits )"],
	wrong_answer_descr:
		"\n!---------------------------!\n" +
		"!------WRONG, ANSWER WAS:----!\n" + 
		"!----------------------------!\n",
	format_4_question: // replaces %max_questions_asked%, %Q%
		//%cur_1_block_correct% etc. 
	//see gui_menu_flaschards_formatted_question(fc)
	//  (not shown in API)
//CORRECT POINTS -------------------%cur_correctPoints%
//THIS ROUND CORRECT/LEFT/MAX---------%cur_1block_correct%/%cur_1block_questions_asked%/%max_questions_asked%
`-- CORRECT POINTS: %cur_correctPoints% --- THIS ROUND CORRECT: %cur_1block_correct% --
%Q% ________(?)
`
};
//API_TAG//


//API_TAG//
// ---------gui_menu_gen_builtin_test
//(THIS FUNCTION GENERATES DATE FOR THE FOLOWING FUNCTION:)
//	gui_menu_flashcard_statemachine_BLOCKING(
//			fc,getDraw_str )
// for an easy way to generate a test. (uses builtin functions)
// can edit certain paramiters afterwards, see
// gui_menu_flashcards_data_example
// 	for full configuration. 
// For FULLY custom tests, copy paste gui_menu_flashcards_data_example,
// 	edit it, and use gui_menu_flaschards_genQuestions_BASIC
// 	(or another function that spits out {Q:"", A:"", ...} )
// 	--- put results in the tests qs_n_as variable, 
// 	and it should be ready to go. 
// 	(this function doesn't need to define qs_n_as)
function gui_menu_gen_builtin_test( getTxt, getSplit_txt_by, 
	MIN_SENTENCE_WORDS_OPTIONAL, 
		getAsk_Qs_4_all_words_OPTIONAL,
		get_QS_show_prev_QA_OPTIONAL, getQ_A_SplitBy_OPTIONAL){
//API_TAG//

	var tmp_test = JSON.parse( JSON.stringify( 
		gui_menu_flashcards_data_example ) );
	tmp_test.qs_n_as = 
	 gui_menu_flaschards_genQuestions_BASIC( getTxt, getSplit_txt_by, 
		MIN_SENTENCE_WORDS_OPTIONAL, 
		getAsk_Qs_4_all_words_OPTIONAL,
		get_QS_show_prev_QA_OPTIONAL, getQ_A_SplitBy_OPTIONAL);
	return tmp_test;} 

//API_TAG//
// mostly built in stuff. Included 
// 	to show how to generate a test around the 
// 	pre-defined test
var gui_menu_flashcards_DECK_TEST;
//OK, need to make a 'gen basic test' algorithim that takes a string, 
//	spits out a test. 
function gui_menu_flashcards_GEN_DECK_TEST( ){
	gui_menu_flashcards_DECK_TEST = JSON.parse(JSON.stringify( 
		gui_menu_flashcards_data_example ));
	//gui_menu_flaschards_genQuestions_BASIC( getTxt, getSplit_txt_by, getQ_A_by_OPTIONAL)
	gui_menu_flashcards_DECK_TEST.qs_n_as = gui_menu_flaschards_genQuestions_BASIC( 
	`
This is only a test. 
did you remember to pay 
the utilities? (or not) 
One two three four, 
five six seven eight, 
nine ten eleven twelve, 
thirteen, fourteen, fifteen, sixteen
`, ",", 2, true, true ); // ask_every_word, display prev. questions/A
	return gui_menu_flashcards_DECK_TEST;
}
//API_TAG//


// https://stackoverflow.com/questions/2450954/how-to-randomize-shuffle-a-javascript-array
// should work for any array, returns a copy
function gui_menu_flaschards_shuffleArray(array) {
    array = array.concat(); //I modified it so it returns a COPY of array
    for (var i = array.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;	}
   return array;
}


//used internally, not documenting. 
function gui_menu_flaschards_formatted_question(fc){
	return txttools_limit_width( 
	   fc.format_4_question
		.split("%cur_correctPoints%").join(fc.cur_correctPoints)
		.split("%cur_1block_correct%").join(fc.cur_1block_correct)
		.split("%cur_1block_questions_asked%").join(
			fc.cur_1block_questions_asked)
		.split("%max_questions_asked%").join(fc.max_questions_asked)
		.split("%Q%").join(fc.qs_n_as[ fc.cur_Spot].Q),
		50);
}

//API_TAG//
//easy way to launch a test 
//  see: gui_menu_gen_builtin_test (above) for a 
//  		explaination of how to generate tests
//  		(using that function is probably the easiest) 
//	ALSO: an example of how to use this funct in a NON-BLOCKING WAY
async function gui_menu_flashcard_statemachine_BLOCKING(
		fc,getDraw_str, // flaschcard data
		bg_OPTIONAL){ //underlay_bg_gridstr_canuse__rmloaded_last_draw_OPTIONAL){ 
	
	controllers_clear_pressed();
	// init(rest), good ex for non-blocking, need to init, then will 
	// spit out answer answer (once given) until reset again.
	if(bg_OPTIONAL == void null){bg_OPTIONAL = "";} 
	draw(bg_OPTIONAL, 0,0,"	");
	await gui_menu_flashcard_statemachine( fc, getDraw_str, // flaschcard data
		true);
	while( await gui_menu_flashcard_statemachine( fc,getDraw_str)== null ){ 
		
		await update();
		draw( bg_OPTIONAL,0,0,"	");
	}
	file_input( JSON.stringify(
		await gui_menu_flashcard_statemachine( fc,getDraw_str)));
	return await gui_menu_flashcard_statemachine(fc, getDraw_str); } 
//API_TAG//



//API_TAG//
// An example of using this asyncro can be found in the 
//  gui_menu_flashcard_statemachine_BLOCKING function (above)
//  (as well as a more detailed explaination of how 
//  	to use this function.)
async function gui_menu_flashcard_statemachine( fc, getDraw_str,  // flaschcard data
		bool_results_toggle_reset_Q_block_OR_NULL){
//API_TAG//
	if( bool_results_toggle_reset_Q_block_OR_NULL == true){
		//return fc.cur_1block_correct/fc.max_questions_asked;	 
		fc.cur_state = "2_gen_question_n_load_it";
		fc.cur_1block_correct =0;
		fc.cur_1block_questions_asked=0;
	}

	if( fc.cur_state == null){	fc.cur_state = "1_init_reset";	}

	//probably should put 'init' stuff here, as this unneeded
	if(fc.cur_state == "1_init_reset"){
		if(fc.quizFunction != null){
			fc.qs_n_as = fc.quizFunction();}
		if(fc.quizFunction_RUN_EVERY_Q != null){
			fc.qs_n_as = fc.quizFunction_RUN_EVERY_Q();}

		if(fc.shuffle_questions){ fc.qs_n_as =
			gui_menu_flaschards_shuffleArray(fc.qs_n_as); }
		fc.cur_state = "2_gen_question_n_load_it";}

	if(fc.cur_state == "2_gen_question_n_load_it"){
		// gen random answers list, one correct
		
		if(fc.quizFunction_RUN_EVERY_Q != null){
			fc.qs_n_as = fc.quizFunction_RUN_EVERY_Q();
			fc.cur_Spot = 0;}
		if(fc.cur_Spot >= fc.qs_n_as.length){ 
			fc.cur_Spot = 0;
			if(fc.quizFunction != null){
				fc.qs_n_as = fc.quizFunction();}
			if(fc.shuffle_questions){ fc.qs_n_as =
			  gui_menu_flaschards_shuffleArray(fc.qs_n_as); }
		}if(fc.cur_Spot <0){ fc.cur_Spot =0;}
		if( fc.cur_correctPoints > fc.max_correctPoints){
		   fc.cur_correctPoints = fc.max_correctPoints;	}

		var correct_answer = fc.qs_n_as[ fc.cur_Spot].A;
		var random_answer = correct_answer;	
		var question_list = [correct_answer];	
		while(question_list.length <fc.number_of_possible_answers){
			if(question_list.indexOf(random_answer)==-1 ){
			    question_list.unshift(random_answer); }
			random_answer = fc.qs_n_as[ Math.floor(
				Math.random() * fc.qs_n_as.length)].A;}
		fc.cur_scambled_answers = 
			gui_menu_flaschards_shuffleArray(question_list);
		

		fc.cur_loaded_answer = correct_answer;
		
		fc.cur_loaded_question =  
			gui_menu_flaschards_formatted_question(fc); 
		if(fc.cur_correctPoints==0){
			var tmp_options = fc.ask_knows_answer;
			fc.cur_loaded_answers_possible_list= tmp_options; 
			//gui_menu( 
			//fc.cur_loaded_question, fc.gui_menu_config,getDraw_str, 
			//tmp_options);
		}else{
		  var tmp_options = fc.ask_knows_answer_FULL.concat();
		  fc.cur_loaded_answers_possible_list= tmp_options; 
		  //gui_menu( 
		//	fc.cur_loaded_question,fc.gui_menu_config ,getDraw_str, 
		//	tmp_options);
		}
		
		//THIS IS FOR A SINGLE QUESTION BLOCKS
		if( fc.ask_questions_instead_of_know_it_1_block ){
			tmp_options = tmp_options.concat();
			tmp_options.shift(); //removing 'know answer'
			//reversing order for usability.
			tmp_options.shift();
			tmp_options.push( fc.
			ask_questions_instead_of_know_it_1_block_DNTKNW_TXT
			 );
			tmp_options = fc.cur_scambled_answers.concat(
				tmp_options);
			
			fc.tmp_options_CATCH = tmp_options;
			
			
			fc.cur_loaded_answers_possible_list= tmp_options; 
			//gui_menu( 
			//fc.cur_loaded_question,fc.gui_menu_config ,getDraw_str, 
			//tmp_options);
			
			fc.cur_state = "4.2_ask_question_wait_for_response";
			//return null; // progresses next time ran	
		}else{

		fc.cur_state = "3_ask_does_know_answer";
		//return null; // progresses next time ran
		}	
	}

	if(fc.cur_state == "3_ask_does_know_answer"){
		
		var tmp_menu_return = 
		  await gui_menu(fc.cur_loaded_question,fc.gui_menu_config ,
			fc.cur_loaded_answers_possible_list);
		if( tmp_menu_return == null){ return null;}		
		var tmp_i = fc.ask_knows_answer_FULL 
				.indexOf( tmp_menu_return );
		if(fc.cur_correctPoints ==0){
			var tmp_i = fc.ask_knows_answer
				.indexOf( tmp_menu_return );}

		if( tmp_i == 1 ){ // don't know answer, go back 1 question 
			fc.cur_state = "4.3_show_answer";
			fc.cur_1block_questions_asked +=1;
			fc.cur_Spot -=1;
		}if( tmp_i == 0){ // knows answer
			fc.cur_state = "4.1_ask_question";		
		}if( tmp_i == 2||tmp_i== -1){ 
			// ENOUGH/CASH OUT (show answer, end quiz here)
			fc.cur_state = "4.3_show_answer";
			fc.cur_1block_questions_asked =
					fc.max_questions_asked;
			if( fc.cur_correctPoints == 0){
				fc.cur_Spot-=10; }
			fc.cur_1block_correct += fc.cur_correctPoints;
			if( fc.cur_1block_correct > fc.max_questions_asked){
			   fc.cur_1block_correct = fc.max_questions_asked;}
			fc.cur_correctPoints = 0;
		}
	}
	if(fc.cur_state == "4.1_ask_question"){
		fc.cur_loaded_answers_possible_list=
			fc.cur_scambled_answers; 
		//gui_menu( fc.cur_loaded_question,fc.gui_menu_config ,getDraw_str, 
		//	fc.cur_scambled_answers);	
		fc.cur_state = "4.2_ask_question_wait_for_response";}
	if(fc.cur_state == "4.2_ask_question_wait_for_response"){
		
		// correct answer: fc.qs_n_as[ fc.cur_Spot].A
		var tmpAnswer = await gui_menu( fc.cur_loaded_question, 
			  fc.gui_menu_config,
			fc.cur_loaded_answers_possible_list);
		if(tmpAnswer == null){ return null;}
		
		

		if(tmpAnswer == fc.qs_n_as[ fc.cur_Spot].A){ 
			fc.cur_state = "5_assess_quiz_n_return";
			fc.cur_Spot +=1; 	
			fc.cur_1block_correct +=1;
			fc.cur_correctPoints +=1;
			fc.cur_1block_questions_asked +=1;	
		}else{
			
			if( fc.ask_questions_instead_of_know_it_1_block ){
			  var tmp_i = 
			    fc.tmp_options_CATCH.indexOf(tmpAnswer);
			  var tmp_len = fc.tmp_options_CATCH.length;
				//"DON'T KNOW-------
			  if( tmp_i == tmp_len -1 || tmp_i== -1 ){
				fc.cur_state = "4.3_show_answer";
				fc.cur_1block_questions_asked +=1;
				fc.cur_Spot -=1;
				return null;	}
				//"CASH OUT--------
			  if( tmp_i == tmp_len -2 ){
				// ENOUGH/CASH OUT (show answer, end quiz)
				fc.cur_state = "4.3_show_answer";
				fc.cur_1block_questions_asked =
					fc.max_questions_asked;
				if( fc.cur_correctPoints == 0){
				  fc.cur_Spot-=10; }
				fc.cur_1block_correct += 
					  fc.cur_correctPoints;
				if( fc.cur_1block_correct > 
				   fc.max_questions_asked){
			   	fc.cur_1block_correct = 
						fc.max_questions_asked;}
				fc.cur_correctPoints = 0;
				return null; }
		}
		fc.cur_state = "4.3.1_show_answer_WRONG";
		fc.cur_correctPoints =0;	
		fc.cur_1block_questions_asked =
			fc.max_questions_asked;
			
		}
	}
	if(fc.cur_state == "4.3_show_answer"){
		fc.cur_loaded_answers_possible_list=[fc.cur_loaded_answer];
		//gui_menu( fc.cur_loaded_question,fc.gui_menu_config ,getDraw_str, 
		//	[fc.cur_loaded_answer]);
		fc.cur_state = "4.4_show_answer_wait_for_response";
	}
	if(fc.cur_state == "4.3.1_show_answer_WRONG"){
		fc.cur_loaded_answers_possible_list=
		    [fc.wrong_answer_descr + fc.cur_loaded_answer]
		//gui_menu( fc.cur_loaded_question,fc.gui_menu_config ,getDraw_str, 
		//	[fc.wrong_answer_descr + fc.cur_loaded_answer]);
		fc.cur_state = "4.4_show_answer_wait_for_response";
	}
	if(fc.cur_state == "4.4_show_answer_wait_for_response"){
		var tmp_i = 
		  await gui_menu( fc.cur_loaded_question,fc.gui_menu_config ,
			fc.cur_loaded_answers_possible_list);
		if(tmp_i != null){ fc.cur_state = "5_assess_quiz_n_return";}
	}
	if( fc.cur_state == "5_assess_quiz_n_return"){
		// need a rest input variable 
		// I use max_questions_asked to test if done /w block
		if(fc.cur_1block_questions_asked >=fc.max_questions_asked){
			var tmpRet = 
			   fc.cur_1block_correct/fc.max_questions_asked;
			if(tmpRet >1){return 1;}else{ return tmpRet;}
		}else{
			fc.cur_state ="1_init_reset";
		}
	}
}




//////////////////////////////////////

