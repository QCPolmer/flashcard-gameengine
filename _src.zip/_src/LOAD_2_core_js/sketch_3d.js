//API_TAG//
//API_TAG//

/////////////////
//////////////////////////////////////////////////////
//////// sketch_3d__convertobj
//////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////

// these 'functs' allow standard data to be 'loaded' into 3d. 
// 	NOTE: all 3d-stuff is  experimental and based on raycasting,
// 		probably best to avoid ALL 3d stuff with this engine.
var sketch_3d__convertobj_lrg_functs = {};
var sketch_3d__convertobj_functs = {};
sketch_3d__convertobj_lrg_functs.default  = void null;// placeholder, defined later
sketch_3d__convertobj_functs.default = void null; // placeholder, defined later (TODO)

var _sketch_3d_lrgobj_diagnol_dist_1turn_catch = [];
var _sketch_3d_BLANK_TO_DRAW_CHAR = "	"; // TAB

var _sketch_3d___sketch_3d__INITIAL_BG_FILL_CHAR= 
	_sketch_3d_BLANK_TO_DRAW_CHAR; 
//o3d
//FOR ANIMATIONS/ CHANGING GRAPHICS, SHOULD RUN THIS!!!
//API_TAG//
function sketch_3d__convertobj_clear_obj_vars_to_allow_reinitialize(o){ //obj
	//doesn't clear o.z, non-present keys will harmlessly pass over
//API_TAG//
	delete o.d3loaded;
	//d3transparentChar --ACTUAL VAR, not modifying
	
	// o.d3funct is NOT modified, so it can run again
	//BELOW: large maps
	delete o.d3ceils; delete o.d3floors;
	//BELOW: small objs
	delete o.d3graphic;
	delete o.d3height; delete o.d3width;
}

//generic one, will add more... maybe
// NOTE: d3loaded == o.graphic WHEN LOADED!!!
// 	This is a SLIGHT hack, that allows recalc-ing for 
// 	animating/ rotating map. 
//d3ceils d3floors d3texturemaps
function sketch_3d__convertobj_gen_floor_ceil_array(getGridstr){
	var tmpWidth = getGridstr.indexOf("\n")-1;
	var out2dArr = new Array( //getting height
		Math.floor(getGridstr.length/(tmpWidth +1)  ));
	for(var i =0; i< out2dArr.length; i+=1){
		out2dArr[i] = new Float32Array(tmpWidth);}
	return out2dArr;	}
function sketch_3d__convertobj_lrg(o){ // lrg_object = boolean
	if(o.d3loaded == o.graphic){ return;}
	if(o.d3funct == void null){ o.d3funct = "default";}
	sketch_3d__convertobj_lrg_functs[o.d3funct](o); }
//below is for:small sprites. for large sprites, use above.
function sketch_3d__convertobj(o){ 
	if(o.d3loaded == true){ return;}
	if(o.d3funct == void null){ o.d3funct = "default";}
	sketch_3d__convertobj_functs[o.d3funct](o);
	o.d3graphic = gridstr_replaceall( 
		o.d3graphic, o.d3transparentChar, 
		_sketch_3d_BLANK_TO_DRAW_CHAR);
		
}
//API_TAG//
function sketch_3d__convertobj_lrg__template(o){
	// 	NOTE: all 3d-stuff is  experimental and based on raycasting,
	// 	  probably best to avoid ALL 3d stuff with this engine.
	// WHY THIS IS HERE: conversion happens on running 3d 
	// 	based on function in o.d3functs. 
	// Obj-3d largeObjs vars: z, d3ciels, d3floors,
	// d3loaded != o.graphic means recalculating. 
	// NOTE: need to nuke these if graphic changes/ rotates!!!
	// (will need to recalc. )
	// WHERE TO PLACE/ LOAD 3d CONVERT FUNCTIONS:
	// ---sketch_3d__convertobj_lrg_functs.FUNCTION_NAME
	// ---o.d3funct (undefined is this template, see template
	// 	to see how this works) 
	// --- NOTE: large objsLrg and objs convert differently to 3d. 
	// 	check the sketch_3d__convertobj_template!
//API_TAG//	
	o.d3loaded = o.graphic;
	if( o.z == void null){ o.z = 0;}
	if( o.d3ciels == void null){ 
		var a = sketch_3d__convertobj_gen_floor_ceil_array(o.graphic);//ret array
		var g = o.graphic; 
		var r=0; var c=-1; //row for 'r', 'c' for cols (for 'a')
		for(i=0; i<  g.length; i+=1){ c+=1;
			if( g[i] == "\n"){ r+=1; c = -1; continue;}
			//ABOVE is boilerplate
			if( g[i] == "#"){a[r][c] = -150; continue;}
			if( g[i] == "" ){a[r][c] =  -200; continue;} 
			// 1000:} arbitrary, should modify
			
			a[r][c] =  -100;
		
		} o.d3ceils = a;
	
	}if( o.d3floors == void null){
		var a = sketch_3d__convertobj_gen_floor_ceil_array(o.graphic); //ret array
		var g = o.graphic; 
		var r=0; var c=-1; //row for 'r', 'c' for cols  (for 'a')
		for(i=0; i<  g.length; i+=1){ c+=1;
			if( g[i] == "\n"){ r+=1; c = -1; continue;}
			//ABOVE is boilerplate
			if( g[i] == "#"){a[r][c] = -100; continue;}
			if( g[i] == "" ){a[r][c] =  70; continue;} 
			// 1000:} arbitrary, should modify
			a[r][c] =  -3;
		} o.d3floors = a;
	}


}
sketch_3d__convertobj_lrg_functs.default = sketch_3d__convertobj_lrg__template;


//API_TAG//
function sketch_3d__convertobj_template(o){
	// WHY THIS IS HERE: conversion happens on running 3d 
	// 	based on function in o.d3functs. 
	// NOTE: obj. vars for 3d:
	//z, d3width, d3height, d3simplescale, d3transparentChar, d3graphic
	// NOTE: recalcs on o.d3loaded change. 
	// (will need to recalc. )
	// WHERE TO PLACE/ LOAD 3d CONVERT FUNCTIONS:
	// ---sketch_3d__convertobj_functs.FUNCTION_NAME
	// ---o.d3funct (undefined is this template, see template
	// 	to see how this works) 
	// --- NOTE: large objsLrg and objs convert differently to 3d. 
	// 	check the sketch_3d__convertobj_lrg__template!
//API_TAG//
	o.d3loaded = o.graphic;
	if( o.z == void null){ o.z = 0;}
	if( o.d3height == void null){ o.d3height = 20.8;}
	if( o.d3width == void null){ o.d3width = .8;}
	if( o.d3simplescale ==void null ){ o.d3simplescale = true;}
	//below is 'tab'
	if( o.d3transparentChar == void null){ o.d3transparentChar = "\t";}
	if( o.d3graphic == void null){ 
		if(o.graphic.length ==1){
			//for single characters, making them a 'frame'
			o.d3graphic = 
`\t   \t
 000 
 0 0 
 000 
\t   \t`.replace(new RegExp('0','g'), o.graphic);
		}else{ o.d3graphic = o.graphic;} } 
}
sketch_3d__convertobj_functs.default = sketch_3d__convertobj_template;

/////////////////
//////////////////////////////////////////////////////
//////// END:sketch_3d__convertobj
//////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////
////////////////////////////////////////////////
////////////////////////////////////////////////
//// js-part sketch_3d
////////////////////////////////////////////////
////////////////////////////////////////////////
var _sketch_3d__skygrids = {};
var _sketch_3d__skygrids_catch_size = 0;
var _sketch_3d__skygrids_catch_size_MAX = 25;
function _sketch_3d__skygrids_scale( getGridstr, getTarget_width){ 
	if( _sketch_3d__skygrids[ getGridstr] != void null){
		return _sketch_3d__skygrids[ getGridstr];}
	if(_sketch_3d__skygrids_catch_size ==
		_sketch_3d__skygrids_catch_size_MAX){
			_sketch_3d__skygrids = {};
			_sketch_3d__skygrids_catch_size =0;
	}else{  _sketch_3d__skygrids_catch_size+=1; }
	//file_input(1);
	var tmp_half_width = Math.floor(getTarget_width/2);
	var gridstr_width = txttools_getmax_width( getGridstr);
	var gridstr_height = txttools_getheight(getGridstr);
	sketch_init( gridstr_scale( getGridstr, getTarget_width,
		gridstr_height ));
	
	var getGridstr_reverse = gridstr_scale( getGridstr, -gridstr_width,
		gridstr_height )
		getGridstr
	var i =0; 
	var toggle_reverse =0;
	while( i <= tmp_half_width){
		if(!toggle_reverse){ 
			sketch_grid( getGridstr, i, 0, "");
		}else{ sketch_grid( getGridstr_reverse, i, 0, "");}
		//file_input(tmp_half_width + " " + i);
		i+= gridstr_width;
		toggle_reverse = !toggle_reverse;
	}
	var made_grid = sketch_get();
	sketch_grid( made_grid, tmp_half_width, 0);
	made_grid = gridstr_scale( getGridstr, -getTarget_width,
		gridstr_height )
	sketch_grid( made_grid, -tmp_half_width,0);

	_sketch_3d__skygrids[getGridstr] = 
		sketch_get();
	sketch_end();
	return _sketch_3d__skygrids[getGridstr];
}
//below will be a wrapper for sketch_3d that takes MANY less inputs!
function sketch_3d_FULL_SCREEN_DEFAULT(
	cam_x, cam_y, cam_angle, cam_height, cam_tilt,
	coltag_walls, coltag_sprites, 
		skygridstr_or_null, // DOES NOT SCALE WITH SCREENSIZE!!!
		shadowgrid_or_null, 
		// If above is null, the next ones aren't needed. 
		shadowgrid_shadow_char, 
		shadowgrid_x, shadowgrid_y,
		view_dist){
	
	return sketch_3d( 
		cam_x, cam_y, cam_angle, cam_height, cam_tilt,
		coltag_walls,  coltag_sprites,
		view_dist, //9,//30, //view dist max
		6,//10, // wall border disappears at this dist
		.8, // field of view (eg, fish-eye effect)
		.60,  // fade at this % of max dist
		draw_canvas_get_width(), draw_canvas_get_height(),
		skygridstr_or_null, // DOES NOT SCALE WITH SCREENSIZE!!!
		shadowgrid_or_null, shadowgrid_shadow_char, 
		shadowgrid_x, shadowgrid_y
		);
}

var _sketch_3d_DIST_START = .01; 
// see sketch_3d_FULL_SCREEN_DEFAULT for defaults
function sketch_3d( origin_x, origin_y, angle,cam_height,cam_tilt,
		get_coltag_for_walls, get_coltag_for_sprites,
		dist_max, 
		MAX_WALLBRDER_DIST_default_6,
		fieldOfView_Default_pnt8,
		fade_start_precent_Default_pnt60,
		inSketch_width, inSketch_height,
		skygridstr_or_null, // DOES NOT SCALE WITH SCREENSIZE!!!
		shadowgrid_or_null, shadowgrid_shadow_char, 
		shadowgrid_x, shadowgrid_y){ 

	inSketch_height +=2; // don't know why, but it's needed.
	
	// this catch is used for drawing large OBJ sprites
	// in: _sketch_3d_sprites_at_tile
	_sketch_3d__lrgobj_sprites_1turn_catch = false;
	// above is checked in per-tile-detection.
	_sketch_3d_lrgobj_diagnol_dist_1turn_catch__SETTUP(
		origin_x, origin_y, get_coltag_for_sprites, dist_max );

	var tmpLen = _sketch_3d_lrgobj_diagnol_dist_1turn_catch.length;
	//file_input(tmpLen);
	
	// I REMOVED BUFFER as drawing every other col 
	// would not work with the sprite system!
	//grabbing 1/3rd of drawing
	sketch_init( gridstr_scale( _sketch_3d___sketch_3d__INITIAL_BG_FILL_CHAR, 
		   inSketch_width, 
			inSketch_height) );
	
	cam_height = cam_height *100; //speeds thing up
	
	_sketch_3d_CORE_draw_cols_n_sprites( 
		origin_x, origin_y, angle, cam_height, cam_tilt,
		get_coltag_for_walls, get_coltag_for_sprites,
		inSketch_width, inSketch_height,
		dist_max,
		shadowgrid_or_null, shadowgrid_shadow_char, 
		shadowgrid_x, shadowgrid_y,
		MAX_WALLBRDER_DIST_default_6,
		fieldOfView_Default_pnt8,
		fade_start_precent_Default_pnt60);
	
	
	//////////////////////
	// SKYBOX
	////////////////
	//for looping around
	//*
	if(skygridstr_or_null != void null){
		angle = (angle * (fieldOfView_Default_pnt8/.8))
				// I set this up for default field of view
				// (.8), so going fractional
				% (Math.PI); // % Math.PI * 2;
		if( angle < 0){ angle += (Math.PI);}
		var skybox_full_circle = 
			//fieldOfView_Default_pnt8 
			.8* // not sure why,but it works.
			draw_canvas_get_width();
		
		var skybox_gridstr_HEIGHT = 
			txttools_getheight(skygridstr_or_null);
		// the *3.5 below is to draw it 3.5 times! ( so will scale 
		// 	around 3.5 views, so to speak. 
		skygridstr_or_null = _sketch_3d__skygrids_scale( skygridstr_or_null, 
			3.5* skybox_full_circle*Math.PI,
			fieldOfView_Default_pnt8);
			
		//	gridstr_scale_nearest_neighbor(
		//	skybox_gridstr, skybox_full_circle*Math.PI, 
		//	skybox_gridstr_HEIGHT);
		
		//left ORDER MATERS HERE! OTHERWISE, WILL NOT DRAW CORRECTLY
		// (because of 'draw over' not drawing over " ")
		sketch_grid_DRAW_UNDER_TRANSPCHAR(		
			skygridstr_or_null, 	
			//the +2 below... It's an offset... 
			// OK, OK, I'm not sure why that in particular works, but,
			// 	Yeah...
			0-(angle +Math.PI +2)
				*skybox_full_circle,
			cam_tilt - (skybox_gridstr_HEIGHT/2), 
			_sketch_3d_BLANK_TO_DRAW_CHAR);
	}
	//file_log(0-((angle +.5)*skybox_full_circle))
	// I added an extra top/bottom line before, now removing them
	sketch_replaceall(_sketch_3d_BLANK_TO_DRAW_CHAR, " ");
	var caught_sketch = 
		sketch_get().slice(inSketch_width+1,-(inSketch_width+1));
		//.replace( 
		//new RegExp(_sketch_3d_BLANK_TO_DRAW_CHAR, "g"), 
		//	" "); // ABOVE is replaceAll in old js. 
	sketch_end();

	return caught_sketch;
}
//
