// NAME FUNCTIONS IN JS FILES LIKE SO, OR THEY WON'T WORK!!!
importableFunctExample = function(){};

//
// TODO: make a 'data bundle' type of structure
// just take all the 'loaded' files in a 'load all' 
// file, bundle them up in a list, 
// and encrypt. 
//
// ALSO: load multiple: do it!
// IDEA: either run the 'js' file IF JS FORMAT
// OR save file to var (set as new line) if not
// ...
// actually, could have a simple interpreter:
// RUN or SAVE var_to_save_to
// as half the lines 


