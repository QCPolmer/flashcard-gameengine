// image  rotation:
// http://www.leptonica.org/rotation.html
// https://datagenetics.com/blog/august32013/index.html

//API_TAG//	
// this should be slower than full gridstr rotation.
// I THINK origin would be center... see 'offset' in _gridstr_rotate
// 	( gridstr.js)
// I think offest (which is originX/Y ) should be below:
//	   (NOTE: CHECK THE FUNCTION, may need to reduce 1 from len_x/y)
// 	if( len_x % 2.0 < 1.0){var x_off = (len_x)/2;
//	}else{ var x_off = (len_x-1)/2;}
//	if( len_y % 2.0 < 1.0){var y_off = (len_y)/2;
//	}else{ var y_off = (len_y-1)/2;}
// NOTE: UNTESTED!!! SHOULD work!!! THERE IS A C VERSION, ALSO UNTESTED
// 	IN sketch_lines.c!!!
function gridstr_rotate_point_X( originX, originY, x, y, degrees){
	var tmp_cos = .001*roundf(Math.cos(degrees)*1000); 
	var tmp_sin = .001*roundf(Math.sin(degrees)*1000);
	return originX+ Math.floor( (x-originX)*tmp_cos + 
			(y-originY)*tmp_sin);}
// NOTE: UNTESTED!!! SHOULD work!!!
function gridstr_rotate_point_Y( originX, originY, x, y, degrees){
	var tmp_cos = .001*roundf(Math.cos(degrees)*1000); 
	var tmp_sin = .001*roundf(Math.sin(degrees)*1000);
	return originY+ Math.floor( (-(x-originX)*tmp_sin) + 
			(y-originY)*tmp_cos);}
//API_TAG//	

//API_TAG//	
// us this on the base image/obj to move (translate), (to get dist
//  NOTE: I think these are untested, and I KNOW 
//  	that one was suppose to be X and wasn't...
function gridstr_rotation_ROTABLE_BORDER_X_OFFSET( getTxt_BEFORE_BORDER ){
	var max_diagonal = 4+ Math.floor(
		Math.sqrt(Math.pow(gridstr_width(getTxt_BEFORE_BORDER),2)+
		 	Math.pow(gridstr_height(getTxt_BEFORE_BORDER),2)));
	return  Math.floor(max_diagonal - 
		gridstr_width(getTxt_BEFORE_BORDER))/2; }
function gridstr_rotation_ROTABLE_BORDER_Y_OFFSET( getTxt_BEFORE_BORDER ){
	var max_diagonal = 4+ Math.floor(
		Math.sqrt(Math.pow(gridstr_width(getTxt_BEFORE_BORDER),2)+
			Math.pow(gridstr_height(getTxt_BEFORE_BORDER),2)));
	return Math.floor(max_diagonal - 
		gridstr_height(getTxt_BEFORE_BORDER))/2; }
//API_TAG//	

//API_TAG//	
// use above functions to account for offset.
// The reason for using this is otherwise, this WON'T 
function gridstr_rotation_MAKE_ROTATABLE_BORDER( getTxt, 
		OPTIONAL_traspchar){
//API_TAG//	
	if(OPTIONAL_traspchar == void null){ OPTIONAL_traspchar = " ";}
	var g_width = gridstr_width( getTxt);
	var g_height = gridstr_height( getTxt);
	// think it might be 1 px bigger
	var max_diagonal = 4+ Math.floor( 
		Math.sqrt(Math.pow(g_width,2)+
				Math.pow(g_height,2)));
	//file_input( max_diagonal + " "+ tmp_lines.length);
	//
	// gridstr_make gives 2 different values!!!
	//file_input( gridstr_make( max_diagonal, max_diagonal).length);
	//file_input( 
	//	g_width + " " + g_height + " " +
	//	"\n" + Math.floor(max_diagonal - g_width)/2
	//	+ " " + Math.floor(max_diagonal - g_height)/2 +" " +
	//	gridstr_height(
	//		gridstr_make( max_diagonal, max_diagonal)));
	
	//if( max_diagonal <=0 ){ max_diagonal=1;}
	return 	gridstr_overlay(
			gridstr_fill( 
			   gridstr_make( max_diagonal, max_diagonal),
			OPTIONAL_traspchar, ""), 
		  getTxt, 
		  Math.floor((max_diagonal - g_width)/2),
		  Math.floor((max_diagonal - g_height)/2)); 
}
//API_TAG//	
var _gridstr_rotation_catch = {};
// MOST ACCURATE IF USING:
// gridstr_rotation_MAKE_ROTATABLE_BORDER
// AND width & height are ODD numbers BEFOREHAND TRANSFORMING!!!
function gridstr_rotate( getTxt, getAngle,  transp_char, 
 	useCatch_n_round_to_number){ // useCatch  is optional, leave as 
					// null to not use
//API_TAG//	
	if(useCatch_n_round_to_number != void null){
		//simplifying angle to reduce catch load
		getAngle = getAngle % 2*Math.PI;
		if( getAngle < 1){ getAngle += 2*Math.PI;}
		getAngle = 
		   Math.floor(getAngle/useCatch_n_round_to_number)*
			useCatch_n_round_to_number;
		if(_gridstr_rotation_catch[getTxt+getAngle+transp_char] 
				!= undefined){
			return _gridstr_rotation_catch[
				getTxt+getAngle+transp_char];}
	}
	// actual rotation script
	var retTxtGrid= _gridstr_rotate( getTxt, getAngle, transp_char);
	//var retTxtGrid= _gridstr_rotate( getTxt, getAngle);

	if(useCatch_n_round_to_number != void null){ 
		_gridstr_rotation_catch[getTxt+getAngle+transp_char]
			= retTxtGrid;}
	return retTxtGrid
	
}



function gridstr_rotate_mirror_lines(getTxt){
	return gridstr_rotate_mirror_rows(
		gridstr_reverse_text( getTxt, getTxt.length));	}
function gridstr_rotate_mirror_rows( getTxt){
	return getTxt.split("\n").reverse().join("\n");	}

// this will rotate 
// https://stackoverflow.com/questions/42519/how-do-you-rotate-a-two-dimensional-array
// See later bits.
var _gridstr_rotate_90_degrees_CATCH= {};
//API_TAG//	
function gridstr_rotate_90_degrees(getTxt,getAngle, catch_OPTIONAL){	
// leave catch_OPTIONAL as void to not sure
//API_TAG//	

	getAngle = getAngle % (Math.PI*2);
	if(getAngle < 0){ getAngle += Math.PI*2;}

	var numb_rots = 0;
	if( getAngle < Math.PI/2){ numb_rots = 0;
	}else{ if( getAngle < Math.PI){ numb_rots = 1;
		}else{ if( getAngle < Math.PI*1.5){  numb_rots = 2;
			}else{ numb_rots = 3; } } }

	if(catch_OPTIONAL == true){
	  if(_gridstr_rotate_90_degrees_CATCH[ getTxt+ numb_rots]
	    == void null){ 
		_gridstr_rotate_90_degrees_CATCH[ getTxt+ numb_rots]
		  = _gridstr_rotate_90_degrees_CORE(getTxt, numb_rots); }
	  return _gridstr_rotate_90_degrees_CATCH[ getTxt+ numb_rots];
	
	}else{ return _gridstr_rotate_90_degrees_CORE(getTxt, numb_rots); }
}
function _gridstr_rotate_90_degrees_CORE(getTxt, get_numb_rots){
	// 0=0, 1=90, 2=180, 3=270
	var a = "12345678\n12345678\n12345678\nabcdefgh";
	//file_input(	_gridstr_transpose(a, a.length));

	if( get_numb_rots ==0 ){ 
		return getTxt; }
	
	
	//var out_str = [];
	//getTxt = getTxt.split("\n"); 
	if( get_numb_rots==1){  // 90 degrees
		//file_log(gridstr_transpose( 
		//	"0011--", getTxt.length));
		//reversing lines... now just need to transpose. 
		//return gridstr_mirror_lines( gridstr_transpose( getTxt));
		return gridstr_transpose( 
			gridstr_rotate_mirror_lines(getTxt), getTxt.length);
	
	}
	if( get_numb_rots==2){ // 180 degrees
		return gridstr_reverse_text(getTxt, getTxt.length);	}
	// 270 degrees
	//return gridstr_transpose( gridstr_mirror_lines(getTxt));
	return gridstr_rotate_mirror_lines( 
		gridstr_transpose( getTxt, getTxt.length));
	
}
