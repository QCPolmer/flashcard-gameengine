
////API_TAG//
////////////////////////////////
///// univ2d/BIGROOM- (specially formatted rooms of sub-rooms, really)
///////////////////////////
// ONLY load BIGROOMS and UNIV2D's through g_rmwarp()-
//	--these require the g_rmwarp_stack to be built, which g_rmwarp does
//		AND g_rmwarp resets the following, which is needed:
//	g_rmwarp_stack_getNset2NULL__justWarped
//
// univ2d/BIGROOM is used to MAKE ROOMS THAT SPAWN SUB-ROOMS IN A GRID!!! 
// 	(see below 'g_rmwarp_univ2d_example__rmAsTile1' 
// 		for sub-rooms example!)
// CONCEPT:
//  basically, instead of 'gluing' a bunch of rooms together,
//  draw the 'shape' of the world as a mml-grid, and run it with 
//  univ2d -OR- BIGROOM update behaviors on the room data containing it,
//	-- the data type is a special room type 
//		(see g_rmwarp_univ2d_n_BIGROOM__example below)
//  	-- 1 room generated per 'tile' 
//  	-- (higher magnitudes mean 'zooms into' sub-grids till 
//  		gets to smallest 1 room tile) 
//  	(it will make more sense looking at examples-data, see below:
//  		g_rmwarp_univ2d_n_BIGROOM__example)
///////////////////////
/// univ2d/BIGROOM - NOTE: WHAT IS univ2d
///////////////////
// A 'worldmap' that isn't loaded directly- it loads a sub room based
// 	on place on map (can use 'magnitude'(see below) to make giant maps) 
// 	Rooms, 
// 	--- exits entries (via g_rmwarp) are "left"/"down"/"up"/"right",
// 		(SAME ACROSS MAP)
// 		-- so if on tile x/y, going 'left' would move one tile
// 			over, and load it. 
// 	--- MOVING BETWEEN ROOMS ONCE SUB ROOM LOADED WITH THE FOLLOWING:
// 		g_rmwarp("G_PREV_ROOM", 
// 				"left/right/up/down"(dir2move on map));
// 		(NOTE: see g_rmwarp for jumping up multiple rooms 
// 			(going to room loaded prior too univ2d), as
// 			univ2d-room in the g_rmwarp_stack is above the 
// 			loaded subroom.
// 	-- g_rmwarp-ing to a non-previous room and returning will
// 		return to same spot as exit.(return warp via "G_PREV_ROOM") 
// 	--- can handle non-typical rooms/ etc- rooms can be different 
// 		shape/non standardized type. 
// 		(example shows how to auto- generate rooms with 
// 			auto-generated walk-over exits, 
// 			but could, in reality, be ANY type of room)
// 	--- can (MAYBE!) set tileX/Y on g_rmwarp_stack to 
// 		'warp' to a location in a univ2d, or handle it onEnter
// 			if a var is set (onEnter the univ2d/wrldmap)
// 	--- tracks locations of objs tagged with the following, 
// 		g_rmwarp.moveObjsBox.lazylinktag_player 
// 		EXAMPLE shows how to get to auto exit in direction
// 		of exiting room if crossing over sides of rooms
// 			(so rooms mostly build themselves) 
///////////////////////
/// univ2d/BIGROOM   NOTE: -WHAT IS bigroom
///////////////////
// same as univ2d, only tiles must be in standard size 
// 	(same height==width and same hight/width for ALL sub-rms)
// 	Loads a grid of rooms and scrolls loading during movement:
// 	basically seems like 1 continuous 'big' room,
// 	-- g_rmwarp-ing to a non-previous room and returning will
// 		return to same spot as exit.(return warp via "G_PREV_ROOM") 
// 	-- NOTE: BIGROOM does NOT run onUpdate injections, but does 
// 		run onEnter per-tile. 
//      -- FOR BIGRM, tiles MUST have height==width and per BIGROOM
//      	ALL tiles must have same height/width. 
//      (this simplifies a lot of stuff, see data on this & other examples)
// 	--- tracks locations of objs tagged with the following, 
// 		g_rmwarp.moveObjsBox.lazylinktag_player
// 		-- SCROLLS based on this location, unloads rooms 
// 		 and objs based on the location of this tagged obj.
// 			(so rooms mostly build themselves)   
///////////////////////
/// univ2d/BIGROOM - NOTE:  FOR SET PIECES (rooms that MUST not be progen):
///////////////////
//	------- BIG---- FOR IMPORTANT SET PIECES IN GIANT MAPS, 
//		------ (like city centers/important game locations...)
//		-- HAVE -ALL- magnitudes of maps HAVE ONLY 1 CHAR
//			(like a 2d map with 1 'x' char, marking the 'city')
//		      WITH THAT ICON: meaning it will only be spawned 1x!!!
//		-- (this is very limiting, but makes this easy to do)
//		-- So, like 1-9 as major cities, and sub tiles 1-9
//			ONLY have 1 of 1-9 on the corrisponding 1-9 tile!
//		(assuming a good 50-ish keys, if 20 of them are these
//			tiles, that's 20 major set-piece cities, can be
//			minor ones too)
///////////////////////
/// univ2d/BIGROOM - NOTE: Higher magnitude (making it BIG!)
///////////////////
//	------ max-magitude is in mmlmaps, and a list 
//		of gridstr2d's per character to draw from for 
//		higher magnitudes. The idea is it pulls and repulls
//		from higher magnitudes to 'zoom' in on a grid location,
//		so the original map will be size of map to power of 
//		magnitude. This works for univ2d and bigroom:
//		rooms can be very very large. 
///////////////////////
/// univ2d/BIGROOM - NOTE: These are by-default procedrual/semi-random
///////////////////
//	---- basically, a list of possible tiles is used for a series
//		of chars on the 2d gridstr. 
//	---- will draw from the list based on position on grid and 
//		a random seed (generates sub-seed based on location,
//			so location generations are repeatable)
//	---- using a single item in the list to draw from for one char
//		will force a single character drawing
/////////////////////////
// univ2d/BIGROOM-  NOTE- WALLS:
//////////////////
// NOTE: univ2d/BIGROOMs auto-make walls on sides of 
// 	roomtiles if the next char on 'worldmap' is "#"- 
// 		set specific char in (probably best to leave alone): 
// 		g_rmwarp_stack->enter_avoid_colgroup
// 		( I use the function that does this with
// 			as 'onEnter' for example below)

/////////////////////////
// univ2d/BIGROOM-  NOTE:  character starting point
//////////////////
//'start_pointChar' in 'mml_worldmap' marks the spot!
//	--- NOTE: for highest magnitude, drops in upper right 
//		hand corner-tile (meaning, looks at highest
//		magnitude FIRST, works way down, 
//			NOT RELEVENT FOR SMALL MAPS!)
//	(DROPS/PULLS via objs pulled via g_rmwarp 
//			OR 
//		the moveObjsBox in there, same mechanic,
//		g_rmwarp pulls some 'lazyloaded' tags automatically
//			into the moveObjsBox,
//		see the g_rmwarp.moveObjsBox.lazylinktag_player 
//			(and lazylinktag_warpWith)
//	--- drops happen at edges of rooms for BIGROOM/univ2d
//		below, but I think for univ2d it's based on set 
//		injected behavior: can just not drop the objs in room. 
//		( g_rmwarp_moveObjsBox_drop_objs does it AFTER
//			g_rmwarp_moveObjsBox_pull_objs_with_tag
//				or g_rmwarp)
//	--- so need to load player by putting in a root room
//		and g_rmwarping (probably can do on load), 
//		   or running the moveObjsBox-pull on a data pool.
//
/////////////////
//////////////////////////////
// ROOMS FOR THIS (BELOW) DONT -NEED- TO BE STRINGIFIED, BUT 
// 	IT'S CLEANER(generated cleanly) IF THEY ARE FOR BIGROOMS
// 	(for static rooms, just g_warping, it works.)
/////////////////////////
// univ2d/BIGROOM-  example data
//////////////////
var g_rmwarp_univ2d_n_BIGROOM__example = JSON.stringify(
{objs:[], objs_large:[], 
	// THIS DATA WORKS AS 2D UNIV -AND- GIANTROOM!
	//
	//uncomment ONE update_behavs below!
	//update_behavs:["g_rmwarp_univ2d_behav"], 
	update_behavs:["g_rmwarp_univ2d_behav_GIANTRM"],
	leave_behavs:[], room_type:"shadows_no_lights",

	mml_wrldMap_injectBehavs_to_subRooms__4_BIGROOMS_onEnter_ONLY:{ 
	   onEnter:{ //NOTE: will run per obj-creation IN bigroom... 
		ALL:[ "g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav" ],
		// 	NONE:"asdfa","c#@":[], ".-":[]  //UNTESTED
		// see--  _g_rmwarp_univ2d_bigrm_stack_GETMML_CHAR_behavs
		},
	   //onUpdate is per tile, NOT running in BIGRM, Universe2D ONLY
	   onUpdate:{ALL:[ 
		"g_rmwarp_sidewalls_rtrnUpOnCross_FOR_rmUpdate_behav"] 
		// 	NONE:"asdfa", "c#@":[], ".-":[] //UNTESTED
		// see--  _g_rmwarp_univ2d_bigrm_stack_GETMML_CHAR_behavs
		}, 
	   onLeave:{ }//see above for how to use for data, UNTESTED 
	   },
	mml_wrldMap:"g_rmwarp_univ2d__mml_wrldMap_dotNote_test"} 
	  //CAN BE ACTUAL STRUCT!!!, NOT JUST A DOT-NOTE REFERENCE!!!  
	);

var g_rmwarp_univ2d__mml_wrldMap_dotNote_test = { //can be pre-stringified 
		mml:
`###a###
##aaa##
aaa>aaa
##aaa##
###a###
###a###`, // can by any RECTANGLE size, BUT no trailing/leading newlines
		// OK, it's now ALL looping, have a 'border' if don't want
		// 	it to loop (a ring of uncrossable chars) 
		tilesizeXY_hiMag:3, tilesizeXY_at_mag0:20, 
		   //tilesizeXY_at_mag0 is needed by BIGROOMS,
		   //	(it's 'room-size')
		   //tilesizeXY_hiMag is for ANY higher magnitude
		   //	rmSizeXY in cmds-rooms is needed for Univ2d!
		max_magnitude:2, // i think 1 == 1-lvl-wrldmap magnitude?
		start_pointChar:">", start_pointDir:"down",
		cmds_hiMag:{//MUST==same height/width as tilesizeXY_at_mag0
a:[`aaa
aaa
aaa`],
// INITIAL ENTRY: 
// PLAYER IS DROPPED IN UPPER RIGHT HAND CORNER
// OF THIS BLOCK:
">":[
`aaa
aaa
aaa`],
"#": [ `###
###
###`],
		undefined:[""] //default, for out of bounds
			}, //global_dotnotation_string_names
			   // CAN POINT TO LISTS OF STRINGS!!!
			   // MUST BE SAME X/Y SIZE AS tilesizeXY_hiMag!!!
		cmds:{ // can be dotnote names! draws from 'list of rooms!'
		undefined:[""], // default
		a:["g_rmwarp_univ2d_example__rmAsTile1", 
			"g_rmwarp_univ2d_example__rmAsTile2"],
		">":["g_rmwarp_univ2d_example__rmAsTile1"],
		"-":["g_rmwarp_univ2d_example__rmAsTile1"],
		"#":["g_rmwarp_univ2d_example__rmAsTile1"]
		}};
////API_TAG//

//API_TAG//
/////////////////////////
// univ2d/BIGROOM-  tile examples 1 (sub rooms generated by univ2d/BIGROOM
//////////////////
//Example of tiles-rooms used for sub-rooms/sections of 
//	univ2d OR BIGROOM (same datat type, SEE ABOVE FOR FULL DATA)
var g_rmwarp_univ2d_example__rmAsTile1 = JSON.stringify({
objs:[
	//	lazylink:["linkylinky2","linkylinky", "lazylink_player"],
	//	p_mix:"mix_standard ppp.basic_behav"}
	], 
	objs_large:[
	{x:19, y:19, behavior:"b_none", lazylink:[],
graphic:`--------
---O----
--------`, 
	colgroup:"0", ignore_pause:false, 
		draw_1late_2last:0, dead:0, progen:null} 
		], //next params are optional!!!
	//below are needed for univ2d (rooms can be different sizes)behavs!
	//	(BIGROOM pulls from main BIGROOM tilesize) 
	rmSizeXY:20,
	wall_graphic:"#", //needed, or no walls-created /w 
				//g_rmwarp_univ2d_behav / 
				// g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav
	//enter_behavs:["g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav"],
	//update_behavs:[
	//	"g_rmwarp_sidewalls_rtrnUpOnCross_FOR_rmUpdate_behav"],
	leave_behavs:[], room_type:"_2d"});
///////////////////
// univ2d/BIGROOM-  tile examples 2
// ///////////
var g_rmwarp_univ2d_example__rmAsTile2 = JSON.stringify({objs:[
	//	lazylink:["linkylinky2","linkylinky", "lazylink_player"],
	//	p_mix:"mix_standard ppp.basic_behav"}
	], 
	objs_large:[
	{x:15, y:15, behavior:"b_none", lazylink:[],
graphic:`---x----
---O-O--
----x---`, 
	colgroup:"0", ignore_pause:false, 
		draw_1late_2last:0, dead:0, progen:null} 
		], //next params are optional!!!
	//below are needed for univ2d (rooms can be different sizes)behavs!
	//	(BIGROOM pulls from main BIGROOM tilesize) 
	rmSizeXY:20,
	wall_graphic:"#", //needed, or no walls-created /w 
				//g_rmwarp_univ2d_behav / 
				// g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav
	//walls should already be made in BIGROOM,
	// so SHOULD work with univ2d and BIGRM
	//enter_behavs:["g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav"],
	//update_behavs:[
	//	"g_rmwarp_sidewalls_rtrnUpOnCross_FOR_rmUpdate_behav"],
	leave_behavs:[], room_type:"_2d"});
//API_TAG//


//API_TAG//
///////////////////////////////////////
//////////////////////// univ2d/BIGROOOM behaviors 
//			(EXAMPLES OF ROOMS ABOVE!!!)
////				AND helper functs
//			(1st 4 functs are main ones!)
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//same rmdata-type as _g_rmwarp_univ2d_behav_n_GIANTRM/ 
//	g_rmwarp_univ2d_behav_GIANTRM
//	---- SEE EXAMPLE ROOM TO SEE HOW TO USE!!!---
//	---- AND DESCRIPTION!!! ------------
async function g_rmwarp_univ2d_behav( o){
//API_TAG//
//
//	//QUICKLINK _warp2genTileOnEnter_OPTIONAL

	//g_rmwarp("g_rmwarp_univ2d_example__rmAsTile1", "down",
	//	["g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav"],
	//	["g_rmwarp_sidewalls_rtrnUpOnCross_FOR_rmUpdate_behav"]);
	//return;
	
	if(rmloaded_room._warp2genTileOnEnter_OPTIONAL !=1){
		rmloaded_room._warp2genTileOnEnter_OPTIONAL = 1;}
	await _g_rmwarp_univ2d_behav_n_GIANTRM( o);}
//API_TAG//
//same rmdata-type as _g_rmwarp_univ2d_behav_n_GIANTRM/ 
//	g_rmwarp_behav_univ2ders
//	// OK, GIANTRM, should probably save ROOM as JSON.stringified,
// 	so GIANTRMS are generated every time.
// 	--- ALSO: runs 'enter_behavs' for generated tiles (if avaliable) 
// 		(if need some last-minute customization!) 
// --- ONLY onEnter works for SUB ROOMS in GIANT ROOM
//	---- SEE EXAMPLE ROOM TO SEE HOW TO USE!!!---
async function g_rmwarp_univ2d_behav_GIANTRM( o){
//	---- SEE EXAMPLE ROOM TO SEE HOW TO USE!!!---
//API_TAG//
	if(rmloaded_room._warp2genTileOnEnter_OPTIONAL ==1){
		rmloaded_room._warp2genTileOnEnter_OPTIONAL = 0;}
	await _g_rmwarp_univ2d_behav_n_GIANTRM( o);}

//API_TAG//
//... OK, this SHOULD GET exits ("left", "right", etc, 
//		all=["left","right","up","down"]
//	of room to EITHER prev_room (if it's a univ2derse) OR
//		IF BIGRM- around current loaded tile!
//		(assuming walls = stack.enter_avoid_colgroup)
//    ---- ONLY RUNS IF A PREVIOUS g_rmwarp-CALL LOADED A BIGROOM/UNIV2D---
function g_rmwarp_univ2d_grabRmLoaded_shape(){ 
			//retrn list: ["left","right","up","down"]
			// (LEFT RIGHT UP DOWN )(test for indexOf char
	//1st: if room has wrldMap, pulls from that (assumes BIGROOM)
	// else, will SET to GENERATED STACK, so will have 
	// PREVIOUS world-exit ROOM-SHAPE!!!
	// (basically, run this function, will get Univ/bigroom
	// 	shape, or prev-roomshape!!! :D
	//API_TAG//
	var curStack = g_rmwarp_stack_getCurStack();
	
	var tmpMmlWorldMap = rmloaded_room.mml_wrldMap;
	if(tmpMmlWorldMap != void null){ 
	  var retList= [];//["leftrightupdown" is exit ALL 4 directions!!!
	  var tmpXYC = [0,1,"down",  0,-1,"up", -1,0,"left", 1,0,"right"];
	  var tmpChar = "";
	  for(var i=0; i< tmpXYC.length; i+=3){
		tmpChar = g_rmwarp_univ2d_grabTile( 
		   tmpMmlWorldMap, 1,//min_magntude 
		   curStack, curStack.tileX+tmpXYC[i], 
		   curStack.tileY+tmpXYC[i+1], true,
			null, //OPTIONAL_ONLY_get_rmname_NOT_data,
			1  );//OPTIONAL_getCHAR_ON_MAP_ONLY
		if(g_rmwarp_stack.enter_avoid_colgroup != tmpChar){ 
			retList.push( tmpXYC[i+2]); } }
	  return retList;
	}else if(curStack._prev2UnivExitRmShape != void null){
	  return curStack._prev2UnivExitRmShape;
	}else{ return "";} // default exit!
}

//API_TAG//
// returns 'undefined' if not in list! 
// used for bigRooms OR 2d univ... can pull 2d string for 
// 	high-mag maps, or chars of tile, or rooms!
// ----use 'wrldMap' from univ2d/BIGROOM data, see above example data---
function g_rmwarp_univ2d_grabTile( getMml_wrldMap, get_min_magnitude, 
		curStack, getTileX, getTileY, OPTIONAL_looping_world,
		OPTIONAL_ONLY_get_rmname_NOT_data,
		OPTIONAL_getCHAR_ON_MAP_ONLY ){
  // mml_wrldMap(in univ2d structs): {cmds, cmds_hiMag(str), mml, 
  // 	max_magnitude, tilesizeXY_hiMag}
  // // cmds AND cmds_hiMag are BOTH dotnotation references to obj-pools!
  // 		(string pools for other)
  //curstack from g_rmwarp_stack_getCurStack()(typically, last stack pos)
  ////API_TAG//
	var cur_mml_4mag = getMml_wrldMap.mml;
	var cur_mag = getMml_wrldMap.max_magnitude;
	var tmpTileSizeXY = getMml_wrldMap.tilesizeXY_hiMag;
	var tmpTileX_offset =0;	//zzz need to throw out 
	var tmpTileY_offset =0; // 	space taken by each 'spin'
	var cur_mag_TileSize = 0;

	if(OPTIONAL_looping_world == true){
		getTileX = _g_rmwarp_univ2d_loop_adjusted_x_or_y_n_tiles(
			getTileX, "x", getMml_wrldMap );
		getTileY = _g_rmwarp_univ2d_loop_adjusted_x_or_y_n_tiles(
			getTileY, "y", getMml_wrldMap );}
	
	var tmpRm_Name_or_mml = "";
	var tmpRmList = [];
	
	while(get_min_magnitude <= cur_mag){
	  cur_mag_TileSize = Math.pow( tmpTileSizeXY, cur_mag-1);
	  var tmpMag_mml_X = Math.floor((getTileX-tmpTileX_offset)/ 
					cur_mag_TileSize);
	  var tmpMag_mml_Y = Math.floor((getTileY-tmpTileY_offset)/ 
					cur_mag_TileSize);
	  
	  tmpTileX_offset += tmpMag_mml_X * cur_mag_TileSize;
	  tmpTileY_offset += tmpMag_mml_Y * cur_mag_TileSize;	

	  progen_seed_init( curStack._seed );
	  var tmpSeed =_g_warp_gen_seed(curStack._seed, gRandom_seed, 
		curStack._rmName, tmpMag_mml_X, tmpMag_mml_Y, cur_mag); 
	 
 	  progen_seed_end(); 
	  
	  var curMagTileChar = gridstr_char_get( cur_mml_4mag, 
			tmpMag_mml_X, tmpMag_mml_Y, 0);
	  //pulling actual gridstr/room
	  if(cur_mag > 1){ //gets from 'gridsr' pool (cmds_hiMag)
	       tmpRmList = getMml_wrldMap.cmds_hiMag[ curMagTileChar];
	  }else{ //gets from 'rms' pool (cmd)
	       tmpRmList = getMml_wrldMap.cmds[ curMagTileChar];
	  }
	  progen_seed_init( tmpSeed );
	  
	  if(tmpRmList != void null){ 
	  	tmpRm_Name_or_mml = tmpRmList[ 
			  progen_d_roll(tmpRmList.length-1)];	
	  }else{ //early termination, if found char NOT in mml!
		progen_seed_end(); 
		cur_mml_4mag = null;
		if(get_min_magnitude != cur_mag){
			curMagTileChar= null; tmpRm_Name_or_mml = null;  }
		get_min_magnitude = cur_mag +1; //breaks list!
		continue;
	  }
	
	  if(cur_mag > 1){ //tmpRm_Name_or_mml == gridstr at higher mags
  	    cur_mml_4mag =tmpRm_Name_or_mml;  
	  }else{ // at bottom, WILL be a room...
	    cur_mml_4mag = progen_dotnote(tmpRm_Name_or_mml,
		null, true); //draw random from end-point-list
	  }
	  progen_seed_end(); 
	  
	  cur_mag-=1;
	}
	if(OPTIONAL_getCHAR_ON_MAP_ONLY ==1 ){
		return curMagTileChar; }
	if(OPTIONAL_ONLY_get_rmname_NOT_data == 1){
		return tmpRm_Name_or_mml; }
	return cur_mml_4mag; 
}
function _g_rmwarp_univ2d_loop_adjusted_x_or_y_n_tiles(
		getX_or_Y_val, getStrXorY, getMml_wrldMap ){
	var curStack = g_rmwarp_stack_getCurStack();
	if(getStrXorY == "y"){
		var map_height_or_width_n_tiles = 
			curStack.mml_main_hiMag_height_n_tiles;
	}else{ var map_height_or_width_n_tiles = 
			curStack.mml_main_hiMag_width_n_tiles;}
	
	while(getX_or_Y_val < 0){ 
		getX_or_Y_val += map_height_or_width_n_tiles; }
	while(getX_or_Y_val >= map_height_or_width_n_tiles ){
		getX_or_Y_val -= map_height_or_width_n_tiles;}
	return getX_or_Y_val;
}
// -- USE ABOVE FUNCT-WRAPPERS FOR THIS!!!
// --- ONLY onEnter works for SUB ROOMS in GIANT ROOM
async function _g_rmwarp_univ2d_behav_n_GIANTRM( o){ //o is 'room'
//{tileX:0, tileY:0, x:0, y:0, _seed:1,_rmName:"", _dir_leftFrom:""}
	var curStack = g_rmwarp_stack_getCurStack();
	var tmpJWarped = g_rmwarp_stack_getNset2NULL__justWarped();

	var tmpMmlWorldMap = rmloaded_room.mml_wrldMap;
	var tmpTileSizeXY_hiMag = tmpMmlWorldMap.tilesizeXY_hiMag;
	var tmpMaxMag = tmpMmlWorldMap.max_magnitude;
	var tmpMag0Tilesize = tmpMmlWorldMap.tilesizeXY_at_mag0;
	
	// CURRETNLY jumps to corner of tile for start! (for BIGRM)
	if(tmpJWarped != void null){
	 curStack.mml_main_hiMag_height_n_tiles = 
		Math.pow(tmpMmlWorldMap.tilesizeXY_hiMag, tmpMaxMag-1)*
			 gridstr_height(tmpMmlWorldMap.mml);
	 curStack.mml_main_hiMag_width_n_tiles = 
		Math.pow(tmpMmlWorldMap.tilesizeXY_hiMag, tmpMaxMag-1)*
			 gridstr_width(tmpMmlWorldMap.mml); 
	 if(0 == tmpJWarped.direction_or_custCmd.indexOf("JUMP_TO_CHAR")){
		var tmpDir = tmpJWarped.split(".")[1];
		var tmpChar = tmpJWarped.split(".")[2];
		
		tmpJWarped.direction_or_custCmd = tmpDir;
		var tmpXY = gridstr_indexOf_char_getXY(
			tmpMmlWorldMap.mml, tmpChar);
		curStack.tileX = tmpXY.x*
		 (Math.pow(tmpMmlWorldMap.tilesizeXY_hiMag, tmpMaxMag-1 ));
		curStack.tileY = tmpXY.y*
		 (Math.pow(tmpMmlWorldMap.tilesizeXY_hiMag, tmpMaxMag-1 ));
	 }else if( tmpJWarped.rtrnFromLower ==false){
 	 //       // CURRETNLY jumps to corner of tile for start!
		var gotXY = gridstr_indexOf_char_getXY( 
			tmpMmlWorldMap.mml, 
			tmpMmlWorldMap.start_pointChar);
		curStack.tileX = gotXY[0]*
		 Math.pow(tmpMmlWorldMap.tilesizeXY_hiMag, tmpMaxMag-1 );  
		curStack.tileY= gotXY[1]*
		 Math.pow(tmpMmlWorldMap.tilesizeXY_hiMag, tmpMaxMag-1 );  
		
		tmpJWarped.direction_or_custCmd=
			 tmpMmlWorldMap.start_pointDir;
			
	 }
	/////////////////////////////
	// universe (the room acts as an 'outliner') code starts HERE:
	 if( rmloaded_room._warp2genTileOnEnter_OPTIONAL == true){
		var tmpDir = tmpJWarped.direction_or_custCmd;
		if(tmpJWarped.rtrnFromLower ==true){ //MODDED 1/27/2026
			if(tmpDir =="left"){ curStack.tileX -=1;
			}else if(tmpDir =="right"){ curStack.tileX +=1;
			}else if(tmpDir =="up"){ curStack.tileY -=1;
			}else if(tmpDir =="down"){ curStack.tileY +=1; } }
		//looping
		curStack.tileX = 
		 _g_rmwarp_univ2d_loop_adjusted_x_or_y_n_tiles(
			curStack.tileX, "x", tmpMmlWorldMap );
		curStack.tileY = 
		  _g_rmwarp_univ2d_loop_adjusted_x_or_y_n_tiles(
			curStack.tileY, "y", tmpMmlWorldMap );
		
		//a random draw for room...
		var tmpRmName = g_rmwarp_univ2d_grabTile( 
			tmpMmlWorldMap, 1, //min magnitude, 0=rms!
			curStack, curStack.tileX, curStack.tileY,
			1, 1 );
		var tmpChar = g_rmwarp_univ2d_grabTile( 
			tmpMmlWorldMap, 1, //min magnitude, 0=rms!
			curStack, curStack.tileX, curStack.tileY,
			1, 0, 1);
		
		var tmpRoom2 = g_rmwarp( tmpRmName, tmpDir,
		  _g_rmwarp_univ2d_bigrm_stack_GETMML_CHAR_behavs(
	 	     rmloaded_room, tmpChar, 1), //1 == getOnEnter
		  _g_rmwarp_univ2d_bigrm_stack_GETMML_CHAR_behavs(
	 	     rmloaded_room, tmpChar, 0), //0 == getOnUpdate
		  _g_rmwarp_univ2d_bigrm_stack_GETMML_CHAR_behavs(
	 	     rmloaded_room, tmpChar, 2) //2 == getOnLeave
			);
		//added 3/17/2026 level_editor_loader__room_on_enter_behav
		tmpRoom2._level_editor_loader__room_on_enter_SEED =
			_g_warp_gen_seed(curStack._seed, 
				gRandom_seed, tmpRmName, curStack.tileX, 
				curStack.tileY, 0);
		
		return; 	
	 }
	/////////////////////////////////
	/// universe specific code ENDS here
	//  (ONLY runs on '_justWarped',sends 2 another room at that point!
	
	///////////////////////////////
	// Just warped in, for BIGRM (STILL IN JUSTWARPED-BLOCK!!!)
	 //full update, to catch positions of above!
	  rmloaded_search_lazylink_update( true );
	 
	///////////////////////////////////
	//setting init player position:
	 if(tmpJWarped.rtrnFromLower == true ){// return from prev rm
		// k, just pull from stack, I guess
		g_rmwarp_moveObjsBox_drop_objs( 
          		curStack.x, curStack.y,
			curStack._dir_leftFrom,  
			g_rmwarp_stack.enter_avoid_colgroup,
			1,1 ); //reverse_direction,don'tOffsetBy1(off)
		rmloaded_search_lazylink_update( true );
	 }else{ //init enter room
	   //trying to mimic entry points similar to univ2d...
	   var tmp_offset_x = Math.floor(tmpMag0Tilesize *0.5); 
	   var tmp_offset_y = Math.floor(tmpMag0Tilesize *0.5);
	   var tmpDir2= tmpMmlWorldMap.start_pointDir;
	   if(tmpDir2 == "left"){ tmp_offset_x =  tmpMag0Tilesize ;} 
	   if(tmpDir2 == "right"){ tmp_offset_x =0;} 
	   if(tmpDir2 == "up"){ tmp_offset_y =  tmpMag0Tilesize ;} 
	   if(tmpDir2 == "down"){ tmp_offset_y =0;} 

	   g_rmwarp_moveObjsBox_drop_objs( 
		tmpMag0Tilesize * curStack.tileX + tmp_offset_x, 
          	tmpMag0Tilesize * curStack.tileY + tmp_offset_y, 
		tmpJWarped.direction_or_custCmd,  
		g_rmwarp_stack.enter_avoid_colgroup );
	   rmloaded_search_lazylink_update(true);
	 }
	}
	//////////////////////////////////////
	// BIGMAP specific UPDATE code starts HERE (above for ENTERRM)
	// 
	var tmpPlayer = rmloaded_search_lazylink[
		g_rmwarp_stack.moveObjsBox.lazylinktag_player][0];
	
	if(tmpJWarped == void null){
		// reclaculate borders! (in tiles)
		// (should rename tX tY? so shows in tiles?)
		var tX = Math.floor(tmpPlayer.x/ tmpMag0Tilesize );  
		var tY = Math.floor(tmpPlayer.y/ tmpMag0Tilesize ); 
		curStack.tileX = tX;
		curStack.tileY = tY;
		//////////////////////////////////////
		/// TRYING loop room around here
		//////////////////////
		
		// checking MAIN tile(center), moving map if over
		if(tX < 0 || tY < 0 
		   || tX > curStack.mml_main_hiMag_width_n_tiles
		   || tY > curStack.mml_main_hiMag_height_n_tiles){
			//move ALL objects in room by this!!!
		   var tmpX_prime =0;
		   var tmpY_prime =0; 
		   
		   //moving objs in room (for looping map!)	
		   var tmpX_move_obs_by =  
			(_g_rmwarp_univ2d_loop_adjusted_x_or_y_n_tiles(
				tX, "x", tmpMmlWorldMap )
			- tX ) * tmpMag0Tilesize;
		   var tmpY_move_obs_by = 
			(_g_rmwarp_univ2d_loop_adjusted_x_or_y_n_tiles(
				tY, "y", tmpMmlWorldMap )
			- tY ) * tmpMag0Tilesize;
		   
		   var t_o = rmloaded_room.objs;
		   for(var i=0; i< t_o.length; i+=1){
	   	    t_o.x += tmpX_move_obs_by;t_o.y += tmpY_move_obs_by;}
		   var t_o = rmloaded_room.objs_large;
		   for(var i=0; i< t_o.length; i+=1){
	   	    t_o.x += tmpX_move_obs_by;t_o.y += tmpY_move_obs_by;}
		   // player x/y should be recalculated at this point.
		   var tX = Math.floor(tmpPlayer.x/ tmpMag0Tilesize );  
		   var tY = Math.floor(tmpPlayer.y/ tmpMag0Tilesize ); 
		}
		
		/////////////////////////////
		// checking 3x3 grid, to see if over edge of screen!
		var tmpNEWTilesXY_3x3_keyLoopedMll_valueNonLooped={};
		var tmpKey=""; var tmpVal = ""; 
		var tmpTileX=0; var tmTileY=0;
		for(var i_x=-1; i_x <= 1; i_x+=1){
		 for(var i_y=-1; i_y <= 1; i_y+=1){
			tmpTileX =
			 _g_rmwarp_univ2d_loop_adjusted_x_or_y_n_tiles(
				(tX +i_x), "x", tmpMmlWorldMap );
			tmpTileY =
			 _g_rmwarp_univ2d_loop_adjusted_x_or_y_n_tiles(
				(tY + i_y), "y", tmpMmlWorldMap );
			
			tmpNEWTilesXY_3x3_keyLoopedMll_valueNonLooped[
			   tmpTileX + "_" + tmpTileY] =
				(tX +i_x) + "_"+ (tY + i_y);
		} }
		// end world looping SPECIFIC cmds!!!
		////////////////
		//////////////////////////////////
		//	tilesXY_last_3x3 == last
		//	 tmpNEWTilesXY_3x3_keyLoopedMll_valueNonLooped
		if(tmpMmlWorldMap['tilesXY_last_3x3']!= void null){
		  var tmp_last_3x3_keys = 
		    Object.keys( tmpMmlWorldMap.tilesXY_last_3x3);
		}else{ var tmp_last_3x3_keys = [];}
		var tmpNew3x3_keys = Object.keys(
			tmpNEWTilesXY_3x3_keyLoopedMll_valueNonLooped);
		for( var i=0; i< tmpNew3x3_keys.length; i+=1){
		  if( tmp_last_3x3_keys.indexOf(tmpNew3x3_keys[i]) == -1){
				//generate tile
			  var tmpXY_in_rm = 
			   tmpNEWTilesXY_3x3_keyLoopedMll_valueNonLooped[
				tmpNew3x3_keys[i]].split("_");
			  var tmpXY_on_mml = 
			    tmpNew3x3_keys[i].split("_");
			  tmpXY_on_mml[0] = parseInt(tmpXY_on_mml[0]);
			  tmpXY_on_mml[1] = parseInt(tmpXY_on_mml[1]);
			 
			  var tmp_off_X_in_rm = 
			   parseInt(tmpXY_in_rm[0])* tmpMag0Tilesize;
			  var tmp_off_Y_in_rm = 
			    parseInt(tmpXY_in_rm[1])* tmpMag0Tilesize;
			  
			  var tmpRmName = g_rmwarp_univ2d_grabTile( 
			   tmpMmlWorldMap, 1, //min magnitude, 0=rms!
			   curStack, tmpXY_on_mml[0], tmpXY_on_mml[1],
			   1, 1 );//looping, (OFF)getrmname,getchar
			
			   //catching generating, and re-establishing catch
			   var catchTileX = curStack.tileX;
			   var catchTileY = curStack.tileY;
			  		  
			var tmpChar = g_rmwarp_univ2d_grabTile( 
			  tmpMmlWorldMap, 1, //min magnitude, 0=rms!
			  curStack, curStack.tileX, curStack.tileY,
			  1, 0, 1);

			var tmpRm = g_rmwarp( tmpRmName, 
			  "down",//random, ID think needed here
			  _g_rmwarp_univ2d_bigrm_stack_GETMML_CHAR_behavs(
	 	   	       rmloaded_room, tmpChar, 1),  
			  null, null, //update/leave behavs to add
			  null, 1, // no progen (done next!) 
			  null, null, null, null,
			  true);
			 
			   //above breaks linkage, reestablishing it!
			   curStack = g_rmwarp_stack_getCurStack();
			  
			   curStack.tileX = parseInt(tmpXY_on_mml[0]);
			   curStack.tileY = parseInt(tmpXY_on_mml[1]);
			   
			  var tmpSeed2 = _g_warp_gen_seed(curStack._seed, 
				gRandom_seed, tmpRmName, curStack.tileX, 
				curStack.tileY, 0)
			  //OPTIONAL_rtrn_rm_ONLY_no_load_or_stackupdate )
			  progen_seed_init( tmpSeed2);
				//curStack.tileX/Y are TEMPORARY,
				// the actual ones are caught/restored!!!
			 //added 3/17/2026 
			//	level_editor_loader__room_on_enter_behav
			tmpRm._level_editor_loader__room_on_enter_SEED =
				tmpSeed2;
			  
			  //running ENTERRM behaviors
			  if(tmpRm['enter_behavs'] != void null){
			   for(var j=0; j<tmpRm.enter_behavs.length;j+=1){
			     await rmloaded_b_globalThis[
				tmpRm.enter_behavs[j]](tmpRm); } }
			 //dropping objs in room  
			progen_obj_room(tmpRm, 0, 
			   void null, rmloaded_room, void null,
			   //noprogen_just_add_OPTIONAL,
			   tmp_off_X_in_rm, tmp_off_Y_in_rm );
			  
			  progen_seed_end();
			  curStack.tileX = catchTileX;
			  curStack.tileY= catchTileY;
		}	}
		tmpMmlWorldMap.tilesXY_last_3x3 = 
			tmpNEWTilesXY_3x3_keyLoopedMll_valueNonLooped;
		
		 ///////////////////////////////////////
		 // SETTING UP BORDERS (3 tiles width, start at tile 0)
		 // 	setting tight borders (*0.25 1 tile width!)
		 /////////////
		
	}
	
	curStack.x= tmpPlayer.x;  curStack.y = tmpPlayer.y;
	var tmpB = tmpMmlWorldMap._3x3_del_outside_grid_bounds;	
	
	curStack.tileX = 
	   Math.floor(tmpPlayer.x/tmpMag0Tilesize);
	curStack.tileY = 
	   Math.floor(tmpPlayer.y/tmpMag0Tilesize);

	rmloaded_delbox_lazy_del_out_bound_chars( rmloaded_room, 
	   -1+((curStack.tileX-1) *tmpMag0Tilesize),
	   -1+((curStack.tileY-1) *tmpMag0Tilesize),
	   1+((curStack.tileX+2) *tmpMag0Tilesize),
	   1+((curStack.tileY+2) *tmpMag0Tilesize),
		gConf.BIGRM_leave_bounds_ignore_colgroup );
	
}
//////////////////////////
//This function pulls rm_behavs per univ2d/bigroom
function _g_rmwarp_univ2d_bigrm_stack_GETMML_CHAR_behavs( //returns list
	 getRm_univ_or_bigroom, getSubroom_char, 
		getOnEnter_1_onUpdate_0_onLeave_2){
	//NOTE: USE of "NONE":"letters to give plank list if present"
	//	AND per-character item returns are UNTESTED!!!

	var tmpOutList = [];
	
	tmpData = getRm_univ_or_bigroom[
	  "mml_wrldMap_injectBehavs_to_subRooms__4_BIGROOMS_onEnter_ONLY"];
	if( tmpData == void null){return [];}
	
	if(getOnEnter_1_onUpdate_0_onLeave_2==1){ 
		tmpData = tmpData["onEnter"];
	}else{ if(getOnEnter_1_onUpdate_0_onLeave_2 ==2){
		 tmpData = tmpData["onLeave"];
		}else{ tmpData = tmpData["onUpdate"]; } }
	if( tmpData == void null){return [];}

	var tmp_none = tmpData["NONE"];
	if(tmp_none != void null &&-1 != tmp_none.indexOf(getSubroom_char)
		){ return []; }
	
	var tmpData = JSON.parse( JSON.stringify(tmpData));
	
	if(tmpData["ALL"] != void null){
		tmpOutList = tmpData["ALL"].concat(); }
	delete tmpData["ALL"]; delete tmpData["NONE"];

	var tmpKeys = Object.keys(tmpData);
	for(var i=0; i<tmpKeys.length; i+=1){
	   if(-1 != tmpKeys[i].indexOf(getSubroom_char) ){
		tmpOutList = tmpOutList.concat( tmpData.tmpKeys[i]); } }
	return tmpOutList; 
}
	
