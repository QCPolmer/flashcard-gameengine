file_check_loaded("rmloaded.js");

//API_TAG//
// behaviors are pulled from global-namespace via string, 
// 	typically, they start with b_, but this works 
async function behav_controller_basic_gridmove(o){
//API_TAG//
	var c_isdown = controllers[0].isdown;
	if( c_isdown["DOWN_RIGHT"]){
		if(rmloaded_col_test_SIMPLE(o.x+1, o.y+1,"0")==""){
			o.x+=1; o.y+=1;  } return;}
	if( c_isdown["DOWN_LEFT"]){
		if(rmloaded_col_test_SIMPLE(o.x-1, o.y+1,"0")==""){
			o.x-=1; o.y+=1;  } return;}
	if( c_isdown["UP_RIGHT"]){
		if(rmloaded_col_test_SIMPLE(o.x+1, o.y-1,"0")==""){
			o.x+=1; o.y-=1;  } return;}
	if( c_isdown["UP_LEFT"]){
		if(rmloaded_col_test_SIMPLE(o.x-1, o.y-1,"0")==""){
			o.x-=1; o.y-=1;  } return;}

	if(c_isdown["RIGHT"] && c_isdown["UP"]){
		if(rmloaded_col_test_SIMPLE(o.x+1, o.y-1,"0")==""){
			o.x+=1; o.y-=1;  }return;}
	if(c_isdown["LEFT"] && c_isdown["UP"]){
		if(rmloaded_col_test_SIMPLE(o.x-1, o.y-1,"0")==""){
			o.x-=1; o.y-=1;  }return;}
	if(c_isdown["RIGHT"] && c_isdown["DOWN"]){
		if(rmloaded_col_test_SIMPLE(o.x+1, o.y+1,"0")==""){
			o.x+=1; o.y+=1;  } return;}
	if(c_isdown["LEFT"] && c_isdown["DOWN"]){
		if(rmloaded_col_test_SIMPLE(o.x-1, o.y+1,"0")==""){
			o.x-=1; o.y+=1;  } return;}

	if(c_isdown["RIGHT"] && 
		rmloaded_col_test_SIMPLE(o.x+1, o.y,"0")==""){ o.x+=1; }
	if(c_isdown["LEFT"] && 
		rmloaded_col_test_SIMPLE(o.x-1, o.y,"0")==""){ o.x-=1; }
	if(c_isdown["DOWN"] && 
		rmloaded_col_test_SIMPLE(o.x, o.y+1,"0")==""){ o.y+=1; }
	if(c_isdown["UP"] && 
		rmloaded_col_test_SIMPLE(o.x, o.y-1,"0")==""){ o.y-=1; }
}


async function _behave_controller_3d_move_MOVE_FORWARD(
		o, getAngle, move_speed){
	var dx = Math.cos(getAngle) * move_speed;
  	var dy = Math.sin(getAngle) * move_speed;
  	if (rmloaded_col_test_SIMPLE(o.x + dx, o.y, "0") == ""){ o.x += dx;}
  	if (rmloaded_col_test_SIMPLE(o.x, o.y + dy, "0") == ""){ o.y += dy;}
}
//API_TAG//
// behaviors are pulled from global-namespace via string, 
// 	typically, they start with b_, but this works 
async function behav_controller_3d_move(o){
// for movement EXAMPLE in 3d. NOTE: 
	// collision detection does NOT work in 3d, 
	// need to set that up (probably per object) 
	// (the Raycast3d_C_version is an example)
// use: rmloaded_camera_3d_set(x,y, z, rot, tilt ) to set camera!!!
	var move_speed =0.2;
	//tmpAngle;  the player angle, defined in 3d-thing
	// as it's currently a place-holder-var, will need to replace
	var c_isdown = controllers[0].isdown;
	if( c_isdown["DOWN_RIGHT"]){return;}
	if( c_isdown["DOWN_LEFT"]){  return;}
	if( c_isdown["UP_RIGHT"]){ // key codes are for 'strife left'
		_behave_controller_3d_move_MOVE_FORWARD(
			o, tmpAngle + (Math.PI/2), move_speed);
		 return;}
	if( c_isdown["UP_LEFT"]){ // this signifies 'strife right'
		_behave_controller_3d_move_MOVE_FORWARD(
			o, tmpAngle + (Math.PI/2), -move_speed);
		return;}

	if(c_isdown["RIGHT"]){ tmpAngle +=.05;}
	if(c_isdown["LEFT"]){ tmpAngle -=.05; }
	//if(controllers[0].pressed[0] == "DOWN"){  tmpAngle -= Math.PI;}
	if(c_isdown["DOWN"]){  
		_behave_controller_3d_move_MOVE_FORWARD(
		o, tmpAngle, -move_speed);  }
	if(c_isdown["UP"] ){  _behave_controller_3d_move_MOVE_FORWARD(
		o, tmpAngle, move_speed); }
}
//API_TAG//

