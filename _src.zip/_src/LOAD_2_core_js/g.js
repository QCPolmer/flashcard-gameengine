//API_TAG//  	
//This is 'game-library' (g), or 'glue'
//	NOTE: "lazylink_player" is current pull-method of 'player'/s
//		-- USE LAZYLINK to handle fetching player 
//			(it's fast, and allows parse/stringify)
// putting a easy-access way to use many low level systems, 
// 	(like files/saving/world maps, etc)
// and tie stuff together+ 'glue' systems together.
//
// MANY VARS WILL AUTO-SAVE WITH gFiles(as in savefiles)
// 	FUNCTIONS (see those)
// 


//API_TAG//
//
//
//
//API_TAG//
////////////////////////////////////////////
/////////COPY BELOW VARS TO GAME AND EDIT THERE!!! (ones used in game!)
/////////	EDIT: in 'autoload' files in game directories now!
/////////	
/////////// ( are all saved to savefile,
////////////	gConf remains the same across ALL save files!!!)
/////////////////////////////////////////
var gVars2saveGame = ["_gFiles", "gConf", "_gFileNumberLoaded"];
var gVars2saveFile = [  "gFile_vars",
		"gSaved_rooms", "g_rmwarp_stack", "_rogue_player_running" ];
var gVars2NOTsaveFile = ["rmloaded_b_globalThis",
	"_rmloaded_search_struct__BASE","_rmloaded_search_struct",
	"_rmloaded_search_lazylink_struct", "rmloaded_search_lazylink"]; 
var gConf = { saveMenu:"menu_test_o__saveMenu",  
		menu:"menu_test_o__saveMenu", //MUST be LIST BASED?
 		textMmlGui://"", 
		    "menu_test_o__disp_text", 
		txtMmlGui_menu:"menu_test_o__saveMenu",
		
		txtMmlGui_hide_roll_numbers:false,
		txtMmlGui_stnd_roll_max:99,
		
		BIGRM_leave_bounds_ignore_colgroup:'?',
		player_wall_colgroup:"0" // "#"
	 }; // global configs (stay same across save files)
var gFile_vars = {}; // saves to save-file
var gSaved_rooms = {}; // I guess test 4/pull with room functions?

var gRandom_seed = 0; // used for room generation, randomize on startup!

var gPlayer_lazylink_FOR_WARP_OR_WHATEVER_EXAMPLE =
	{lazylink:["lazylink_player"]}; 
	// "lazylink_player" is standard, can be changed in g_rmwarp!

////////////////////////////////////////
//////////////////////////////////////////
///////////////////////////////////////////

var gGlobalThis = this;
//API_TAG//
//

var _gFiles = [];
var _gFiles_restored_from_file_this_startup = 0;
var _gFiles__quicksave_index = 20;
var _gFileNumberLoaded = -1; // recorded on LOAD or LAST SAVE


//API_TAG//
async function gMenu(getDescript, getCmdsList){ //API_TAG//
  return await gui_menu_blocking( getDescript, gConf.menu, getCmdsList
		//getHints_text_on_toggle_OPTIONAL,bg_OPTIONAL
		); }


//gLink2obj links a global var to object (can redefine on the fly):
//		gVAR[0].o = o && o.gVAR = gVAR[0]
//	SHOULD BE RUN -EVERY- FRAME TO ENSURE LINKAGE!!!
//	(multiple objs refencing 1 global is OK, but no gVar.o won't work)
//API_TAG//
function gLink2obj(getObj, getglobalList_var_name, getlistItemNumber){
//API_TAG//
	var tmpVar=gGlobalThis[getglobalList_var_name][getlistItemNumber];
	getObj[getglobalList_var_name] = tmpVar;
	tmpVar.o = getObj;
	return tmpVar;
}



	
//API_TAG//
// This runs upon trying to load/save first time, too. 
async function gFiles_backup2File_Load( bool_htmlVers_load_from_file ){
//API_TAG//
	if(gGlobalThis["document"]==void null){ // c version, html has it
	   var tmpStrJSON= await file_load(file_js_cd(), "saves.backup");
	}else{ //html version
	   //load to something like a 'cookie'
	   var tmpStrJSON= localStorage.getItem('gFiles_backup2File');
	   if(bool_htmlVers_load_from_file){
		  var tmpStrJSON= await file_load(
				file_js_cd(),"saves.backup");}}
	if( tmpStrJSON != null){ rmloaded_saveState_load(tmpStrJSON);}
}
//API_TAG//
async function gFiles_backup2File( bool_htmlVers_save_2_file ){ 
//API_TAG//
	var tmpSave = rmloaded_saveState( 1, [], gVars2saveGame);
	if(gGlobalThis["document"]==void null){ // c version, html has it
		await file_save( file_js_cd(), "saves.backup", tmpSave);
	}else{ //html version
		//save to something like a 'cookie'
		localStorage.setItem('gFiles_backup2File', tmpSave);
		if(bool_htmlVers_save_2_file){
		  await file_save(file_js_cd(),"saves.backup", tmpSave);}
	}
} 


//API_TAG//
// Menu config is gConf.saveMenu
//  WARNING: may break rmloaded_searches still running (~ a few frames)
//  	so be careful running during search-heavy stuff.
async function gFiles_savePrevSave(){ //prev save OR loaded gFile!!!
  await _gFiles_saveLoad( "save", 0, _gFileNumberLoaded);}
async function gFiles_loadPrevSave(){ //prev save OR loaded gFile!!!
  await _gFiles_saveLoad( "load", 0, _gFileNumberLoaded);} 

// this does NOT save gFile vars, so shouldn't effect 'lives',etc.
function gFiles_saveRmloadedOnly(){ //returns the 'room-loaded' data
	return rmloaded_saveState( 0, gVars2NOTsaveFile); }
function gFiles_loadRmloadedOnly( getData_gFiles_saveRmloadedOnly){  
	rmloaded_saveState_load( getData_gFiles_saveRmloadedOnly); }

async function gFiles_quickSave(){ 
	await _gFiles_saveLoad( "save", 0, _gFiles__quicksave_index); }
async function gFiles_quickLoad(){
	await _gFiles_saveLoad( "load", 0, _gFiles__quicksave_index); }

async function gFiles_saveFileNumb(getNumb){ // numbs > 20 AREN'T shown
	await _gFiles_saveLoad( "save", 0, getNumb); }
async function gFiles_loadFileNumb(getNumb){ // numbs > 20 AREN'T shown
	await _gFiles_saveLoad( "load", 0, getNumb); }

function g_gamereset(){ // loads fileSaves(gVars2saveGame) & initialRm 
  gFiles_backup2File_Load( 0);// bool_htmlVers_load_from_file )
  rmloaded_loadroom( JSON.parse( rmloaded_firstRmLoaded_stringified ));}

async function gFiles_menu( int_1_OnlySave_2OnlyLoad_OPTIONAL ){
//API_TAG//
	var tmpL = []; var tmpOnly = int_1_OnlySave_2OnlyLoad_OPTIONAL;
	if(tmpOnly == 1){ tmpL.push("save file"); //only allow LOAD
	}else if(tmpOnly == 2){ //only allow LOAD
		tmpL.push( "load file","load last save"); 
	}else{  tmpL.push("save file", "load file","load last save",
		"delete file"); }
	if(gGlobalThis["document"] != void null){ // html version
		tmpL.push( "save all files to computer", 
		  "load all files from computer");}
	tmpL.push("cancel(esc)");
	var tmpS = await gMenu("", tmpL);
	if(tmpS == "save file"){ await _gFiles_saveLoad("save", 1);
	}if(tmpS == "load file"){ await _gFiles_saveLoad("load", 1);
	}if(tmpS == "load last save"){ await gFiles_loadPrevSave();
	}if(tmpS == "delete file"){ await _gFiles_saveLoad("del", 1);
	}if(tmpS == "save all files to computer"){ //html only
		await gFiles_backup2File( 1 );
	}if(tmpS == "load all files from computer"){ //html only
		await gFiles_backup2File_Load( 1 );
}}

// 
// This is low level, use the other gFiles functions 
// 	for (most) games. This is here if I need it, though,
// as well as rmloaded_saveState (which only catches room)
async function _gFiles_saveLoad( //returns 1 if WORKED
	getStr_save_load_del, 
	bool_use_menu, state_key_if_no_menu){ // both optional
	
	if(_gFiles_restored_from_file_this_startup ==0){
		await gFiles_backup2File_Load( );
		_gFiles_restored_from_file_this_startup = 1;}

	if(bool_use_menu){state_key_if_no_menu = 
	  await _gMenu_saveFileSelect( getStr_save_load_del);}
	
	//var state_key_if_no_menu	
	if(state_key_if_no_menu == void null){ return 0;} 
	if(state_key_if_no_menu < 0){ return 0;} 

	var retWorked =0;
	
	if( "save" ==getStr_save_load_del||"load" ==getStr_save_load_del){
		_gFileNumberLoaded = state_key_if_no_menu; }
	
	if(getStr_save_load_del == "del" ){ 
		if(state_key_if_no_menu >0){
		  if("yes"==await gMenu(
				"Really delete?", ["yes","no"])){
		    if("yes"==await gMenu(
				  "Last chance. Delete?",["yes","no"])){
				retWorked=1; //del file
				_gFiles[state_key_if_no_menu] = void null;
	}  }  } }
	if(getStr_save_load_del == "save" ){ 
		retWorked=1; //save file
		_gFiles[state_key_if_no_menu] = rmloaded_saveState(  
		  0, gVars2NOTsaveFile,  gVars2saveFile); 
		}
	if(getStr_save_load_del == "load" ){ 
	 retWorked=1; //load file
	 if(_gFiles[state_key_if_no_menu] != void null){
	  rmloaded_saveState_load(_gFiles[state_key_if_no_menu]); }  }

	if(retWorked == 1 ){ gFiles_backup2File(); }
	return retWorked;
}

async function _gMenu_saveFileSelect(
		getS ){ //getStr_save_load_del;
	var tmpDescr = "Select save file to "
	if("save" == getS ){ tmpDescr+=" SAVE:";
	   var tmpFiles = "cancel 1 2 3 4 5 6 7 8 9".split(" "); 
	}else{ tmpFiles = ["cancel"];
	   for(var i=0; i< _gFiles.length; i+=1){
		if( i !=  _gFiles__quicksave_index && i < 20 
			  && _gFiles[i] != null){
			tmpFiles.push(""+i); }	}	}
	if("load" == getS ){ tmpDescr+=" LOAD:"}
	if("del" == getS){ tmpDescr+=" DELETE:"}
	var tmpRet = await 
		gui_menu_blocking( tmpDescr, gConf.saveMenu, tmpFiles
		//getHints_text_on_toggle_OPTIONAL,bg_OPTIONAL
		);
	if(tmpRet == "cancel"){ tmpRet = -1;}
	return parseInt(tmpRet);
} 




