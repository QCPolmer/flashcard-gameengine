//API_TAG//
//creates room_debug object, which draws debug options on screen.
//	and gives access to debug cmds/menu.
// It's a small obj, and the bomb. 
// Parts that are UNIMPLIMENTED are labeled, search the text in the 
// menu where they are found to find them in rmloaded_debug.js. 
// 	There are blank functions to fill/edit in UNIMPLIMENTED sections. 
function rmloaded_debug_obj(){ //ADD VIA: room.objs[rmloaded_debug_obj()]!
	// EDIT: looks like 'objs.push' is the way to go... 
//API_TAG//
	var x = _rmloaded_camera_x; var y = _rmloaded_camera_y;
	return {
x:x, y:y, colgroup:"-", ignore_pause:false, dead:0,
behavior:"rmloaded_debug_behav", graphic:" ", draw_1late_2last:3 }};


var rmloaded_debug_menu_savestates = {};
//handles ALL non-realtime debug options
// (should save realtime displays to object!
async function rmloaded_debug_menu( obj_with_debug_behav ){

var tmpOptions ={
"a": [ "a) obj DATA VIEW AND ALTER", async function(){ 
  await rmloaded_debug_find_n_alter_obj(
   obj_with_debug_behav, null,//tmpcmds,// can be null 
   0, null, //progen_objs, progen_optional_hist_neg1or1,
   1,1);//obj_1Debug_2del_3realtimedisp, tmp_1_target_1_object_or_all)
	} ],
"b": [ "b) obj DATA VIEW AND ALTER alter and progen (NEEDS_TESTING)", async function(){ 
  await rmloaded_debug_find_n_alter_obj(
   obj_with_debug_behav, null,//tmpcmds,// can be null 
   1, null, //progen_objs, progen_optional_hist_neg1or1,
   1,1);//obj_1Debug_2del_3realtimedisp, tmp_1_target_1_object_or_all
}],
"c": [ "c) obj VARIBLE REALTIME DISPLAY and can control it", async function(){ 
  await rmloaded_debug_find_n_alter_obj(
   obj_with_debug_behav, null,//tmpcmds,// can be null 
   0, null, //progen_objs, progen_optional_hist_neg1or1,
   3,1);//obj_1Debug_2del_3realtimedisp, tmp_1_target_1_object_or_all
}],
"d": [ "d) obj VARIBLE REALTIME DISPLAY remove by index", async function(){
	var tmpint = file_input("Enter index:").trim();
	if(!isNaN(tmpint)){
		obj_with_debug_behav.debug_objvars_list.splice(
			parseInt(tmpint), 1); }
}],
"e": [ "e) obj REALTIME DISP reset all", async function(){
	obj_with_debug_behav.debug_objvars_list = [];
}],
"f": [ "f) obj PROGEN (NEEDS_TESTING)", async function(){ 
  await rmloaded_debug_find_n_alter_obj(
   obj_with_debug_behav, null,//tmpcmds,// can be null 
   1, null, //progen_objs, progen_optional_hist_neg1or1,
   0,1);//obj_1Debug_2del_3realtimedisp, tmp_1_target_1_object_or_all
}],
"g": [ "g) objs PROGEN ALL with paramiters", async function(){ 
  await rmloaded_debug_find_n_alter_obj(
   obj_with_debug_behav, null,//tmpcmds,// can be null 
   1, null, //progen_objs, progen_optional_hist_neg1or1,
   0,0);//obj_1Debug_2del_3realtimedisp, tmp_1_target_1_object_or_all
}],
"h": [ "h) objs DELETE with paramiters", async function(){
  await rmloaded_debug_find_n_alter_obj(
   obj_with_debug_behav, null,//tmpcmds,// can be null 
   1, null, //progen_objs, progen_optional_hist_neg1or1,
   2,1);//obj_1Debug_2del_3realtimedisp, tmp_1_target_1_object_or_all
}],
"i": [ "i) objs DELETE ALL with paramiters", async function(){
  await rmloaded_debug_find_n_alter_obj(
   obj_with_debug_behav, null,//tmpcmds,// can be null 
   1, null, //progen_objs, progen_optional_hist_neg1or1,
   2,0);//obj_1Debug_2del_3realtimedisp, tmp_1_target_1_object_or_all
}],
"j": [ "j) room PROGENALL(NEEDS_TESTING)", async function(){
	progen_obj_room( rmloaded_room);}],
"k": [ "k) room PROGENALL advance 1(NEEDS_TESTING)", async function(){
	progen_obj_room( rmloaded_room, 1);  }],
"l": [ "l) room PROGENALL advance -1(NEEDS_TESTING)", async function(){ 
	progen_obj_room( rmloaded_room, -1); }],

"o": [ "o) room PROGEN WITH CHARGRP '!'(NEEDS_TESTING)", async function(){
	progen_obj_room( rmloaded_room, null, "!"); }],
"m": [ "m) room PROGEN WITH CHARGRP '!' advance 1(NEEDS_TESTING)", async function(){
	progen_obj_room( rmloaded_room, 1, "!"); }],
"n": [ "n) room PROGEN WITH CHARGRP '!' advance -1(NEEDS_TESTING)", async function(){ 
	progen_obj_room( rmloaded_room, -1, "!"); }],

"p": [ "p) room LOAD NAMED (UNIMPLIMENTED)", async function(){ }],
"q": [ "q) room CREATE OBJ NAMED (UNIMPLIMENTED)", async function(){ }],
"r": [ "r) room CREATE RMTILE NAMED (UNIMPLIMENTED)", async function(){
	//maybe allow 'run_last_operation x_optional y_optional'
	//and create via 'getroomtype'?
}],
"s": [ "s) room SAVESTATE: SAVE ", async function(){
	rmloaded_debug_menu_savestates[
		file_input( "(saved globally) Name room savestate:")
		.trim()] = JSON.stringify(rmloaded_room);
}],
"t": [ "t) room SAVESTATE: LOAD ", async function(){ 
	var rm_key =file_input("(saved globally) Savestate to load:"
		.trim());
	if(rmloaded_debug_menu_savestates[rm_key] != null){
		rmloaded_room = JSON.parse(
			rmloaded_debug_menu_savestates[rm_key]);} }],
"u": [ "u) room dump & load data to/from json ", async function(){ 
	rmloaded_room = JSON.parse(
	await file_copybox( JSON.stringify( rmloaded_room,null, 5) ));
}]
};

	var tmp_options_txt =""; var tmpkeys = Object.keys(tmpOptions);
	for(var i=0; i< tmpkeys.length; i+=1){
		tmp_options_txt += tmpOptions[ tmpkeys[i] ][0] + "\n";}

	var tmp_menu_params = file_input(
	"DEBUG MODE:TYPE PARAMITER LETTER AND ENTER:\n"
	+ tmp_options_txt ).trim().toLowerCase();

	if( tmpOptions[ tmp_menu_params ]  != undefined){
	tmpOptions[tmp_menu_params][1](); return; }

	file_input("invalid input, returning to game.");
	return;
}



// input key
rmloaded_debug_behav_init_key = "!";
async function rmloaded_debug_behav(o){
	
	if(o.debugmode_on == void null){ o.debugmode_on = true;}
	if( controllers[0].getch == rmloaded_debug_behav_init_key){
		if(o.debugmode_on == false){ o.debugmode_on = true;
		}else{ o.debugmode_on = false;} }

	o.x = _rmloaded_camera_x; o.y = _rmloaded_camera_y;
	if(o.debugmode_on == true){
	   if( o.debug_objvars_list == void null){
		o.debug_objvars_list= []; } //used for displaying vars!
	  var rm = rmloaded_room;
	  if( controllers[0].getch == "'"){ 
		  await rmloaded_debug_menu( o);}
	  if( controllers[0].getch == "+"){ 
		  progen_obj_room( rmloaded_room, +1); }
	  if( controllers[0].getch == "-"){ 
		  progen_obj_room( rmloaded_room, -1); }
	  if( controllers[0].getch == "*"){ 
		  progen_obj_room( rmloaded_room); }
	}
	
	rmloaded_debug_realtime_disp_drawNvarmod( o );
	
	// can add/remove trackable objects as a list!
	// so I can have the readout of 'vars to track' 
	// on screen! (and maybe a readout for 'debug:'@'key!)

}
function rmloaded_debug_realtime_disp_drawNvarmod( 
		obj_with_debug_behav ){
	var ls = obj_with_debug_behav.debug_objvars_list;
	// [[0] larg_obj_1_small_2, [1]obj_index,
	//  [2]var_to_disp, [3]char_to_increase, [4]char_to_decrease]
	
	if(obj_with_debug_behav.debugmode_on == false){
		rmloaded_draw_overlay( 
			rmloaded_debug_behav_init_key+
			":debug turnON ", 
		0,0, " ");
		return;
	}
		
	rmloaded_draw_overlay( 
		rmloaded_debug_behav_init_key+
":debug_turnOFF ':debug --Progen:+=up,-=down,*=random ", 
		0,0, " ");
	
	var tmpGetCh = controllers[0].getch;
	for(var i=ls.length-1; i>= 0; i-=1){
		var l_i = ls[i];
		if(l_i[0] == 2){ //small objs
			var o = rmloaded_room.objs[l_i[1]];
		}else{ //small objs
			var o = rmloaded_room.objs_large[l_i[1]];}
		if(o == void null){ ls.splice(i,1); continue;}
		
		rmloaded_draw_overlay( i + l_i[2] +
			":" + o[l_i[2]], 0, i+1, " ");
		
		if(l_i[3] != void null && l_i[4] != void null
				&& l_i[5] != void null){
			if(tmpGetCh == l_i[3]){
				o[l_i[2]] += l_i[5];
			}if(tmpGetCh == l_i[4]){
				o[l_i[2]] -= l_i[5];	} }
	}
}
function rmloaded_debug_realtime_disp_launch( 
	obj_with_debug_behav,  
	larg_obj_1_small_2, obj_index){ 
	
	var tmpList = obj_with_debug_behav.debug_objvars_list;
	//OK, this list is only modified here (or objs removed/added)
	//so I can pretty much do what I want with the data type...
	//
	//gotta get var to display here.
	var tmpParams = file_input("Input 4 paramiters: var_to_display char_to_increase(optional) char_to_decrase(optional) increase_decrease_amount\n").trim().split(" ");
	var var_to_disp = tmpParams[0];
	var char_to_increase = tmpParams[1];
	var char_to_decrease = tmpParams[2];
	var increase_decrase_amount = parseFloat(tmpParams[3]);

	tmpList.push( 
		[ larg_obj_1_small_2, obj_index,
		var_to_disp, char_to_increase, char_to_decrease,
		increase_decrase_amount] );
}
// returns true on pattern match! (NOT efficeint, but shouldn't need 2 be)
function rmloaded_debug_obj_test( o, cmds){
	var keys = Object.keys(o);
	for(var i=0; i< keys.length; i+=1){
		var key = keys[i]; 
		if( key.indexOf(cmds[0]) == -1){ continue; }
		var val = o[key];
		if( !isNaN(cmds[1])){//is a number (or string of a number)
			
			if(parseFloat(cmds[1]) == val){ return true;}
			//checking if val < cmds [1] and cmds > [2]
			if(parseFloat(cmds[1]) < val){ 
				if( !isNaN(cmds[2])){
				 if( parseFloat(cmds[2]) > val){
					return true
			} } }
		}else{ 
		   if( val.indexOf(cmds[1]) != -1 ||
		   		cmds[1] == void null){ // string match!
			return true;
		}}
	}
	return false;
}
async function rmloaded_debug_rewrite_obj_in_list( objlist, i){
	var modded_obj_str = await file_copybox( 
		JSON.stringify( objlist[i], null, 5 ));
	try {   modded_obj_str = JSON.parse( modded_obj_str);
		objlist[i] = modded_obj_str;
    	} catch (e) {
        	file_input("unable to convert text to object!"); }
}


// OK, this should handle ALL object search paramiters.
var rmloaded_debug_find_n_alter_obj_LAST_CMDS =[""]; 
async function rmloaded_debug_find_n_alter_obj(
	obj_with_debug_behav, cmds,// can be null  
	progen_objs, progen_optional_hist_neg1or1,
	  config, //obj_1Debug_2del_3realtimedisp, 
		tmp_1_target_1_object_or_all){
	
	if(cmds == void null){
	  var cmds = file_input(`Type in pattern to get room object.
(PATTERN: part_of_a_obj_var_name 
	OR:  part_of_a_var_name min_# max_#
	OR:  part_of_a_var_name part_of_var_str
	OR: ' to repeat last search.
`).trim().split(" ");
	 if(cmds[0] == "'"){ 
		 cmds = rmloaded_debug_find_n_alter_obj_LAST_CMDS; } 
	 rmloaded_debug_find_n_alter_obj_LAST_CMDS = cmds;
	}

	var tmp_Os = rmloaded_room.objs;
  	for(var i=0; i< tmp_Os.length; i+=1){
	   var o = tmp_Os[i];
	   if(rmloaded_debug_obj_test( o, cmds)){ 
		if(config == 1){ //debug
			await rmloaded_debug_rewrite_obj_in_list(tmp_Os, i);
		}if(config == 2){ //del
	   		if( o == obj_with_debug_behav){ continue;}
			tmp_Os[i].dead = true;
		}if(config == 3){ // realtime disp
			rmloaded_debug_realtime_disp_launch( 
				obj_with_debug_behav,  
				2, i);//larg_obj_1_small_2, i)
		}
		if(progen_objs){
			progen_obj(tmp_Os[i], tmp_Os[i], rmloaded_room, 
				progen_optional_hist_neg1or1); }
	   	if(tmp_1_target_1_object_or_all == 1){ return; }
	   } }
	var tmp_Os = rmloaded_room.objs_large;
	for(var i=0; i< tmp_Os.length; i+=1){
	   var o = tmp_Os[i];
	   if(rmloaded_debug_obj_test( o, cmds)){ 
		if(config == 1){ //debug
			await rmloaded_debug_rewrite_obj_in_list(tmp_Os, i);
		}if(config == 2){ //del
	   		if( o == obj_with_debug_behav){ continue;}
			tmp_Os[i].dead = true;
		}if(config == 3){ // realtime disp
			rmloaded_debug_realtime_disp_launch( 
				obj_with_debug_behav,  
				1, i);//larg_obj_1_small_2, i)
		}
		if(progen_objs){
			progen_obj(tmp_Os[i], tmp_Os[i], rmloaded_room, 
				progen_optional_hist_neg1or1); }
	   	if(tmp_1_target_1_object_or_all == 1){ return; }
	   	if(tmp_1_target_1_object_or_all == 1){ return; }
	   	} }

}

//API_TAG//
var _behavior_progen_char4_call_all ="!";
// behaviors saved to global namespace, typically start with 'b_'
async function behav_rmloaded_debug_progen(){
// returns nothing (it's a behavior), but can be used to advance or reverse 
// procedural generation, or set the target char to use
//  (control keys: .,@) 
	//  ---Can save room as file here too. //API_TAG//
	// can use file_input for getting key to look for 
	// THEN I do 'advance operation' or 'advance last operation' 
	if( controllers[0].getch == "."){
	  progen_obj_room(rmloaded_room, 1, _behavior_progen_char4_call_all); }
	if( controllers[0].getch == ","){
	  progen_obj_room(rmloaded_room, -1, _behavior_progen_char4_call_all); }
	if( controllers[0].getch == "@"){ 
		var caught_str = 
			file_input( "input char to target objs with "+
			"char in obj.progen.group string\n" +
"OR sv FILENAME(filename is optional) to save room(json) to file... \n" + 
			"CONTROLS 4 progen:\n"+
	"'!' default char, ',' run and itterate to prev randseed\n,"+
			"'.' same as ',' but itterates next,\n" + 
			"(think of them as 'back' and 'forward'\n");
		if(caught_str.trim().split(" ")[0] == "sv"){
			
			if( caught_str.trim().split(" ").length==1 ||
				 caught_str.split(" ")[1] == "m.js"){
				//save room as progen save
				file_save( file_dir_cd(), 
				  "progen_rm_json_save.json", 
				  JSON.stringify(rmloaded_room, 
					  null, 2));
			}else{
				//save room as filename
				file_save( file_dir_cd(), 
				  caught_str.trim().split(" ")[1] , 
				  JSON.stringify(rmloaded_room, 
					  null, 2));
			}
		}else{
		 _behavior_progen_char4_call_all = caught_str.trim("");
	} }
}

