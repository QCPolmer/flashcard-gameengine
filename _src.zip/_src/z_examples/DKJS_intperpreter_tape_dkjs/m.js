// 




function m_js_autoload_file_update_if_available(){
// below is for html version, which doesn't do file-operations!
 if(typeof file_dir_search != "undefined"){
    var tmpFILENAME= "_auto_load_js_files_in_this_file.js";
    if(1 == file_dir_search( file_dir_cd_js(),0,[tmpFILENAME+"$"]).length){
	var TMPFILENAMES_DIVIDER= "//AUTO_ADDS_FILES_BTWEEN_HERE//";
	
	var tmp_search = file_dir_search(
		file_dir_cd_js() ,5, ["js$"], ["m.js$", "m.loadLate.js$", 
			"m.set_start_level_and_configs.js$", "_auto_load_js_files_in_this_file.js$" +"$"]);
	
	for(var i=0; i< tmp_search.length; i+=1){ 
	  tmp_search[i] = tmp_search[i].split(file_dir_cd_js())[1]; }
	var tmp_outStr = "";
	for(var i=0; i< tmp_search.length; i+=1){
		tmp_outStr += '"' + tmp_search[i]+ '", '; }

	var tmpFileData = file_load( file_dir_cd_js(), tmpFILENAME);
	tmpFileData = tmpFileData.split(TMPFILENAMES_DIVIDER);
	tmpFileData[1] = "\n\n" + tmp_outStr + "\n\n";
	tmpFileData = tmpFileData.join(TMPFILENAMES_DIVIDER);
	file_save( file_dir_cd_js(), tmpFILENAME, tmpFileData);
}	} }



///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
///////////////////////////////////////////////////////



importableFunctExample = function(){};


globalThis = this;
global = this;
print = file_debug_printf;
//basically loads js terminal
function file_js_terminal_mode(){
	
	while(1){
		// for if 'exit()' is called...
		
		file_debug_printf("\n>");
		tmpstr = _file_debug_scanf(100000);
		if(tmpstr==null){ break;}
		// above is for pipes!
		try{ 
		  // file_run_js_debug( drops to global scale,
		  // 	used for file-loading if this gives trouble. )
		   file_debug_printf(eval(
		  _file_preprocess_js( tmpstr)
			.split("[[").join("('").split("]]").join("')")
			));
		}
		catch(e){ file_debug_printf(e);}  
	}
}

var exit= file_exit;
var system_ret =system_return_output;

function help(){
	file_debug_printf(
		"/////////////////////////////////////////////\n"+
		"/// HELP (designed similar too 'awk' ) //////\n"+
		"//	----TRYS TO RUN 'RUN.js' in file first thing--\n"+
		"//	----IF NO INPUTS(not m.js,loads from .exe)-\n"+
		"/// 	USES '_0' instead of '$0' and double quotes- \n"+
		"/// 	for in-line ('$0' pulls linux file stuff) - \n"+
		"/////////////////////////////////////////////\n"+
		"// NOTE: GLOBAL VARS ARE SET TO globalThis!!!,\n"+
		"// 		-----BIG FILES------ "+
		"//    FOR BIG FILES- PIPE DATA IN AND DO -NOT- USE\n"+
		"//		-ENDFILE (-ENDLINE reads by line ONLY\n"+
		"//			for piped in data\n"+
		"/////////////////////////////////////////////\n"+
		" -b / -B/ -BEGIN (load js in terminal, example below\n" +
		"      USES DOUBLE NOT SINGLE QUOTES- \n"+
		"      \" END{globalThis=1;} ENDLINE{} ENDFILE{}\"\n"+
		"       runs AS FUNCTIONS, like how awk uses this\n" +
		"	'ENDLINE{' expands to 'function ENDLINE', etc\n"+
		"	BEGIN is unused, as script itself is BEGIN\n"+
		"	SHORTHAND FOR THIS ONLY: [[ -> (\", ]]->\") \n"+
		" _0 - data in, global var, the data file/line text\n"+
		" FILENAME - filename (for files in ONLY)\n"+
		" data files (files to run script on with -ENDLINE/ENDFILE\n"+
		"	can be addad at end of statment- \n"+
		"-i interpter mode(runs automatically if no RUN.js\n"+
		"	SHORTHAND FOR THIS ONLY: [[ -> (\", ]]->\") \n"+
		"-f file.js (load file, BEGIN END ENDLINE ENDFILE \n" +
		"       (all with _0 as input for full line/finetext)\n" +
		"       can be defined here; \n" +
		
		"after that, takes in files to execute,\n" +
		"       (looks for param entries without '-' before it,\n" +
		"       runs those as text-input.) \n"+
		"-help - runs 'help();' in js, displays this help. \n" +
		"dir/ls(dirname_or_null); (in js)-list directory files.\n"+
		"file_dir_search( cd(), maxRecursiveDepth, \n"+
		"     list_of_regex(str), list_of_exclude_regex(str)))\n"+
		"file_dir_copy( getDir_toCopy, getDir_toMake, \n"+
		"     getCopyDepth, getRegex_partslist_to_match,\n"+
		"     getRegex_partslist_to_EXCLUDE)\n"+
		"rm/del(fileName); (in js) delete a file\n"+	
		"rmdir(dirName); (in js) delete a directory\n"+	
		"mkdir(dirName); (in js) make a directory\n"+
		"help(); (in js)- show this file/tooltip;\n"+
		"exit(); (in js)- ends script\n"+	
		"print/file_debug_printf(str); (in js) - pipe/write out \n"+
		"error/file_debug_printf_ERROR- error pipe out\n"+
		"save(name,txt) (in js) save to file\n"+
		"sleep/sleep_seconds(seconds)- min 1/24th a sec \n"+
		"load(name)/loadjs(name)(in js) load a file/run js file\n"+
		"file_load_noembed('',name)(in js)-same as above\n"+
		" 'FILENAME' - globalVar stores working data file-name\n"+
		"        'piped_data' for piped data. \n"+
		"cd(); cd-directory for save/load\n"+
		"      NOTE: check API for os-walk, etc. handling\n"+
		"	for stuff like this. \n"+
		"system(); (js) system calls\n"+
		"system_ret/system_return_output();(js) system call, \n"+
		"       stores output as [out, errorout]\n"+
		"       WARNING- makes tmp-files in dir, cleans itself,\n"+
		"       but use file_dir for file reading or will see them, \n"+
		"copybox/file_copybox(txtIn) - opens a prog of choice \n"+
		"        for text in/out (like a copy box)-vim works.\n"+
		"        WRITE ACCESS IN CD REQUIRED\n"+
		"prompt_menu(array) (in js) - user input, picks list item,\n"+
		"        returns index or -1\n"+
		"pipe_(data_in, [[funct/name, PIPE_OUT, param2..],\n"+
		"   [funct2/name, param1, param2]...]\n"+
		"   for basic pipes, PIPE_OUT is last pipe section out.\n"+
		"global/globalThis-  in js,\n"+
		"        set vars this way, as functions are\n"+
		"        run in function scope, NOT global eval!\n"+
		"    OR\n"+
		"	 define without 'var' first (a=1;)... maybe\n"+
		"////////////////////////////////////////////\n"+
		"// DUKTAPE LICENSE(and windows_dirent.h license):\n"+
		"///////////////////////\n"+
		"-duktape_license  (in engine:var file_duktape_license)\n"+
		"////////////////////////////////////////////\n"+
		"// LEVEL EDITOR (MUST open in a valid game base-dir:\n"+
		"///////////////////////\n"+
		"-level_editor :OR: -le :OR: 'level_editor_launch();'\n"+
		"(ctrl+c exits)\n");
}


////////////////////////////////
/////////// CODE FOR SETTING UP A SLEEP TIMER IS BELOW!!!
//		(set to framerate, if I set it to 1/100th of 
//			a second, should be able to round 
//			and get a clean pause-timer!)
//////////////////////////
////assuming update framerate set to 24fps
function pause_1_24th_of_a_sec_hacked_from__update_dont_clear( i_24ths){ 
	_update_then = Date.now();  
	while( i_24ths > 0){ i_24ths-=1
		_update_now = Date.now(); 
		_update_delta = _update_now - _update_then;
		//while(0){
		while( (1000 / _update_delta) > _update_framerate){ 
			//This here 'zooms in', waiting less on framerate
			tmpFrameRt_diff =  
				(1000-_update_framerate) / _update_delta;
			if(tmpFrameRt_diff > _update_MAX_FAMERT_DIFF){
				update_sleep(10);
			}else{ update_sleep(1);}
			_update_now = Date.now();
			_update_delta = _update_now-_update_then; }
		_update_then = _update_now; 
	}; }
function sleep_seconds(getSecs){
	getSecs = getSecs*24; //assuming update framerate set to 24fps
	if( getSecs <2/24){ getSecs=2;}
	pause_1_24th_of_a_sec_hacked_from__update_dont_clear( getSecs);
}
var sleep = sleep_seconds;


/////////////////////////////////////////
//////////////////////////////
////////////////////
//

var rmdir =function(getDirName){ return file_dir_rmdir(cd(), getDirName);}
var rm= function(getName){ return file_remove(cd(), getName);}
var del = rm;
var mkdir = function(getName){ //returns nothing, but in case I change it
	return file_dir_mkdir( cd(), getName);}
var rmdir = function(getName){ //returns nothing, but in case I change it
	return file_dir_rmdir( cd(), getName);}



var copybox = file_copybox;
var filename = 'piped_data';
// BELOW MAY NEED WORK, for if saving to absolute path,
// 	this goes local path
var save = function(getFileName,txtToSave){
	return file_save(cd(),getFileName, txtToSave);}
var load = function(getFileName){
	return file_load_noembed(cd(),getFileName);}
var loadjs = function(getFileName){
	file_load_js_noembed(cd(),getFileName);}
var system = file_system;

var cd = file_dir_cd;
var dir = function(tmp_dir_name){ 
		if(tmp_dir_name == undefined){ tmp_dir_name ="";}
		return file_dir( cd(), tmp_dir_name);}

var ls = dir;
var error = file_debug_printf_ERROR;
var print = file_debug_printf;
var _0 = "";

function prompt_menu(getArray){
	file_debug_printf("TYPE IN A CHOICE THEN ENTER:\n");
	var items = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	for(var i=0; i< getArray.length; i+=1){
		file_debug_printf( items[i]+":" + getArray[i] + "\n");	}
	var tmpIn = _file_debug_scanf(10000).trim();
	return 	items.indexOf(tmpIn);

}
function this_js_file_global_eval( getTxt){
	file_data_eval= getTxt;
	file_data_eval(); file_data_eval = null; 
	
}

var FILENAME = null;
async function main_funct(){	
	//await file_treeload_js( file_js_cd(), '/Test_scale_text.js');

	//loading:  (edit all m.js:grep/replace one lib.js name with two)
	await file_load_js( file_core_js_cd(),
	["txttools.js", "progen.js",  "progen_obj.js", "rmloaded_search.js", "rmloaded.js",
	 "ml.js",   "pipe_n_rows.js", 
	"gui_and_gui_menu.js", "gui_menu_flashcards.js",
		"controller_behaviors.js",
		"gridstr_rotate.js", "sketch_rays.js",
		"g.js", "g_rmwarp.js", "g_rmwarp_univ2d.js", "g_convo.js", "rogue.js", "level_editor_loader.js"] );
	await file_load_js( file_dir_cd(),
	["level_editor_files/level_editor_data.js", 
	  "level_editor_files/level_editor_display.js", 
	  "level_editor_files/level_editor_draw_mode.js", 
	  "level_editor_files/level_editor_menu.js", 
	  "level_editor_files/level_editor_template.js", 
	  "level_editor_files/level_editor_launch.js"] );

	//m_js_autoload_file_update_if_available()
	
	//await file_load_js( file_js_cd(), [
	//	"_auto_load_js_files_in_this_file.js",		
	//	"m.loadLate.js"] );
	
	//   draw_settup_canvas();       update_start_game();

	
	// rmloaded_loadroom( testRoom); 
	


	
	//for developing, can run with tcc prior to full compile
	var tcc_compiling_arg_1 = "-run_js";
	/////////////////////////////////
	//only 1 argument, m.exe should be arg 0, I think
	if( file_argument_get(1) == "" ||
			file_argument_get(1) == tcc_compiling_arg_1){
		///////////////////////////////
		//first tries to load RUN.js if no args 
		//	(would run m.js, but baked into script,
		//		so likely can't run local m.js right)
		var f= 	load('RUN.js');
	  	if(f != null){ loadjs( "RUN.js");
		////////////////////////////
		//if no m.js, show help.
		}else{ help(); 
			file_js_terminal_mode();
			exit();
			return;} 
	}else{
		/////////////////////////////////
		//args found! processing:
		//
		//These are functions below, can be set in functions 
		//	or 'null' if unset. (global 
		
		var i=1; var tmp_txt_block =[]; 
		var tmpBlock_funct_to_get = null;
		while( file_argument_get(i) != ""){
			//
			//CODE-INJECTION ARGUMENTS
			//
			if(0 == file_argument_get(i).indexOf(  "'" ) ){
				i = inject_prompt_function(
				   i, file_argument_get(i)).split("-")[1];
				continue;
			}
			if( file_argument_get(i) == "-level_editor"||
				file_argument_get(i) == "-le"){
				level_editor_launch(1); 
				//1 above is 'reload local files on start'!
				exit(); }
			if( file_argument_get(i) == "-help"){
				help(); exit(); }
			if( file_argument_get(i) == "-duktape_license"){
				file_debug_printf(file_duktape_license); exit(); }
			if( file_argument_get(i) == "-f"){
				i+=1;
				file_load_js(file_dir_cd(), 
					file_argument_get(i));
				i+=1;
				continue
			}
			if( file_argument_get(i) == "-b" ||
			    file_argument_get(i) == "-B" || 
			    file_argument_get(i) == "-BEGIN"){
			      i+=1;
			      
			      file_run_js_debug( file_argument_get(i)
				.split("[[").join("('").
					split("]]").join("')")
				.split("END{").join("function END(){")
				.split("ENDLINE{")
					.join("function ENDLINE(){")
			  	.split("ENDFILE{")
					.join("function ENDFILE(){"));
			      i+=1;
			      continue;
			}
			if( file_argument_get(i) == "-i"){
				i+=1; continue;
			}
			
			if( file_argument_get(i) != "-"){ break; };
			i+=1;
			//
			//FILE-INPUT ARGUMENTS
			//
		}

	}	
	// interpreter mode. 
	for(var j=0; file_argument_get(j) != ""; j+=1){  
		if( file_argument_get(j) == "-i"){
				help();  file_js_terminal_mode();
				exit();  return; } }	
		


	///////////////////////
	// RUNNING COMMANDS:
		
	// k, going to read files BY LINE, then pull full files
	// 	for both script types. 
	while(file_argument_get(i) != "" &&
			(globalThis.ENDFILE != null ||
				globalThis.ENDLINE != null )){
		filename = file_argument_get(i);
		var tmpf = file_load(file_argument_get(i))
				.split("\r").join("");
		if(tmpf== null){ //ERROR NOT FOUND
			i+=1; continue;	}
		FILENAME = file_argument_get(i);
		
		if( globalThis.ENDLINE != null){
			var tmp_piped_line_array = tmpf.split("\n");
			for(var j=0; j< tmp_piped_line_array.length;j+=1){
				_0 = tmp_piped_line_array[j];
				globalThis.ENDLINE();}
		}
		if(globalThis.ENDFILE != null){
		  _0 = tmpf;
		  globalThis.ENDFILE();
		} 
		i+=1;
		
	}
	//HANDLING PIPES:	
	if(filename == "piped_data"){
	  FILENAME = "piped_data";
	  
	  var tmp_piped_line_array = [];
	  var tmpline="";
	  // for if ONLY ENDLINE defined, to allow scanning large files...
	  if( globalThis.ENDLINE != null && globalThis.ENDFILE == null  ){
		while(1){
			// adding str is needed for linux, or 
			// 	don't work right
			_0 = _file_debug_scanf(10000); 
			if(_0==null){ break;}
			// can customize _file_debug_scanf for speed,
			// 	to replace below, but here you go:
			_0 = _0.split("\n")[0].split("\r").join("");
			globalThis.ENDLINE(); 
	  }	} 
	  //handling other piped input
	  if( globalThis.ENDFILE != null  ){ // handles ENDLINE
		while(1){
			tmpline = _file_debug_scanf(10000);
			if(tmpline==null){ break;}
			
			tmp_piped_line_array.push(
			    tmpline.split("\n")[0].split("\r").join(""));
		}
		if( globalThis.ENDLINE != null){
			for(var i=0; i< tmp_piped_line_array.length;i+=1){
				_0 = tmp_piped_line_array[i];
				globalThis.ENDLINE();}
		}
		
		//run pull new l
		_0 = tmp_piped_line_array.join("\n");
		globalThis.ENDFILE(); 
	  }
	}
	//
	if( globalThis.END != null){ globalThis.END(); }
	
} main_funct();


