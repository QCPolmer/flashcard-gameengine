
async function level_editor_menu(){
	var tmpMenuOut = await level_editor_menu_list(
			["add_obj_by_name('i' in editor)",
				"Save_load_menu('s' in editor)",
				"Set_starting_room_etc",
				"Set_a_level_var",
				"Select/cut/clear All Objects",
		"Draw mode ('m/M' draw-edits obj under cursor)",
		"----('n/N' only enters draw-mode, no obj-edit)",
		"Save last obj selected with drawmode as template",
		"Convo sub-menu",
		"Save a template(submenu)",
	     "Test run level('t',change rooms disabled)",
	     "Test run level,save,N rescan levels('T')"]);
	if(tmpMenuOut == "add_obj_by_name('i' in editor)"){
	    level_editor_display__set_level_editor_display__cursor_objs_to_add__from_menu();}
	if(tmpMenuOut == "Save_load_menu('s' in editor)"){ 
		await level_editor_menu__SAVE_LOAD_Menu();}
	
	if(tmpMenuOut == "Set_a_level_var"){ 
		await level_editor_menu__change_level_vars_Menu();}
	if(tmpMenuOut == "Set_starting_room_etc"){
	await level_editor_menu__set_init_room_etc_to_load__in_autoload();}
	if(tmpMenuOut == "Select/cut/clear All Objects"){
	    var tmpMenuOut2 = await level_editor_menu_list(
			["Select","Cut","Clear"]);
	    var tmpData = level_editor_data__GET_level_loaded(true);
	    if(tmpMenuOut2 == "Select" || tmpMenuOut2 =="Cut"){
		level_editor_display__copy_objlist_to_cursor(
			tmpData.level_data, true); //using level_data...
	    }if(tmpMenuOut2 == "Clear" || tmpMenuOut2 =="Cut"){
		tmpData.level_data = []; 
		level_editor_data__UPDATE_data__and__room( tmpData);
		level_editor_data__GET_level_loaded(true); 
		level_editor_data__undoRedo_list_add_undo();	
	   }		     
	}
	if(tmpMenuOut == "Draw mode ('m/M' draw-edits obj under cursor)"
	|| tmpMenuOut=="----('n/N' only enters draw-mode, no obj-edit)"){
		level_editor__mode__draw_or_normal = "draw"; 
		return;}
	if(tmpMenuOut =="Save last obj selected with drawmode as template"){
	   level_editor_draw_save_obj_loaded_copy_as_frames_template(); }
	if(tmpMenuOut =="Convo sub-menu"){
		level_editor_menu__convo_viewer_main();}
	if(tmpMenuOut =="Save a template(submenu)"){
		level_editor_template__save_menu();}
	if(tmpMenuOut=="Test run level('t',change rooms disabled)"){
		level_editor_launch__test_level_RUN(); } 
	if(tmpMenuOut=="Test run level,save,N rescan levels('T')"){
		level_editor_launch__test_level_RUN( true); } 
}	


var LEVEL_EDITOR_MENU__CURRENT_LIST = 
	JSON.parse(JSON.stringify(menu_test_o));
LEVEL_EDITOR_MENU__CURRENT_LIST._menu_type = "LIST"; //"INPUT_W_AUTOCOMP_WORDS_WAIT_TILL_TYPED", // "LIST", "LIST_WORDS","INPUT", "INPUT_W_AUTOCOMP_WORDS", "INPUT_W_AUTOCOMP_WORDS_WAIT_TILL_TYPED","AUTOCOMP", "AUTOCOMP_WAIT_TILL_TYPED", "AUTOCOMP_SINGLE_WORDS",  "AUTOCOMP_SINGLE_WORDS_WAIT_TILL_TYPED"
async function level_editor_menu_list(getChoices, getDescrText){
	return await gui_menu_blocking(
		  getDescrText,//getDescribedText, 
		   "LEVEL_EDITOR_MENU__CURRENT_LIST" ,
			//getGui_Menu_Object_NAME_SEE_EXAMPLES_FOR_DATA, 
		   getChoices,//getCmds_list, //options
		   "HINTS!!!", //getHints_text_on_toggle_OPTIONAL,
		   true);
}

var LEVEL_EDITOR_MENU__CURRENT_SEL_BY_NAME = 
	JSON.parse(JSON.stringify(menu_test_o));
LEVEL_EDITOR_MENU__CURRENT_SEL_BY_NAME._menu_type = "INPUT_W_AUTOCOMP_WORDS"; // "LIST", "LIST_WORDS","INPUT", "INPUT_W_AUTOCOMP_WORDS", "INPUT_W_AUTOCOMP_WORDS_WAIT_TILL_TYPED","AUTOCOMP", "AUTOCOMP_WAIT_TILL_TYPED", "AUTOCOMP_SINGLE_WORDS",  "AUTOCOMP_SINGLE_WORDS_WAIT_TILL_TYPED"
async function level_editor_menu_autocomplete(getChoices, getDescrText){
	return await gui_menu_blocking(
		  getDescrText,//getDescribedText, 
		   "LEVEL_EDITOR_MENU__CURRENT_SEL_BY_NAME" ,
			//getGui_Menu_Object_NAME_SEE_EXAMPLES_FOR_DATA, 
		   getChoices,//getCmds_list, //options
		   "HINTS!!!", //getHints_text_on_toggle_OPTIONAL,
		   true);
}

var level_editor_menu__is_obj_a_convo_string__STR_TO_LOOK_FOR = 
	"//LEVEL_EDITOR_CONVO_IF_STR_HAS_THIS_STR//";
function level_editor_menu__is_obj_a_convo_string(a){
 if( typeof a == "string" && a.length > 
     level_editor_menu__is_obj_a_convo_string__STR_TO_LOOK_FOR.length
	&& a != level_editor_menu__is_obj_a_convo_string__STR_TO_LOOK_FOR
	&& -1 != a.indexOf(
	   level_editor_menu__is_obj_a_convo_string__STR_TO_LOOK_FOR) ){
	return 1; }
	return 0
}
// need to make a basic test-convo
var level_editor_menu__caught_running_convo = 
	"level_editor_template__convo_template"; //dotnote
var level_editor_menu__convo_player_otxtPlayer = {};
var level_editor_menu__convo_other_otxtOther = {};
async function level_editor_menu__convo_viewer_main(){
	if(level_editor_menu__caught_running_convo == null){
		level_editor_menu__caught_running_convo = 
			"level_editor_template__convo_template";  }
	var tmpMenuOut = await level_editor_menu_list(
			["Test recently tested convo",
			"Test Convo",	
			"Use recent Objs which where used with convo",
			"Pick Objs to use with convo",
			"Save template convo",
			"Rescan_files(saves file first)",
	     		"Exit to leveleditor"]);
	if(tmpMenuOut == "Test recently tested convo"){
	   var tmpConvo =level_editor_data__get_item_recent( 
					"convo_saved");
	   if(tmpConvo != null){
		level_editor_menu__caught_running_convo = 
			rmloaded_b_globalThis[tmpConvo];
	   //TODO- make recent list
	      	g_convo_run_BLOCKING(
			level_editor_menu__convo_player_otxtPlayer,
			level_editor_menu__convo_other_otxtOther,
			progen_dotnote(
				level_editor_menu__caught_running_convo), 
			0, null); //bool_reset_UNUSED, rm_OPTIONAL)
	   }
	
	}if(tmpMenuOut == "Use recent Objs which where used with convo"){
		var tmpObj_names =level_editor_data__get_item_recent( 
					"convo_objs_saved");
		if(tmpObj_names != null){
		  tmpObj_names = tmpObj_names.split("::")
		  level_editor_menu__convo_player_otxtPlayer = 
			rmloaded_b_globalThis[tmpObj_names[0]];
		  level_editor_menu__convo_other_otxtOther = 
			rmloaded_b_globalThis[tmpObj_names[1]]; }
	}if(tmpMenuOut == "Pick Objs to use with convo"){
	   var tmpObjPl = await level_editor_menu_get__compatible_obj(
		   level_editor_data__is_rmloaded_compatable_obj, true,
			"Type in part/all of a otxtPlayer NAME to use:");
	   if(tmpObjPl != null){
		var tmpObjOt = await level_editor_menu_get__compatible_obj(
		   level_editor_data__is_rmloaded_compatable_obj, true,
			"Type in part/all of a otxtOther NAME to use:");
		if(tmpObjOt != null){
		  level_editor_data__save__recently_used_item(
			tmpObjPl + "::"+tmpObjOt, 
			"convo_objs_saved");//getListName_to_save_as);
		  level_editor_menu__convo_player_otxtPlayer = 
			rmloaded_b_globalThis[tmpObjPl];
		  level_editor_menu__convo_other_otxtOther = 
			rmloaded_b_globalThis[tmpObjOt];
	   }}
	}if(tmpMenuOut == "Save template convo"){
		var getSave_as = level_editor_menu__SAVE_AS( 
			"Enter var-name of convo:", true);
		//getAlternativeStr_to_askFor_instead_of_levelname_OPTIONAL,
		//getReturn_level_n_file_name_ONLY__NO_SAVING_OPTIONAL
		//{filename:tmpFileName, levelname:tmpLevelName}
		if(getSave_as != null){
			file_save( file_dir_cd(), getSave_as.filename, 
			"var " + getSave_as.levelname + " = \n" +
			  String.fromCharCode(96) +//multiline str char 
				level_editor_template__convo_template +
			String.fromCharCode(96) +//multiline str char
				";\n"); }	
	}if(tmpMenuOut == "Rescan_files(saves file first)"){
		level_editor_menu__SAVE();
		level_editor_data__load_files_SCHEMA(); 
		level_editor_data__UPDATE_data__and__room(
	   		level_editor_data__GET_level_loaded( true), true );
	}if(tmpMenuOut == "Exit to leveleditor" || tmpMenuOut == -1){
		return; 
	}if(tmpMenuOut == "Test Convo" ){
	    var gotConvoDotNote = level_editor_menu_get__compatible_obj( 
			//returns list
	    	level_editor_menu__is_obj_a_convo_string, 
			//test-funct to see if obj-type matches
	    	true, // getDoteNameOnly_OPTIONAL,
	    	"pick a convo");
	   if(gotConvoDotNote != null){
		level_editor_data__save__recently_used_item(
			gotConvoDotNote, 
			"convo_saved");//getListName_to_save_as);
		level_editor_menu__caught_running_convo =  gotConvoDotNote;
		
	   	g_convo_run_BLOCKING(
			level_editor_menu__convo_player_otxtPlayer,
			level_editor_menu__convo_other_otxtOther,
			progen_dotnote(
			  level_editor_menu__caught_running_convo), 
			0, null); //bool_reset_UNUSED, rm_OPTIONAL)
	   }	}
	//loops, above param exits:
	return await level_editor_menu__convo_viewer_main();
}


async function level_editor_menu_get__compatible_obj( //returns list
	    getFunctIsObj_test, //test to see if obj-type matches
	    getDoteNameOnly_OPTIONAL,
	    getDisplayText){
	var tmpGlobObjKeys = Object.keys(rmloaded_b_globalThis);
	// pulling objs with names directly
	var tmpObjNamesMakable = tmpGlobObjKeys.filter(
		function(a){ return getFunctIsObj_test(
			progen_dotnote(a ));});
	
	
	// pulling objs containing objs
	var tmpObjNames_subObjs_tmp= tmpGlobObjKeys.filter(
		level_editor_data__is_dotnote_name_obj_list_filter);
	// pulling sub-sub-objs
	var tmpObjs_sub_2_depth = [];
	for(var i=0; i< tmpObjNames_subObjs_tmp.length; i+=1){
		
		var tmpSubObj_keys =Object.keys(
			progen_dotnote(tmpObjNames_subObjs_tmp[i]));

		for(var j=0; j< tmpSubObj_keys.length; j+=1){
			tmpSubObj_keys[j] = tmpObjNames_subObjs_tmp[i] +"."
				+ tmpSubObj_keys[j]; }
		tmpObjs_sub_2_depth = tmpObjs_sub_2_depth.concat(
			tmpSubObj_keys.filter( 
		   level_editor_data__is_dotnote_name_obj_list_filter)); }

	tmpObjNames_subObjs_tmp = 
		tmpObjNames_subObjs_tmp.concat(tmpObjs_sub_2_depth);
		
	//removing all that start with '_'
	tmpObjNames_subObjs_tmp = tmpObjNames_subObjs_tmp.filter(
		function(a){if(a.indexOf("_")==0){return 0;} return 1;});
	tmpObjNamesMakable = tmpObjNamesMakable.filter(
		function(a){if(a.indexOf("_")==0){return 0;} return 1;});

	//searching IN objs, 1 depth:
	for(var i=0; i< tmpObjNames_subObjs_tmp.length; i+=1){
		
		var tmpSubObj = progen_dotnote(tmpObjNames_subObjs_tmp[i]);
		var tmpSubObj_keys = Object.keys(tmpSubObj);
		var tmpSubObj_name = tmpObjNames_subObjs_tmp[i]; 
		for(var j=0; j< tmpSubObj_keys.length; j+=1){
			var tmpObj = tmpSubObj[ tmpSubObj_keys[j] ];
			if(getFunctIsObj_test( tmpObj)){
				tmpObjNamesMakable.push( 
				    tmpSubObj_name+"."+tmpSubObj_keys[j]);
	}	} 	} 


	var tmp_choice = await menu_autocomp_menu_THEN_OUTPUT_2_list_menu( 
		tmpObjNamesMakable, // list of words selectable
		level_editor_menu_autocomplete, //first menu wrapper
		level_editor_menu_list, //outputs to sub-menu wrapper
		getDisplayText
			//text too display
			);
	if(tmp_choice == -1){ return null;}	

	if(!getFunctIsObj_test(
		progen_dotnote(tmp_choice))){ 
		return null; }
	if(getDoteNameOnly_OPTIONAL){ return tmp_choice;}
	return	progen_dotnote(tmp_choice);
}



// level_editor_loader__in_autoload__load_init_tag --- data
// { 
//    room_name_dotnote:"", 
//    default_player_obj_dotnote:"", // or null, only works if warpInPL...
//    					// is defined, OR rmwarp is. 
//    warpInPlayerXY_overrides_rmwarp:{x:23, y,23}, // or null
//    use_rmwarp:false, 
//    use_rmwarp_direction:"left", //or null
//
//	//below vars NOT related to any of above...
//    level_editor_last_loaded_STORING_HERE_FOR_EASE: null
// }
	
function level_editor_menu__set_init_room_etc_to_load__in_autoload(){
	/////////////////////////////
	// loading config (from 'm.js')
	//////////////////////
	var tmpConfig = 
		level_editor_loader__in_autoload__load_obj_data();
	/////////////////////
	/// USE RMWARP (stand alone block) 	
	//////////////////////////////////
	var get_rmwarp_cmd = await level_editor_menu_list(
		["Clear All",
		 "Set All",
		"Set room to Load",
		"Set Player",
		"Set Player start XY",
		"Set Rmwarp or loadroom"
		]);
	if(get_rmwarp_cmd == -1){ return; }

	//can go state machine with above: if state-> do (below)
	if( get_rmwarp_cmd == "Clear All"){  
		var tmpClearThese =["use_rmwarp_direction", "use_rmwarp", 
			"warpInPlayerXY_overrides_rmwarp",
			"default_player_obj_dotnote","room_name_dotnote"];
		for(var i=0; i< tmpClearThese.length; i+=1){
			delete tmpConfig[tmpClearThese[i]]; } }

	/////////////////////
	/// GETTING ROOM (stand alone block) (tmpConfig.room_name_dotnote)
	//////////////////////////////////
	if( get_rmwarp_cmd == "Set room to Load" || 
			get_rmwarp_cmd == "Set All" ){
		
		var tmpGot_Room_name = 
			level_editor_data__get__room__from_menu(true,
			   "Type in all/part START ROOM name to use:"); 
		// only go if one found:
		if(tmpGot_Room_name != null){ 
			tmpConfig.room_name_dotnote =tmpGot_Room_name; }
	}
	/////////////////////
	/// GETTING PLAYER (stand alone block) 
	//		(tmpConfig.default_player_obj_dotnote):""
	//////////////////////////////////
	if( get_rmwarp_cmd == "Set Player" || 
			get_rmwarp_cmd == "Set All" ){
		
		var tmpGot_obj_name = 
			level_editor_data__get__obj__from_menu(true,
				"Type in all/part PLAYER obj name:"); 
		// only go if one found:
		if(tmpGot_obj_name != null){ 
		   tmpConfig.default_player_obj_dotnote =tmpGot_obj_name;}
	 }
	/////////////////////
	/// GETTING WARP/rmload player XY (stand alone block) 
	//	(tmpConfig.warpInPlayerXY_overrides_rmwarp):{x:0,y:0}
	//////////////////////////////////	
	if( get_rmwarp_cmd == "Set Player start XY" || 
			get_rmwarp_cmd == "Set All" ){
		
		var tmpNumbX = await level_editor_menu_autocomplete(
			[], "PLAYER START:type number for X:").trim();
		if(! isNaN(tmpNumbX) && tmpNumbX != -1){ 
			tmpNumbX = parseInt(tmpNumbX);
			var tmpNumbY = 
			await level_editor_menu_autocomplete(
			   [], "PLAYER START:type number for Y:").trim();
			
			if(! isNaN(tmpNumbY) && tmpNumbY != -1){
				tmpNumbY = parseInt(tmpNumbY);
				tmpConfig.warpInPlayerXY_overrides_rmwarp
					= { x:tmpNumbX, y:tmpNumbY };
		}	}
	}
	/////////////////////
	/// GETTING use_rmwarp_direction (stand alone block) 
	//	(tmpConfig.use_rmwarp_direction):"left/right/up/down"
	//////////////////////////////////
	if( get_rmwarp_cmd == "Set Rmwarp or loadroom" || 
			get_rmwarp_cmd == "Set All" ){
		
		var tmpDir = await level_editor_menu_list(
		["Use_loadrm_not_rmwarp","left", "right", "up","down" ], 
			"Rmwarp enter direction?");

		if(tmpDir == "Use_loadrm_not_rmwarp" ||
				tmpDir == -1 ){
			tmpConfig.use_rmwarp_direction = false;
		}else{ tmpConfig.use_rmwarp_direction = true; 
			tmpConfig.use_rmwarp_direction = tmpDir;  }
	}
	/////////////////////////////
	// saving config (to 'm.js')
	//////////////////////
	level_editor_loader__in_autoload__save_obj_data(tmpConfig);
	

}

async function level_editor_menu__SAVE(){
	var tmp_level_data = level_editor_data__GET_level_loaded();
	if(tmp_level_data == null){ level_editor_menu__SAVE_AS(); return;
	}else{
		// first two show, then blank 
		level_editor_data__save_level_data( 
			tmp_level_data.file_name, 
			tmp_level_data.level_name,
			tmp_level_data.level_raw_file_text, 
			tmp_level_data.level_data);
				
		level_editor_data__save__recently_used_item(
			tmp_level_data.level_name,
			"CAUGHT_LOADED_level_names_list");
	}
	// updating catch (probably not needed)
	level_editor_data__GET_level_loaded( true);
}
async function level_editor_menu__SAVE_AS(
		getAlternativeStr_to_askFor_instead_of_levelname_OPTIONAL,
		getReturn_level_n_file_name_ONLY__NO_SAVING_OPTIONAL){
		//if using above param, returns 
		//	{filename:tmpFileName, levelname:tmpLevelName}
		//	(or null)
	var tmpLevelName_or_alternive =
		getAlternativeStr_to_askFor_instead_of_levelname_OPTIONAL;
	if( tmpLevelName_or_alternive == null){ 
		var tmpLevelName_or_alternive = "levelname";} 

	var tmpSubFolders= file_dir_search( file_dir_cd(),4);
	tmpSubFolders = tmpSubFolders.map(function(a){
		     a = a.split(file_dir_cd())[1];
		     a = a.split("/"); a.pop();a.join("/");return a+"/";})
		     .reduce(function(a,b){  //removing doubles:
			if(a.indexOf(b)==-1){ a.push(b)} return a;}, []);
	var tmpFileName = await level_editor_menu_autocomplete(
			tmpSubFolders, 
		"Filename(include folder,only sub-folders /w files show)");
	if(tmpFileName == -1){return;}
	tmpFileName = tmpFileName.trim();
	

	var tmpLevelName = await level_editor_menu_autocomplete(
	   [], "enter "+tmpLevelName_or_alternive +" (one word, '_'s OK)");
	if(tmpLevelName == -1){return;}
	tmpLevelName = tmpLevelName.trim();
		
	var tmpBadChars=" \"%$#@!^&*()({}-+=,;'";
	for(var i=0; i< tmpBadChars.length; i+=1){
		if( tmpLevelName.indexOf(tmpBadChars[i])!=-1){
			file_input("bad char:", tmpBadChars[i],
			  "invalid file name!(no spaces/alpha_charsONLY)")
			return; }
		   if( tmpLevelName.indexOf(tmpBadChars[i])!=-1){
			file_input( "bad char:", tmpBadChars[i],
			 "invalid level name!(no spaces/alpha_charsONLY)");
			return; }  }
	if( tmpLevelName.indexOf(".") != -1){
			file_input( "invalid level name!: No '.'s  ");
			return; }
	if( tmpLevelName.length ==0){
			file_input( "invalid level name! too short!  ");
			return; }
	if( tmpFileName.length ==0){
			file_input( "invalid file name! too short!  ");
			return; }
	if( tmpFileName.split("").reverse()[0] == "/"){
			file_input( 
			   "invalid file name!: No ending with '/'  ");
			return; }
	if( "0123456789".indexOf(tmpLevelName[0]) != -1){
			file_input(
			 "invalid level name!(can't start with a number)");
			return; }
	//making sure ends with ".js"
	if(tmpFileName.split("").reverse().join("")
				.indexOf("sj.") != 0){
			tmpFileName = tmpFileName + ".js";}
		
	if( file_load_noembed(file_dir_cd(), tmpFileName) != null){
		if("Yes (confirm)" != await level_editor_menu_list(
		   ["Yes (confirm)", "No (cancel)"],
		   "WARNING:file already exists! continue saving?")){
				return null;	}	}

	if(getReturn_level_n_file_name_ONLY__NO_SAVING_OPTIONAL){
		return {filename:tmpFileName, levelname:tmpLevelName};
	}

	// pulling file data (if avialable)
	var tmp_level_data_loaded = level_editor_data__GET_level_loaded();
	if(tmp_level_data_loaded != null){
			/// ...?
		   var tmp_level_data__level_data = 
			tmp_level_data_loaded.level_data;
		   var  tmpFile_data = 
			tmp_level_data_loaded.level_raw_file_text;
	}else{ 
		  var tmpFile_data = 
			level_editor_template__SAVE_LEVEL_DATA + "";
		   tmpFile_data = tmpFile_data
				.split("NAME_HERE").join(tmpLevelName);
	  	 var tmpBreak = "//_level_editor_data//";
	  	  var tmp_level_data__level_data= 
			JSON.parse(tmpFile_data.split(tmpBreak)[1]);
	}
		

	//putting quotes around 'level_name' in file:
	tmpFile_data = tmpFile_data.split("//level_name//");
	
	//hopefully, right place for 'name'
	for(var i=1; i<tmpFile_data.length; i+=2){
		if(i == 1){ tmpFile_data[i] = '\n' + tmpLevelName + '\n'; 
		}else{tmpFile_data[i] = '\n"' + tmpLevelName + '"\n'; } }
	tmpFile_data = tmpFile_data.join("//level_name//");

	// rmloaded_room.level_name -> used to find data
//		{ level_data: tmp_level_data, 
//		level_raw_file_text: tmp_file_data_raw, 
//		level_name: tmp_level_name,
//		file_name: tmp_file_name }
		
	level_editor_data__save_level_data( tmpFileName, tmpLevelName,
			tmpFile_data, tmp_level_data__level_data);
		
	//saving loaded level to m.js...
	level_editor_data__save__recently_used_item( 
		tmpLevelName, "CAUGHT_LOADED_level_names_list" );
	
	//schema/Schema Update (this comment is to allow searching)
	level_editor_data__load_files_SCHEMA();
		
	// rmloaded_room.level_name -> used to find data	
	rmloaded_room.level_name = tmpLevelName;
	//refreshing catch for level_data/ updating room...
	level_editor_data__UPDATE_data__and__room(
	   level_editor_data__GET_level_loaded( true) );
}
async function level_editor_menu__LOAD(){
	var tmpOptions= level_editor_data__caught_files_SCHEMA
			.map( function(a){ 
			  return a.level_name
				+ "::" + a.file_name; } );
	var tmpEntry= 
	   await menu_autocomp_menu_THEN_OUTPUT_2_list_menu( 
		tmpOptions, // list of words selectable
		level_editor_menu_autocomplete,//first menu wrapper
		level_editor_menu_list,//out to sub-menu wrapper
	"Enter part or full name of level::file"
			//text too display
		);
		// none found / got
	if(tmpEntry == -1){ return;}
	var tmpEntry_catch = tmpEntry.split("::");
	tmpEntry = {}; 
	tmpEntry.file_name = tmpEntry_catch[1];
	tmpEntry.level_name = tmpEntry_catch[0];
		
	//so can pull same file/etc... 
	// DOES scan all files... again...
	//level_editor_data__load_files_SCHEMA(  );	
	var tmpLevel_data_found= 
	  ROWS_FILTER(
	      level_editor_data__caught_files_SCHEMA,
		function(a, b ){ 
		  if( a.file_name == b.file_name &&
			  a.level_name == b.level_name){ 
		  return 1;} return 0 },
		tmpEntry )[0];	
	 
	//saving loaded level to m._autoload...js...
	level_editor_data__save__recently_used_item(
		tmpLevel_data_found.level_name, 
		"CAUGHT_LOADED_level_names_list");

	// rmloaded_room.level_name -> used to find data
	rmloaded_room.level_name = tmpLevel_data_found.level_name;
	
//		{ level_data: tmp_level_data,
//		level_raw_file_text: tmp_file_data_raw,  
//		level_name: tmp_level_name,
//		file_name: tmp_file_name }
		
	// clearing undoRedo options, 
	level_editor_data__undoRedo_clear();
	
	level_editor_data__GET_level_loaded( true);


	//refreshing catch for level_data/ updating room...
	level_editor_data__UPDATE_data__and__room(
	   level_editor_data__GET_level_loaded( true), true );
	

	level_editor_data__undoRedo_list_add_undo();

}

async function level_editor_menu__change_level_vars_Menu(){
	// pulling level data (if available)
	var tmp_level_name = rmloaded_room.level_name;
	if(tmp_level_name == null){
		return file_input("Please save level FIRST!");	}
	var tmp_level_data = level_editor_data__GET_level_loaded(true);
	if(tmp_level_data == null){ 
		return file_input("Please save level FIRST!");	}

	var get_cmd = await level_editor_menu_list(
		//put vars to change here, 1 by 1!
		["room_type", //ROOM TYPE (_2d, etc)
		"rmSizeXY",
		"_level_editor_loader__room_on_enter_SEED",
		"rmwarp_use_a_deep_copy_per_spawn",
		"wall_graphic",
		"leave_behavs",
		"update_behavs",
		"enter_behavs"]);
	if(get_cmd == "enter_behavs" || get_cmd == "leave_behavs" ||
			get_cmd == "update_behavs"){
		var get_sub_cmd =  await level_editor_menu_list(
			["add", "clear", "remove_entry"],get_cmd );
		if( get_sub_cmd == -1 ){ return;}
		var tmp_data_split = 
			"//"+ get_cmd + "//";

		var tmp_cmds = tmp_level_data.level_raw_file_text.split(
			tmp_data_split )[1];
		tmp_cmds = JSON.parse( "[" + tmp_cmds + "]");
		
		if(get_sub_cmd == "add"){
			var tmpPossibleFunctNames = 
			Object.keys( rmloaded_b_globalThis)
			       .filter( function(a){		
			  var a_obj= rmloaded_b_globalThis[a];
			  //length below is 1 param-in for funct 
			  if(typeof a_obj=="function"&& a_obj.length==1){
				return 1; } return 0; } );

			var gotFunctName = 
			 await menu_autocomp_menu_THEN_OUTPUT_2_list_menu(
				tmpPossibleFunctNames,
				level_editor_menu_autocomplete,
					//first menu wrapper
				level_editor_menu_list,
					//out to sub-menu wrapper
				"pick functname (this does NOT test"+
					 "for right behavs)" );
			if( gotFunctName == -1 ){ return;}
			tmp_cmds.push(gotFunctName);
			// use 2 part menu to add
			// OK, pull and reinject
		}if(get_sub_cmd == "clear"){ tmp_cmds = [];
		}if(get_sub_cmd == "remove_entry"){
			if(tmp_cmds.length==0){
				file_input("no items to remove!");
				return;	 }
			var item_remove = await level_editor_menu_list(
				tmp_cmds);
			if( item_remove == -1){ return;}
			tmp_cmds.splice(tmp_cmds.indexOf(item_remove),1);
		}
		
		//putting them back in (basically, making a list:
		var out_list = '"' + tmp_cmds.join('",\n"')+ '"';
		tmp_level_data.level_raw_file_text = 
		  tmp_level_data.level_raw_file_text.split(tmp_data_split);
		if(tmp_cmds.length ==0){
			tmp_level_data.level_raw_file_text[1] = "\n\n";
		}else{ tmp_level_data.level_raw_file_text[1] = 
				"\n" + out_list +"\n"; }
		tmp_level_data.level_raw_file_text = 
		  tmp_level_data.level_raw_file_text.join(tmp_data_split);
		
		level_editor_data__undoRedo_list_add_undo();
		return;
	}
	if(get_cmd == "rmSizeXY"){
		var tmpNumb = await level_editor_menu_autocomplete(
			[], "type a number:").trim();	
		if(tmpNumb == -1){ return;}
		if( isNaN(tmpNumb)){ 
			file_input("ERROR:Not a valid number");}
		var get_sub_cmd = tmpNumb;
		
		var tmp_data_split = "//"+ get_cmd +"//";
		
		tmp_level_data.level_raw_file_text = 
		  tmp_level_data.level_raw_file_text.split(tmp_data_split);
		tmp_level_data.level_raw_file_text[1] = 
			'\n'+ get_sub_cmd +'\n';
		tmp_level_data.level_raw_file_text = 
		  tmp_level_data.level_raw_file_text.join(tmp_data_split);
		
		// so it shows in editor
		level_editor_data__UPDATE_data__and__room(
			level_editor_data__GET_level_loaded(), true);
		
		level_editor_data__undoRedo_list_add_undo();
		return;
	}
	
	if(get_cmd == "_level_editor_loader__room_on_enter_SEED"){	
		var tmpNumb=await level_editor_menu_autocomplete([],
		    "_level_editor_loader__room_on_enter_SEED('null' ok)");
		tmpNumb = tmpNumb.trim();
		if(isNaN(tmpNumb)==1 ||tmpNumb == -1 || 
				tmpNumb==""||tmpNumb=="null"){ 
			tmpNumb = "null";}
		
		tmp_data_split = "//"+ get_cmd + "//";

		tmp_level_data.level_raw_file_text = 
		  tmp_level_data.level_raw_file_text.split(tmp_data_split);
		tmp_level_data.level_raw_file_text[1] = 
			'\n'+ tmpNumb +'\n';
		tmp_level_data.level_raw_file_text = 
		  tmp_level_data.level_raw_file_text.join(tmp_data_split);
		
	}
	if(get_cmd == "rmwarp_use_a_deep_copy_per_spawn"){	
		var tmpBool=await level_editor_menu_list(["true","false"],
		    "rmwarp_use_a_deep_copy_per_spawn set to 'on'?");
		if(tmpBool == -1){ return;}
		
		tmp_data_split = "//"+ get_cmd + "//";

		tmp_level_data.level_raw_file_text = 
		  tmp_level_data.level_raw_file_text.split(tmp_data_split);
		tmp_level_data.level_raw_file_text[1] = 
			'\n'+ tmpBool +'\n';
		tmp_level_data.level_raw_file_text = 
		  tmp_level_data.level_raw_file_text.join(tmp_data_split);
		
	}
	if(get_cmd == "wall_graphic"){	
		var tmpGfx = await level_editor_menu_autocomplete([], 
			"wall_graphic:enter 1 or more character:");
		if(tmpGfx == -1 || tmpGfx.length==0){ return;}
		tmpGfx = tmpGfx.split('"').join("\\\"");
		tmpGfx = '"' + tmpGfx + '"';

		tmp_data_split = "//"+ get_cmd + "//";

		tmp_level_data.level_raw_file_text = 
		  tmp_level_data.level_raw_file_text.split(tmp_data_split);
		tmp_level_data.level_raw_file_text[1] = 
			'\n'+ tmpGfx +'\n';
		tmp_level_data.level_raw_file_text = 
		  tmp_level_data.level_raw_file_text.join(tmp_data_split);
	
	}
	if(get_cmd == "room_type"){
		var tmp_cmds = 
  			["_3d", "_2d", "shadows","shadows_no_lights", 
			"shadows_ignore_walls",
			"shadows3d__requires_mjs_importing_3d_stuff", 
			"_3d__requires_mjs_importing_3d_stuff" ];
	 	var get_sub_cmd =  await level_editor_menu_list(tmp_cmds);
		if(get_sub_cmd == -1 || 
			tmp_cmds.indexOf(get_sub_cmd)==-1){ return;}
	   	if( get_sub_cmd== 
		  "shadows3d__requires_mjs_importing_3d_stuff"){
		    	 get_sub_cmd= "shadows3d";}
	    	if( get_sub_cmd== 
		  "_3d__requires_mjs_importing_3d_stuff"){ 
			get_sub_cmd= "_3d";}
		// injecting into data...
		var tmp_data_split = "//"+ get_cmd +"//";

		tmp_level_data.level_raw_file_text = 
		  tmp_level_data.level_raw_file_text.split(tmp_data_split);
		tmp_level_data.level_raw_file_text[1] = 
			'\n"'+ get_sub_cmd +'"\n';
		tmp_level_data.level_raw_file_text = 
		  tmp_level_data.level_raw_file_text.join(tmp_data_split);

		level_editor_data__UPDATE_data__and__room( 
			level_editor_data__GET_level_loaded(true));
		
		level_editor_data__undoRedo_list_add_undo();
	}
}

async function level_editor_menu__SAVE_LOAD_Menu(){
	//pulling room data, or template
	var tmp_level_name = rmloaded_room.level_name;		
	if(tmp_level_name != null){
		var tmp_level_data = ROWS_FILTER(
		  level_editor_data__caught_files_SCHEMA,
		   function(a,b){if(a.level_name == b){ return 1;}
				return 0; }, 
			tmp_level_name)[0];	
	}else{ var tmp_level_data = null;}

	//updating level_raw_text_data... (NOT running if no file loaded)
	if(_level_data_get_level_data_loaded_catch!=null){
	   level_editor_data__UPDATE_data__and__room(
		level_editor_data__GET_level_loaded(), true);}
	
	var get_cmd = await level_editor_menu_list(
		["Load_previously_loaded/saved_level",
		"Save_as",
		"Save",
		"Load",
		"Rescan_files(saves file first)"], 
		"NOTE: m.js/m.loadlate.js are NOT scanned for rms/objs");
	if(get_cmd == "Save"){ level_editor_menu__SAVE(); return;}
	if(get_cmd == "Save_as"){ level_editor_menu__SAVE_AS(); return;}
	if(get_cmd == "Load"){ level_editor_menu__LOAD(); return;} 
	if(get_cmd == "Load_previously_loaded/saved_level"){
		var get_lvl = level_editor_data__get_item_recent( 
			"CAUGHT_LOADED_level_names_list");
		
		rmloaded_room.level_name = get_lvl;
		level_editor_data__undoRedo_clear();
		if(level_editor_data__GET_level_loaded( true) == null){
			return;};
		level_editor_data__UPDATE_data__and__room(
	   		level_editor_data__GET_level_loaded( true), true );
		level_editor_data__undoRedo_list_add_undo();
	}
	if(get_cmd == "Rescan_files(saves file first)"){
		level_editor_menu__SAVE();
		level_editor_data__load_files_SCHEMA(); 
		level_editor_data__UPDATE_data__and__room(
	   		level_editor_data__GET_level_loaded( true), true );
		return;
	}
}

// if first input is a entry, ignores list-menu
// 	returns -1 if undefined
async function menu_autocomp_menu_THEN_OUTPUT_2_list_menu(
	getLaunch_word_list_that_can_run,
	getLaunch_autocomp_menu_wrapper_2inputs_wordList_txtArrOptions,
	getLaunch_list_menu_wrapper_1inputs_wordList_txtdisp,
	get_txt_to_display ){
	
	tmpObjNamesMakable = getLaunch_word_list_that_can_run;

	//MENUS (first type to select):
	var tmp_choice = await 
	   getLaunch_autocomp_menu_wrapper_2inputs_wordList_txtArrOptions(
			tmpObjNamesMakable, get_txt_to_display);
	if(tmp_choice == -1 || tmp_choice == ""){ return -1;}
	//MENUS, SUB (lists of items, if didn't type in FULL name)
	if(!level_editor_data__is_rmloaded_compatable_obj(
		progen_dotnote(tmp_choice))){
			
		var tmpObjNamesMakable = tmpObjNamesMakable.filter(
		function(a){if(a.indexOf(tmp_choice)!=-1){return 1;}
				return 0; });
			
		if(tmpObjNamesMakable.length == 1){
			tmp_choice = tmpObjNamesMakable[0]; 
		}else if(tmpObjNamesMakable.length!=0){
		 var tmp_choice = 
		 await getLaunch_list_menu_wrapper_1inputs_wordList_txtdisp(
				tmpObjNamesMakable); }
	}
	return  tmp_choice;
		
}
