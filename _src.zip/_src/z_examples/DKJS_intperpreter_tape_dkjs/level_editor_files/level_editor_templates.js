//
//TODO:
//	--- get this working across board: 
//		--- one section for saving text with a level-name
//	--- once I this working on ANY text string,
//		--- scrub ALL SOURCE for comments/etc:
//			I can audit/refactor WHILE doing this
//			(make templates where relevent) 
async function level_editor_template__save_menu(){
	var tmpMenuOut = await level_editor_menu_list(
		["(for level template, just 'save' a blank level)",
	   	"(use 'draw-mode' for related 'objs'/'graphics' templates",
		"Save convo template",
		"(gui-menus/textboxes: NA- see 'gui_n_gui_menus.js'",
		"----------(for examples)",
		"(mml/mml_status-see ml.js (there are behaviors there))'",
		"----------(for examples)",
		]);
	if(tmpMenuOut == -1){ return;}

	var tmpSaveText = null;
	if(tmpMenuOut == "Save convo template"){
		var tmpSaveText = "Enter var-name of convo-template:";
		var tmpSaveTemplate_text = 
			level_editor_template__convo_template_COPY;
	}else if(tmpMenuOut == 
	   "---------"){
		var tmpSaveText = "-----";
		var tmpSaveTemplate_text = 
			"--------";
	}else if(tmpMenuOut == 
	   "---------"){
		var tmpSaveText = "-----";
		var tmpSaveTemplate_text = 
			"--------";
	}else if(tmpMenuOut == 
	   "---------"){
		var tmpSaveText = "-----";
		var tmpSaveTemplate_text = 
			"--------";
	}else if(tmpMenuOut == 
	   "---------"){
		var tmpSaveText = "-----";
		var tmpSaveTemplate_text = 
			"--------";
	}
	
	if(tmpSaveText == null){ return;}
	
	//saving....
	var getSave_as = level_editor_menu__SAVE_AS( 
			"Enter var-name of convo:", true);
	//getAlternativeStr_to_askFor_instead_of_levelname_OPTIONAL,
	//getReturn_level_n_file_name_ONLY__NO_SAVING_OPTIONAL
	//{filename:tmpFileName, levelname:tmpLevelName}
	
	if(getSave_as != null){
		file_save( file_dir_cd(), getSave_as.filename, 
			"var " + getSave_as.levelname + " = \n" +
			  String.fromCharCode(96) +//multiline str char 
				tmpSaveTemplate_text +
			String.fromCharCode(96) +//multiline str char
				";\n"); }
}




// in level_editor_menu.js
var level_editor_template__convo_template = `

@@ 0 @? CONVO-ENGINE COMMENT, this template in:'m.level_editor_menu.js' 
	NOTE: think of this as 'mml-like'
	//LEVEL_EDITOR_CONVO_IF_STR_HAS_THIS_STR//
@@ 
## 0 #? PREPROCESSOR-COMMENT ( "0 @ #" is auto-failling if statement)
	-- preprocessor should work in mml, too, same preprocessor,
		I think. Allows redrawin stuff per 'goto' or 
		running a convo (or mml-reset): meaning convos are easy to 
		procedrually generate. 
	-- delete what is not needed, this template is more of a demo 
##
## 0 #? COMMENT: TAGS/GOTO
	TAGS: used with 'goto' and variants
	-- @@ !!start @@  <--tags look like this: 
	-- these work: (or tag reuse):
		@@ goto_prev,, "!!TAG_NAME" @@
		@@ goto_next,, "!!TAG_NAME" @@
	--  @@ goto ,, 1,, "!!TAG_NAME" @@ 
			 '1' here is 'reroll preprocessor on goto',
			 same as below:
	--  @@ goto ,, 1,, "TMP_CONVO_GLOBAL_VAR_SUBCONVO" @@ 
	-- @@ goto_menu,, 1,, "testing goto_menu... ",, 
		"Goto sub-convo :tmp_global_convo_test",,
		"Goto sub-convo funct :tmp_global_convo_test_funct",,	
		 "question1 gotoEnd :gotoEND
		   --run a testroll 'if' statement script :goto_testRoll
		   --ask1 goto1(run normally):goto1
		   --ask2 goto2(run normally2):goto2"  @@ 
		(CAN KEEP ADDING ENTRIES TO ABOVE, IT'S VIARDIC!!!
		    (and last text block is read as a list of entries))
##
@@ !!start @@

@@ set,, TMP_CONVO_GLOBAL_VAR_SUBCONVO,, 
	" this is a sub conversation string, format like this conversation script! (I think indefinitely nexing!!)" @@
@@ goto ,, 1,, "TMP_CONVO_GLOBAL_VAR_SUBCONVO" @@ 

@@ set,, tmpConvoGlobal_var_to_text_display = "display this text!" @@

@@ display ,,caption,, "caption"@@
@@ display ,,text,, "some text (can be dotnote entry!)",, "or more!",,
	"and more!",, 
	tmpConvoGlobal_var_to_text_display @@
@@ display ,,bg_as_lastdraw,, ""@@
@@ display ,,clear,, ""@@  
@@ display ,,clear2strtbg,, ""@@  

displays text between commands, too! (gotta set caption seperately!)
(this is mostly normal way to display text, use display-caption  (above...)
(to set captions for text like this!) 

@@ file_input,, "running external function param1", "param2 exc." @@    
	## 0 #? try to limit external functions, use conov-builtins!##

a ('RIGHT' is as of writing this the 'goto-next' thing in the text!
  'LEFT' goes back if in same txt-block!)

## 0 #? COMMENT: ROLLS and IF STATMENTS:
	all statments can have an 'if' qualifier (like this comment's
	auto-fail before the '?') ALSO: global vars 
	otxtPlayer and 
	otxtOther are input at the start of command,
	(see below! )
##

## 0 #? Setting these can be done to any global vars ##

@@ set,, otxtPlayer.y = 20 @@
@@ set,, otxtPlayer.playerX = 30 @@
@@ set,, otxtOther.y = 40 @@
@@ set,, otxtOther.playerX = 50 @@

@@ ROLL ,, 1,, 50,, "otxtPlayer.y otxtPlayer.playerX",, 
 "testing ROLL(should file_input on PASS)" 
@? file_input,,"PASS" @@

@@ ROLL_SAVING ,, 1,, 50,, "otxtOther.y otxtOther.playerX",, 
 "testing ROLL_SAVING(should file_input on FAIL)" 
@? file_input,,"FAIL" @@

## 0 #? COMMENT: ALL VARS ARE GLOBAL/DOTNOTE IN CONVOS!!! ##


PREPROCESSORS can be put ANYWHERE including in preprocessors:
## 0 #? below reads the global var, then pastes it, and runs
	preprocessor a second time: should read 'read from 'BLABLABLA' ##
 ## ### g_convo__4_LEVEL_EDITOR_PREPROCESSOR_TEST_A ### ## 


Lists placed as preprocessor directives draw 1 item from list at random:
## g_convo_run__4_LEVEL_EDITOR_TEMPLATE_LIST ## 
## g_convo_run__4_LEVEL_EDITOR_TEMPLATE_LIST ##

list linear ( param 2 ==0) ( ALSO WORKS: param 2==1 (randomized list draw
	(and with a number > 1- draws that number of items)
	(for drawing 1 item, see above 
		(it's just put list-name in preprocessor)) :
### LISTPROCESS;; 0;; "tmp_i";; g_convo_run__4_LEVEL_EDITOR_TEMPLATE_LIST 
	;; "Give me a : -- ##tmp_i## -- " ###

SETTING AND IF-THEN STATEMENTS (functs OR see below for ==/<=, etc)

@@ set_list_item,, g_convo_run__4_LEVEL_EDITOR_TEMPLATE_LIST ,, 1,, "this set list item" @@
@@ display ,,"text",, g_convo_run__4_LEVEL_EDITOR_TEMPLATE_LIST.1@@ 

@@ set,, tmpGlobal_CONVO_SET_TMP_NUMB = 0 @@
@@ tmpGlobal_CONVO_SET_TMP_NUMB <= 1 @? 
	file_input,, tmpGlobal_CONVO_SET_TMP_NUMB @@

@@ set,, tmpGlobal_CONVO_SET_TMP_NUMB += 1 @@
@@ tmpGlobal_CONVO_SET_TMP_NUMB >= 200 @? goto ,, 1,, "start" @@
above one shoudl not run!

`;
var level_editor_template__convo_template_COPY  =
	level_editor_template__convo_template;


// FORMATTING IS TO PREVENT REMOVAL OF LINES STARTING WITH '//'
// 	(COMPILED VERSION HAS ISSUES SCRUBBING THIS!!!)

// was level_editor_data__SAVE_DATA_TEMPLATE
// 	(found in level_editor_menu.js)
var level_editor_template__SAVE_LEVEL_DATA = 
`
; // this template in :'level_editor_templates.js' 

; //level_editor_block//
;///////////////////////////////////////////
; /////////////////////OBJS GENERATED BY LEVEL_EDITOR__ARE__PROGENED!!!
; // can use creative naming & funct below to auto-make lists:
; // level_editor_loader__get_global_objs_named_like( 
; //		getTextToLookFor, useCatched_results_OPTIONAL)
var //level_name//
NAME_HERE  		//level_name//
 =
{ 
_level_name: //level_name//
NAME_HERE   		//level_name//
,
rmSizeXY: //rmSizeXY//
35  		//rmSizeXY//
,
objs:[], objs_large:[], // <-CLEARED WITH BELOW BEHAV TO ALLOW RM RELOAD
enter_behavs:[ "level_editor_loader__room_on_enter_behav", //enter_behavs//  //enter_behavs// 

],  
update_behavs:[ //update_behavs// //update_behavs// 
], 
leave_behavs:[ //leave_behavs// //leave_behavs// 

],  //DEFAULT: null
_level_editor_loader__room_on_enter_SEED:  //_level_editor_loader__room_on_enter_SEED//
null 		//_level_editor_loader__room_on_enter_SEED//
,
rmwarp_use_a_deep_copy_per_spawn: //rmwarp_use_a_deep_copy_per_spawn//
true 		//rmwarp_use_a_deep_copy_per_spawn//
, ///////////BELOW FOR 'g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav'
wall_graphic: //wall_graphic//
"##"  		//wall_graphic//
,

room_type: //room_type// 
"_2d" 		//room_type//
,

_level_editor_data: //_level_editor_data//
[] 		//_level_editor_data//

} //level_editor_block//
`;


// in level_editor_draw.js
var level_editor_template__save_draw_obj_TEMPLATE= JSON.stringify(
   	{x:0, y:0, behavior:"level_editor_loader__draw_animation__behav", 
   	graphic:"REWORKED_IN_BEHAV", 
 	colgroup:"0", ignore_pause:false, draw_1late_2last:1, dead:0});


// the '; //' here is becuase the system scrubbs lines starting with '//'
//	FOUND IN: level_editor_draw_mode.js
var level_editor_template__draw_GRAPHIC_FRAMES_TEMPLATE = // graphic_frames == anim
`
; /////////// this template in :'m.level_editor_draw_mode.js'
 
; //level_editor_block//  
; //TYPE_GRAPHIC_FRAMES//  <- needed, or processed as level, not 'frames'...
; //////////////////////
; /// NOTE: Objects dont automatically use this, 
; //	set 	o.graphic_frames__dotnote 
; //			AND
; //		o.graphic_frames__delay_between_frames //<-anim speed
; //	in objs and run (set as behav or embed in behav):
; //		level_editor_loader__draw_animation__behav(o)
; //	(can swap o.graphic_frames__dotnote to change animations!) 
; /////////////////////	
var //level_name//
level_editor_loader__draw__DEFAULT_graphic_frames	//level_name//
 =  //list of frames (animation) 	//_level_editor_data//
[

]		//_level_editor_data//
;	//level_editor_block//
`.split(";;").join("");



