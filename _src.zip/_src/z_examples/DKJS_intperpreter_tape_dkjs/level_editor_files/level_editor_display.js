
var level_editor_display_rmSizeXY_CAUGHT_SIZE = null;
var level_editor_display_rmSizeXY_outline_CAUGHT_VERT_GFX= null;
var level_editor_display_rmSizeXY_outline_CAUGHT_HORIZ_GFX= null;
var level_editor_display_rmSizeXY_TIMER = 0;
var level_editor_display_rmSizeXY_char = "x";
function level_editor_display_rmSizeXY_outline(){
	if( rmloaded_room.rmSizeXY 
			!=level_editor_display_rmSizeXY_CAUGHT_SIZE){
		level_editor_display_rmSizeXY_outline_CAUGHT_VERT_GFX =null;
		level_editor_display_rmSizeXY_outline_CAUGHT_HORIZ_GFX=null;}
	if(level_editor_display_rmSizeXY_outline_CAUGHT_VERT_GFX == null){
		level_editor_display_rmSizeXY_outline_CAUGHT_VERT_GFX = 
		gridstr_scale(level_editor_display_rmSizeXY_char
			, 1, rmloaded_room.rmSizeXY+3);	}
	if(level_editor_display_rmSizeXY_outline_CAUGHT_HORIZ_GFX == null){
		level_editor_display_rmSizeXY_outline_CAUGHT_HORIZ_GFX = 
		gridstr_scale(level_editor_display_rmSizeXY_char
			,  rmloaded_room.rmSizeXY+3, 1);	}
	
	// so it blinks:
	if( (level_editor_display_rmSizeXY_TIMER +=1) % 16 > 3){
		rmloaded_draw_overlay(
		  level_editor_display_rmSizeXY_outline_CAUGHT_HORIZ_GFX,
			_rmloaded_camera_x-1, _rmloaded_camera_y-1, "-");
		rmloaded_draw_overlay(
		  level_editor_display_rmSizeXY_outline_CAUGHT_VERT_GFX,
			_rmloaded_camera_x-1, _rmloaded_camera_y-1, "-");
		rmloaded_draw_overlay(
		  level_editor_display_rmSizeXY_outline_CAUGHT_HORIZ_GFX,
			_rmloaded_camera_x -1, 
			1+_rmloaded_camera_y +rmloaded_room.rmSizeXY,"-");
		rmloaded_draw_overlay(
		  level_editor_display_rmSizeXY_outline_CAUGHT_VERT_GFX,
			1+ _rmloaded_camera_x + rmloaded_room.rmSizeXY, 
			-1 + _rmloaded_camera_y, "-");
		// drawing midpoints:
		rmloaded_draw_overlay(
		  level_editor_display_rmSizeXY_char,
		    _rmloaded_camera_x -2, 
		    _rmloaded_camera_y +(rmloaded_room.rmSizeXY/2),"-");
		rmloaded_draw_overlay(
		  level_editor_display_rmSizeXY_char,
			 _rmloaded_camera_x +(rmloaded_room.rmSizeXY/2), 
			-2 + _rmloaded_camera_y, "-");
		rmloaded_draw_overlay(
		  level_editor_display_rmSizeXY_char,
		    2+ _rmloaded_camera_x + rmloaded_room.rmSizeXY, 
		    _rmloaded_camera_y +(rmloaded_room.rmSizeXY/2),"-");
		rmloaded_draw_overlay(
		  level_editor_display_rmSizeXY_char,
			 _rmloaded_camera_x +(rmloaded_room.rmSizeXY/2), 
			2 + _rmloaded_camera_y + rmloaded_room.rmSizeXY, 
			"-");
		// drawing center
		rmloaded_draw_overlay(
		  level_editor_display_rmSizeXY_char,
			 _rmloaded_camera_x +(rmloaded_room.rmSizeXY/2), 
			 _rmloaded_camera_y + (rmloaded_room.rmSizeXY/2), 
			"-");
	}
}

//set to level_editor_display__
function level_editor_display__cursor_cycle_objlist(get_next_or_last){//str
	if(level_editor_display__prev_objlist_cursors.length ==0){ return;}
	if(get_next_or_last == "next"){ 
		level_editor_display__prev_objlist_cursors.push(
			level_editor_display__cursor_objs_to_add);
		level_editor_display__cursor_objs_to_add = 
		    level_editor_display__prev_objlist_cursors.shift();}
	if(get_next_or_last == "last"){
		level_editor_display__prev_objlist_cursors.unshift(
			level_editor_display__cursor_objs_to_add);
		level_editor_display__cursor_objs_to_add = 
			level_editor_display__prev_objlist_cursors.pop();
	} 
}

var level_editor_display__prev_objlist_cursors = [];
function level_editor_display__copy_objlist_to_cursor(getObjs,
		OPTIONAL_use_level_editor_data_type_as_getObjs){
	
	level_editor_display__prev_objlist_cursors.push(
			level_editor_display__cursor_objs_to_add);
	if( level_editor_display__prev_objlist_cursors.length > 10){
		level_editor_display__prev_objlist_cursors.unshift(); }
	
	level_editor_display__cursor_objs_to_add =[];
	if(OPTIONAL_use_level_editor_data_type_as_getObjs){
		var tmpKey = "obj_dotnote_name";
	}else{ var tmpKey = "_level_editor_data_dotnote_name";}
	
	for(var i=0; i< getObjs.length; i+=1){
		level_editor_display__cursor_objs_to_add.push(
		{	x:(getObjs[i].x- 
				(controller_mouse_x -_rmloaded_camera_x)), 
		  	y:(getObjs[i].y- 
				(controller_mouse_y -_rmloaded_camera_y)),
			obj_dotnote_name:
			   (getObjs[i][tmpKey])});
	}
}


////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
//	Below should be labeled 'display'
//
var level_editor_display__box_select_on = false;
var _level_editor_display__box_x_start = 0; 
var _level_editor_display__box_y_start = 0;
var _level_editor_display__box_x_end = 0; 
var _level_editor_display__box_y_end = 0;
function _level_editor_display__box_select__is_running(){ 
	return level_editor_display__box_select_on; }
function _level_editor_display__box_select__start(){ 
	level_editor_display__box_select_on = true;
	_level_editor_display__box_x_start = 
		controller_mouse_x -_rmloaded_camera_x;
	_level_editor_display__box_y_start = 
		controller_mouse_y -_rmloaded_camera_y; }
var _level_editor_display__box_update_blinker_timer = 0;
function _level_editor_display__box_select_update(){
	_level_editor_display__box_x_end = 
		controller_mouse_x -_rmloaded_camera_x;
	_level_editor_display__box_y_end = 
		controller_mouse_y -_rmloaded_camera_y;
	
	_level_editor_display__box_update_blinker_timer+=1;
	var tmpC = "X"; //tmp draw char
	if(_level_editor_display__box_update_blinker_timer %3 ==2){ 
		var tmpC = " ";}
	if(_level_editor_display__box_update_blinker_timer %3 ==1){
	  //drawing corners
	  rmloaded_draw_overlay(tmpC, 
		_level_editor_display__box_x_start + _rmloaded_camera_x, 
		_level_editor_display__box_y_start + _rmloaded_camera_y, 
		"");
	  rmloaded_draw_overlay(tmpC, 
		_level_editor_display__box_x_start + _rmloaded_camera_x, 
		_level_editor_display__box_y_end + _rmloaded_camera_y, "");
	  rmloaded_draw_overlay(tmpC, _level_editor_display__box_x_end
		 + _rmloaded_camera_x, 
	      _level_editor_display__box_y_start + _rmloaded_camera_y, "");
	  rmloaded_draw_overlay(tmpC, 
	    _level_editor_display__box_x_end + _rmloaded_camera_x, 
	    _level_editor_display__box_y_end + _rmloaded_camera_y, "");
	}
}


var _level_editor_display__obj_under_mouse_blink_timer = 0;
var _level_editor_display__obj_under_mouse_blink_frames_per_step = 7;
var _level_editor_display__obj_under_mouse_blink_timer_step = 0; //on which obj
// this is for this file ONLY
function _level_editor_display__objs_under_cursor(getRm, 
		filter_by_obj_key_OPTIONAL,
		 return_list_of_values_for_this_obj_key_OPTIONAL,
		getX, getY){ // to draw at
	var tmpObjs = 
	   _level_editor_display__get_objs_under_cursor__NOT_EFFICIENT( 
		getRm,
		filter_by_obj_key_OPTIONAL, //string
		return_list_of_values_for_this_obj_key_OPTIONAL );
	if(tmpObjs.length==0){ return; }
	
	_level_editor_display__obj_under_mouse_blink_timer+=1;
	if(_level_editor_display__obj_under_mouse_blink_timer >
	  _level_editor_display__obj_under_mouse_blink_frames_per_step ) {
	   
	   _level_editor_display__obj_under_mouse_blink_timer = 0;
	   _level_editor_display__obj_under_mouse_blink_timer_step +=1; }
	if(_level_editor_display__obj_under_mouse_blink_timer_step 
			>= tmpObjs.length){
	   _level_editor_display__obj_under_mouse_blink_timer_step =0; }
	
	// OK, main room contents goes here!
	rmloaded_draw_overlay( "" + tmpObjs[
		_level_editor_display__obj_under_mouse_blink_timer_step ],
		getX, getY);
}

//to display...
//update on mouse change loc? 
var _level_editor_display__get_objs_under_cursor_last_x=0; 
var _level_editor_display__get_objs_under_cursor_last_y=0;
var _level_editor_display__get_objs_under_cursor_last_results=[];
// using below because it does NOT use collisions, so works 
// 	with ALL objects. (normally, use colgroups!)
function _level_editor_display__get_objs_under_cursor__NOT_EFFICIENT( 
		getRm,
		filter_by_obj_key_OPTIONAL, //string
		return_list_of_values_for_this_obj_key_OPTIONAL ){ //string
	
	if(tmpX == _level_editor_display__get_objs_under_cursor_last_x &&
	    tmpY ==_level_editor_display__get_objs_under_cursor_last_y){
	      return 	
	       _level_editor_display__get_objs_under_cursor_last_results;}
	//return list! 
	var tmpX =(controller_mouse_x -_rmloaded_camera_x); 
	var tmpY =(controller_mouse_y - _rmloaded_camera_y ); 
	var tmpReturn_objs = [];
	// objs (small)
	var tmpObjs = getRm.objs;
	for(var i=0; i< tmpObjs.length; i+=1){ var tmpObj = tmpObjs[i];
		if( tmpObj.x == tmpX && tmpObj.y== tmpY){
			tmpReturn_objs.push(tmpObj);}	}
	// objs (large)
	var tmpObjs = getRm.objs_large;
	for(var i=0; i< tmpObjs.length; i+=1){ var tmpObj = tmpObjs[i];
		if(tmpObj.x <= tmpX && 
		     tmpObj.x+ gridstr_width(tmpObj.graphic)>tmpX 
		    && tmpObj.y <= tmpY 
			&& tmpObj.y+ tmpObj.graphic.split("\n").length 
				> tmpY){
			tmpReturn_objs.push( tmpObj ); } }
	// filtering if needed: 
	if(	filter_by_obj_key_OPTIONAL	){
		tmpReturn_objs = ROWS_FILTER( tmpReturn_objs,
		  function(a,b){if(a[b]!=undefined){return 1;}return 0},
			filter_by_obj_key_OPTIONAL)
	}
	// mapping, if needed
	if(	return_list_of_values_for_this_obj_key_OPTIONAL	){
		tmpReturn_objs = ROWS_MAP( tmpReturn_objs,
		  function(a,b){return a[b]; },
			return_list_of_values_for_this_obj_key_OPTIONAL)
	}
	_level_editor_display__get_objs_under_cursor_last_results 
		= tmpReturn_objs;
	return tmpReturn_objs;
}


//to display...
function level_editor_display__box_select__end_n_reset__GET_CORDINATES(
		getRm,
		getON_SCREEN_chords_OPTIONAL){
	level_editor_display__box_select_on = false;
	if(_level_editor_display__box_x_start > 
			_level_editor_display__box_x_end){
		var tmpX = _level_editor_display__box_x_start; 
		_level_editor_display__box_x_start = 
			_level_editor_display__box_x_end;
		_level_editor_display__box_x_end = tmpX;  }
	if(_level_editor_display__box_y_start > 
			_level_editor_display__box_y_end){
		var tmpY = _level_editor_display__box_y_start; 
		_level_editor_display__box_y_start = 
			_level_editor_display__box_y_end;
		_level_editor_display__box_y_end = tmpY;  }
	if(getON_SCREEN_chords_OPTIONAL != true){
		return {x_start : _level_editor_display__box_x_start, 
			x_end : _level_editor_display__box_x_end,
			y_start : _level_editor_display__box_y_start, 
			y_end : _level_editor_display__box_y_end};
	}else{
		// undoing I THINK is baked in offset
		return {x_start : (_level_editor_display__box_x_start 
				+ _rmloaded_camera_x), 
			x_end : (_level_editor_display__box_x_end 
				+ _rmloaded_camera_x),
			y_start : (_level_editor_display__box_y_start
				+ _rmloaded_camera_y), 
			y_end : (_level_editor_display__box_y_end
				+ _rmloaded_camera_y)};
}	}
//to display...
function level_editor_display__box_select__end_get_results_n_reset(getRm, 
		getPick_up_objs_ONLY_fully_in_box_OPTIONAL,
		getFilter_for_str_obj_key_OPTIONAL){
		//must be running,or no use, 
	level_editor_display__box_select_on = false;
	if( _level_editor_display__box_x_start> 
			_level_editor_display__box_x_end){ 
		var tmp_i = _level_editor_display__box_x_end;
		_level_editor_display__box_x_end = 
			_level_editor_display__box_x_start; 
		_level_editor_display__box_x_start = tmp_i; }
	if( _level_editor_display__box_y_start> 
			_level_editor_display__box_y_end){ 
		var tmp_i = _level_editor_display__box_y_start;
		_level_editor_display__box_y_end = 
			_level_editor_display__box_y_start; 
		_level_editor_display__box_y_start = tmp_i;}  

	var tmp_box_select_small_objs = [];
	var tmp_box_select_large_objs = [];

	// small objs
	for(var i=0; i< getRm.objs.length; i+=1){
		var tmpObj = getRm.objs[i];
		if( tmpObj.x <= _level_editor_display__box_x_end 
			&& tmpObj.x >= _level_editor_display__box_x_start 
		   && tmpObj.y <= _level_editor_display__box_y_end  
			&& tmpObj.y >=_level_editor_display__box_y_start){
			tmp_box_select_small_objs.push( tmpObj ); }  }
	
	// large objs
	for(var i=0; i< getRm.objs_large.length; i+=1){
		var tmpObj = getRm.objs_large[i];
		// Axis-Aligned Bounding Box detection (edge col OK)
		if(!getPick_up_objs_ONLY_fully_in_box_OPTIONAL){
		  if( tmpObj.x <= _level_editor_display__box_x_end && 
		     tmpObj.x+ gridstr_width(tmpObj.graphic)>
			_level_editor_display__box_x_start 
		    && tmpObj.y <= _level_editor_display__box_y_end 
			&& tmpObj.y+ tmpObj.graphic.split("\n").length 
				> _level_editor_display__box_y_start){
			tmp_box_select_large_objs.push( tmpObj ); }  
		}else{// Axis-Aligned Bounding Box detection (fully in box
		  // ONLY
		  // if(!getPick_up_objs_ONLY_fully_in_box_OPTIONAL){
		  if( tmpObj.x >= _level_editor_display__box_x_start && 
		     tmpObj.x+ gridstr_width(tmpObj.graphic)<
			_level_editor_display__box_x_end 
		    && tmpObj.y >= _level_editor_display__box_y_start
			&& tmpObj.y+ tmpObj.graphic.split("\n").length 
				< _level_editor_display__box_y_end ){
			tmp_box_select_large_objs.push( tmpObj ); }  }

	}

	//filtering out getFilter_for_str_obj_key_OPTIONAL, 
	if( typeof getFilter_for_str_obj_key_OPTIONAL == "string"){
		tmp_box_select_small_objs = 
		    ROWS_FILTER(tmp_box_select_small_objs, 
			function(a,b){ // item, config (below!)
			  if(a[b]!=undefined){return 1;} return 0;}, 
			getFilter_for_str_obj_key_OPTIONAL);
		tmp_box_select_large_objs = 
		    ROWS_FILTER(tmp_box_select_large_objs, 
			function(a,b){ // item, config (below!)
			  if(a[b]!=undefined){return 1;} return 0;}, 
			getFilter_for_str_obj_key_OPTIONAL);
	}

	return {objs:tmp_box_select_small_objs, 
	   objs_large: tmp_box_select_large_objs};
}



var level_editor_display__cursor_objs_to_add = []; // list of objs, large small works, 
				// splits them on create.
				// DATA:
		// { x:?, y:?, obj_dotnote_name:?}
//cursor_objs_added_one_last_move={x:-1, y:-1};
	//so can add more if mouse held down

/////////////////////////////////////
///////// :b: CURSOR SET OBJS FROM MENU :b:
/////////////////////////////////////
/////////////////////////////////////

async function level_editor_display__set_level_editor_display__cursor_objs_to_add__from_menu(){
	var tmpObj = await level_editor_menu_get__compatible_obj(
		level_editor_data__is_rmloaded_compatable_obj, true,
			"Type in part/all of a OBJ NAME to use:");
	if(tmpObj!= null){
		level_editor_display__cursor_objs_to_add=[{obj_dotnote_name:tmpObj, x:0, y:0}];}
}


var _level_editor_display__cursor_timer = 0;// only counts up, 1 per turn
function level_editor_display_cursor_and_objects_in_cursor(
		getCursor_objs_to_add){
	_level_editor_display__cursor_timer +=1;
	if( _level_editor_display__cursor_timer % 8 <3){ 	
		if(level_editor_display__cursor_objs_to_add.length ==0){	
	  		rmloaded_draw_overlay(
			  "X", controller_mouse_x, controller_mouse_y);
		}else{	//drawing objs to put down 
				// (if any in level_editor_display__cursor_objs_to_add...)
			for(var i=0; i< level_editor_display__cursor_objs_to_add.length; i+=1){
			  rmloaded_draw_overlay(
			       //progen_dotnote__return_obj_if_JSON_string(
				progen_dotnote(
				level_editor_display__cursor_objs_to_add[i]
				.obj_dotnote_name )
				.graphic,
			   
			    level_editor_display__cursor_objs_to_add[i].x 
				+ controller_mouse_x,
			    level_editor_display__cursor_objs_to_add[i].y 
				+ controller_mouse_y);
		}  }
	}else if( _level_editor_display__cursor_timer % 8 <5){	 
		rmloaded_draw_overlay(
			" ", controller_mouse_x, controller_mouse_y);
	}

}

