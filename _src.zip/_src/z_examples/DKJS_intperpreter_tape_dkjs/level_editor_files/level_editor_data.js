
// level_editor_loader__in_autoload__load_init_tag --- data
// { 
//    room_name_dotnote:"", 
//    default_player_obj_dotnote:"", // or null, only works if warpInPL...
//    					// is defined, OR rmwarp is. 
//    warpInPlayerXY_overrides_rmwarp:{x:23, y,23}, // or null
//    use_rmwarp:false, 
//    use_rmwarp_direction:"left", //or null
//
//	//below vars NOT related to any of above...
//    level_editor_last_loaded_STORING_HERE_FOR_EASE: null
// }





///////////////////////////////////////////
// getRm._level_editor_data =  [ { x:?, y:?, obj_dotnote_name:?} ... ];
//	(in obj:)
// getObj._level_editor_data_dotnote_name = (above.obj_dotnote_name)
////////////////////////
//removes based on x/y/obj_dotnote_name
async function level_editor_data__remove_objs_from_level_data( getObjs){
	if(getObjs.length==0){return;}
	var getData = level_editor_data__GET_level_loaded();
	
	getData.level_data = ROWS_FILTER( 
		getData.level_data,
		function(getLevelData, getObjGroups){ 
			var tmpGroup = getObjGroups[
				getLevelData.obj_dotnote_name];
			if(tmpGroup== undefined){return 1;} 
			
			for(var i=0; i< tmpGroup.length; i+=1){
			   if(tmpGroup[i].x == getLevelData.x 
				 && tmpGroup[i].y == getLevelData.y){
					return 0;}  }
			return 1; },
		ROWS_GROUPBY( //now ordered by obj name
			getObjs, "_level_editor_data_dotnote_name") );
	
	await level_editor_data__UPDATE_data__and__room( getData);	
	level_editor_data__GET_level_loaded(true);

}

 
//getRM: { ...
//	_level_editor_data: //_level_editor_data:NAME_OF_LEVEL//
//		(the data)
//	//_level_editor_data:NAME_OF_LEVEL//
//	--- can use same naming convention for 
//		behavs_update/enter
//	;
//
if( typeof level_editor_data__caught_files_SCHEMA  == "undefined"){
     var level_editor_data__caught_files_SCHEMA = [];}//see below datatype
//		{ level_data: tmp_level_data, 
//		level_raw_file_text: tmp_file_data_raw, 
//		level_name: tmp_level_name,
//		file_name: tmp_file_name }

////TYPE_GRAPHIC_FRAMES//
if( typeof level_editor_data__caught_graphic_frames_SCHEMA  == "undefined"){
     var level_editor_data__caught_graphic_frames_SCHEMA = []; }
//		{ level_data: tmp_level_data, 
//		level_raw_file_text: tmp_file_data_raw, 
//		level_name: tmp_level_name,
//		file_name: tmp_file_name }


// ran on start!
//schema/Schema Update (this comment is to allow searching)
async function level_editor_data__load_files_SCHEMA( 
	   getFirstRun_DONT_reload_js_files_as_game_does_that_OPTIONAL){
	// updating and reloading files (this is needed if 
	//     running on an outside directory/as a dkjs-stand-alone-prog)
	await level_editor_loader__update_autoload_files_if_available();
	if(1 !=getFirstRun_DONT_reload_js_files_as_game_does_that_OPTIONAL){
		//for "m._autoload_n_configs_n_start_level.js"
		await level_editor_loader__load_m_autoload__NO_EMBED( );
	}		

	var tmpfiles= file_dir_search( file_dir_cd(), 6,["js$"],
		["m.level_editor_draw_mode.js$"]); //exclude these files..
	
	//, ["js$"], []);
	var tmpfiles_data = [];
	var tmpFrames_data = [];
	
	for(var i=0; i< tmpfiles.length; i+=1){

		var tmp_file_name = tmpfiles[i];
		var tmp_file_data_raw = 
			file_load_noembed( tmp_file_name,"");
		tmp_file_data = tmp_file_data_raw.split(
				"//"+"level_editor_block//");
	
		//ADDED on 5/22/2026 for ONLINE VERSION (VFS)
		var tmp_file_name_OUT = tmp_file_name
			.split(file_dir_cd())[1];
		if(tmp_file_name_OUT == undefined){
			tmp_file_name_OUT = tmp_file_name; }
		tmp_file_name = tmp_file_name_OUT;


		if(tmp_file_data.length < 2){ continue;}
		
		// bouncing every 2 entries, want every OTHER entry... 
		// 	(it's between brackets!)
		for(var i_2=1; i_2< tmp_file_data.length; i_2+=2){
			var tmp_level_name = tmp_file_data[i_2]
			   .split( "//level_name//" )[1];
			tmp_level_name = tmp_level_name.trim();
			if(tmp_level_name == null){ continue;}
		
			
			var tmp_level_data = tmp_file_data[i_2]
			   .split( "//_level_editor_data//" )[1];
			
			/////////////////////////
			// SETTING SCHEMA FOR LEVEL GRAPHIC_FRAMES(anims)
			///////////////
			if(tmp_file_data[i_2].indexOf(
				"//"+"TYPE_GRAPHIC_FRAMES//")!=-1){
				//settup graphic-frames schema... ;
			  //ignores invalid data:
			  try{ 
			  level_editor_draw__string_to_graphic_frames_list(
				tmp_level_data );
			  }catch(e){	continue;	}
			
			  if(tmp_level_data == null){ continue;}
			  if( tmp_level_name ==
			"level_editor_loader__draw__DEFAULT_graphic_frames"
			   	){ continue;}


			  
			  tmpFrames_data.push(
				{ level_data: tmp_level_data, 
				  level_raw_file_text: tmp_file_data_raw, 
				  level_name: tmp_level_name,
				  file_name: tmp_file_name }); 		

				continue;
			}
			/////////////////////////
			// SETTING SCHEMA FOR LEVEL DATA
			///////////////
						
			//ignores invalid data:
			try{ tmp_level_data = JSON.parse( tmp_level_data);
			}catch(e){	continue;	}
			
			if(tmp_level_data == null){ continue;}
			
			
			
			tmpfiles_data.push(
				{ level_data: tmp_level_data, 
				  level_raw_file_text: tmp_file_data_raw, 
				  level_name: tmp_level_name,
				  file_name: tmp_file_name }); 
			//K, now to pull/save level data,
			//	it's literally just a string split/join. 
			//	(plus a string formatting with '+'s )
		}
	}
	// This way, can update objs without leaving level editor
	//	(does take a schema-reset though...) 
	level_editor_loader__is_dotnote_progenable__reset_CATCH();

	level_editor_data__caught_files_SCHEMA = tmpfiles_data;
	level_editor_data__caught_graphic_frames_SCHEMA 
		= tmpFrames_data;
	
	//

}

if(typeof _level_editor_data__undoRedo__undo_list ==  "undefined"){
	var _level_editor_data__undoRedo__undo_list = []; 
	var _level_editor_data__undoRedo__redo_list = [];
}
var _level_editor_data__undoRedo__max_undos =100;
function level_editor_data__undoRedo_clear(){ 
	_level_editor_data__undoRedo__undo_list = [];
	_level_editor_data__undoRedo__redo_list = []; }
function level_editor_data__undoRedo_list_add_undo(){ 
	// no redos after this...
 	_level_editor_data__undoRedo__redo_list = []; 
 	_level_editor_data__undoRedo__undo_list.push(
		JSON.stringify( level_editor_data__GET_level_loaded()));
	if(_level_editor_data__undoRedo__max_undos < 
			_level_editor_data__undoRedo__undo_list.length){
		_level_editor_data__undoRedo__undo_list.shift(); } 
}
async function level_editor_data__undoRedo_list_undo(){
	var tmpItem = _level_editor_data__undoRedo__undo_list.pop();
	if(tmpItem == null){ return;}
	
	var tmpItem_parsed = JSON.parse(tmpItem);
	var tmp_data = level_editor_data__GET_level_loaded();
	tmp_data.level_data = tmpItem_parsed.level_data;
	tmp_data.level_raw_file_text = tmpItem_parsed.level_raw_file_text;
	// not updateing level name/file name as maybe saved differnt
	// file

	await level_editor_data__UPDATE_data__and__room(tmp_data);
	
 	_level_editor_data__undoRedo__redo_list.push( tmpItem ); }
async function level_editor_data__undoRedo_list_redo(){
	var tmpItem = _level_editor_data__undoRedo__redo_list.pop();
	if(tmpItem == null){ return;}
	
	var tmpItem_parsed = JSON.parse(tmpItem);
	var tmp_data = level_editor_data__GET_level_loaded();
	tmp_data.level_data = tmpItem_parsed.level_data;
	tmp_data.level_raw_file_text = tmpItem_parsed.level_raw_file_text;
	// not updateing level name/file name as maybe saved differnt
	// file
	
	await level_editor_data__UPDATE_data__and__room(tmp_data);

 	_level_editor_data__undoRedo__undo_list.push( tmpItem ); }
// ----------
// -----------------
	// rmloaded_room.level_name -> used to find data//
	// 	------------- 
////		{ level_data: tmp_level_data, //level_data_CMDS_LIST
//			{ x:?, y:?, obj_dotnote_name:?}
//		level_raw_file_text: tmp_file_data_raw, 
//		level_name: tmp_level_name,
//		file_name: tmp_file_name }
if( _level_data_get_level_data_loaded_catch == undefined){
	var _level_data_get_level_data_loaded_catch = null; }
function level_editor_data__GET_level_loaded( getForceResetCatch_OPTIONAL){
		// use level_editor_data__UPDATE_data__and__room to 
		// 	update everything after modding this data!
		// 	( this_return.level_data can be manipulated
		// 		DIRECTLY, 
		// 		level_editor_data__UPDATE_data__and__room
		// 		updates the level_raw_file_text/etc)
		//returns 'null' if none loaded
		// (forceResetCatch if saving/loading)
	if( getForceResetCatch_OPTIONAL ){
		_level_data_get_level_data_loaded_catch = null;}
	if( _level_data_get_level_data_loaded_catch != null ){
		return _level_data_get_level_data_loaded_catch; }

	// rmloaded_room.level_name -> used to find data	
	var tmp_level_name = rmloaded_room.level_name;
	if(tmp_level_name == null){ return null;}
	var tmp_level_data = ROWS_FILTER(
			   level_editor_data__caught_files_SCHEMA,
			   function(a,b){if(a.level_name == b){ return 1;}
				return 0; },
			   tmp_level_name)[0];

	if(tmp_level_data!= null){
	  _level_data_get_level_data_loaded_catch = tmp_level_data }

	return tmp_level_data; // can be null
}
// (below updates level data/objs in room, so run at END of cmds
// 	(does all at once as this can test if lowing will be slow))
// returns 'null' if no level data found!
// 	-- updates getData.level_raw_file_text with getData.level_data,
// 		so can edit getData.level_data directly,
// 		and renders objs based on getData.level_data
// 		(again, direct manipulation cool!)
async function level_editor_data__UPDATE_data__and__room(
	   getData, getUpdateLevel_editor_data_in_raw_data_4SAVE_LOAD,
	   getUpdateLevel_editor_raw_text__ONLY_OPTIONAL ){
			// 2knd param optional 
		// getData__from_level_data_get_level_data_loaded()
	
	var tmp_level_data = getData;
	_level_editor_data__objs_gen__IN_EDITOR_ITSELF__CLEAR();
	
	if(getUpdateLevel_editor_raw_text__ONLY_OPTIONAL == true){
		getUpdateLevel_editor_data_in_raw_data_4SAVE_LOAD = true;}

	//level_raw_file_text update
	if(getUpdateLevel_editor_data_in_raw_data_4SAVE_LOAD){
	  var tmpRaw = getData.level_raw_file_text;
	  var tmpBreak = "//_level_editor_data//";
	  tmpRaw= tmpRaw.split(tmpBreak);
	  tmpRaw[1]= "\n" +JSON.stringify( getData.level_data) 
				+ "\n";
	  getData.level_raw_file_text = tmpRaw.join(tmpBreak);
	
	  
	}
	if(getUpdateLevel_editor_raw_text__ONLY_OPTIONAL == true){
		return; }
	
	// setting room rmSizeXY
	rmloaded_room.rmSizeXY= parseInt(
		getData.level_raw_file_text.split(
			"//rmSizeXY//")[1].trim() );


	await level_editor_loader__gen_items__n_progen( rmloaded_room, 
			getData.level_data, true );
	
}
// USED WITH FUNCTION BELOW THIS ONE: 
////////// SAVES TO 'm._autoload_n_configs_n_start_level.js' FILE 
async function level_editor_data__get_item_recent( getListNameSavedToo){
		var tmpObj = 
		 await level_editor_loader__in_autoload__load_obj_data();
		if( tmpObj[getListNameSavedToo] == null){
				return; }

		var get_data =  await level_editor_menu_list(
			tmpObj[getListNameSavedToo] );
		if(get_data== -1){ return; }
		await level_editor_data__save__recently_used_item(
			get_data, getListNameSavedToo);
		return get_data; }
// USED WITH FUNCTION ABOVE THIS ONE: 
////////// SAVES TO 'm._autoload_n_configs_n_start_level.js' FILE 
async function level_editor_data__save__recently_used_item(
	get_item, getListName_to_save_as){ //levelname
	
	//saving loaded level to m.js...
	var tmpObj = await level_editor_loader__in_autoload__load_obj_data();
	if(tmpObj[getListName_to_save_as]== null){
		tmpObj[getListName_to_save_as]=[];	}
	// updating tmpObj[getListName_to_save_as]
	var tmp_i =tmpObj[getListName_to_save_as].indexOf(get_item);
	if(tmp_i != -1){
	  tmpObj[getListName_to_save_as].splice(tmp_i, 1);
	  tmpObj[getListName_to_save_as].unshift( get_item);
	  await level_editor_loader__in_autoload__save_obj_data(get_item);
	}else{
	  tmpObj[getListName_to_save_as].unshift(get_item);
	  if( 10 < tmpObj[getListName_to_save_as].length){
	  	tmpObj[getListName_to_save_as].pop();} }
	
	await level_editor_loader__in_autoload__save_obj_data(
		tmpObj);

}

async function level_editor_data__save_level_data( 
	getFileName, getLevelName,
	getFileText, getLevelData, 
		getInjectThisString_INSTEAD_of_level_data__OPTIONAL){
	//////// MOVE BELOW TO 'save' SYSTEM (seperate FUNCTION!)
		// adding stuff to level-data:
		var tmpBreak = "//_level_editor_data//";
		var tmpFile_data = getFileText.split(tmpBreak);
		if(getInjectThisString_INSTEAD_of_level_data__OPTIONAL
			!= null){ 
		  tmpFile_data[1] = 
		     getInjectThisString_INSTEAD_of_level_data__OPTIONAL;
		}else{
		// add new lines with stuff added like this!
			tmpFile_data[1] = "\n" +JSON.stringify(
				getLevelData, null, 1) + "\n";
		}
		tmpFile_data = tmpFile_data.join( tmpBreak);
	
		await file_save( file_dir_cd(), getFileName, tmpFile_data);
}

/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
///////////////// THINK BELOW IS NO LONGER DATA TYPE/////////////////////
// getRm._level_editor_data =  [ { x:?, y:?, obj_dotnote_name:?} ... ];
//	(in obj:)

// move to data...
if(typeof _level_editor_data__init_objs_CAUGHT == undefined){ 
	var _level_editor_data__init_objs_CAUGHT = null; }
	//{objs:[], objs_large:[]};
function _level_editor_data__objs_gen__IN_EDITOR_ITSELF__CLEAR(){
	var tmpL = _level_editor_data__init_objs_CAUGHT;
	//loading initial objs
	if(tmpL == null){
		tmpL = {objs:rmloaded_room.objs.concat(), 
		objs_large:rmloaded_room.objs_large.concat()}
		_level_editor_data__init_objs_CAUGHT = tmpL; }
	rmloaded_room.objs = tmpL.objs.concat();
	rmloaded_room.objs_large = tmpL.objs_large.concat();
}

// below is a filter
function level_editor_data__is_rmloaded_compatable_obj( a){ // getObj){
	if(a==null){return 0;}
	return a.x != null && a.y != null &&
		a._menu_type == null && //menus have these
		a.graphic !=null && a.colgroup != null &&
		a.behavior != null;
}
function level_editor_data__is_rmloaded_compatable_room_obj( a){// getRoom
	if(a==null){return 0;}
	if(a == rmloaded_room ||
	   a == g_rmwarp_stack_DEFAULT.moveObjsBox ||
	   a == g_rmwarp_stack.moveObjsBox
		){ return 0;}
	return a.objs != null && a.objs_large != null;
}
var level_editor_data__is_dotnote_name_obj_list_filter = function(a){
			var tmpObj = progen_dotnote(a); //no JSON-strs...
			/// 				as 'lists'...
			// getting object, typeof pulls true on these two
			  return null != tmpObj && 
				!Array.isArray(tmpObj) && 
				tmpObj != rmloaded_b_globalThis && 
				typeof tmpObj == "object";}

async function level_editor_data__get__room__from_menu( 
		getDotNoteName_only, getTxtDisp_OPTIONAL){ 
			//returns null== fail
	if(getTxtDisp_OPTIONAL == null){ getTxtDisp_OPTIONAL=
		"Type in part/all of a ROOM NAME to use:"}
	return await level_editor_menu_get__compatible_obj(
		level_editor_data__is_rmloaded_compatable_room_obj, 
			getDotNoteName_only,
			getTxtDisp_OPTIONAL);
}
async function level_editor_data__get__obj__from_menu(
		getDotNoteName_only, getTxtDisp_OPTIONAL){ 
			//returns null== fail
	if(getTxtDisp_OPTIONAL == null){ getTxtDisp_OPTIONAL=
		"Type in part/all of a OBJ NAME to use:"}
	return await level_editor_menu_get__compatible_obj(
		level_editor_data__is_rmloaded_compatable_obj, 
			getDotNoteName_only,
			getTxtDisp_OPTIONAL);
}


