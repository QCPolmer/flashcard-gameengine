
async function Main_behav__draw_mode__tab_menu_SET_RESIZE_BRUSH_OR_IMG(
	getResizeBrush_NOT_img){ 

		var tmpScale_type =await level_editor_menu_list(
			["Resize canvas (no scaling)",
			"Nearest char extrapolate",
			"Border expand(grows center pixels /w 'frame')"]);
		if(tmpScale_type == -1){ return;}
		
		var tmpNumbX = await level_editor_menu_autocomplete(
			[], "Enter X scale:"); //.trim();
		// WEB VERSION NEEDS THIS ON SEPEARTE LINE
		tmpNumbX = tmpNumbX.trim();
			
		if( isNaN(tmpNumbX) || tmpNumbX == -1 || 
			parseInt(tmpNumbX)<1 ){ return; }
		
		var tmpNumbY = await level_editor_menu_autocomplete(
			[], "Enter Y scale:");//.trim();
		// WEB VERSION NEEDS THIS ON SEPEARTE LINE
		tmpNumbY = tmpNumbY.trim();
		if( isNaN(tmpNumbY) || tmpNumbY == -1 || 
			parseInt(tmpNumbY)<1 ){ return; }
		tmpNumbY = parseInt(tmpNumbY);
		
		// getting gridstr_2_resize (will re-declare later)
		var tmpData =
		   level_editor__mode__draw__loaded_graphic__data_obj;
		if(getResizeBrush_NOT_img){ //getting Brush
		    var tmpGridstr_2_resize = _level_editor_draw__brush;
		}else{ var tmpGridstr_2_resize = 
				tmpData.graphic_frames[0];}
			
		if(tmpScale_type == "Resize canvas (no scaling)"){
			tmpGridstr_2_resize= gridstr_scale(
			   tmpGridstr_2_resize,tmpNumbX, tmpNumbY); }
		if(tmpScale_type == "Nearest char extrapolate"){
		    tmpGridstr_2_resize= gridstr_scale_nearest_neighbor(
			   tmpGridstr_2_resize,tmpNumbX, tmpNumbY); }
		if(tmpScale_type == 
			"Border expand(grows center pixels /w 'frame')"){
			var tmpImg =gridstr_scale("-",tmpNumbX, tmpNumbY);
			tmpGridstr_2_resize =gridstr_overlay_grid( 
			   tmpImg, //drawToo (graphic too edit)	
			   tmpGridstr_2_resize, //draw from
			   0,0,null); //offsets
		}
		
		//adding back in img/brush...
		if(getResizeBrush_NOT_img){ //getting Brush
		    _level_editor_draw__brush = tmpGridstr_2_resize;
		}else{ tmpData.graphic_frames[0]= tmpGridstr_2_resize; }
		
		undoRedo_DRAWMD_list_add_undo();
}


async function Main_behav__draw_mode__save_load_menu(){
	var tmpMenuOut = await level_editor_menu_list(
			[
			"Save graphic_frames",
			"Save as graphic_frames",
			"Load frames if forat_right",
			"Save obj copy as frames_template",
			"--NOTE:saved templates do NOT always connect to ",
			"----animations by default,as anims have own files",
			"----see generated templates for details!" 
			]);
	if(tmpMenuOut == "Save graphic_frames"){
		await level_editor__mode__draw_save_frames();
	}if(tmpMenuOut == "Save as graphic_frames" ){
		await level_editor__mode__draw_save_frames_as();
	}if(tmpMenuOut ==  "Load frames if forat_right"){
		await level_editor__draw_mode__load_frames_from_schema();
	}if(tmpMenuOut == "Save obj copy as frames_template" ){
	   await level_editor_draw_save_obj_loaded_copy_as_frames_template();
	}
}


async function Main_behav__draw_mode__tab_menu(){
	// redefine below...
	var tmpMenuOut = await level_editor_menu_list(
			[
			"Save_Load__frames_options (s-key in editor)",
			"Normal mode (NOT draw mode, m/n key in editor)",
			"Brush- Set by text input",
			//TODO: next 2- via copy-pastebox( got it working)
			"Image Resize",
				"Brush Resize",
		"Copy/paste img (external-use vim?)",
		"Copy/paste img (external-use notepad?)",
		"Copy/paste img (external-use user-set-editor)"
			]);
	"Normal mode (NOT draw mode)"
	if(tmpMenuOut == "Save_Load__frames_options (s-key in editor)"){
		await Main_behav__draw_mode__save_load_menu();	}
	if(tmpMenuOut == "Normal mode (NOT draw mode, m/n key in editor)"){
		level_editor_launch__mode__draw_or_normal = "normal"; 
		return;}
	if(tmpMenuOut == "Brush- Set by text input"){
		var tmpBrush = await level_editor_menu_autocomplete(
			[], "Type in brush:");
		if(tmpBrush == -1 || tmpBrush.length==0){ return;}
		_level_editor_draw__brush = tmpBrush;	}
	if(tmpMenuOut == "Image Resize"){
	   await Main_behav__draw_mode__tab_menu_SET_RESIZE_BRUSH_OR_IMG(0); }
	if(tmpMenuOut == "Brush Resize"){
	   await Main_behav__draw_mode__tab_menu_SET_RESIZE_BRUSH_OR_IMG(1); }
	if(tmpMenuOut == "Copy/paste img (external-use vim?)"){
		await level_editor_draw__copy_paste_loaded_graphic("vim"); }
	if(tmpMenuOut == "Copy/paste img (external-use notepad?)"){
		await level_editor_draw__copy_paste_loaded_graphic("notepad"); }
	if(tmpMenuOut == "Copy/paste img (external-use user-set-editor)"){
		await level_editor_draw__copy_paste_loaded_graphic(); }
}

////TYPE_GRAPHIC_FRAMES//
//var level_editor_data__caught_graphic_frames_SCHEMA = [];
//		{ level_data: tmp_level_data, 
//		level_raw_file_text: tmp_file_data_raw, 
//		level_name: tmp_level_name,
//		file_name: tmp_file_name }

async function level_editor__mode__draw_save_frames(){
	var tmpD= level_editor__mode__draw__loaded_graphic__data_obj;
	if(tmpD.graphic_frames_dotnote_name_FOR_SAVING_LOADING == null){
		if("yes" != await level_editor_menu_list( ["yes", "no"],
		"Graphic not saved as 'graphic_frames' file, make file?"
			)){ return;}
		await level_editor__mode__draw_save_frames_as();
		return;
	}else{
		//find level name in 
		var tmpGraphicData= ROWS_FILTER(
		    level_editor_data__caught_graphic_frames_SCHEMA,
		     function(a,b){if(a.level_name == b){ return 1;}
			return 0;},
		    tmpD.graphic_frames_dotnote_name_FOR_SAVING_LOADING
		    )[0];
		if(tmpGraphicData == null){ 
			/// TODO ERROR
			return;}
		
		await level_editor_data__save_level_data( 
			tmpGraphicData.file_name, 
			tmpGraphicData.level_name,
			tmpGraphicData.level_raw_file_text, 
			null, //below overrides this param...
			"\n"+
			  level_editor_draw__graphic_frames_list_to_string(
				tmpD.graphic_frames )+"\n");

		//updating schema (dotnote, basic...):
		rmloaded_b_globalThis[tmpGraphicData.level_name ] = 
			tmpD.graphic_frames;
		
		//refreshing catch for level_data/ updating room...
		tmpData_refresh = level_editor_data__GET_level_loaded()
		await level_editor_data__UPDATE_data__and__room(tmpData_refresh);
		return;
	}
}


async function level_editor__mode__draw_save_frames_as(){
	// make sure to say: this data saved to file
	// 	is NOT going to go back in working object!
	// 	(MIGHT after reload...)
	if("yes" != await level_editor_menu_list( ["yes", "no"],
		"WARNING:saving like this does NOT modify the objs-data:"
		+"\n\n\n\n"
		+"\n graphic-frame data is seperate from rm-obj-data... "
		+"\n 'saving as' just makes a file WITH the data... "
		+"\n(may not be connected with obj,see graphic-data-file)"
		+"\n continue?")){ return;}
	tmpD1 = await level_editor_menu__SAVE_AS( "graphic_frame_dotnote", 1); 
		// returns{filename:tmpFileName, levelname:tmpLevelName}
		// 	(or null)
	if(tmpD1== null){return;}

	var tmpFileName = tmpD1.filename; 
	var tmpGraphicFramesName = tmpD1.levelname;

	//setting fileTxt to default if room type not matching... 
	var tmpFileTxt = file_load_noembed(tmpFileName);
	if(tmpFileTxt == null || 
	   tmpFileTxt.split(level_editor_block).length < 2||
	   tmpFileTxt.split(level_editor_block)[1].indexOf(
	   "//TYPE_GRAPHIC_FRAMES//") == -1 ){
		tmpFileTxt = 
		   level_editor_template__draw_GRAPHIC_FRAMES_TEMPLATE;
	}
	
	// adding 'level name' (really graphic name...)
	tmpFileTxt = tmpFileTxt.split("//level_name//");
	tmpFileTxt[1] = "\n" + tmpGraphicFramesName + "\n";
	tmpFileTxt = tmpFileTxt.join("//level_name//");
	
	level_editor__mode__draw__loaded_graphic__data_obj.
		graphic_frames_dotnote_name_FOR_SAVING_LOADING=
			tmpGraphicFramesName;

	level_editor__mode__draw__loaded_graphic__data_obj
			.graphic_frames = 
		level_editor__mode__draw__loaded_graphic__data_obj
			.graphic_frames.concat();

	await level_editor_data__save_level_data( 
		tmpFileName, 
		tmpGraphicFramesName,
		tmpFileTxt, 
		null, //below overrides this param...
		"\n"+level_editor_draw__graphic_frames_list_to_string(
		  level_editor__mode__draw__loaded_graphic__data_obj
			.graphic_frames )+"\n");

	//refreshing catch for level_data/ updating room...
	await  level_editor_data__UPDATE_data__and__room(
	   level_editor_data__GET_level_loaded( true) );	


	
	await level_editor_data__load_files_SCHEMA();
	
	rmloaded_b_globalThis[
	level_editor__mode__draw__loaded_graphic__data_obj.
		    graphic_frames_dotnote_name_FOR_SAVING_LOADING
	] = level_editor__mode__draw__loaded_graphic__data_obj
			.graphic_frames;
	
	level_editor__mode__draw__loaded_graphic__data_obj.
		graphic_frames = progen_dotnote(
		 level_editor__mode__draw__loaded_graphic__data_obj.
		    graphic_frames_dotnote_name_FOR_SAVING_LOADING);

}


async function level_editor__draw_mode__load_frames_from_schema(){
	if("yes" != await level_editor_menu_list( ["yes", "no"],
		"WARNING:loading like this does NOT modify the objs-data:"
		+"\n\n\n\n"
		+"\n graphic-frame data is seperate from rm-obj-data... "
		+"\n(may not be connected with obj,see graphic-data-file)"
		+"\n manual entry of data into obj will be required:"
		+"\n continue?")){ return;}
	//below is copied from 'save_as' for level, modify it!
	var tmpOptions=level_editor_data__caught_graphic_frames_SCHEMA
			.map( function(a){ 
			  return a.level_name
				+ "::" + a.file_name; } );
		
				
	var tmpEntry= 
	   await menu_autocomp_menu_THEN_OUTPUT_2_list_menu( 
		tmpOptions, // list of words selectable
		level_editor_menu_autocomplete,//first menu wrapper
		level_editor_menu_list,//out to sub-menu wrapper
	"Enter part or full name of level::file"
			//text too display
		);
		// none found / got
	if(tmpEntry == -1){ return;}
	var tmpEntry_catch = tmpEntry.split("::");
	tmpEntry = {}; 
	tmpEntry.file_name = tmpEntry_catch[1];
	tmpEntry.level_name = tmpEntry_catch[0];
		
	//so can pull same file/etc... 
	// DOES scan all files... again...
	//level_editor_data__load_files_SCHEMA(  );	
	var tmpGraphic_frames_data_found= 
	  ROWS_FILTER(
	      level_editor_data__caught_graphic_frames_SCHEMA,
		function(a, b ){ 
		  if( a.file_name == b.file_name &&
			  a.level_name == b.level_name){ 
		  return 1;} return 0 },
		tmpEntry )[0];	
	 
	//loading...
	level_editor__mode__draw__loaded_graphic__data_obj.
		    graphic_frames_dotnote_name_FOR_SAVING_LOADING =
		tmpGraphic_frames_data_found.level_name;
	level_editor__mode__draw__loaded_graphic__data_obj.
		graphic_frames = progen_dotnote(
			tmpGraphic_frames_data_found.level_name);
	
	//refreshing catch for level_data/ updating room...
	await level_editor_data__UPDATE_data__and__room(
	   level_editor_data__GET_level_loaded( true), true );

	undoRedo_DRAWMD_clear();
	undoRedo_DRAWMD_list_add_undo();
	
}

///--------------------Object design for below...
// o.graphic_frames__dotnote (the rest are internal) -> graphics list
// o.graphic_frames__delay_between_frames = 1; -> animation speed
//
// o._graphic_frames__on_delay_countup = 0;
// o._graphic_frames__CAUGHT
// o._graphic_frames__dotnote_CAUGHT
// o._graphic_frames__on_frame (int)
//

async function level_editor_draw_save_obj_loaded_copy_as_frames_template(){
	if("yes" != await level_editor_menu_list( ["yes", "no"],
		"Save A COPY of obj-data as TEMPLATE?:")){ return;}
	tmpD1 = await level_editor_menu__SAVE_AS( "graphic_frame_dotnote", 1);
	// returns{filename:tmpFileName, levelname:tmpLevelName}
		// 	(or null)
	if(tmpD1== null){return;}

	var tmpFileName = tmpD1.filename; 
	var tmpGraphicFramesName = tmpD1.levelname;

	var tmpDotNote = 
		level_editor__mode__draw__loaded_graphic__data_obj.
			dotnote_of_obj;
	if(tmpDotNote != null){
	     var o= JSON.parse(JSON.stringify( progen_dotnote(
		level_editor__mode__draw__loaded_graphic__data_obj.
			dotnote_of_obj)));
	}else{
	     var o = JSON.parse(
		level_editor_template__save_draw_obj_TEMPLATE);
	}
	
	o.graphic_frames__dotnote =
		level_editor__mode__draw__loaded_graphic__data_obj.
			graphic_frames_dotnote_name_FOR_SAVING_LOADING;

	if(o.graphic_frames__dotnote != null){
		var tmpGfx = progen_dotnote(o.graphic_frames__dotnote);
		if(Array.isArray(tmpGfx)){ 
			o.graphic = tmpGfx[0];} //first frame
	}else{ //falling back to default loaded in-editor graphic...
		o.graphic = 
			level_editor__mode__draw__loaded_graphic__data_obj.
				graphic_frames[0];
	}
	
	o.graphic_frames__delay_between_frames = 1; //animation speed
	    o._graphic_frames__NOTES = "Can delete this note-var, use level_editor_loader__draw_animation__behav(o) as obj behavior or in OBJ behavior to play animation (graphic_frames__dotnote, at speed graphic_frames__delay_between_frames), can change graphic_frames__dotnote/graphic_frames__delay_between_frames whenever";  
	//explicitly setting so will show up in generated data
	if( o.light_width == null){ o.light_width = null;}
	if( o.light_gfx == null){ o.light_gfx = null;}
	o.light___how_to_use = "set light_width (optional, add a gfx) AND set behavior to 'ray_light_width' (may only work on small 1 char objs, IDK)";

	await file_save( file_dir_cd(), tmpFileName, 
		"var " + tmpGraphicFramesName + "=\n" +
		"\n"+ JSON.stringify(o, null, 2)+ ";\n");

	//updating schema
	rmloaded_b_globalThis[tmpGraphicFramesName] = o;	
 
	//refreshing catch for level_data/ updating room...
	await level_editor_data__UPDATE_data__and__room(
	   level_editor_data__GET_level_loaded( true) );
}



function level_editor__mode__draw__loaded_graphic__data_obj_DEFAULT(){ 
return {
	y:10,   
	x:4,
	transparent_char:" ",
	dotnote_of_obj:null,
		//object below is stored/defined in 
		//	o.graphic_frames__dotnote 
	graphic_frames_dotnote_name_FOR_SAVING_LOADING: null,
	graphic_frames: //1st frame is ONLY one drawn,will use pop unshift
[
`i----
--+--
- u--`	
]
}; }
	
if(typeof level_editor__mode__draw__loaded_graphic__data_obj=="undefined"){
	var level_editor__mode__draw__loaded_graphic__data_obj = 
	   level_editor__mode__draw__loaded_graphic__data_obj_DEFAULT();
}

// returns 1 for success, 0 for failure
async function level_editor_draw__load__from_obj_under_cursor( getRm){
	//TODO: settup so it loads from graphic OR IF AVAILABLE:
	//	graphic_frames (from obj) (sets graphic to 1st frame)
	var tmpObjs = 
	   await _level_editor_display__get_objs_under_cursor__NOT_EFFICIENT( 
		getRm,
		"_level_editor_data_dotnote_name" ); 

	var tmpNames = [];
	for(var i=0; i< tmpObjs.length; i+=1){
		tmpNames[i] =tmpObjs[i]["_level_editor_data_dotnote_name"]
			+ ":::" + i; } 
	tmpNames.unshift("Enter draw mode, NO obj-focus change");
	
	if(tmpNames.length == 0){ return 0;}

	var tmpMenuOut = await level_editor_menu_list( tmpNames,
		"Select an obj to draw-edit(or press esc!)");
	if(tmpMenuOut == -1 ){ return 0;}
	if(tmpMenuOut ==  "Enter draw mode, NO obj-focus change"){ 
		level_editor_launch__mode__draw_or_normal = "draw";
		return; }

	
	var gotObj = tmpObjs[ parseInt(tmpMenuOut.split(":::")[1]) ];

	var tmpD = level_editor__mode__draw__loaded_graphic__data_obj;
	
	//loads from graphic-frames (if available)
	if(gotObj.graphic_frames__dotnote != null){
		var tmpFrames2 = progen_dotnote(
			gotObj.graphic_frames__dotnote );
		if(tmpFrames2 == null){
		   file_input(
		        "Error in finding object.graphic_frame__dotnote:",
		      gotObj.graphic_frames__dotnote,
		   "in function"+
		   "'level_editor_draw__load__from_obj_under_cursor'");}
		tmpD.graphic_frames = tmpFrames2;
		tmpD.graphic_frames_dotnote_name_FOR_SAVING_LOADING =
			gotObj.graphic_frames__dotnote; 
		
		undoRedo_DRAWMD_clear();
		undoRedo_DRAWMD_list_add_undo();
	}else{ tmpD.graphic_frames = [gotObj.graphic]; }
	
	tmpD.dotnote_of_obj = gotObj._level_editor_data_dotnote_name;
	tmpD.x = gotObj.x; 
	tmpD.y = gotObj.y; 
	level_editor_launch__mode__draw_or_normal = "draw";
	
	undoRedo_DRAWMD_list_add_undo();

	return 1;
	
}
//---- SET THIS AND LOAD FORM THIS... make a funct for it?
//
//level_editor__mode__draw__loaded_graphic__data_obj.dotnote_of_obj

// for drawing location, so not drawing every frame, only on mouse move

var _level_editor_draw__prev_x_click= null;
var _level_editor_draw__prev_y_click= null;
var _level_editor_draw__frames_wait_copy_buffer_ON = 0;
var _level_editor_draw__frames_wait_FRAMES2PAUSE = 3;

if( typeof _level_editor_draw__brush ==  "undefined"){
	var _level_editor_draw__brush = ".";}

var MULTI_LINE_CHAR_STRING_BRACKET = String.fromCharCode(96);


//OK, should be isolated
function level_editor_draw__graphic_frames_list_to_string(
		getFrames  ){ //list, of gridstr2d strings
	return "[ \n" + MULTI_LINE_CHAR_STRING_BRACKET+
		getFrames.join( MULTI_LINE_CHAR_STRING_BRACKET + ",\n"+
			MULTI_LINE_CHAR_STRING_BRACKET) 
		+ MULTI_LINE_CHAR_STRING_BRACKET+ "\n ] " ;
}

function level_editor_draw__string_to_graphic_frames_list(
	getString ){  //uses multi-line sting char, list-of-strings

	var tmpResult = getString.split(
			MULTI_LINE_CHAR_STRING_BRACKET); 
	var tmpResults_out_list= [];
	//scrubbing results from tmpResults... (jumping every other item)
	for(var i2=1; i2<tmpResult.length; i2+=2){
		var tmpResult_i2 =tmpResult[i2]; 
		// gettting max width
		var tmpResult_i2 = tmpResult_i2.split("\n");
		var tmpWidth_max = tmpResult_i2[0].length;
		for(var i=0; i< tmpResult_i2.length; i+=1){
			if(tmpResult_i2[i].length > tmpWidth_max){
				tmpWidth_max = tmpResult_i2[i].length;
		}	}
		// Making sure all same width:
		for(var i=0; i< tmpResult_i2.length; i+=1){
			if(tmpResult_i2[i].length < tmpWidth_max){
			  tmpResult_i2[i] = tmpResult_i2[i].split("");
			  while(tmpResult_i2[i].length < tmpWidth_max){
				tmpResult_i2[i].push(" ");}
			  tmpResult_i2[i] = tmpResult_i2[i].join("");
			}	}
		tmpResults_out_list.push( tmpResult_i2.join("\n"));
	}
	return tmpResults_out_list;
}

//split into pull/save functions
async function level_editor_draw__copy_paste_loaded_graphic(
		getEditor_terminal_cmd_or_null){	
	
	 var tmpResult = level_editor_draw__graphic_frames_list_to_string(
		 level_editor__mode__draw__loaded_graphic__data_obj.
			graphic_frames  );

	//k, getting via copybox...
	tmpResult=  await file_copybox(tmpResult,
		getEditor_terminal_cmd_or_null);

	level_editor__mode__draw__loaded_graphic__data_obj.
		graphic_frames = 
	  level_editor_draw__string_to_graphic_frames_list( tmpResult );

	undoRedo_DRAWMD_list_add_undo();
}


var _level_editor_draw__cursor_timer =0
async function Main_behav__draw_mode(getRoom){
	
	var tmpD = level_editor__mode__draw__loaded_graphic__data_obj;

	await level_editor_launch__camera_controls()

	
	
	// c-opy a box, use box as brush!
	if(controllers[0].getch.toUpperCase() == "C"){
		_level_editor_display__box_select__start(); return;
	}
	if(controllers[0].getch.toUpperCase() == "S"){
		await Main_behav__draw_mode__save_load_menu(); return;
	}
	
	// Main (tab) draw menu...
	if(controllers[0].getch == "Tab"){
		await Main_behav__draw_mode__tab_menu();
		return;
	}
	
	if(_level_editor_display__box_select__is_running()){
		//drawing data obj:
		rmloaded_draw_overlay(
				tmpD.graphic_frames[0],
				tmpD.x + _rmloaded_camera_x,
				tmpD.y + _rmloaded_camera_y,
		 		tmpD.transparent_char);
		
		// stopping frame mouse goes up, to avoid catching 
		// draw -box_select-border...
		if(0==_level_editor_draw__frames_wait_copy_buffer_ON){
			_level_editor_display__box_select_update(); 

			
		}
		
		//drawing rmSizeXY outline
		level_editor_display_rmSizeXY_outline();
		
		if(controller_mouse_up){
		   _level_editor_draw__frames_wait_copy_buffer_ON =
		    _level_editor_draw__frames_wait_FRAMES2PAUSE;}
		
		if(controller_mouse_up || 
			_level_editor_draw__frames_wait_copy_buffer_ON>0){
		   //pause 1 frame to suspend drawing of 'frame
		   //	around box_update...
		   _level_editor_draw__frames_wait_copy_buffer_ON-=1;
		   if(_level_editor_draw__frames_wait_copy_buffer_ON>0){
			return ;}
			
		   var tmp_choards = // o.x_start, o.x_end, etc.  
		   level_editor_display__box_select__end_n_reset__GET_CORDINATES(
			getRoom, true);//getON_SCREEN_chords_OPTIONAL)
		  
		  var tmpXsize = 
			Math.abs(tmp_choards.x_end- tmp_choards.x_start);
		  var tmpYsize = 
			Math.abs(tmp_choards.y_end- tmp_choards.y_start);
			  
		  var tmpNewStr =gridstr_scale(" ",tmpXsize+1,tmpYsize+1);
		  
		  _level_editor_draw__brush = gridstr_overlay_grid( 
				//one size fits-all draw
			tmpNewStr, //drawToo (graphic too edit)	
			rmloaded_last_draw,//drawFrom (replace with brush!)
			//x/y offset to draw on: 
			-tmp_choards.x_start, -tmp_choards.y_start,
			null);
		}
		return;	
	}

	// undo/redo
	if(controllers[0].getch == "y" || controllers[0].getch == "Y"){
		undoRedo_DRAWMD_list_redo();
		file_log("Redone! Total number frames:" + 
			level_editor__mode__draw__loaded_graphic__data_obj
				.graphic_frames.length  + "       ");
		return; }
	if(controllers[0].getch == "z" || controllers[0].getch == "Z"){
		undoRedo_DRAWMD_list_undo();
		file_log("Undone! Total number frames:" + 
			level_editor__mode__draw__loaded_graphic__data_obj
				.graphic_frames.length + "       ");
		return; }

	// i-for insert-frame
	if(controllers[0].getch == "i" || controllers[0].getch == "I"){
		level_editor__mode__draw__loaded_graphic__data_obj
				.graphic_frames.unshift(
			level_editor__mode__draw__loaded_graphic__data_obj
				.graphic_frames[0]);
		file_log("Frame added! Total number frames:" + 
			level_editor__mode__draw__loaded_graphic__data_obj
				.graphic_frames.length + "       " );
		undoRedo_DRAWMD_list_add_undo();
		return;
	}
	// d-for delete frame
	if(controllers[0].getch == "d" || controllers[0].getch == "D"){
		if(level_editor__mode__draw__loaded_graphic__data_obj
			.graphic_frames.length > 1){
			level_editor__mode__draw__loaded_graphic__data_obj
				.graphic_frames.shift();
			undoRedo_DRAWMD_list_add_undo();	
			file_log("Frame deleted! Total number frames:" + 
			level_editor__mode__draw__loaded_graphic__data_obj
				.graphic_frames.length + "       " );
		}
		return;
	}

	// M-for draw MODE
	if(controllers[0].getch == "m" || controllers[0].getch == "M"||
	   controllers[0].getch == "n" || controllers[0].getch == "N"){
			level_editor_launch__mode__draw_or_normal="normal";
			controllers_clear_pressed();
			return; 
	 }
	var tmpFrames = level_editor__mode__draw__loaded_graphic__data_obj.
		graphic_frames;
	// ROTATE FRAMES: w/s-keys? 
	if(controllers[0].getch == "q"){
		tmpFrames.unshift(tmpFrames.pop());}
	if(controllers[0].getch == "w"){
		tmpFrames.push(tmpFrames.shift());}


	//handling 'painting'
	if( !controller_mouse_held){
		if(_level_editor_draw__prev_x_click!= null){
			undoRedo_DRAWMD_list_add_undo(); }
		_level_editor_draw__prev_x_click= null;
		_level_editor_draw__prev_y_click= null;
	}else{
	   if(_level_editor_draw__prev_x_click != controller_mouse_x ||
	   	_level_editor_draw__prev_y_click != controller_mouse_y){
		
		var tmpXLoc = (controller_mouse_x -_rmloaded_camera_x);
		var tmpYLoc = (controller_mouse_y -_rmloaded_camera_y);
		

		tmpD.graphic_frames[0] = gridstr_overlay_grid( 
				//one size fits-all draw
			tmpD.graphic_frames[0], 
				//drawToo (graphic too edit)	
			_level_editor_draw__brush, 
				//drawFrom (replace with brush!)
			//x offset to draw on: 
			tmpXLoc // location of 'brush'
			- tmpD.x // location of obj to draw on
			,
			//y offset to draw on
			tmpYLoc //location of 'brush'
			- tmpD.y // location of obj to draw on,
			,
			null); //overlayChar_or_null)

		
	     _level_editor_draw__prev_x_click = controller_mouse_x+0;
	     _level_editor_draw__prev_y_click = controller_mouse_y+0;
	   }

	   
	}

	rmloaded_draw_overlay(
	 "TAB-menu,n/m-ode(gotoNormal),s-ave,c-opy,q/w-next-last frame\n"+
	"---DRAW MODE ON---  (z/y=undo-redo, i-addFrame, d-deleteFrame)"+
	(controller_mouse_x -_rmloaded_camera_x)+"--"+
		(controller_mouse_y - _rmloaded_camera_y )
			+"--"+ controller_mouse_held +
		"\n-----Draw_graphics_data_dotnote_name:"+
		level_editor__mode__draw__loaded_graphic__data_obj
			.dotnote_of_obj + "------",
		 1,0, " ");

	
	//drawing data obj:
	rmloaded_draw_overlay(
		tmpD.graphic_frames[0],
		tmpD.x + _rmloaded_camera_x,
		tmpD.y + _rmloaded_camera_y,
		 tmpD.transparent_char);

	//drawing cusor (blinking)
	_level_editor_draw__cursor_timer +=1;
	if( _level_editor_draw__cursor_timer % 8 <3){ 
	       rmloaded_draw_overlay(
		_level_editor_draw__brush, //replace with 'brush'
		controller_mouse_x, 
		controller_mouse_y, "");
	}
	//drawing rmSizeXY outline
	level_editor_display_rmSizeXY_outline();

	

}

////////////////////
/////////////////		
if(typeof _undoRedo_DRAWMD__undo_list ==  "undefined"){
	var _undoRedo_DRAWMD__undo_list = []; 
	var _undoRedo_DRAWMD__redo_list = [];
	var _undoRedo_DRAWMD__max_undos =100;}
function undoRedo_DRAWMD_clear(){ _undoRedo_DRAWMD__undo_list = [];
	_undoRedo_DRAWMD__redo_list = []; }
function undoRedo_DRAWMD_list_add_undo(){ 
 	_undoRedo_DRAWMD__redo_list = []; // no redos after this...
 	_undoRedo_DRAWMD__undo_list.push(
		  level_editor__mode__draw__loaded_graphic__data_obj.
			graphic_frames.concat() );
	if(_undoRedo_DRAWMD__max_undos<_undoRedo_DRAWMD__undo_list.length){
		_undoRedo_DRAWMD__undo_list.shift(); } 
}
function undoRedo_DRAWMD_list_undo(){
	var tmpItem = _undoRedo_DRAWMD__undo_list.pop();
	if(tmpItem == null){ return;}
	
	var tmpItem_current =
		   level_editor__mode__draw__loaded_graphic__data_obj.
			graphic_frames.concat();

	level_editor__mode__draw__loaded_graphic__data_obj
		.graphic_frames = tmpItem;

	if(level_editor__mode__draw__loaded_graphic__data_obj
		.graphic_frames_dotnote_name_FOR_SAVING_LOADING != null){
		
		rmloaded_b_globalThis[ 
			level_editor__mode__draw__loaded_graphic__data_obj
			.graphic_frames_dotnote_name_FOR_SAVING_LOADING
			] = tmpItem;
	}
	
 	_undoRedo_DRAWMD__redo_list.push( tmpItem_current ); }
function undoRedo_DRAWMD_list_redo(){
	var tmpItem = _undoRedo_DRAWMD__redo_list.pop();
	if(tmpItem == null){ return;}
	
	var tmpItem_current =
		   level_editor__mode__draw__loaded_graphic__data_obj.
			graphic_frames.concat();

	level_editor__mode__draw__loaded_graphic__data_obj
		.graphic_frames = tmpItem;

	if(level_editor__mode__draw__loaded_graphic__data_obj
		.graphic_frames_dotnote_name_FOR_SAVING_LOADING != null){
		
		rmloaded_b_globalThis[ 
			level_editor__mode__draw__loaded_graphic__data_obj
			.graphic_frames_dotnote_name_FOR_SAVING_LOADING
			] = tmpItem;
	}
	
 	_undoRedo_DRAWMD__undo_list.push( tmpItem_current ); ; }
///////////////////
/////////////////////////////////////

if(	_undoRedo_DRAWMD__undo_list.length == 0){
	undoRedo_DRAWMD_list_add_undo(); } 
