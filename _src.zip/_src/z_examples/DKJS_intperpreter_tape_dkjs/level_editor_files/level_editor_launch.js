
var level_editor_launch_room = progen_obj_room({
	update_behavs:[ "level_editor_launch__main_behavior" ],
	objs:[  ],  objs_large:[ ]});


async function level_editor_launch__camera_controls(){
	// camera controls
	if(controllers[0].getch == "f"){
	   rmloaded_camera_focus( controller_mouse_x-_rmloaded_camera_x, 
			controller_mouse_y-_rmloaded_camera_y ,1,1); }
	if(controllers[0].getch == "ArrowLeft"){ _rmloaded_camera_x+=8; }
	if(controllers[0].getch == "ArrowRight"){ _rmloaded_camera_x-=8; }
	if(controllers[0].getch == "ArrowUp"){ _rmloaded_camera_y+=4; }
	if(controllers[0].getch == "ArrowDown"){ _rmloaded_camera_y-=4; }
}


var _box_sel_mode = null; var _box_sel_pull_in_box_fully=0;

if(typeof level_editor_launch__mode__draw_or_normal ==  "undefined"){
	var level_editor_launch__mode__draw_or_normal = "normal"; //"draw"
							//"test_run_level"
}
var level_editor_launch__test_level_CAUGHT_LEVEL = {};
async function level_editor_launch__test_level_RUN(
		getSave_n_rescan_files__OPTIONAL){
	
	if(getSave_n_rescan_files__OPTIONAL){
		level_editor_menu__SAVE();
		level_editor_data__load_files_SCHEMA();  } 

	level_editor_launch__mode__draw_or_normal = "test_run_level";
	rmloaded_room.objs = []; rmloaded_room.objs_large = [];
	
	// catching current room stuff...
	level_editor_launch__test_level_CAUGHT_LEVEL = 
		JSON.parse(JSON.stringify( rmloaded_room ));
	//copying room vars, caught above, will reset on leave 'test'...
	var tmpTxt=
	   level_editor_data__GET_level_loaded(true).level_raw_file_text;
	rmloaded_room.room_type = 
		tmpTxt.split("//room_type//")[1].split('"')[1];
	rmloaded_room._level_editor_loader__room_on_enter_SEED = 
		tmpTxt.split("//_level_editor_loader__room_on_enter_SEED//"
		)[1].split('"')[1];
	rmloaded_room.update_behavs = rmloaded_room.update_behavs.concat(
	   JSON.parse(
		"[" + tmpTxt.split("//update_behavs//")[1] + "]"));
	rmloaded_room.enter_behavs = JSON.parse(
		"[" + tmpTxt.split("//enter_behavs//")[1] + "]");

	level_editor_loader__gen_items__n_progen(  
		rmloaded_room, 
		level_editor_data__GET_level_loaded().level_data, 
		0); // do NOT disable generated obj behavs.
	
	rmloaded_DISABLE_SWITCHING_LEVELS( true ); 
	
	// running enter_behavs...
	for(var i=0; i< rmloaded_room.enter_behavs.length; i+=1){
		rmloaded_b_globalThis[ rmloaded_room.enter_behavs[i]](
			rmloaded_room); }
}
//zzz TODO --  see about running behav-rm-enter
//		and update in rooms loaded. 
//		-- can probably pull via 'data' ? 
//		-- catch and reinject?
//		-- change rm-type? so can test lights?
			//getBool_Set_is_level_switching_disabled )
//		-- see about a 'conversation tester' in editor
//			(would be bomb...)

async function level_editor_launch__test_level_RETURN(){
	level_editor_launch__mode__draw_or_normal = "normal";
	rmloaded_room.objs = []; rmloaded_room.objs_large = [];
	level_editor_loader__gen_items__n_progen(  
		rmloaded_room, 
		level_editor_data__GET_level_loaded().level_data, 
		1); // disable generated object behavs.
	rmloaded_DISABLE_SWITCHING_LEVELS( false ); 
			//getBool_Set_is_level_switching_disabled )
			
	//restoring possibly changed vars. 
	rmloaded_room.room_type = 
		level_editor_launch__test_level_CAUGHT_LEVEL.room_type;
	rmloaded_room.update_behavs = 
		level_editor_launch__test_level_CAUGHT_LEVEL.update_behavs;
	rmloaded_room.enter_behavs = 
		level_editor_launch__test_level_CAUGHT_LEVEL.enter_behavs;
	rmloaded_room._level_editor_loader__room_on_enter_SEED =
		level_editor_launch__test_level_CAUGHT_LEVEL. 
			_level_editor_loader__room_on_enter_SEED;
}


async function level_editor_launch__main_behavior(getRoom){
	
	// forces load room on enter (or save)
	if(_level_data_get_level_data_loaded_catch==null){
		if(file_load_noembed( file_dir_cd(), "m.js") == null){
		   file_input(
			"m.js (the file the level editor looks for)"+
			"is not found in current directory"+
			"\n exiting, launch"+
		      "\n level editor from a standard-level directory");
			return file_exit(); }
		await level_editor_menu__SAVE_LOAD_Menu(); 
		return;}

		
	// testing level editor
	if(level_editor_launch__mode__draw_or_normal == "test_run_level"){
		rmloaded_draw_overlay( "type 't' to return to editor",
			0, 0,"");
		if(controllers[0].getch == "t" || 
				controllers[0].getch == "T"){
			controllers_clear_pressed();
			await level_editor_launch__test_level_RETURN(); }
		return;
	}else if(controllers[0].getch == "t"){
			await level_editor_launch__test_level_RUN();
			controllers_clear_pressed();
			return; 
	}else if(controllers[0].getch == "T"){
			await level_editor_launch__test_level_RUN(true);
			controllers_clear_pressed();
			return; 
	}

	// launch draw mode
	if(level_editor_launch__mode__draw_or_normal == "draw"){
		Main_behav__draw_mode(getRoom);
		return
	}		

	// entering graphic-edit mode (pull object)
	if(controllers[0].getch == "m" || controllers[0].getch == "M"){
		if( level_editor_draw__load__from_obj_under_cursor(
				getRoom) ){
			level_editor_launch__mode__draw_or_normal = "draw";
			controllers_clear_pressed();
			return; 
	} }
	// entering graphic-edit (DONT pull object)
	if(controllers[0].getch == "n" || controllers[0].getch == "N"){
		level_editor_launch__mode__draw_or_normal = "draw";
		controllers_clear_pressed();
		return; 
	}

	//undoRedo
	if(controllers[0].getch != ""){
		if("zZ".indexOf(controllers[0].getch) !=-1){
				level_editor_data__undoRedo_list_undo();}
		if("yY".indexOf(controllers[0].getch) !=-1){
			level_editor_data__undoRedo_list_redo();}
	}
	
	await level_editor_launch__camera_controls();
	
	// cycling through copied (selected) objs
	if(controllers[0].getch != "e"){
		level_editor_display__cursor_cycle_objlist("next"); }
	if(controllers[0].getch != "r"){
		level_editor_display__cursor_cycle_objlist("last"); }

	//box selector:
	if(!_level_editor_display__box_select__is_running()){
	     if(controllers[0].getch != ""){
		  if( "sS".indexOf(controllers[0].getch) != -1){ 
			await level_editor_menu__SAVE_LOAD_Menu(); 
			return;} 
		  if( "cC".indexOf(controllers[0].getch) != -1){ 
			_box_sel_mode = "select"; 
			_level_editor_display__box_select__start(); } 
		  if( "dD".indexOf(controllers[0].getch) != -1){ 
			_box_sel_mode = "delete"; 
			_level_editor_display__box_select__start(); }
		 if( "xX".indexOf(controllers[0].getch) != -1){ 
			_box_sel_mode = "cut"; 
			_level_editor_display__box_select__start(); } }
		  // UPPER CASE test:
		  _box_sel_pull_in_box_fully = false;
		  if( controllers[0].getch == 
				controllers[0].getch.toUpperCase()){ 
			_box_sel_pull_in_box_fully=true;} }


	if(_level_editor_display__box_select__is_running()){
		_level_editor_display__box_select_update();
		if(controller_mouse_up){ 
		  	var tmpObjs = level_editor_display__box_select__end_get_results_n_reset(
				getRoom, _box_sel_pull_in_box_fully,
				"_level_editor_data_dotnote_name"); 
			
			 var tmpObjs_1_pool = tmpObjs.objs.concat(
						tmpObjs.objs_large );
			if(_box_sel_mode == "select" || 
				_box_sel_mode  == "cut"){
			   level_editor_display__copy_objlist_to_cursor(
				tmpObjs_1_pool );
			}if(_box_sel_mode == "delete" || 
				_box_sel_mode  == "cut"){
			   level_editor_data__remove_objs_from_level_data(
				tmpObjs.objs.concat( tmpObjs.objs_large));
			   level_editor_data__undoRedo_list_add_undo();
			}
			_box_sel_mode = null;
		}
		file_log("-------" + 
		   level_editor_data__GET_level_loaded().level_data.length+
			     "objs in room-----------");
		return;  }
		
	// draw 
	rmloaded_draw_overlay(
	 "TAB-menu,z/y-Un/Redo,s-ave,c-copy,x-cut,d-el,er-pasteCycle,i-add,f-ocusCam"
	+"\nn-drawmode/m-obj2Gfx2drawmode"+
	"(Upper-case=select FULLY engulfed by box)\n"+
	(controller_mouse_x -_rmloaded_camera_x)+"--"+
		(controller_mouse_y - _rmloaded_camera_y )
			+"--"+ controller_mouse_held ,
		 1,0, " ");


	// only gets objs made by level generator
	_level_editor_display__objs_under_cursor(getRoom, 
		"_level_editor_data_dotnote_name", //draw with this key
		 "_level_editor_data_dotnote_name", //draw this key
		10, 23); //draw at X Y 

	if(controllers[0].getch == "Tab"){ 
		await level_editor_menu(); return;}
	if(controllers[0].getch == "i"){ 
	   level_editor_display__set_level_editor_display__cursor_objs_to_add__from_menu(); }

	// clicking cursor //controller_mouse_up
	if( controller_mouse_up){ 
		var tmp_LED = JSON.parse(//tmp_LED ==level_editor_data..
			JSON.stringify(level_editor_display__cursor_objs_to_add));		

		for(var i=0; i< tmp_LED.length; i+=1){
		    tmp_LED[i].x +=controller_mouse_x -_rmloaded_camera_x;
		    tmp_LED[i].y +=controller_mouse_y-_rmloaded_camera_y;}
		
		var tmpData = level_editor_data__GET_level_loaded();
		tmpData.level_data = tmpData.level_data.concat(tmp_LED);
		//level_editor_loader__gen_items( rmloaded_room, 
		//	tmp_LED, true );
		// NOT updating, this is much much faster. 
		level_editor_data__UPDATE_data__and__room( tmpData);
		level_editor_data__undoRedo_list_add_undo();		
		file_log("-------" + 
		   level_editor_data__GET_level_loaded().level_data.length+
			     "objs in room-----------");
	}
	//drawing cusor (blinking)
	level_editor_display_cursor_and_objects_in_cursor(level_editor_display__cursor_objs_to_add);
	//drawing rmSizeXY outline
	level_editor_display_rmSizeXY_outline();
	
	
}



//////////////////////////
////////////////////////////
////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////

var _level_editor_launch__RUNNING=0;
async function level_editor_launch(
		getUpdateAutoload_n_load_latelate_OPTIONAL){
		// above param for running from dkjs

	if(!_level_editor_launch__RUNNING){
		_level_editor_launch__RUNNING = 1;
	
		level_editor_data__load_files_SCHEMA(
			!getUpdateAutoload_n_load_latelate_OPTIONAL );  
				// do NOT reload files first time,
				// only get schema (files already loaded)
		rmloaded_loadroom( level_editor_launch_room);
	 }

	draw_settup_canvas(); update_start_game();
	rmloaded_launch_game();
}

