
async function behave_log_rmloaded_loadroom_signal(o){
	file_log(rmloaded_signal_sets_with_loadroom__get()); }
async function behave_center_cam_0_0(o){ //o is a rm here
	rmloaded_camera_focus(0,-3, 0, 0); } //(x,y, x_limit, y_limit)
async function behav_enter_fade_in_LRG_OBJS_ONLY(o){ //o is Room
	var tmpSize = 100; var tmpSpeed = 20;
	var tmpBox = gridstr_scale(" ", tmpSize, tmpSize);
	var tmp_imax = 5;
	//file_input(JSON.stringify(o));
	
	//for if in 1st frame, or isn't settup:
	for(var i=0; i<tmp_imax;  i+=1){
	   batch_draw_obj_list( o.objs_large,
		_rmloaded_camera_x, _rmloaded_camera_y,  
		1); // ???	
	   draw( tmpBox, i*tmpSpeed,0, "-" );
	   await update();
	   //file_log(i);
	}
	batch_draw_obj_list( o.objs_large,
		_rmloaded_camera_x, _rmloaded_camera_y,  
		1); // ???	
	//batch_draw_obj_list( o.objs,
	//	_rmloaded_camera_x, _rmloaded_camera_y, 
	//	1 ); // ???
}
async function behav_enter_fade_out_USES_LAST_DRAW(o){  //o is Room
	var tmpLastDraw = rmloaded_last_draw;
	var tmpSize = 100; var tmpSpeed = 20;
	var tmpBox = gridstr_scale(" ", tmpSize, tmpSize);
	var tmp_imax = 5;

	for(var i=0; i<tmp_imax;  i+=1){
	   draw( tmpLastDraw, 0,0, "");
	   draw( tmpBox, (tmp_imax -i)*tmpSpeed,0, "-" );
	   await update();
	}
	rmloaded_draw_overlay( tmpBox, 0,0, "-" );
	draw( tmpBox, 0,0, "-" );
}

var behav_wait_n_rmwarp_prev_room_FADE = "";
async function behav_wait_n_rmwarp_prev_room(o){ 
		// for 'updates' on room...
	
	if(o._timerRunning == void null){ 
		o._timerRunning = 0; controllers_clear_pressed();
	}else{ o._timerRunning +=1;}
	if(o._timerMax == void null){ o._timerMax = 200; }  
	if(o._timerMin == void null){ o._timerMin = 15; }  

	if(o._timerRunning > o._timerMin  
		&& controllers[0].getch != "" ){
			o._timerRunning = o._timerMax }

	if(o._timerRunning >= o._timerMax){ 
	  o._timerRunning =0; 
	  controllers_clear_pressed();
	  rmloaded_loadroom("NEXT_RM");
	  
	  //'blanking' draw_canvas
	  //rmloaded_draw_overlay(gridstr_scale(" ", 
	//	draw_canvas_get_width()+1, draw_canvas_get_height()+1));
	
	 }	
}
var credits_rooms = [
	{ objs:[], objs_large:[
	   {graphic:"zero", colgroup:"", x:0, y:0,behavior:"b_none"}] },
	{ objs:[], objs_large:[
	   {graphic:"one", colgroup:"", x:0, y:0,behavior:"b_none"}] },
	{ objs:[], objs_large:[
	   {graphic:"two", colgroup:"", x:0, y:0,behavior:"b_none"}] },
	{ objs:[], objs_large:[
	   {graphic:"three", colgroup:"", x:0, y:0,behavior:"b_none"}] },
	{ objs:[], objs_large:[
	   {graphic:"four", colgroup:"", x:0, y:0,behavior:"b_none"}] }
];
credits_rooms = ROWS_MAP( credits_rooms, function(a){
	a.enter_behavs = ["behave_center_cam_0_0", 
			"behave_log_rmloaded_loadroom_signal",
			"behav_enter_fade_in_LRG_OBJS_ONLY"];
	a.update_behavs = ["behav_wait_n_rmwarp_prev_room"];
	return a;} );

//first item needs to be loaded directly (no 'waiting' for it...)
rmloaded_loadroom( credits_rooms[0], null, 0, "signal");
for(var i =1; i< credits_rooms.length; i+=1){
	rmloaded_loadroom( credits_rooms[i], null, -1, "signal"+i);
}
