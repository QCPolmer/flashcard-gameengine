var rmloaded_enter_allrms_behavs =  null;//[]; //RUNS IN -ALL- ROOMS
var rmloaded_update_allrms_behavs = null;//[]; //= [];//RUNS IN -ALL- ROOMS
var rmloaded_leave_allrms_behavs = null;//[]; //= []; //RUNS IN -ALL- ROOMS

var testRoom = progen_obj_room({
	objs:[ 
	
	{x:4, y:5, behavior:"behavior_test_this_script", graphic:"@",
	  ignore_pause:false,  draw_1late_2last:1,colgroup:"",
	  dead:0, lazylink:["linkylinky2","linkylinky", "lazylink_player"]}
	], 
	objs_large:[
	{x:-21, y:12, behavior:"b_none", graphic:
`0#####    ## #######0
######## :E# ########
E#####    ## ####EE##
##E##### :D# ########
######## :D# ########
`, colgroup:"z0", ignore_pause:false, draw_1late_2last:1, dead:0}
	]});

// behaviors can be nested, one in another funct. (same object):behav(o)
async function behavior_test_this_script(o){
	await behav_mml_status( o);
	await behav_controller_basic_gridmove(o);
	rmloaded_camera_focus(o.x,o.y, 3, 3);
}

rmloaded_loadroom( testRoom); 

