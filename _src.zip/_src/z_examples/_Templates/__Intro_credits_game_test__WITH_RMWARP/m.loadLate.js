

async function behave_center_cam_0_0(o){ //o is a rm here
	rmloaded_camera_focus(0,-3, 0, 0); } //(x,y, x_limit, y_limit)
async function behav_enter_fade_in_LRG_OBJS_ONLY(o){ //o is Room
	var tmpSize = 100; var tmpSpeed = 20;
	var tmpBox = gridstr_scale(" ", tmpSize, tmpSize);
	var tmp_imax = 5;
	//file_input(JSON.stringify(o));
	
	//for if in 1st frame, or isn't settup:
	for(var i=0; i<tmp_imax;  i+=1){
	   batch_draw_obj_list( o.objs_large,
		_rmloaded_camera_x, _rmloaded_camera_y,  
		1); // ???	
	   draw( tmpBox, i*tmpSpeed,0, "-" );
	   await update();
	   //file_log(i);
	}
	batch_draw_obj_list( o.objs_large,
		_rmloaded_camera_x, _rmloaded_camera_y,  
		1); // ???	
	//batch_draw_obj_list( o.objs,
	//	_rmloaded_camera_x, _rmloaded_camera_y, 
	//	1 ); // ???
}
async function behav_enter_fade_out_USES_LAST_DRAW(o){  //o is Room
	var tmpLastDraw = rmloaded_last_draw;
	var tmpSize = 100; var tmpSpeed = 20;
	var tmpBox = gridstr_scale(" ", tmpSize, tmpSize);
	var tmp_imax = 5;

	for(var i=0; i<tmp_imax;  i+=1){
	   draw( tmpLastDraw, 0,0, "");
	   draw( tmpBox, (tmp_imax -i)*tmpSpeed,0, "-" );
	   await update();
	}
	rmloaded_draw_overlay( tmpBox, 0,0, "-" );
	draw( tmpBox, 0,0, "-" );
}

var behav_wait_n_rmwarp_prev_room_FADE = "";
async function behav_wait_n_rmwarp_prev_room(o){ 
		// for 'updates' on room...
	
	if(o._timerRunning == void null){ 
		o._timerRunning = 0; controllers_clear_pressed();
	}else{ o._timerRunning +=1;}
	if(o._timerMax == void null){ o._timerMax = 200; }  
	if(o._timerMin == void null){ o._timerMin = 15; }  

	if(o._timerRunning > o._timerMin  
		&& controllers[0].getch != "" ){
			o._timerRunning = o._timerMax }

	if(o._timerRunning >= o._timerMax){ 
	  o._timerRunning =0; 
	  controllers_clear_pressed();
	  g_rmwarp("G_PREV_ROOM.1", "right");
	  
	  //'blanking' draw_canvas
	  //rmloaded_draw_overlay(gridstr_scale(" ", 
	//	draw_canvas_get_width()+1, draw_canvas_get_height()+1));
	
	 }	
}
var credits_rooms = {
	0:{ objs:[], objs_large:[
	   {graphic:"zero", colgroup:"", x:0, y:0,behavior:"b_none"}] },
	1:{ objs:[], objs_large:[
	   {graphic:"one", colgroup:"", x:0, y:0,behavior:"b_none"}] },
	2:{ objs:[], objs_large:[
	   {graphic:"two", colgroup:"", x:0, y:0,behavior:"b_none"}] },
	3:{ objs:[], objs_large:[
	   {graphic:"three", colgroup:"", x:0, y:0,behavior:"b_none"}] },
	4:{ objs:[], objs_large:[
	   {graphic:"four", colgroup:"", x:0, y:0,behavior:"b_none"}] }
};

//ONLY access big-rooms/univs through rm_warp()!
//	AND warp this one in going 'right!!!"
var start_credits__UNIV2D = //similar data works for BIGRM 
{objs:[], objs_large:[], //next params are optional!!!
	//enter_behavs:["g_rmwarp_univ2d_behav"],
	update_behavs:[	"g_rmwarp_univ2d_behav"],
	leave_behavs:[], room_type:"shadows_no_lights",

	mml_wrldMap_injectBehavs_to_subRooms__4_BIGROOMS_onEnter_ONLY:{ 
	   onEnter:{ALL:["behave_center_cam_0_0", 
			"behav_enter_fade_in_LRG_OBJS_ONLY"]},
	   onUpdate:{ALL:["behav_wait_n_rmwarp_prev_room"], 
		 	NONE:"E", //"c#@":[], ".-":[]
		// /////UNTESTED--- NONE/ chars to push to specific rooms
		// 		UNTESTED
		// see--  _g_rmwarp_univ2d_bigrm_stack_GETMML_CHAR_behavs
		}, 
	   onLeave:{ ALL:["behav_enter_fade_out_USES_LAST_DRAW"]}
		//see above for how to use for data, UNTESTED 
	   },
	mml_wrldMap:{
		mml:`>123E`, 
		tilesizeXY_hiMag:3, tilesizeXY_at_mag0:20, //<-unused here 
		max_magnitude:1, // i think 1 == 1-lvl-wrldmap magnitude?
		start_pointChar:">", start_pointDir:"right",
		cmds_hiMag:{}, 
		cmds:{ // can be dotnote names! draws from 'list of rooms!'
		undefined:[""], // default
		">":["credits_rooms.0"],
		"1":["credits_rooms.1"],
		"2":["credits_rooms.2"],
		"3":["credits_rooms.3"],
		"E":["credits_rooms.4"]
		}}};


//rmloaded_loadroom( start_credits__UNIV2D); 
g_rmwarp( "start_credits__UNIV2D", "right"); 

