var rmloaded_enter_allrms_behavs =  null;//[]; //RUNS IN -ALL- ROOMS
var rmloaded_update_allrms_behavs = null;//[]; //= [];//RUNS IN -ALL- ROOMS
var rmloaded_leave_allrms_behavs = null;//[]; //= []; //RUNS IN -ALL- ROOMS

var tmpPlayer={x:4, y:5, behavior:"behavior_test_this_script", graphic:"@",
	  ignore_pause:false,  draw_1late_2last:1,colgroup:"",
	  dead:0, lazylink:["linkylinky2","linkylinky", "lazylink_player"]};

// behaviors can be nested, one in another funct. (same object):behav(o)
async function behavior_test_this_script(o){
	
	//file_input(JSON.stringify(o, null,2));
	await behav_controller_basic_gridmove(o);
	rmloaded_camera_focus(o.x,o.y, 3, 3);
	file_log(controller_mouse_x + " "+ controller_mouse_y+
		" " + g_rmwarp_stack.stack.length);
	//file_input(JSON.stringify(o, null,2));
}

/////////////////////////////////////////////
/////////////////////////////////////////////
/////////////////////////////////////////////
/////////////////////////////////////////////
/////////////////////////////////////////////
/////////////////////////////////////////////
/////////////////////////////////////////////
/////////////////////////////////////////////
/////////////////////////////////////////////

var credits_rooms = { //rmSizeXY is needed for EACH ROOM in addition
			// to the tilesizeXY_at_mag0 in main mml
	0:JSON.stringify(
	   { wall_graphic:"#", rmSizeXY:21, objs:[], objs_large:[
	   {graphic:"zero", colgroup:"", x:2, y:2,behavior:"b_none"}] }),
	1:JSON.stringify(
	   { wall_graphic:"#", rmSizeXY:21, objs:[], objs_large:[
	   {graphic:"one", colgroup:"", x:2, y:2,behavior:"b_none"}] }),
	2:JSON.stringify(
	   { wall_graphic:"#", rmSizeXY:21, objs:[], objs_large:[
	   {graphic:"two", colgroup:"", x:2, y:2,behavior:"b_none"}] }),
	3:JSON.stringify(
	   { wall_graphic:"#", rmSizeXY:21, objs:[], objs_large:[
	   {graphic:"three", colgroup:"", x:2, y:2,behavior:"b_none"}] }),
	4:JSON.stringify(
	  { wall_graphic:"#", rmSizeXY:21, objs:[], objs_large:[
	   {graphic:"four", colgroup:"", x:2, y:2,behavior:"b_none"}] })
};

//ONLY access big-rooms/univs through rm_warp()!
//	AND warp this one in going 'right!!!"
var tmp_univ2d_DEMO_ROOM = //similar data works for BIGRM 
{objs:[], objs_large:[], //next params are optional!!!

	//uncomment ONE update_behavs below!
	//update_behavs:["g_rmwarp_univ2d_behav"], 
	update_behavs:["g_rmwarp_univ2d_behav_GIANTRM"],
	leave_behavs:[], room_type:"shadows_no_lights",

	mml_wrldMap_injectBehavs_to_subRooms__4_BIGROOMS_onEnter_ONLY:{ 
	   onEnter:{ //NOTE: will run per obj-creation IN bigroom... 
		ALL:[ "g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav" ],
		// 	NONE:"asdfa","c#@":[], ".-":[]  //UNTESTED
		// see--  _g_rmwarp_univ2d_bigrm_stack_GETMML_CHAR_behavs
		},
	   //onUpdate is per tile, NOT running in BIGRM, Universe2D ONLY
	   onUpdate:{ALL:[ 
		"g_rmwarp_sidewalls_rtrnUpOnCross_FOR_rmUpdate_behav"] 
		// 	NONE:"asdfa", "c#@":[], ".-":[] //UNTESTED
		// see--  _g_rmwarp_univ2d_bigrm_stack_GETMML_CHAR_behavs
		}, 
	   onLeave:{ }//see above for how to use for data, UNTESTED 
	   },
	mml_wrldMap://STRUCT OR GLOBAL DOTNOTE
		{ 
		mml:
`###E####
#0>0100E#
###E####`, 
		tilesizeXY_hiMag:3, tilesizeXY_at_mag0:21, //<-for BIGROOM 
		max_magnitude:2, // i think 1 == 1-lvl-wrldmap magnitude?
		start_pointChar:">", start_pointDir:"down",
		cmds_hiMag:{}, 
		cmds:{ // can be dotnote names! draws from 'list of rooms!'
		undefined:[""], // default
			">":["credits_rooms.0"],
			"0":["credits_rooms.0"],
			"1":["credits_rooms.1", //random draw from these
				"credits_rooms.2","credits_rooms.3"],
			"E":["credits_rooms.4"],
			"#":["credits_rooms.4"] //wall character
		},
		cmds_hiMag:{//MUST==same height/width as tilesizeXY_at_mag0
// INITIAL ENTRY: 
// PLAYER IS DROPPED IN UPPER RIGHT HAND CORNER
// OF THIS BLOCK:
'>':[`EEE
EEE
EEE`],
"1":[`111
1#1
111`],
"0":[`000
0E0
000`],
'E':[`000
0E0
000`,
`111
1#1
111`],

'#':[`###
###
###`]
	}}
};

g_rmwarp_moveObjsBox_add_objs__run_pre_g_rmwarp( //ADDED 1/27/2026
   [tmpPlayer], []); //getObjsList, getObjsLargeList)

//rmloaded_loadroom( start_credits__UNIV2D); 
g_rmwarp( "tmp_univ2d_DEMO_ROOM", "down"); //initial entry set in:
			//tmp_univ2d_DEMO_ROOM, search: start_pointDir 
