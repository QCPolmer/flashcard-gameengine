
 //level_editor_block//  
 //TYPE_GRAPHIC_FRAMES//  <- needed, or processed as level, not 'frames'...
 //////////////////////
 /// NOTE: Objects dont automatically use this, 
 //	set 	o.graphic_frames__dotnote 
 //			AND
 //		o.graphic_frames__delay_between_frames //<-anim speed
 //	in objs and run (set as behav or embed in behav):
 //		level_editor_loader__draw_animation__behav(o)
 //	(can swap o.graphic_frames__dotnote to change animations!) 
 /////////////////////	
var //level_name//
testGfx1
//level_name//
 =  //list of frames (animation) 	//_level_editor_data//
[ 
`i-...
--+.-
- ..-`,
`i-...
--+--
- ..-`,
`i-...
-.+--
- ..-`
 ] 
//_level_editor_data//
;	//level_editor_block//
