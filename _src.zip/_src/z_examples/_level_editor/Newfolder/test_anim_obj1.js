var test_anim_obj1=

{
  "x": 0,
  "y": 0,
  "behavior": "level_editor_loader__draw_animation__behav",
  "graphic": "i-...\n--+.-\n- ..-",
  "colgroup": "0",
  "ignore_pause": false,
  "draw_1late_2last": 1,
  "dead": 0,
  "graphic_frames__dotnote": "testGfx1",
  "graphic_frames__delay_between_frames": 1,
  "_graphic_frames__NOTES": "Can delete this note-var, use level_editor_loader__draw_animation__behav(o) as obj behavior or in OBJ behavior to play animation (graphic_frames__dotnote, at speed graphic_frames__delay_between_frames), can change graphic_frames__dotnote/graphic_frames__delay_between_frames whenever"
};
