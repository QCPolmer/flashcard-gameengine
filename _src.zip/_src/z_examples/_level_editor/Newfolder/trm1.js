
; //level_editor_block//
; // can use creative naming & funct below to auto-make lists:
; // level_editor_loader__get_global_objs_named_like( 
; //		getTextToLookFor, useCatched_results_OPTIONAL)
var //level_name//
trm1
//level_name//
 =
{ 
_level_name: //level_name//
"trm1"
//level_name//
,
rmSizeXY: //rmSizeXY//
35  		//rmSizeXY//
,
objs:[], objs_large:[], // <-CLEARED WITH BELOW BEHAV TO ALLOW RM RELOAD
enter_behavs:[ "level_editor_loader__room_on_enter_behav", //enter_behavs//  //enter_behavs// 

],  
update_behavs:[ //update_behavs// //update_behavs// 
], 
leave_behavs:[ //leave_behavs// //leave_behavs// 

],  //DEFAULT: null
_level_editor_loader__room_on_enter_SEED:  //_level_editor_loader__room_on_enter_SEED//
null 		//_level_editor_loader__room_on_enter_SEED//
,
rmwarp_use_a_deep_copy_per_spawn: //rmwarp_use_a_deep_copy_per_spawn//
true 		//rmwarp_use_a_deep_copy_per_spawn//
, ///////////BELOW FOR 'g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav'
wall_graphic: //wall_graphic//
"##"  		//wall_graphic//
,

room_type: //room_type//
"shadows"
//room_type//
,

_level_editor_data: //_level_editor_data//
[
 {
  "obj_dotnote_name": "test2.abba",
  "x": 5,
  "y": 6
 },
 {
  "obj_dotnote_name": "test2.abba",
  "x": 14,
  "y": 6
 },
 {
  "obj_dotnote_name": "test2.abba",
  "x": 31,
  "y": 7
 },
 {
  "obj_dotnote_name": "test_anim_obj1",
  "x": 15,
  "y": 11
 },
 {
  "obj_dotnote_name": "test_anim_obj1",
  "x": 28,
  "y": 11
 },
 {
  "obj_dotnote_name": "tmpPlayer",
  "x": 13,
  "y": 8
 },
 {
  "obj_dotnote_name": "test_light",
  "x": 21,
  "y": 10
 },
 {
  "obj_dotnote_name": "test_light",
  "x": 10,
  "y": 10
 }
]
//_level_editor_data//

} //level_editor_block//
