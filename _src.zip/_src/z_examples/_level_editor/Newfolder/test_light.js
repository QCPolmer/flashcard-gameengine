var test_light=

{
  "x": 0,
  "y": 0,
  "behavior": "ray_light_width",
  "graphic": "L",
  "colgroup": "0",
  "ignore_pause": false,
  "draw_1late_2last": 1,
  "dead": 0,
  //"graphic_frames__dotnote": "testGfx1",
  //"graphic_frames__delay_between_frames": 1,
  "_graphic_frames__NOTES": "Can delete this note-var, use level_editor_loader__draw_animation__behav(o) as obj behavior or in OBJ behavior to play animation (graphic_frames__dotnote, at speed graphic_frames__delay_between_frames), can change graphic_frames__dotnote/graphic_frames__delay_between_frames whenever",
  "light_width": 14,
  "light_gfx": null
};
