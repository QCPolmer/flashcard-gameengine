var TTT=

{
  "x": 0,
  "y": 0,
  "behavior": "level_editor_loader__draw_animation__behav",
  "graphic": "i----\n--+--\n- u--",
  "colgroup": "0",
  "ignore_pause": false,
  "draw_1late_2last": 1,
  "dead": 0,
  "graphic_frames__dotnote": null,
  "graphic_frames__delay_between_frames": 1,
  "_graphic_frames__NOTES": "Can delete this note-var, use level_editor_loader__draw_animation__behav(o) as obj behavior or in OBJ behavior to play animation (graphic_frames__dotnote, at speed graphic_frames__delay_between_frames), can change graphic_frames__dotnote/graphic_frames__delay_between_frames whenever",
  "light_width": null,
  "light_gfx": null,
  "light___how_to_use": "set light_width (optional, add a gfx) AND set behavior to 'ray_light_width' (may only work on small 1 char objs, IDK)"
};
