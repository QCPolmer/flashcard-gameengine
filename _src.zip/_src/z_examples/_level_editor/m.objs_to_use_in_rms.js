
var testO = {x:0, y:0, graphic:"aaaaa", behavior:"b_none", lazylink:[],
	colgroup:"0", ignore_pause:false, draw_1late_2last:0, dead:0};

var test2 = {
	// 2 levels of depth... (max limit!)
	"qqq":{"ammma":
		{x:0, y:0, graphic:"ammma", behavior:"b_none", lazylink:[],
	     colgroup:"0", ignore_pause:false, draw_1late_2last:0, dead:0}
		},
	"abba":{x:0, y:0, graphic:"abbba", behavior:"b_none", lazylink:[],
	colgroup:"0", ignore_pause:false, draw_1late_2last:0, dead:0},
	"acca":{x:0, y:0, graphic:"accca", behavior:"b_none", lazylink:[],
	colgroup:"0", ignore_pause:false, draw_1late_2last:0, dead:0},
	"adda":{x:0, y:0, graphic:"addda", behavior:"b_none", lazylink:[],
	colgroup:"0", ignore_pause:false, draw_1late_2last:0, dead:0}
};
var tmpPlayer={x:4, y:5, behavior:"behavior_test_this_script", graphic:"@",
	  ignore_pause:false,  draw_1late_2last:1,colgroup:"",
	  dead:0, lazylink:["linkylinky2","linkylinky", "lazylink_player"]};

// behaviors can be nested, one in another funct. (same object):behav(o)
async function behavior_test_this_script(o){
	
	//file_input(JSON.stringify(o, null,2));
	await behav_controller_basic_gridmove(o);
	rmloaded_camera_focus(o.x,o.y, 3, 3);
	file_log(controller_mouse_x + " "+ controller_mouse_y+
		" " + g_rmwarp_stack.stack.length);
	//file_input(JSON.stringify(o, null,2));
}


				// only get schema (files already loaded)
//rmloaded_loadroom( level_editor_launch_room);

 
