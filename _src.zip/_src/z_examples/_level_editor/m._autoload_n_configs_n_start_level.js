
////////////////
/// auto_load_files_at_bottom_of_page, config towards center
//////

function m_autoload_n_configs_n_start_level(){ 
	
////////////////////
/// :b: START ROOM AND OTHER CONFIGS:b: (see data type below)
////////////////////
	//typically set in level editor, can be set here too!
	//	(it's set-injected directly  in this js file between tags)
	var m_load_configs_n_start_level__init_level_n_data= //default: {}
	//level_editor_loader__in_autoload__load_init_rm_player_etc_data//
{
  "CAUGHT_LOADED_level_names_list": [
    "trm1",
    "testR1"
  ],
  "convo_saved": [
    "level_editor_menu__convo_template",
    "ConvoT"
  ],
  "convo_objs_saved": [
    "tmpPlayer::testO"
  ]
}	
	//level_editor_loader__in_autoload__load_init_rm_player_etc_data//
; 
	// BELOW IS DATA TYPE: --ALL-- KEYS ARE OPTIONAL, CAN BE: '{}'
	//	(and NOT set the level to load too here)
	// { 
	//    room_name_dotnote:"", //null
	//    default_player_obj_dotnote:"", 
	//    	// or null, only works if use_rmwarp is defined (?) 
	//    warpInPlayerXY_overrides_rmwarp:{x:23, y,23}, // or null
	//    use_rmwarp:false, 
	//    use_rmwarp_direction:"left", //or null
	// }



/////////////////////////////////
/// :b: SAVE FUNCTIONS :b:
////////////////////////////////////////
	// await gFiles_menu( int_1_OnlySave_2OnlyLoad_OPTIONAL )
	// g_gamereset()
	// await gFiles_loadPrevSave() / await gFiles_loadPrevSave()
	// await gFiles_quickLoad() /  await gFiles_quickSave()
	//await gFiles_saveFileNumb(getNumb) /gFiles_loadFileNumb(getNumb)
	// 

/////////////////////////////////
/// :b: GAME SPECIFIC CONFIGS :b: (first found in g.js):
//////////////////////////////////////
	gGlobalThis.gVars2saveGame = 
		["_gFiles", "gConf", "_gFileNumberLoaded"];
	gGlobalThis.gVars2saveFile = [  "gFile_vars",
	    "gSaved_rooms", "g_rmwarp_stack", "_rogue_player_running" ];
	gGlobalThis.gVars2NOTsaveFile = ["rmloaded_b_globalThis",
	  "_rmloaded_search_struct__BASE","_rmloaded_search_struct",
	  "_rmloaded_search_lazylink_struct", "rmloaded_search_lazylink"]; 
	gGlobalThis.gConf = { saveMenu:"menu_test_o__saveMenu",  
		menu:"menu_test_o__saveMenu", //MUST be LIST BASED?
 		textMmlGui://"", 
		    "menu_test_o__disp_text", 
		txtMmlGui_menu:"menu_test_o__saveMenu",
		
		txtMmlGui_hide_roll_numbers:false,
		txtMmlGui_stnd_roll_max:99,
		
		BIGRM_leave_bounds_ignore_colgroup:'?',
		player_wall_colgroup:"0" // "#"
	 }; // global configs (stay same across save files)
	gGlobalThis.gFile_vars = {}; // saves to save-file
	gGlobalThis.gSaved_rooms = {}; 
		// I don't gGlobalThis.gSaved_rooms is handled yet. 

	gGlobalThis.gRandom_seed = 0; 
		// used for room generation, randomize on startup!

	gGlobalThis.gPlayer_lazylink_FOR_WARP_OR_WHATEVER_EXAMPLE =
			{lazylink:["lazylink_player"]}; 
	// "lazylink_player" is standard, can be changed in g_rmwarp!

	level_editor_loader__in_autoload__load_init_rm_player_etc( 
			m_load_configs_n_start_level__init_level_n_data);
}


////////////////////////
///	:b: AUTO-loading files :b: (set via m.js on run):
//////////////
var m_autoload_list = [
//AUTO_ADDS_FILES_BTWEEN_HERE//

"/", "/", "/", "/", "/", "/", "/", "/", "/", "/", "/", "/", 

//AUTO_ADDS_FILES_BTWEEN_HERE//
];

//auto-loading files, level editor handles it as it sometimes
//	needs to reload files (for game-loading, it's just loading files)
_level_editor_loader__load_m_autoload( m_autoload_list);



