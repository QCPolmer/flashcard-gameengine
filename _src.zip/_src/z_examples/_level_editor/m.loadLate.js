var rmloaded_enter_allrms_behavs =  null;//[]; //RUNS IN -ALL- ROOMS
var rmloaded_update_allrms_behavs = null;//[]; //= [];//RUNS IN -ALL- ROOMS
var rmloaded_leave_allrms_behavs = null;//[]; //= []; //RUNS IN -ALL- ROOMS








//level_editor_launch();
//level_editor_data__load_files_SCHEMA(1); // do NOT reload files first time,
				// only get schema (files already loaded)
//rmloaded_loadroom( level_editor_launch_room);

 
