// 
//////////////////////
// NOTE: This file is only one needed (if edited), IT is the loaded one
// 	m.loadLate/_autoload_n_configs_n_start_level are nice though.
//
//


// DUMMY TO TEST, WON'T RUN OUTSIDE OF FULL ENVIORNMENT
// =======================================================================
// =======================================================================
// =======================================================================
// 1. File Loader (Returns file as string or null if not found)

if( typeof file_dir_search=="undefined"){ 
prompt("WARNING: this is ran fom a standard webpage, so saving/many functions will NOT work here! Try in the sandbox or terminal version!");
file_load = function(get_cd, getFileName, ignore_embed){return ""; }
//    let resolved = window.__VFS_RESOLVER__(window.__VFS_CURRENT_DIR__, (get_cd ? get_cd + '/' : '') + getFileName);
//    if (resolved && window.__VFS_MAP__[resolved] !== undefined) {
//        return window.__VFS_MAP__[resolved];    }
//    return null; };
file_load_noembed = function(get_cd, getFileName) { return ""; }
 //   return window.file_load(get_cd, getFileName, 1);};
//window.file_load_js = function(get_cd, getFileName, ignore_embed) {
//    let code = window.file_load(get_cd, getFileName, ignore_embed); };
file_load_js_noembed = function(get_cd, getFileName) {
    return window.file_load_js(get_cd, getFileName, 1); };
_file_dir_search = function(startFileLoc, maxRecursiveDepth, regex_list) { 
	return []; };
file_dir_search = function(startFileLoc, maxRecursiveDepth, list_of_regex, list_of_exclude_regex) { return []; }
function file_dir_cd_js(){return "";}
}


/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////

async function main_funct(){	
	//loading:  (edit all m.js:grep/replace one lib.js name with two)
	await file_load_js( file_core_js_cd(),
	["txttools.js", "progen.js",  "progen_obj.js", 
	"rmloaded_search.js", "rmloaded.js", "ml.js",   
	"pipe_n_rows.js", "level_editor_loader.js",
	"gui_and_gui_menu.js", "gui_menu_flashcards.js",
	"controller_behaviors.js", "gridstr_rotate.js", "sketch_rays.js", 
	"g.js", "g_rmwarp.js", "g_rmwarp_univ2d.js", "g_convo.js", 
	"rogue.js"
	] );

	await level_editor_loader__update_autoload_files_if_available();
	
	// THIS IS DIFFERENT FROM MOST m.js-s SO CAN 
	// 	USE AS A STAND ALONE APP/SINGLE PAGE APP!!!
	await file_load_js( file_js_cd(), [
		"m._autoload_n_configs_n_start_level.js"
	] );

	
	await _level_editor_loader__load_m_autoload( m_autoload_list);
	await level_editor_data__load_files_SCHEMA(1);

	//await file_load_js( file_js_cd(), [
	//	"m.loadLate.js"
	//] );

	draw_settup_canvas(); update_start_game();
	
	// the level/configs in: m._autoload_n_configs_n_start_level.js
	await m_autoload_n_configs_n_start_level(); 
	level_editor_launch();
	//await rmloaded_launch_game();

} main_funct();


