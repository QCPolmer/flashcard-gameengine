
echo  \`" > $null <# \" >NUL  " >/dev/null <<EOF \" 
:: modified https://github.com/llamasoft/polyshell
:: This one gives a bs 1st line echo, but runs on sh. 

@ECHO OFF
REM =====
REM =====
REM =====
REM ===============================================
REM =====
REM ===== Batch Script Begin ==================
REM =====
REM ===============================================
REM =====


set caught_cd=%cd%

:: path to executable folder:
set mypath=%~dp0
:: set mypath=%cd%
set my_execute_js=m.js

:: below is for running the 'file to c' bundler! 
set my_bundler_loc=/../_utilitys/file_to_c_bundler
set my_html_create_loc=/../_utilitys/html_version_bundler

:: below is to put the directory before the .js file
set my_execute_js_dir=%~dp0
set "my_execute_js_dir=%my_execute_js_dir:\=/%"
set my_execute_js=%my_execute_js_dir%%my_execute_js%

set "mypath=%mypath:\=/%"
set compiler_cmds_n_src=/../_utilitys/interpreter_c_base_params.win.txt
set compiler_cmds="" :: this will fill in later
set ex=duktool.exe :: ex is Exectuable Name, can be a system one

:: choose compiler options
:: (ALSO good example of a 'choose a paramiter')
set compiler_to_exe_cmds_n_src==""
set /p compile_to_use="Set Compiler to use(still uses tcc for interpreter): 1)tcc, 2)gcc: "
set /p make_html_version="Make html version? 1)yes, 2)no: "
if %compile_to_use%==1 set compiler_to_exe_cmds_n_src=/../_utilitys/tcc_c_base_params.win.txt
if %compile_to_use%==2 set compiler_to_exe_cmds_n_src=/../_utilitys/gcc_c_base_params.win.txt
if %compiler_to_exe_cmds_n_src%=="" goto end_location

echo ...
echo STARTING...
echo Once you see 'test', press ENTER to continue. 
echo ...

set compiler_to_exe_cmds=""

set src=_src/COMPILE_THIS
set js_core=/../LOAD_2_core_js

set mp=%mypath%
if exist "%mp%/../../../../../../%src%" cd "%mp%/../../../../../../%src%"
if exist "%mp%/../../../../../%src%" cd "%mp%/../../../../../%src%"
if exist "%mp%/../../../../%src%" cd "%mp%/../../../../%src%"
if exist "%mp%/../../../%src%" cd "%mp%/../../../%src%"
if exist "%mp%/../../%src%" cd "%mp%/../../%src%"
if exist "%mp%/../%src%" cd "%mp%/../%src%"
if exist "%mp%/%src%" cd "%mp%/%src%"

for /f "delims=" %%i in (%cd%%compiler_cmds_n_src%) do ( set compiler_cmds=%%i )
for /f "delims=" %%i in (%cd%%compiler_to_exe_cmds_n_src%) do ( set compiler_to_exe_cmds=%%i )

:: getting js_core file
set tmp_cd=%cd%
cd %cd%%js_core%
set js_core_cd=%cd%
cd %tmp_cd%
:: getting js_core_bundler loc
set tmp_cd=%cd% 
cd %js_core_cd%
cd %cd%%my_bundler_loc%
set my_bundler_loc=%cd%\m.js
set "my_bundler_loc=%my_bundler_loc:\=/%"
cd %tmp_cd%
:: getting my_html_create_loc loc
set tmp_cd=%cd% 
cd %js_core_cd%
cd %cd%%my_html_create_loc%
set my_html_create_loc=%cd%\m.js
set "my_html_create_loc=%my_html_create_loc:\=/%"
cd %tmp_cd%


echo %compiler_to_exe_cmds% "%js_core_cd%\m.exe" 
echo "%js_core_cd%\m.exe"



:: running 'bundler' (convert js to c)
%compiler_cmds% "%my_bundler_loc%" -file_dir_cd "%caught_cd%" -file_core_js_cd "%js_core_cd%" "%*"

:: running 'create_html_version' (dumps in main file)
if %make_html_version%==1 %compiler_cmds% "%my_html_create_loc%" -file_dir_cd "%caught_cd%" -file_core_js_cd "%js_core_cd%" "%*"

:: ( %compiler_cmds% "%my_bundler_loc%" -file_dir_cd "%caught_cd%" -file_core_js_cd "%js_core_cd%" "%*" ) && ( goto end_location ) 

:: running 'create_executable'
( %compiler_to_exe_cmds% "%caught_cd%\m.exe"  ) && ( goto end_location ) 


for /f "delims=" %%i in (%cd%%compiler_cmds_n_src%) do ( set compiler_cmds=%%i )

set /p Input="interpreter failed, press any key to continue" 
echo .
echo command that failed
echo %compiler_cmds% "%mypath%/%my_execute_js%" -file_dir_cd "%caught_cd%"  "%*"	
echo  .
echo ----------------------------
echo -- FOR RUNNING VIA INTERPRETER (generally, tcc with _src)
echo -----------------------------
echo Failed to execute %compiler_cmds% . The way this script works is it goes up the file tree and locates %src% [ can look up 4-5 files ], then goes to that directory and runs main.js using commands from %compiler_cmds_n_src%. If your running the script using this method, make sure _src exists, and %compiler_cmds_n_src% [inside _src] contains instructions for a given compiler [ tcc is default, but that can be changed in %compiler_cmds_n_src%. ]
echo The compiler can be located relative to _src, if your going for portable, just leave the location for compiler relative to _src. 
echo -----------------------------
echo -- FOR RUNNING USING %ex%
echo -----------------------------
echo Also failed to find executable %ex% in file path [ can compile it and leave it above this file in the file tree and this should run ]
echo can generate it in _src/COMPILE_THIS [there is a bat file in there]  


:end_location
cd "%caught_cd%"
set /p Input=Enter Text to continue: 


REM =====
REM =====
REM =====
REM ===============================================
REM =====	
REM ====== Batch Script End ======
REM =====
REM ===============================================
GOTO :eof
TYPE CON >NUL
BATCH_SCRIPT




#> 
# ===== PowerShell Script Begin =====
echo "... but also a PowerShell script!"
# ====== PowerShell Script End ======

exit



EOF
# ==========
# ====================================================
# ==========
# ===== Bash Script Begin =============================
# ==========
# ====================================================
# ==========

caught_cd="$PWD"

# path to executable folder
_cwd=$(readlink -f "$0")
_cwd=$(dirname  "$_cwd")
#  _cwd="$PWD";
_exec_this_js_file="m.js";

ex=duktool.lin.exe


# read -p "dirname:$_exec_this_js_file "  username

echo "Set Compiler to use: 1-tcc, 2-gcc: "
read compile_to_use
if [ "$compile_to_use" = "1" ]; then compiler_to_exe_cmds_n_src=/../_utilitys/tcc_c_base_params.unix.txt; fi;
if [ "$compile_to_use" = "2" ]; then compiler_to_exe_cmds_n_src=/../_utilitys/gcc_c_base_params.unix.txt; fi;
echo $compile_to_use
echo $compiler_to_exe_cmds_n_src
if [ "$compiler_to_exe_cmds_n_src" = "" ]; then exit 0; fi;
compiler_to_exe_cmds="" # this will fill in later

echo "Create html version?: 1-yes, 2-no: "
read make_html_version
echo "$make_html_version"

compiler_cmds_n_src=/../_utilitys/interpreter_c_base_params.unix.txt
compiler_cmds="" # this will fill in later

# compiler_to_exe_cmds_n_src=/../_utilitys/tcc_c_base_params.unix.txt
# compiler_to_exe_cmds="" # this will fill in later

src=_src/COMPILE_THIS
js_core=../LOAD_2_core_js
my_bundler_loc=/../_utilitys/file_to_c_bundler
my_html_create_loc=/../_utilitys/html_version_bundler

if [ -d "$_cwd/../../../../../../$src" ] ; 
	then cd "$_cwd/../../../../../../$src"; fi;
if [ -d "$_cwd/../../../../../$src" ] ; 
	then cd "$_cwd/../../../../../$src"; fi;
if [ -d "$_cwd/../../../../$src" ] ; then cd "$_cwd/../../../../$src"; fi;
if [ -d "$_cwd/../../../$src" ] ; then cd "$_cwd/../../../$src"; fi;
if [ -d "$_cwd/../../$src" ] ; then cd "$_cwd/../../$src"; fi;
if [ -d "$_cwd/../$src" ] ; then cd "$_cwd/../$src"; fi;
if [ -d "$_cwd/$src" ] ; then cd "$_cwd/$src"; fi;


# reading file, line by line. printf would work if new lines needed
while read line
do
compiler_cmds=$compiler_cmds$line
done < $PWD$compiler_cmds_n_src

# for compiler_to_exe_cmds
while read line
do
compiler_to_exe_cmd="$compiler_to_exe_cmd$line"
done < $PWD$compiler_to_exe_cmds_n_src

echo "Pausing 1: everything seems good so far... type anything and enter to continue..."
read var2
echo "Pausing 2: And type something, then enter one more time..."
#getting input [for a pause]
read var1


#getting js_core_loc_src
tmp_cd=$PWD
cd $js_core
js_core_cd=$PWD
cd $tmp_cd
# getting js_core_bundler loc
tmp_cd=$PWD 
cd $js_core_cd
cd $PWD$my_bundler_loc
my_bundler_loc=$PWD/m.js
cd $tmp_cd
# getting my_html_create_loc loc
tmp_cd=$PWD 
cd $js_core_cd
cd $PWD$my_html_create_loc
my_html_create_loc=$PWD/m.js
cd $tmp_cd


echo "$make_html_version"

echo "Pausing 3: Everything STILL good. Type anything and enter to continue, then ENTER once 'test'appears"
#getting input [for a pause]
read var1


# this is error testing in sh. ( not '!' operator! )
$compiler_cmds "$my_bundler_loc" -file_dir_cd "$caught_cd" -file_core_js_cd "$js_core_cd" $@

if [ "$make_html_version" = "1" ]; then $compiler_cmds "$my_html_create_loc" -file_dir_cd "$caught_cd" -file_core_js_cd "$js_core_cd" $@; fi;

if ! $compiler_to_exe_cmd "$caught_cd/m.lin.exe" 
# elif [ 1 -eq 1]
then
		echo 
		echo ------------ COMMANDS THAT FAILED:
		echo	$compiler_cmds "$_cwd/$_exec_this_js_file" -file_dir_cd "$caught_cd" $@ 
		echo	$foundex "$_cwd/$_exec_this_js_file" -file_dir_cd "$caught_cd" $@
		echo [also couldnt find the executable file]
		echo
		echo It didnt work! Maybe the compiler wasnt found [ see  $_compiler_base.unix.txt ] or something else broke...
		echo

fi

echo press enter to continue
read var1
cd "$caught_cd"
exit $?


# ==========
# ====================================================
# ==========
# ====== Bash Script End =======================
# ==========
# ==================================================
# ==========
case $- in *"i"*) cat /dev/stdin >/dev/null ;; esac
exit




