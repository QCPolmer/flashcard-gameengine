
//level_editor_block//
var //level_name//
tesssss
//level_name//
 =
{
_level_editor_loader__room_on_enter_SEED: 
//_level_editor_loader__room_on_enter_SEED//
null
//_level_editor_loader__room_on_enter_SEED//
, 
_level_name:
//level_name//
"tesssss"
//level_name//
,
rmSizeXY: //rmSizeXY//
21
//rmSizeXY//
,
objs:[], objs_large:[],  // <-CLEARED WITH BELOW BEHAV TO ALLOW RM RELOAD
enter_behavs:[ "level_editor_loader__room_on_enter_behav", 
//enter_behavs//

//enter_behavs// 

],  
update_behavs:[ //update_behavs// 

//update_behavs// 
], 
leave_behavs:[ //leave_behavs//

//leave_behavs// 
], 

_level_editor_data: //_level_editor_data//
[{"obj_dotnote_name":"test2.abba","x":-9,"y":4},{"obj_dotnote_name":"test2.abba","x":-9,"y":4},{"x":-4,"y":4,"obj_dotnote_name":"test2.abba"},{"x":-8,"y":3,"obj_dotnote_name":"test2.abba"},{"x":-8,"y":3,"obj_dotnote_name":"test2.abba"},{"x":-2,"y":2,"obj_dotnote_name":"test2.abba"},{"x":-2,"y":2,"obj_dotnote_name":"test2.abba"},{"x":3,"y":4,"obj_dotnote_name":"test2.abba"},{"x":3,"y":4,"obj_dotnote_name":"test2.abba"},{"x":43,"y":11,"obj_dotnote_name":"test2.abba"},{"x":43,"y":11,"obj_dotnote_name":"test2.abba"}]
//_level_editor_data//
,

rmwarp_use_a_deep_copy_per_spawn: //rmwarp_use_a_deep_copy_per_spawn//
true
//rmwarp_use_a_deep_copy_per_spawn//
,
///////////BELOW FOR 'g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav'
wall_graphic: //wall_graphic//
"##"
//wall_graphic//
,

room_type: //room_type//
"_2d"
//room_type//
}
//level_editor_block//
