//search z_example files with search_this_file.txt (or use whatever
var testRoom ={
	// define more options for below:rmloaded.js/_rmloaded_launch_game_DISP_PARAMS
	enter_behavs:[],update_behavs:[],leave_behavs:[], 	
	room_type: "shadows3d",// "shadows3d", "_2d", 
	   //"_3d","shadows_ignore_walls", "shadows_no_lights", "shadows"

	//skybox3d, or undefined/ null (commented out works)
	skybox3d:`                    /               /        
		      ----- /               /        
	33333	    /      /              /          
		   /      /              /           
	----------/      /             /            /
		 /                   /             / 
				   /              /  `, 

	objs:[ 
	{x:3, y:9,behavior:"ray_light_width",colgroup:"",
	graphic:"0", draw_1late_2last:1, light_width:5},
	{x:13, y:19,behavior:"ray_light_width",colgroup:"",
	graphic:"0", draw_1late_2last:1, light_width:5},	
	{x:3, y:19,behavior:"ray_light_width",colgroup:"",
	graphic:"0", draw_1late_2last:1, light_width:5},	
		
	 {x:-12, y:10, z:0,behavior:"test_this_script", 
//"behav_rmloaded_debug_progen", //	,  . @... I think R controls... 
	graphic:"@",ignore_pause:true, draw_1late_2last:1, // 0=hidden
		colgroup:"",dead:0 },//dead is optional	
	{x:-13, y:10, z:2,behavior:"test_3d_move",
//"behav_rmloaded_debug_progen", //	,  . @... I think R controls... 
	graphic:"@",ignore_pause:true, draw_1late_2last:1, // 0=hidden
		colgroup:"d",dead:0 },//dead is optional
	{x:-18.5, y:10.3, z:2,behavior:"b_none",
//"behav_rmloaded_debug_progen", //	,  . @... I think R controls... 
	graphic:"!",ignore_pause:true, draw_1late_2last:1, // 0=hidden
		colgroup:"d",dead:0, d3height:40, 
		d3graphic:
`&&0&&
00 00
0   0
00000`, d3transparentChar:"&"},//dead is optional
{x:-8, y:9, z:40,behavior:"b_none",
//"behav_rmloaded_debug_progen", //	,  . @... I think R controls... 
	graphic:"!",ignore_pause:true, draw_1late_2last:1, // 0=hidden
		colgroup:"d",dead:0, d3height:40, },//dead is optional
	{x:-18, y:10, z:-5, behavior:"test_3d_move",
//"behav_rmloaded_debug_progen", //	,  . @... I think R controls... 
	graphic:"%",ignore_pause:true, draw_1late_2last:1, // 0=hidden
		colgroup:"d",dead:0 }//dead is optional
	], 
	objs_large:[
	{x:-10, y:-10, z:0, behavior:"b_none", 
		graphic:gridstr_scale(".",100,100), 
		colgroup:"", ignore_pause:false, 
		draw_1late_2last:0, dead:0,
		progen:null},
	{x:-13, y:10, z:2,behavior:"test_3d_move",
//"behav_rmloaded_debug_progen", //	,  . @... I think R controls... 
	graphic:
`TEST
TEST
TEST
`,
		ignore_pause:true, draw_1late_2last:1, // 0=hidden
		colgroup:"d",dead:0 },//dead is optional
	{x:14, y:10, z:0, behavior:"test_rot", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		progen:null },
{x:-14, y:10, z:0, behavior:"test_rot", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		progen:null},
{x:4, y:-40, z:0, behavior:"test_rot", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		progen:null},
{x:-6, y:4, z:0, behavior:"b_none", graphic:
`0#####    ## abcd###5
6####### :D# ##  ###4
7 ####    ## ## ### 3
8  ##### :D# #####  2
9####### :D# #######1
                     
     TEqT  TEST      
                     
######## :D# a#######
######    ## b#######
######## :D# c#######
##  ##    ## d#######
0#Qrs### :D# e######X
`, colgroup:"0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		progen:null},
{x:-20, y:4, z:0, behavior:"b_none", graphic:
//{x:-80, y:4, z:0, behavior:"b_none", graphic:
`0#####    ## abcd###5
6####### :D# ##  ###4
                     
                     
      123456         
      a    A         
      b       B      
      c    C         
      dzyxwD         
                     
                     
##  ##    ## d#######
0#Qrs### :D# e######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		progen:null}
	]};

function gen_passages( txtgrid_to_scale, x_size, y_size, getTxt_canvas,
		path_graphic_id, path_thickness){
	
}	
function make_1_passage( getstr, x,y, path_graphic, path_thickness ){

}
//I need a txt-grid erase EDIT: can set overlay or null char to 
//	"X" and paste: " "
//
//
// gridstr_overlay(s_to,	s_from, x, y, overlayChar_or_null)
// var gridstr_scale =function(textblock, size_x, size_y){}
//var gridstr_scale_nearest_neighbor = function(textblock, size_x, size_y){}



function gen_rooms( x_size, y_size, getTxt_canvas, getRandSeed){
	var tmpTxt = gridstr_scale(txtgrid_to_scale, x_size, y_size);
	var tmpGrid = [];

	

	//return {map:tmpTxt };
}
function gen_rooms_test( x_size, y_size, cell_min_x, cell_max_x ){

}
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
/////////////// start js_code /////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////

async function behavior_test_rot(o){
	//_rmloaded_lookup_lrg_colgroups
	//_rmloaded_lookup_xlocs
	if(o.caught_graphic == undefined){ 
		o.rot_angle = 0;
		//o.caught_graphic = o.graphic+"";
		o.caught_graphic = 
		  gridstr_rotation_MAKE_ROTATABLE_BORDER( 
			  gridstr_scale_nearest_neighbor(
				  o.graphic,10,10));}
	

	o.rot_angle +=.02;
	o.graphic =  gridstr_rotate_90_degrees(//gridstr_rotate( 
		o.caught_graphic, o.rot_angle, true);//.01);
}

rmloaded_b_globalThis.test_rot = behavior_test_rot;

//rmloaded_sketch_all_objs(camx,camy);
var tmp_mimimap = gridstr_scale(" ", 20,10);

var tmpAngle=.75; 
var tmpHeight=-1; 
var tmpCam_tilt =0;
var display_as_3d = false; 
async function behavior_test_this_script(o){

	//draw_shadows( _rmloaded_camera_x+10, _rmloaded_camera_y );
	
	//draw_shadows(o.x+_rmloaded_camera_x, o.y+_rmloaded_camera_y);
	

	//o.light_width =12;
	//o.light_force_full_speed = true;
	//rmloaded_b_globalThis.ray_light_width(o);

	rmloaded_draw_overlay("press3=3d-fps :"+(1000/_update_delta),0 ,3, "");
	rmloaded_draw_overlay("xy :"+o.x+" " +o.y,0 ,4, "");
	if(rmloaded_room.room_type != "shadows3d"){
		await rmloaded_b_globalThis.behav_controller_basic_gridmove(o);
	}else{
		await rmloaded_b_globalThis.behav_controller_3d_move(o);
	}

	//file_input(sketch_3d( 
	//	o.x, o.y, 0,0,0));
	if(controllers[0].getch == "b"){
		tmpAngle +=.1; 
	}if(controllers[0].getch == "B"){ tmpAngle -=.1;}
	if(controllers[0].getch == "h"){
		tmpHeight +=.1; 
	}if(controllers[0].getch == "H"){ tmpHeight -=.1;}
	
	if(controllers[0].getch == "j"){ o.x-=.1;}	
	if(controllers[0].getch == "J"){ o.x+=.1;}
	if(controllers[0].getch == "k"){ o.y+=.1;}
	if(controllers[0].getch == "K"){ o.y-=.1;}	
	
	//focal length
	//if(controllers[0].getch == "z"){ 
	//	tmpFieldOfView_Default_pnt8-=.1;}	
	//if(controllers[0].getch == "Z"){ 
	//	tmpFieldOfView_Default_pnt8+=.1;}

	if(controllers[0].getch == "i"){ tmpCam_tilt-=1;}	
	if(controllers[0].getch == "I"){ tmpCam_tilt+=1;}

	//testing light
	o.light_width =1;
	rmloaded_b_globalThis.ray_light_width(o);
	
33	//rmloaded_camera_3d_set(o.x,o.y, tmpHeight, tmpAngle, tmpCam_tilt );
	//display_as_3=	_rmloaded_launch_game_DISP_PARAMS[
	//			rmloaded_room.room_type].draw_3d_n_viewdist;
	if( rmloaded_room.room_type == "shadows3d" ){
		var skybox_gridstr = 
	`                    /               /        
		      ----- /               /        
	33333	    /      /              /          
		   /      /              /           
	----------/      /             /            /
		 /                   /             / 
				   /              /  `;
		var shadow_gridstr = 
`&&&&&&
&&  &&
&&  &&
&&&&&&`;
		
		rmloaded_camera_3d_set( o.x, o.y, 
			tmpHeight, tmpAngle, tmpCam_tilt );
		/*
		draw_grid( sketch_3d_FULL_SCREEN_DEFAULT( 
			o.x, o.y, tmpAngle,tmpHeight,tmpCam_tilt,
			"0", "d",
			  	//above = colgroups walls/ sprites.
			skybox_gridstr,
			shadow_gridstr, "&",
			-14,7,
			9 ), // view_dist
			//angle,cam_height,cam_tilt),
		  	 0, 0, ""	); 
		*/
		// mini-map
		sketch_init( tmp_mimimap);
		await rmloaded_sketch_all_objs(o.x,o.y);
		draw(sketch_get(), 50,0);
		sketch_end();

	}else{
		rmloaded_camera_focus(o.x,o.y, 3, 3);}
	if(controllers[0].getch == "3"){ 
		if(rmloaded_room.room_type =="shadows3d"){
			rmloaded_room.room_type ="shadows";
		}else{rmloaded_room.room_type ="shadows3d";} }

	 //x,y, x/y limit
	//rmloaded_room.objs[rmloaded_room.objs.length-1].dead = true;
    //if(controllers[0].pressed[0]=="RIGHT" //.isdown['RIGHT'];.getch="r"
		//UP,LEFT,RIGHT,DOWN,A/B/C/D/ENTER/ESCAPE 
	//&& rmloaded_col_test_SIMPLE(o.x+1, o.y,"z")==""){o.x+=1;return;}
}
rmloaded_b_globalThis.test_this_script = behavior_test_this_script;

//testing moving in 3d
async function behavior_test_3d_move(o){
	if(!o.hasOwnProperty( "move_polarity")){
		o.move_ticker = 50;
		o.move_ticker_MAX = 50;
		o.move_polarity = -1;
	}
	//file_input(o.move_ticker);
	if(o.move_ticker > 0){ o.move_ticker -=1;
		o.x+=.2 *o.move_polarity;
		o.y+=.2 *o.move_polarity;
		o.z-=2 *o.move_polarity;
	}else{ o.move_ticker += o.move_ticker_MAX;
		
		if( o.move_polarity == -1){
			o.move_polarity =1; }else{ o.move_polarity = -1;}}

}
rmloaded_b_globalThis.test_3d_move = behavior_test_3d_move;


rmloaded_loadroom( testRoom); 
