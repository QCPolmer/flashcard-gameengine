// 
//////////////////////
// NOTE: This file is only one needed (if edited), IT is the loaded one
// 	m.loadLate/_autoload_n_configs_n_start_level are nice though.
//
async function main_funct(){	
	//loading:  (edit all m.js:grep/replace one lib.js name with two)
	await file_load_js( file_core_js_cd(),
	["txttools.js", "progen.js",  "progen_obj.js", 
	"rmloaded_search.js", "rmloaded.js", "ml.js",   
	"pipe_n_rows.js", "level_editor_loader.js",
	"gui_and_gui_menu.js", "gui_menu_flashcards.js",
	"controller_behaviors.js", "gridstr_rotate.js", "sketch_rays.js", 
	"g.js", "g_rmwarp.js", "g_rmwarp_univ2d.js", "g_convo.js", 
	"sketch_3d.js",
	"rogue.js"
	] );

	await level_editor_loader__update_autoload_files_if_available();
	
	await file_load_js( file_js_cd(), [
		"m._autoload_n_configs_n_start_level.js"
	] );
	await _level_editor_loader__load_m_autoload( m_autoload_list);
	await file_load_js( file_js_cd(), [
		"m.loadLate.js"
	] );
	
	draw_settup_canvas(); update_start_game();
	
	// the level/configs in: m._autoload_n_configs_n_start_level.js
	m_autoload_n_configs_n_start_level(); 
	
	await rmloaded_launch_game();

} main_funct();


