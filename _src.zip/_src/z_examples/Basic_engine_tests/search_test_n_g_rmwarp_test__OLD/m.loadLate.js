
// :b: rmloaded_bounding_box_test_n_deloutbounds_n_limit_cam :b:



////////////////////////////////////////////////////////////////////
// :b: ABOVE IS NEW CODE FOR UNIV/BIGRM TO TEST!!! :b:
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////





// OK, index of, and lastindex of WORK!!!
file_input("111112222111111".lastIndexOf("1",-100));

file_input("111112222111111".split(new RegExp("12".split("").join('|'))).join("@"));



///////////////////////////////////////////////////
/////////////////////
///////////////////////////////////////////
////////////////////////////////////
//////////////////////////////////////
////////////////////////////////////////////
///////////////////////////////////////////
////////////////////////////////////



/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////
//////// Progen_mix basic testing (NOT complete, but seems to work
/////		Still need to test the monte-carlo method
///		(changes player char to 'Q' or 'R')
////////////////////////////////

var mix_standard = progen_mix_stringify([
{ignore_pause:true, dead:0, graphic:"Q", draw_1late_2last:1,colgroup:"" },
{ignore_pause:true, dead:0, graphic:"R", draw_1late_2last:1,colgroup:""}
]) // 0=hidden
		
var ppp = {};
ppp.basic_behav = progen_mix_stringify( 
[{behavior:"test_this_script"}]);


var mix_walk_in_square = progen_mix_stringify(
	{behavior:"ml_looping_behavior", 
		mml:{mml:"1b3?d25 24d?c 24c?d  1a3?c25 ", cmds:{
			//CAN WRITE OUT AS OBJS, FOR EASIER FUNCT USE!!!! 
			a:{0:"ml_move", 1:"x", 2:0.2},
			//a:["ml_move", "x", 0.2],
			b:["ml_move", "x", -0.2],
			c:["ml_move", "y", 0.2],
			d:["ml_move", "y", -0.2],
			Q:["ml_break_test"]
			}} });

function behav_test_rmloadedsearch_SLOW(o){
	//file_log(
	 	rmloaded_search_near("near 20 player_marker", null,
		 o.x, o.y); 
	//);
}
function behavior_none(o){}

var testRoom = progen_obj_room({
	objs:[ 
	 
	 //{x:4, y:10, //behavior:"test_this_script", graphic:"@",
	//	p_mix:"mix_standard",
		//testing out like this :D
	//	behavior:"rmloaded_searchUpdate"},
	

	
	//MUST load rmloaded_searchUpdate_slow FIRST!!!
	//	(sets up room variables)
	{x:4, y:10, //behavior:"test_this_script", graphic:"@",
		p_mix:"mix_standard",
		//testing out like this :D
		behavior:"behav_test_rmloadedsearch_SLOW"},
	 
	{x:4, y:10, //behavior:"test_this_script", graphic:"@",
		player_marker:1, //for testing search
		
		lazylink:["linkylinky2","linkylinky", "lazylink_player"],
		p_mix:"mix_standard ppp.basic_behav"}, 	
	
	 
	{x:4, y:10, p_mix:"mix_standard mix_walk_in_square",
		lazylink:["linkylinky"] }  	
	], 
	objs_large:[
	{x:14, y:10, behavior:"test_rot", lazylink:["linkylinky"],
	graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		progen:null},
{x:-14, y:10, behavior:"test_rot", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0},
{x:1, y:12, behavior:"test_rot_90", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0}

	]});

function gen_passages( txtgrid_to_scale, x_size, y_size, getTxt_canvas,
		path_graphic_id, path_thickness){
	
}	
function make_1_passage( getstr, x,y, path_graphic, path_thickness ){

}
//I need a txt-grid erase EDIT: can set overlay or null char to 
//	"X" and paste: " "
//
//
// gridstr_overlay(s_to,	s_from, x, y, overlayChar_or_null)
// var gridstr_scale =f unction(textblock, size_x, size_y){}
//var gridstr_scale_nearest_neighbor = f unction(textblock, size_x, size_y){}



function gen_rooms( x_size, y_size, getTxt_canvas, getRandSeed){
	var tmpTxt = gridstr_scale(txtgrid_to_scale, x_size, y_size);
	var tmpGrid = [];

	

	//return {map:tmpTxt };
}
function gen_rooms_test( x_size, y_size, cell_min_x, cell_max_x ){

}

async function behavior_test_rot(o){
	if(o.caught_graphic == undefined){ 
		o.rot_angle = 0;
		//o.caught_graphic = o.graphic+"";
		
		o.caught_graphic = 
		  gridstr_rotation_MAKE_ROTATABLE_BORDER( 
			  gridstr_scale_nearest_neighbor(
				  o.graphic,100,130));

		}
	o.rot_angle +=.02;
	//o.graphic =  gridstr_rotate_90_degrees(//gridstr_rotate(
	// 	o.caught_graphic, o.rot_angle, true);//.01);
	
	o.graphic =  gridstr_rotate( 
		o.caught_graphic, o.rot_angle, " ", .01);
}
rmloaded_b_globalThis.test_rot = behavior_test_rot;

async function behavior_test_rot_90(o){
	if(o.caught_graphic == undefined){ 
		o.rot_angle = 0;
		//o.caught_graphic = o.graphic+"";
		o.caught_graphic = ""+o.graphic;}
	o.rot_angle +=.02;
	o.graphic =  gridstr_rotate_90_degrees(//gridstr_rotate(
	 	o.caught_graphic, o.rot_angle, true);//.01);
	//o.graphic =  gridstr_rotate( 
	//	o.caught_graphic, o.rot_angle," ",  .01);
}
rmloaded_b_globalThis.test_rot_90 = behavior_test_rot_90;

var flaschard_deck = gui_menu_flashcards_GEN_DECK_TEST( )

var save_state_test= {};

var rmloaded_TMP_WARPED =0;
// behaviors can be nested, one in another funct. (same object):behav(o)
async function behavior_test_this_script(o){
	rmloaded_draw_overlay("fps :"+(1000/_update_delta),0 ,3, "");
	rmloaded_draw_overlay(
"PRESS 'm' MENU-BLOCKNG,'f' flashcards,u rmstackTest-THEN>U subrm, i:loadtest",0 ,4, "");
	
	var srch = rmloaded_search_lazylink["linkylinky"];
	var srch2 = rmloaded_search_lazylink["linkylinky2"];
	if(srch2 != void null){
		file_log(srch2[0].x + "--" + srch2[0].y + "---"+
			srch.length ); }

	if(controllers[0].getch == "i"){ await gFiles_menu(); }
	if(controllers[0].getch == "I"){ 
		//DEBUGGING
		file_input(JSON.stringify(gConf)); }
	 
	//generate a marker with this object, and test for it!
	//(also, check number of objs in room, to make 
	//	sure gen-obj is actually self-destructing!)
	
	await rmloaded_b_globalThis.behav_controller_basic_gridmove(o);
	rmloaded_camera_focus(o.x,o.y, 3, 3);
	
	if(controllers[0].getch == "u"){
	   //run txt-disp funct!!
	   g_rmwarp("g_rmwarp_univ2d_n_BIGROOM__example", "down");	
	}	
	if(controllers[0].getch == "U"){
	   //run txt-disp funct!!
	   g_rmwarp("g_rmwarp_univ2d_example__rmAsTile1", "down",
		["g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav"],
		["g_rmwarp_sidewalls_rtrnUpOnCross_FOR_rmUpdate_behav"]); }	

	if(controllers[0].getch == "d"){
	   //run txt-disp funct!!
	   await gui_disp_txt_BLOCKING( 
		o.x, o.y,//<only relevent it used /w right disp
		"gui_disp_width", "gui_disp_height",
		"menu_test_o__disp_text",
		"I've been scared to stop and survey all the choices", 
		rmloaded_last_draw, "pedantic",true );	
	}
	if(controllers[0].getch == "s"){
		//generate txt-disp obj!
		gui_disp_txt__by_creating_mmlobj(o.x, o.y,
		gui_disp_txt__conf_fixed_objxy,  
		"GOOOOO!", 
		true, "YES!", 
		true, 10);
		//file_input(JSON.stringify(
		//	rmloaded_room.objs[rmloaded_room.objs.length-1]) );
	}
	if(controllers[0].getch == "m"){	//for 'menu'

		await gui_menu_blocking( "DESCRIPTION",
			"menu_test_o__disp_text",//getConfigName, 
			["one", "two", "threee"],
			"HINTS",
			rmloaded_last_draw
			//,bg_OPTIONAL
			);
	}
	if(controllers[0].getch == "f"){ //for 'flashcard'
		
		await gui_menu_flashcard_statemachine_BLOCKING(
			flaschard_deck,"draw",
			rmloaded_last_draw );
		//async f unction gui_menu_flashcard_statemachine_BLOCKING(
		//fc,getDraw_str, // flaschcard data
		//bg_OPTIONAL)
	}

	
	 //x,y, x/y limit
	//rmloaded_room.objs[rmloaded_room.objs.length-1].dead = true;
    //if(controllers[0].pressed[0]=="RIGHT" //.isdown['RIGHT'];.getch="r"
		//UP,LEFT,RIGHT,DOWN,A/B/C/D/ENTER/ESCAPE 
	//&& rmloaded_col_test_SIMPLE(o.x+1, o.y,"z")==""){o.x+=1;return;}
	 //behav_wrldUpdate(o);
	 var exits= rmloaded_bounding_box_test_n_deloutbounds_n_limit_cam(
	  rmloaded_room, 1, null, 1, 1,
	  "0", "0><+-", o.x, o.y, 
			// REPLACE BELOW WITH COMMENTED-OUT for limit-view
			// -----> CENTERX, CENTERY, SIZEX, SIZEY 
			//50, 50, 100,100
			0, 0, 100000000,100000000
	
	);
}
rmloaded_b_globalThis.test_this_script = behavior_test_this_script;

rmloaded_loadroom( testRoom); 

