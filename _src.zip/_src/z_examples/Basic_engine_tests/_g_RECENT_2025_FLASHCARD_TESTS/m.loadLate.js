// g_STORYENGINE: -----------


// OK, index of, and lastindex of WORK!!!
file_input("111112222111111".lastIndexOf("1",-100));

file_input("111112222111111".split(new RegExp("12".split("").join('|'))).join("@"));


//file_dir_search = function( startFileLoc, maxRecursiveDepth,
//		list_of_regex, list_of_exclude_regex);

///////////////////////////////////////////////////
/////////////////////
///////////////////////////////////////////
////////////////////////////////////
//////////////////////////////////////
////////////////////////////////////////////
///////////////////////////////////////////
////////////////////////////////////



/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////
//////// Progen_mix basic testing (NOT complete, but seems to work
/////		Still need to test the monte-carlo method
///		(changes player char to 'Q' or 'R')
////////////////////////////////

var mix_standard = progen_mix_stringify([
{ignore_pause:false, dead:0, graphic:"Q", draw_1late_2last:1,colgroup:"" },
{ignore_pause:false, dead:0, graphic:"R", draw_1late_2last:1,colgroup:""}
]); // 0=hidden
		
var ppp = {};
ppp.basic_behav = progen_mix_stringify( 
[{behavior:"test_this_script"}]);

var tmpRandWalk =["4", "24","10"];
var mix_walk_in_square = progen_mix_stringify(
	{behavior:"ml_looping_behavior", 
		mml:{
			mml_loop_resets_preprocess:1,
			mml:"##tmpRandWalk##b3?d2 ##tmpRandWalk##d?c ##tmpRandWalk##c?d  ##tmpRandWalk##a3?c2", cmds:{
			//mml:"##1b3?d25 24d?c 24c?d  1a3?c25 ", cmds:{
			//CAN WRITE OUT AS OBJS, FOR EASIER FUNCT USE!!!! 
			a:{0:"ml_move", 1:"x", 2:0.2},
			//a:["ml_move", "x", 0.2],
			b:["ml_move", "x", -0.2],
			c:["ml_move", "y", 0.2],
			d:["ml_move", "y", -0.2],
			Q:["ml_break_test"]
			}} });

function behav_test_rmloadedsearch_SLOW(o){
	//file_log(
	 	rmloaded_search_near("near 20 player_marker", null,
		 o.x, o.y); 
	//);
}
function behavior_none(o){}


var testObj_1 = {x:0, y:0, //behavior:"test_this_script", graphic:"@",
		//p_mix:"mix_standard", 
		colgroup:"", graphic:"!",
		//testing out like this :D
		behavior:"b_none"};
var testObj_2 = {x:0, y:0, //behavior:"test_this_script", graphic:"@",
		//p_mix:"mix_standard", 
		colgroup:"", graphic:"[",
		//testing out like this :D
		behavior:"b_none"};
var testObj_3 = {x:0, y:0, //behavior:"test_this_script", graphic:"@",
		//p_mix:"mix_standard", 
		colgroup:"", graphic:"+",
		//testing out like this :D
		behavior:"b_none"};
var testObj_4_lrgObj = {x:0, y:0, //behavior:"test_this_script", graphic:"@",
		//p_mix:"mix_standard", 
		draw_1late_2last:1,
		colgroup:"", graphic:
`-------
--<3---
-------`,
		//testing out like this :D
		p_map2d__graphic:{"-":["testObj_3","testObj_2"] },
		behavior:"b_none"};

var testRoom = progen_obj_room({
	objs:[ 
	 
	 //{x:4, y:10, //behavior:"test_this_script", graphic:"@",
	//	p_mix:"mix_standard",
		//testing out like this :D
	//	behavior:"rmloaded_searchUpdate"},
	

	
	//MUST load rmloaded_searchUpdate_slow FIRST!!!
	//	(sets up room variables)
	{x:4, y:10, //behavior:"test_this_script", graphic:"@",
		p_mix:"mix_standard",
		//testing out like this :D
		behavior:"behav_test_rmloadedsearch_SLOW"},
	 
	{x:4, y:10, //behavior:"test_this_script", graphic:"@",
		player_marker:1, //for testing search
		
		lazylink:["linkylinky2","linkylinky", "lazylink_player"],
		p_mix:"mix_standard ppp.basic_behav"}, 	
	
	 
	{x:4, y:10, p_mix:"mix_standard mix_walk_in_square",
		lazylink:["linkylinky"] }  	
	], 
	objs_large:[
	{x:-21, y:12, behavior:"b_none", graphic:
`0#####    ## #######0
######## :E# ########
E#####    ## ####EE##
##E##### :D# ########
######## :D# ########
                     
     p_map2d test     
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		p_map2d__graphic:{"D":["testObj_1", "testObj_2"],
 			"E":["testObj_3", "testObj_4_lrgObj"]}
},

	{x:14, y:10, behavior:"test_rot", lazylink:["linkylinky"],
	graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0},
{x:-14, y:10, behavior:"test_rot", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0},
{x:1, y:12, behavior:"test_rot_90", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0}

	]});

function gen_passages( txtgrid_to_scale, x_size, y_size, getTxt_canvas,
		path_graphic_id, path_thickness){
	
}	
function make_1_passage( getstr, x,y, path_graphic, path_thickness ){

}


function gen_rooms( x_size, y_size, getTxt_canvas, getRandSeed){
	var tmpTxt = gridstr_scale(txtgrid_to_scale, x_size, y_size);
	var tmpGrid = [];

	

	//return {map:tmpTxt };
}
function gen_rooms_test( x_size, y_size, cell_min_x, cell_max_x ){

}

async function behavior_test_rot(o){
	if(o.caught_graphic == undefined){ 
		o.rot_angle = 0;
		//o.caught_graphic = o.graphic+"";
		
		o.caught_graphic = 
		  gridstr_rotation_MAKE_ROTATABLE_BORDER( 
			  gridstr_scale_nearest_neighbor(
				  o.graphic,100,130));

		}
	o.rot_angle +=.02;
	//o.graphic =  gridstr_rotate_90_degrees(//gridstr_rotate(
	// 	o.caught_graphic, o.rot_angle, true);//.01);
	
	o.graphic =  gridstr_rotate( 
		o.caught_graphic, o.rot_angle, " ", .01);
}
rmloaded_b_globalThis.test_rot = behavior_test_rot;

async function behavior_test_rot_90(o){
	o.rogue_speed = 10;
	if(await rogue_behavior_PAUSE_UNTIL_DONE(o, true)){ return; }

	if(o.caught_graphic == undefined){ 
		o.rot_angle = 0;
		//o.caught_graphic = o.graphic+"";
		o.caught_graphic = ""+o.graphic;}
	o.rot_angle +=.02;
	o.graphic =  gridstr_rotate_90_degrees(//gridstr_rotate(
	 	o.caught_graphic, o.rot_angle, true);//.01);
	//o.graphic =  gridstr_rotate( 
	//	o.caught_graphic, o.rot_angle," ",  .01);
}
rmloaded_b_globalThis.test_rot_90 = behavior_test_rot_90;

/////////////////////////////////////////
///////////////////////////////////
/// FLASHCARD TESTS
//////////////////////////////

//hm... IDEA:
//	can I do both? quick-disp and slow-puzzle disp?
async function gui_text_speed_read_n_stop(){
	//search ' "X" ' to find bindings, (x key should launch!)
	var getTextList_to_disp = 
`
I met a traveller from an antique land
Who said: Two vast and trunkless legs of stone
Stand in the desert. Near them, on the sand,
Half sunk, a shattered visage lies, whose frown,
And wrinkled lip, and sneer of cold command,
Tell that its sculptor well those passions read
Which yet survive, stamped on these lifeless things,
The hand that mocked them and the heart that fed:
`;
	var getTextList_to_disp = getTextList_to_disp
		.split("\n").join(" ").split(" ");

	var bg_OPTIONAL = "";

	var FRAMES_PER_WORD = 2;
	var FRAMES_PER_CLICK_TO_WIN_WORD = 20;
	var CLICK_TO_WIN_WORD = "PRESS_NOW!!!";

	var tmp_on_word =0;

	controller_mouse_down = 0;
	controllers_clear_pressed();

	var time_on_cur_word =0 + FRAMES_PER_WORD;	

	while( tmp_on_word < getTextList_to_disp.length ){
		 draw(getTextList_to_disp[tmp_on_word], 5,5, "" );
		
		if(time_on_cur_word > 0){ time_on_cur_word -=1;
		}else{ time_on_cur_word=FRAMES_PER_WORD; 
			tmp_on_word+=1;}

		if( controllers[0].getch != "" ||
			 controller_mouse_down !=0){
			return false; };
		await update();
		if(bg_OPTIONAL !=null){ draw(bg_OPTIONAL,0,0,"	" ); }
	}
	for(var i=FRAMES_PER_CLICK_TO_WIN_WORD; i>0; i-=1){ 
		 draw(CLICK_TO_WIN_WORD, 5,5, "" );
		if( controllers[0].getch != "" || 
			  controller_mouse_down != 0){
			return true; };
		await update();
		if(bg_OPTIONAL !=null){ draw(bg_OPTIONAL,0,0,"	" ); }
	}
	return false;
	
}

// gotta upgrade below a bit... 
async function gui_text_puzzle(){
	//search ' "x" ' to find bindings, (x key should launch!)

	var getTextIn = 
`
I met a traveller from an antique land
Who said: Two vast and trunkless legs of stone
Stand in the desert. Near them, on the sand,
Half sunk, a shattered visage lies, whose frown,
And wrinkled lip, and sneer of cold command,
Tell that its sculptor well those passions read
Which yet survive, stamped on these lifeless things,
The hand that mocked them and the heart that fed:
`;
	getTextIn = getTextIn.trim();
	var tmpList = getTextIn.split("\n");

	//in actual cut, probably best to count up to it, 
	// one char at a time... I can do that with something 
	// blocking: can be inefficient!
	
	var tmpList_shuffle = tmpList.concat();

	progen_seed_init();
	progen_d_list_shuffle( tmpList_shuffle  );
	progen_seed_end();	

	while(tmpList.length > 0){
		var tmpChoseTxt = await gui_menu_blocking(
		  "Once known, whipser text while reading to help with memorization", 
			//getDescribedText
		"menu_test_o__TEST", tmpList_shuffle );
		//getHints_text_on_toggle_OPTIONAL, bg_OPTIONAL)
		
		if(tmpChoseTxt == tmpList[0]){
			tmpList_shuffle.splice(
				tmpList_shuffle.indexOf(tmpChoseTxt),1);
			tmpList.shift();}
	}
}

async function gui_text_speedread(){

}


//cmds = [] ?

////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////



var save_state_test= {};

var rmloaded_TMP_WARPED =0;
// behaviors can be nested, one in another funct. (same object):behav(o)
async function behavior_test_this_script(o){

	if(controller_mouse_button_draw("BUTTON_TEST\n111\n222", 3, 15, 
		"",0,0//getTransparentChar, 
		//getDontDrawJustDetect_OPTIONAL,
		//getDontBlinkOnClick_OPTIONAL
		 )){ file_input("button_clicked"); }
	
	rmloaded_draw_overlay("fps :"+(1000/_update_delta),0 ,3, "");
	
	if(controller_mouse_down){ 
		rmloaded_draw_overlay("CLICK", controller_mouse_x,
			controller_mouse_y, "");	}


	rmloaded_draw_overlay(
"PRESS 'm' MENU-BLOCKNG,'f' flashcards,u rmstackTest-THEN>U subrm, i:loadtest\n 'y'-convo test behav\nP-rogue mode ender p-rogue mode leave \n 'x' for (hopefully) new 'flashcard' system. \n 'X' for speed-read system test \n p_map2d tested "+ controller_mouse_x +" " +controller_mouse_y ,0 ,4, "");
	
	
	//allowing roguelike blocking, now this behavior 
	// needs to RETURN 1 in ALL CMDS IN THIS SCRIPT that
	// do something.
	//
	//roguelike mode toggle!
	 //o.rogue_speed =4;
	 //
	 if(controllers[0].getch == "x"){
		await gui_text_puzzle();
	}if(controllers[0].getch == "X"){
		await gui_text_speed_read_n_stop();
	}

	
	if(controllers[0].getch == "p"){
		  o._rogue_running = 0;
		  rogue_behavior_END_ROGUE_BEHAVE_REVERSE_PAUSE_STATE(o); }
	if(controllers[0].getch == "P"){	
	  if(o._rogue_running  !=1){
		var tmpSpeed =  parseFloat(file_input(
			"Type in rogue-speed:(>1 moves MORE than other /n Objs, between 0 and 1 is FRACTIONAL-FRAME movement! ('s' still works in rogue-mode, btw!)"));
		if(isNaN(tmpSpeed) !=1){ o.rogue_speed =tmpSpeed;} }
	
	   o._rogue_running = 1;
	}
	if(o._rogue_running == 1){
		if(await rogue_behavior_PAUSE_UNTIL_DONE(o)){return;} }
	

	var srch = rmloaded_search_lazylink["linkylinky"];
	var srch2 = rmloaded_search_lazylink["linkylinky2"];

	if(srch2 != void null){
		//file_log(srch2[0].x + "--" + srch2[0].y + "---"+
		//	srch.length ); 
		}

	if(controllers[0].getch == "i"){ await gFiles_menu(); }
	if(controllers[0].getch == "I"){ 
		//DEBUGGING
		file_input(JSON.stringify(gConf)); }
	 
	//generate a marker with this object, and test for it!
	//(also, check number of objs in room, to make 
	//	sure gen-obj is actually self-destructing!)

	await rmloaded_b_globalThis.behav_controller_basic_gridmove(o);
	rmloaded_camera_focus(o.x,o.y, 3, 3);
	
	if(controllers[0].getch == "u"){
	   //run txt-disp funct!!
	   g_rmwarp("g_rmwarp_univ2d_n_BIGROOM__example", "down");	
	}	
	if(controllers[0].getch == "U"){
	   //run txt-disp funct!!
	   g_rmwarp("g_rmwarp_univ2d_example__rmAsTile1", "down",
		["g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav"],
		["g_rmwarp_sidewalls_rtrnUpOnCross_FOR_rmUpdate_behav"]); }	
	if(controllers[0].getch == "y"){
	   //run txt-disp funct!!
	   await g_convo_test_behav(o);	
	}
	

	if(controllers[0].getch == "d"){
	   //run txt-disp funct!!
	   
	   await gui_disp_txt_BLOCKING( 
		o.x, o.y,//<only relevent it used /w right disp
		"gui_disp_width", "gui_disp_height",
		"menu_test_o__disp_text",
		"I've been scared to stop and survey all the choices", 
		rmloaded_last_draw, "pedantic",
		true );	
	}
	if(controllers[0].getch == "s"){
		//generate txt-disp obj!
		gui_disp_txt__by_creating_mmlobj(o.x, o.y,
		gui_disp_txt__conf_fixed_objxy,  
		"GOOOOO!", 
		true, "YES!", 
		true, 10);
		//file_input(JSON.stringify(
		//	rmloaded_room.objs[rmloaded_room.objs.length-1]) );
	}
	if(controllers[0].getch == "m"){	//for 'menu'
	

		await gui_menu_blocking( "DESCRIPTION",
			"menu_test_o__TEST",//getConfigName, 
			["one", "two", "threee"],
			"HINTS", false,
			rmloaded_last_draw
			//,bg_OPTIONAL
			);
	}
	if(controllers[0].getch == "f"){ //for 'flashcard'
		if(progen_globalThis["flashcard_deck"]==null){
		    progen_globalThis["flashcard_deck"] = 
			gui_menu_flashcards_GEN_DECK_TEST( );
		}		
		await gui_menu_flashcard_statemachine_BLOCKING(
			 progen_globalThis["flashcard_deck"],"draw",
			rmloaded_last_draw );
		//async f unction gui_menu_flashcard_statemachine_BLOCKING(
		//fc,getDraw_str, // flaschcard data
		//bg_OPTIONAL)
	}

	
	 //x,y, x/y limit
	//rmloaded_room.objs[rmloaded_room.objs.length-1].dead = true;
    //if(controllers[0].pressed[0]=="RIGHT" //.isdown['RIGHT'];.getch="r"
		//UP,LEFT,RIGHT,DOWN,A/B/C/D/ENTER/ESCAPE 
	//&& rmloaded_col_test_SIMPLE(o.x+1, o.y,"z")==""){o.x+=1;return;}
	 //behav_wrldUpdate(o);
	 
	 var exits= rmloaded_bounding_box_test_n_deloutbounds_n_limit_cam(
	  rmloaded_room, 1, null, 1, 1,
	  "0", "0><+-", o.x, o.y, 
			// REPLACE BELOW WITH COMMENTED-OUT for limit-view
			// -----> CENTERX, CENTERY, SIZEX, SIZEY 
			//50, 50, 100,100
			0, 0, 100000000,100000000
	
	);
	//for rogue-mode ( at top of behavior!)
	if(o.x_caught != o.x || o.y_caught != o.y ){
		o.x_caught = o.x; o.y_caught = o.y;
			return 1; }//ENDS roguelike mode!
	o.x_caught = o.x; o.y_caught = o.y;
}
rmloaded_b_globalThis.test_this_script = behavior_test_this_script;

rmloaded_loadroom( testRoom); 

