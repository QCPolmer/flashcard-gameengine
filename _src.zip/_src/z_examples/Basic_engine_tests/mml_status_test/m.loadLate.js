var rmloaded_enter_allrms_behavs =  null;//[]; //RUNS IN -ALL- ROOMS
var rmloaded_update_allrms_behavs = null;//[]; //= [];//RUNS IN -ALL- ROOMS
var rmloaded_leave_allrms_behavs = null;//[]; //= []; //RUNS IN -ALL- ROOMS


// OK, index of, and lastindex of WORK!!!



//file_dir_search = function( startFileLoc, maxRecursiveDepth,
//		list_of_regex, list_of_exclude_regex);

///////////////////////////////////////////////////
/////////////////////
///////////////////////////////////////////
////////////////////////////////////
//////////////////////////////////////
////////////////////////////////////////////
///////////////////////////////////////////
////////////////////////////////////



/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////
//////// Progen_mix basic testing (NOT complete, but seems to work
/////		Still need to test the monte-carlo method
///		(changes player char to 'Q' or 'R')
////////////////////////////////

var mix_standard = progen_mix_stringify([
{ignore_pause:false, dead:0, graphic:"Q", draw_1late_2last:1,colgroup:"" },
{ignore_pause:false, dead:0, graphic:"R", draw_1late_2last:1,colgroup:""}
]); // 0=hidden
		
var ppp = {};
ppp.basic_behav = progen_mix_stringify( 
[{behavior:"test_this_script"}]);

var tmpRandWalk =["4", "24","10"];
var mix_walk_in_square = progen_mix_stringify(
	{behavior:"ml_looping_behavior", 
		mml:{
			mml_loop_resets_preprocess:1,
			mml:"##tmpRandWalk##b3?d2 ##tmpRandWalk##d?c ##tmpRandWalk##c?d  ##tmpRandWalk##a3?c2", cmds:{
			//mml:"##1b3?d25 24d?c 24c?d  1a3?c25 ", cmds:{
			//CAN WRITE OUT AS OBJS, FOR EASIER FUNCT USE!!!! 
			a:{0:"ml_move", 1:"x", 2:0.2},
			//a:["ml_move", "x", 0.2],
			b:["ml_move", "x", -0.2],
			c:["ml_move", "y", 0.2],
			d:["ml_move", "y", -0.2],
			Q:["ml_break_test"]
			}} });

function behav_test_rmloadedsearch_SLOW(o){
	//file_log(
	 	rmloaded_search_near("near 20 player_marker", null,
		 o.x, o.y); 
	//);
}
function behavior_none(o){}


var testObj_1 = {x:0, y:0, //behavior:"test_this_script", graphic:"@",
		//p_mix:"mix_standard", 
		colgroup:"", graphic:"!",
		//testing out like this :D
		behavior:"b_none"};
var testObj_2 = {x:0, y:0, //behavior:"test_this_script", graphic:"@",
		//p_mix:"mix_standard", 
		colgroup:"", graphic:"[",
		//testing out like this :D
		behavior:"b_none"};
var testObj_3 = {x:0, y:0, //behavior:"test_this_script", graphic:"@",
		//p_mix:"mix_standard", 
		colgroup:"", graphic:"+",
		//testing out like this :D
		behavior:"b_none"};
var testObj_4_lrgObj = {x:0, y:0, //behavior:"test_this_script", graphic:"@",
		//p_mix:"mix_standard", 
		draw_1late_2last:1,
		colgroup:"", graphic:
`-------
--<3---
-------`,
		//testing out like this :D
		p_map2d__graphic:{"-":["testObj_3","testObj_2"] },
		behavior:"b_none"};

var testRoom = progen_obj_room({
	objs:[ 
	
	
	//MUST load rmloaded_searchUpdate_slow FIRST!!!
	//	(sets up room variables)
	{x:4, y:10, //behavior:"test_this_script", graphic:"@",
		p_mix:"mix_standard",
		//testing out like this :D
		behavior:"behav_test_rmloadedsearch_SLOW"},
	 
	{x:4, y:5, //behavior:"test_this_script", graphic:"@",
		player_marker:1, //for testing search
		
		lazylink:["linkylinky2","linkylinky", "lazylink_player"],
		p_mix:"mix_standard ppp.basic_behav"}, 	
	
	 
	{x:4, y:10, p_mix:"mix_standard mix_walk_in_square",
		lazylink:["linkylinky"] }  	
	], 
	objs_large:[
	{x:-21, y:12, behavior:"b_none", graphic:
`0#####    ## #######0
######## :E# ########
E#####    ## ####EE##
##E##### :D# ########
######## :D# ########
                     
     p_map2d test     
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		p_map2d__graphic:{"D":["testObj_1", "testObj_2"],
 			"E":["testObj_3", "testObj_4_lrgObj"]}
},

	{x:14, y:10, behavior:"b_none", lazylink:["linkylinky"],
	graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0},
{x:-14, y:10, behavior:"b_none", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0},
{x:1, y:12, behavior:"b_none", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0}

	]});

 


//UNMODIFIED (YET!!!)
async function behav_CUR_CUSTOM_MOVE(o){
//API_TAG//
	var tmpGravity = 0; var tmpFall_speed =0; var maxVelocity =0;
	var tmpJump_velocity=0;  var tmpEndJumpEarly=0; 
	
	var tmpNextX =0; var tmpNextY =0;
	

	var c_isdown = controllers[0].isdown;
	if( c_isdown["DOWN_RIGHT"]){
		if(rmloaded_col_test_SIMPLE(o.x+1, o.y+1,"0")==""){
			o.x+=1; o.y+=1;  } return;}
	if( c_isdown["DOWN_LEFT"]){
		if(rmloaded_col_test_SIMPLE(o.x-1, o.y+1,"0")==""){
			o.x-=1; o.y+=1;  } return;}
	if( c_isdown["UP_RIGHT"]){
		if(rmloaded_col_test_SIMPLE(o.x+1, o.y-1,"0")==""){
			o.x+=1; o.y-=1;  } return;}
	if( c_isdown["UP_LEFT"]){
		if(rmloaded_col_test_SIMPLE(o.x-1, o.y-1,"0")==""){
			o.x-=1; o.y-=1;  } return;}

	if(c_isdown["RIGHT"] && c_isdown["UP"]){
		if(rmloaded_col_test_SIMPLE(o.x+1, o.y-1,"0")==""){
			o.x+=1; o.y-=1;  }return;}
	if(c_isdown["LEFT"] && c_isdown["UP"]){
		if(rmloaded_col_test_SIMPLE(o.x-1, o.y-1,"0")==""){
			o.x-=1; o.y-=1;  }return;}
	if(c_isdown["RIGHT"] && c_isdown["DOWN"]){
		if(rmloaded_col_test_SIMPLE(o.x+1, o.y+1,"0")==""){
			o.x+=1; o.y+=1;  } return;}
	if(c_isdown["LEFT"] && c_isdown["DOWN"]){
		if(rmloaded_col_test_SIMPLE(o.x-1, o.y+1,"0")==""){
			o.x-=1; o.y+=1;  } return;}

	if(c_isdown["RIGHT"] && 
		rmloaded_col_test_SIMPLE(o.x+1, o.y,"0")==""){ o.x+=1; }
	if(c_isdown["LEFT"] && 
		rmloaded_col_test_SIMPLE(o.x-1, o.y,"0")==""){ o.x-=1; }
	if(c_isdown["DOWN"] && 
		rmloaded_col_test_SIMPLE(o.x, o.y+1,"0")==""){ o.y+=1; }
	if(c_isdown["UP"] && 
		rmloaded_col_test_SIMPLE(o.x, o.y-1,"0")==""){ o.y-=1; }
}


var save_state_test= {};

var THIS_FILE_ONLY_gui_menu_testTxt = 
`SDFDFD KSDFJ LDFJADKF ALDKF LSdfjKldfj 
SDFDFD KSDFJ LDFJADKF ALDKF LSdfjKldfj 
SDFDFD KSDFJ LDFJADKF ALDKF LSdfjKldfj 
SDFDFD KSDFJ LDFJADKF ALDKF LSdfjKldfj 
SDFDFD KSDFJ LDFJADKF ALDKF LSdfjKldfj 
SDFDFD KSDFJ LDFJADKF ALDKF LSdfjKldfj 
SDFDFD KSDFJ LDFJADKF ALDKF LSdfjKldfj`; 

var rmloaded_TMP_WARPED =0;
// behaviors can be nested, one in another funct. (same object):behav(o)
async function behavior_test_this_script(o){
	
	await behav_mml_status( o);

	if(controllers[0].getch == "9"){
		gui_disp_txt__by_creating_satusObj(
		o.x, o.y, "gui_disp_width", "gui_disp_height", 
		"menu_test_o",
		THIS_FILE_ONLY_gui_menu_testTxt, 
		true, //add_obj_to_rmloaded_OPTIONAL, 
		"bro!",
		 true, //use_keys_OPTIONAL, 
		true //timeout_for_keypress_on_OPTIONAL
		//commands data type, can leave in Menu_obj data:
		 );	
	}
	if(controllers[0].getch == "0"){
		await gui_disp_txt_BLOCKING( 
		3, 3,	"gui_disp_width", "gui_disp_height", 
		"menu_test_o",
		THIS_FILE_ONLY_gui_menu_testTxt, rmloaded_last_draw,
		"wut?", //caption
		 true, //use keys 
		false //use keys timeout
		);
	
	}

	if(controllers[0].getch == "5"){
		mml_status_set( //holding items in 'stasis' while held
	 		o, "ALLADD", 
			1, 1, 5, [], 100);
	}
	if(controllers[0].getch == "4"){
		mml_status_set( //holding items in 'stasis' while held
	 		o, "ALLRESET", 
			1, 1, 50, []);
	}
	if(controllers[0].getch == "5"){
		file_input( await gui_menu_blocking(
		  "beethovens BALLS",//getDescribedText, 
		   "menu_test_o" ,
			//getGui_Menu_Object_NAME_SEE_EXAMPLES_FOR_DATA, 
		   ["one", "one boo","two","three"],//getCmds_list, //options
		   "HINTS!!!", //getHints_text_on_toggle_OPTIONAL,
		   true) );  //getReturn_AFTER_anim_done_OPTIONAL,
		//bg_OPTIONAL)
	}
	if(controllers[0].getch == "3"){
		mml_status_set( //holding items in 'stasis' while held
	 		o, "ALL", 
			1, 1, 50, [], 50);
	}
	if(controllers[0].getch == "1"){
		//add status effect here!!!
		//zzz
		mml_status_set( 
	 		o, "timed_countdown", 
			1, 1, 100,	//getMagMax, getMag2Add, time
	  ["mml_status_run_multiple_status_as_substatus",
	    {0:"mml_status_graphic_effect", "x_offset":3, "y_offset":10,
		"o_txt2DispVarName":"graphic", // "var2Mod":"",
		"time_start_end_reverseStart_end":[100,90, 20,10 ]},
	    {0:"mml_status_graphic_effect", "x_offset":4, "y_offset":11,
		"o_txt2DispVarName":"graphic", // "var2Mod":"",
		"time_start_end_reverseStart_end":[90,80, 20,10 ]},
	    {0:"mml_status_graphic_effect", "x_offset":5, "y_offset":12,
		"o_txt2DispVarName":"graphic", // "var2Mod":"",
		"time_start_end_reverseStart_end":[70,60, 20,10 ]}],
	   -1 );
	}
	if(controllers[0].getch == "2"){
		mml_status_set( 
	 		o, "timed_countdown2", 
			1, 1, 100,	//getMagMax, getMag2Add, time
	  ["mml_status_run_multiple_status_as_substatus",
	    {0:"gui_menu_mml_status_expaning_outline", "x_offset":10, "y_offset":10,
		"o_txt2DispVarName":"graphic",
			//var2get txt from //"var2Mod":"",
		"o_txt2DispVarName_caption":"graphic", //OPTIONAL
		"draw_funct":"draw",
		"width":20, "height":5,
		"time_start_end_reverseStart_end":[99,94, 5,0 ],
		"text_type_chars_per_frame_NULL2hide":10,
		"outlineborder_size":1, "outline":
`.--------------.
|               |
|               |
|               |
.LEFT------RIGHT>`, "outline_caption": //OPTIONAL
`.-.
| |
.-.`}] );
	}

	rmloaded_draw_overlay("Press 1 THOUGH 9 to test menus/STATUS effects \nfps :"+(1000/_update_delta),0 ,3, "");
	
	if(controller_mouse_down){ 
		rmloaded_draw_overlay("CLICK", controller_mouse_x,
			controller_mouse_y, "");	}


	await rmloaded_b_globalThis.behav_CUR_CUSTOM_MOVE(o);
	rmloaded_camera_focus(o.x,o.y, 3, 3);
	
	if(controllers[0].getch == "u"){
	   //run txt-disp funct!!
	   g_rmwarp("g_rmwarp_univ2d_n_BIGROOM__example", "down");	
	}	
	if(controllers[0].getch == "U"){
	   //run txt-disp funct!!
	   g_rmwarp("g_rmwarp_univ2d_example__rmAsTile1", "down",
		["g_rmwarp_sidewalls_spawner_FOR_rmEnter_behav"],
		["g_rmwarp_sidewalls_rtrnUpOnCross_FOR_rmUpdate_behav"]); }	
	if(controllers[0].getch == "y"){
	   //run txt-disp funct!!
	   await g_convo_test_behav(o);	
	}
	

	if(controllers[0].getch == "d"){
	   //run txt-disp funct!!
	   await gui_disp_text_BLOCKING( 
		o.x, o.y,//<only relevent it used /w right disp
		gui_disp_txt__conf_fixed,
		"I've been scared to stop and survey all the choices", 
		"pedantic", rmloaded_last_draw);	
	}
	if(controllers[0].getch == "s"){
		//generate txt-disp obj!
		gui_disp_txt__by_creating_mmlobj(o.x, o.y,
		gui_disp_txt__conf_fixed_objxy,  
		"GOOOOO!", 
		true, "YES!", 
		true, 10);
		//file_input(JSON.stringify(
		//	rmloaded_room.objs[rmloaded_room.objs.length-1]) );
	}
	if(controllers[0].getch == "m"){	//for 'menu'

		await gui_menu_blocking( "DESCRIPTION",
			"gui_menu_config",//getConfigName, 
			["one", "two", "threee"],
			"HINTS",
			rmloaded_last_draw
			//,bg_OPTIONAL
			);
	}
	
	 
	 var exits= rmloaded_bounding_box_test_n_deloutbounds_n_limit_cam(
	  rmloaded_room, 1, null, 1, 1,
	  "0", "0><+-", o.x, o.y, 
			// REPLACE BELOW WITH COMMENTED-OUT for limit-view
			// -----> CENTERX, CENTERY, SIZEX, SIZEY 
			//50, 50, 100,100
			0, 0, 100000000,100000000
	
	);
	//for rogue-mode ( at top of behavior!)
	if(o.x_caught != o.x || o.y_caught != o.y ){
		o.x_caught = o.x; o.y_caught = o.y;
			return 1; }//ENDS roguelike mode!
	o.x_caught = o.x; o.y_caught = o.y;
}
rmloaded_b_globalThis.test_this_script = behavior_test_this_script;

rmloaded_loadroom( testRoom); 

