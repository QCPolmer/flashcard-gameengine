//modifiy  this
var mix_disp_GUItext = progen_mix_stringify(
	{ graphic:"A",
	behavior:"ml_looping_behavior", 
		mml:{mml:"24a?q 1?ba 24?c 20a??? 24?b 24?d, ", cmds:{
			//zzz
			q:{0:"ml_draw", 1:"graphic", 2:0, 3:0, 4:0, 5:0},
			a:["ml_move", "x", 0.2],
			b:["ml_move", "x", -0.2],
			c:["ml_move", "y", 0.2],
			d:["ml_move", "y", -0.2]
				}
			}} );



///////////////////////////////////////////////////
/////////////////////
///////////////////////////////////////////
////////////////////////////////////
//////////////////////////////////////
////////////////////////////////////////////
///////////////////////////////////////////
////////////////////////////////////



/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////////////////////////
/////////////////////
//////// Progen_mix basic testing (NOT complete, but seems to work
/////		Still need to test the monte-carlo method
///		(changes player char to 'Q' or 'R')
////////////////////////////////

var mix_standard = progen_mix_stringify([
{ignore_pause:true, dead:0, graphic:"Q", draw_1late_2last:1,colgroup:"" },
{ignore_pause:true, dead:0, graphic:"R", draw_1late_2last:1,colgroup:""}
]) // 0=hidden
		
var ppp = {};
ppp.basic_behav = progen_mix_stringify( 
[{behavior:"test_this_script"}]);





var mix_walk_in_square = progen_mix_stringify(
	{behavior:"ml_looping_behavior", 
		mml:{mml:"1b3?d25 24d?c 24?c 20Qa??? 24?b 24?d ", cmds:{
			//CAN WRITE OUT AS OBJS, FOR EASIER FUNCT USE!!!! 
			a:{0:"ml_move", 1:"x", 2:0.2},
			//a:["ml_move", "x", 0.2],
			b:["ml_move", "x", -0.2],
			c:["ml_move", "y", 0.2],
			d:["ml_move", "y", -0.2],
			Q:["ml_break_test"]
			}} });

var mix_draw_crap = progen_mix_stringify(
	{behavior:"ml_looping_behavior", 
		mml:{mml:"5b?d5 24?c 24?c 20a??? 24?b 24?d, ", cmds:{
			//zzz
			q:{0:"ml_draw", 1:"graphic", 2:0, 3:0, 4:0, 5:0},
			a:["ml_move", "x", 0.2],
			b:["ml_move", "x", -0.2],
			c:["ml_move", "y", 0.2],
			d:["ml_move", "y", -0.2],
			Q:["ml_break_test"]
			}} });

var testRoom = progen_obj_room({
	objs:[ 
	 {x:4, y:10, //behavior:"test_this_script", graphic:"@",
		p_mix:"mix_standard ppp.basic_behav"},
	    	
	 {x:4, y:-20, p_mix:"mix_standard mix_draw_crap"},   	
	
	 {x:0, y:0, p_mix:"mix_standard mix_disp_GUItext",
		GUITEXT:"TEST GUI TEXT"  },   	
	 
	{x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:-20, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:4, y:10, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:14, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:5, y:0, p_mix:"mix_standard mix_walk_in_square" },   	
	 {x:7, y:0, p_mix:"mix_standard mix_walk_in_square" },  	
	 {x:8, y:0, p_mix:"mix_standard mix_walk_in_square" },  
	 {x:4, y:20, p_mix:"mix_standard mix_walk_in_square" }   	
	], 
	objs_large:[
	{x:14, y:10, behavior:"test_rot", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		progen:null},
{x:-14, y:10, behavior:"test_rot", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0},
{x:1, y:12, behavior:"test_rot_90", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0}

	]});

function gen_passages( txtgrid_to_scale, x_size, y_size, getTxt_canvas,
		path_graphic_id, path_thickness){
	
}	
function make_1_passage( getstr, x,y, path_graphic, path_thickness ){

}
//I need a txt-grid erase EDIT: can set overlay or null char to 
//	"X" and paste: " "
//
//
// gridstr_overlay(s_to,	s_from, x, y, overlayChar_or_null)
// var gridstr_scale =function(textblock, size_x, size_y){}
//var gridstr_scale_nearest_neighbor = function(textblock, size_x, size_y){}



function gen_rooms( x_size, y_size, getTxt_canvas, getRandSeed){
	var tmpTxt = gridstr_scale(txtgrid_to_scale, x_size, y_size);
	var tmpGrid = [];

	

	//return {map:tmpTxt };
}
function gen_rooms_test( x_size, y_size, cell_min_x, cell_max_x ){

}

async function behavior_test_rot(o){
	if(o.caught_graphic == undefined){ 
		o.rot_angle = 0;
		//o.caught_graphic = o.graphic+"";
		
		o.caught_graphic = 
		  gridstr_rotation_MAKE_ROTATABLE_BORDER( 
			  gridstr_scale_nearest_neighbor(
				  o.graphic,100,130));

		}
	o.rot_angle +=.02;
	//o.graphic =  gridstr_rotate_90_degrees(//gridstr_rotate(
	// 	o.caught_graphic, o.rot_angle, true);//.01);
	
	o.graphic =  gridstr_rotate( 
		o.caught_graphic, o.rot_angle, " ", .01);
}
rmloaded_b_globalThis.test_rot = behavior_test_rot;

async function behavior_test_rot_90(o){
	if(o.caught_graphic == undefined){ 
		o.rot_angle = 0;
		//o.caught_graphic = o.graphic+"";
		o.caught_graphic = ""+o.graphic;}
	o.rot_angle +=.02;
	o.graphic =  gridstr_rotate_90_degrees(//gridstr_rotate(
	 	o.caught_graphic, o.rot_angle, true);//.01);
	//o.graphic =  gridstr_rotate( 
	//	o.caught_graphic, o.rot_angle," ",  .01);
}
rmloaded_b_globalThis.test_rot_90 = behavior_test_rot_90;

var flaschard_deck = gui_menu_flashcards_GEN_DECK_TEST( )

// behaviors can be nested, one in another funct. (same object):behav(o)
async function behavior_test_this_script(o){
	rmloaded_draw_overlay("fps :"+(1000/_update_delta),0 ,3, "");
	rmloaded_draw_overlay(
	 	"PRESS 'm' FOR MENU-BLOCKNG, 'f' flashcards",0 ,4, "");
	
	await rmloaded_b_globalThis.behav_controller_basic_gridmove(o);
	rmloaded_camera_focus(o.x,o.y, 3, 3);
	
	if(controllers[0].getch == "d"){
	   //run txt-disp funct!!
	   await gui_disp_text_BLOCKING( 
		o.x, o.y,//<only relevent it used /w right disp
		gui_disp_txt__conf_fixed,
		"I've been scared to stop and survey all the choices", 
		"pedantic", rmloaded_last_draw);	
	}
	if(controllers[0].getch == "s"){
		//generate txt-disp obj!
		gui_disp_txt__by_creating_mmlobj(o.x, o.y,
		gui_disp_txt__conf_fixed_objxy,  
		"GOOOOO!", 
		true, "YES!", 
		true, 10);
		//file_input(JSON.stringify(
		//	rmloaded_room.objs[rmloaded_room.objs.length-1]) );
	}
	if(controllers[0].getch == "m"){	//for 'menu'

		await gui_menu_blocking( "DESCRIPTION",
			"menu_test_o__TEST",//getConfigName, 
			["one", "two", "threee"],
			"HINTS",
			rmloaded_last_draw
			//,bg_OPTIONAL
			);
	}
	if(controllers[0].getch == "f"){ //for 'flashcard'
		
		await gui_menu_flashcard_statemachine_BLOCKING(
			flaschard_deck,"draw",
			rmloaded_last_draw );
		//async function gui_menu_flashcard_statemachine_BLOCKING(
		//fc,getDraw_str, // flaschcard data
		//bg_OPTIONAL)
	}

	
	 //x,y, x/y limit
	//rmloaded_room.objs[rmloaded_room.objs.length-1].dead = true;
    //if(controllers[0].pressed[0]=="RIGHT" //.isdown['RIGHT'];.getch="r"
		//UP,LEFT,RIGHT,DOWN,A/B/C/D/ENTER/ESCAPE 
	//&& rmloaded_col_test_SIMPLE(o.x+1, o.y,"z")==""){o.x+=1;return;}
}
rmloaded_b_globalThis.test_this_script = behavior_test_this_script;
rmloaded_loadroom( testRoom); 

