var testRoom ={
	objs:[ 
	{x:11, y:2, behavior:"b_test2", graphic:"@", colgroup:"0", 
		ignore_pause:true, draw_1late_2last:0, dead:0},
		
	], 
	objs_large:[
	{x:1, y:5, behavior:"test_this_script", graphic:"#####################",
	    colgroup:"", ignore_pause:true, draw_1late_2last:2, dead:0},
	{x:1, y:5, behavior:"b_none", graphic:"#####################", 
	    colgroup:"", ignore_pause:false, draw_1late_2last:2, dead:0},
	{x:8, y:12, behavior:"b_none", graphic:
`######    ## ########
######## :0# ########
############ ########`, colgroup:"0", ignore_pause:false, 
		draw_1late_2last:-1, dead:0},
	{x:0, y:16, behavior:"b_none", graphic:
`######    ## ########
######## :P# ########
############ ########`, colgroup:"0"},

	{x:14, y:20, behavior:"b_none", graphic:
`######    ## ########
######## O_# ########
############ ########`, colgroup:"z0", ignore_pause:false, 
	  daw_1late_2last:2, dead:0,
		progen:{ recipe:"test 1 2 3 && test 45 3", 
		_rand_seed_int:null, dont_mod_vars:"x", groups:"pq" } },
	{x:14, y:20, behavior:"b_none", graphic:
`######    ## ########
######## :D# ########
############ ########`, colgroup:"z0", ignore_pause:false, 
	draw_1late_2last:2, dead:0 },
	]
}

/*

//API_TAG//
async function gui_menu_blocking(
		getDescribedText, getConfigName, getCmds_N_toggle){
// returns the returned command OR -1 if esc was pressed
	gui_menu( getDescribedText, getConfigName,draw , getCmds_N_toggle);	
	while( gui_menu(getDescribedText, getConfigName, draw)== null ){ 
		await update();}
	return gui_menu(getDescribedText, getConfigName, draw); }
//API_TAG//
*/



rmloaded_addObjGrid( 5, -100, testRoom, gridstr_scale("a", 10,100), 
	{"a":{x:14, y:1, behavior:"behav_test", graphic:"@", colgroup:"0", ignore_pause:false, draw_1late_2last:0, dead:0}}, {});

//gen_anim -anim_name test -anims_to_use test_anim2||test_anim2
// 	-max_min_len 2||4
//
var ON_FIRST_LOOP = true;
async function behavior_test_this_script(o){
	//var qq = [1,2,3];
	//file_input( rmloaded_room_get_filtered_objs(rmloaded_room, "progen") );
	
	if(await gui_menu("DESCRIPTION TEXT!!!!!", "menu_test_o__TEST_DRAW_OVERLAY", ["one","two","three"]) 
			!= null){	}

	rmloaded_room.objs[rmloaded_room.objs.length-1].dead = true;
	if(controllers[0].pressed[0]== "UP"){
		o.x+=1;
	}
	if(controllers[0].pressed[0]== "DOWN"){
	
	}
	if(controllers[0].pressed[0]== "LEFT"){
		rmloaded_paused= true;


		var flashcard_question_example_txt = 
`
Flashcard example:

This would be the text of a statment or question.

`;
		if("Yes" ==await gui_menu_blocking( 
			flashcard_question_example_txt + 
				"DO YOU KNOW THE ANSWER?",
				"menu_test_o__TEST", // name of config
				["Yes", "No"])){

			if( "Right" ==await gui_menu_blocking( 
			flashcard_question_example_txt + 
				"WHAT IS THE RIGHT ANSWER?",
				"menu_test_o__TEST", // name of config
				["RIGHT", "WRONG",
				"WRONG", "WRONG"])){

				file_input("CORRECT!");}	}
	}
	if(controllers[0].pressed[0]== "RIGHT"){
		rmloaded_paused= false;
	}
}
rmloaded_b_globalThis.test_this_script = behavior_test_this_script;

rmloaded_loadroom( testRoom); 

