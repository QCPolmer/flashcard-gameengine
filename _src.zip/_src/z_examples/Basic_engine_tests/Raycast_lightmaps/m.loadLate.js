
var testOverlay =
`   ooooo   
  oo   oo  
  oo   oo  
   ooooo   `;

//search z_example files with search_this_file.txt (or use whatever
var testRoom ={
	// define more options for below:rmloaded.js/_rmloaded_launch_game_DISP_PARAMS
	enter_behavs:[],update_behavs:[],leave_behavs:[], 	
	room_type: "shadows", // "shadows3d", "_2d", 
	   //"_3d","shadows_ignore_walls", "shadows_no_lights", "shadows"

	objs:[ 
	{x:10, y:10,behavior:"ray_light_width",colgroup:"",
	graphic:"@", draw_1late_2last:1, light_width:5},	
	{x:3, y:9,behavior:"ray_light_width",colgroup:"",
	graphic:"0", draw_1late_2last:1, light_width:5},
	{x:13, y:19,behavior:"ray_light_width",colgroup:"",
	graphic:"0", draw_1late_2last:1, light_width:5, 
		light_gfx:testOverlay},	
	{x:3, y:19,behavior:"ray_light_width",colgroup:"",
	graphic:"0", draw_1late_2last:1, light_width:5, 
		light_gfx:testOverlay},	
	{x:3, y:-19,behavior:"ray_light_width",colgroup:"",
	graphic:"0", draw_1late_2last:1, light_width:5, 
		light_gfx:testOverlay},	
		
	 {x:4, y:10,behavior:"test_this_script",
//"behav_rmloaded_debug_progen", //	,  . @... I think R controls... 
	graphic:"@",ignore_pause:true, draw_1late_2last:1, // 0=hidden
		colgroup:"",dead:0 }//dead is optional	
	], 
	objs_large:[
	{x:-10, y:-10, behavior:"b_none", 
		graphic:gridstr_scale(".",100,100), 
		colgroup:"", ignore_pause:false, 
		draw_1late_2last:0, dead:0,
		progen:null},
	{x:14, y:10, behavior:"test_rot", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		progen:null},
{x:-14, y:10, behavior:"test_rot", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		progen:null},
{x:4, y:-40, behavior:"test_rot", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		progen:null}

	]};

function gen_passages( txtgrid_to_scale, x_size, y_size, getTxt_canvas,
		path_graphic_id, path_thickness){
	
}	
function make_1_passage( getstr, x,y, path_graphic, path_thickness ){

}
//I need a txt-grid erase EDIT: can set overlay or null char to 
//s	"X" and paste: " "
//
//
// gridstr_overlay(s_to,	s_from, x, y, overlayChar_or_null)
// var gridstr_scale =function(textblock, size_x, size_y){}
//var gridstr_scale_nearest_neighbor = function(textblock, size_x, size_y){}



function gen_rooms( x_size, y_size, getTxt_canvas, getRandSeed){
	var tmpTxt = gridstr_scale(txtgrid_to_scale, x_size, y_size);
	var tmpGrid = [];

	

	//return {map:tmpTxt };
}
function gen_rooms_test( x_size, y_size, cell_min_x, cell_max_x ){

}

async function behavior_test_rot(o){
	//_rmloaded_lookup_lrg_colgroups
	//_rmloaded_lookup_xlocs
	if(o.caught_graphic == undefined){ 
		o.rot_angle = 0;
		//o.caught_graphic = o.graphic+"";
		o.caught_graphic = 
		  gridstr_rotation_MAKE_ROTATABLE_BORDER( 
			  gridstr_scale_nearest_neighbor(
				  o.graphic,10,10));}
	

	o.rot_angle +=.02;
	o.graphic =  gridstr_rotate_90_degrees(//gridstr_rotate( 
		o.caught_graphic, o.rot_angle, true);//.01);
}

rmloaded_b_globalThis.test_rot = behavior_test_rot;


//var boobs = 2;
// behaviors can be nested, one in another funct. (same object):behav(o)
async function behavior_test_this_script(o){
	
	//OK, next on the agenda:
	//	The line drawing algorithm WORKS, 
	//	HOWEVER: with caps, it WILL require 
	//	recalculation of width/height. 
	//	(This will be mostly copy-pasing!) 
	//	ALSO: will ONLY work with NONE and QRTR types. 
	//	FULL will give bogus effects...
	//	also, probably a good idea to make a few wrappers for this.
//	SO: (for horizontal):
	//		draw caps:
	//		4 each cap:
	//	 	get_centerY() get_lengthX() 
	// OK, it works... amazing... really. 
	// I have to see if I can get col-testing working with this...
	// MIGHT be able to throw in a dummy-draw function that 
	// catches the collision[s?] 
	// By injecting such a function, I could probably get a 
	// list of collisions, OR the single first hit point. 
	// (as all this is suppose to be 'line' based, 
	// 	I'm not sure how far this can go.
	// 	will probably make a wrapper, and run full 
	// 	script, disabling function if collision. 
	sketch_capped_line( o.x + _rmloaded_camera_x, 
		o.y + _rmloaded_camera_y, 
		10+_rmloaded_camera_x,10+_rmloaded_camera_y,
//"aaa\naa|"

`   ooooo   
  oo   oo  
  oo   oo  
  oo   oQ  
   ooooo   `,

//"aaaaaaaaaaaaaaaaaaaaaa", 
["bbb\nbbb\nbbb", "---\n- -\n---"],
"ccc\n|cc\nccc", "-", //str,mid,end,tanspChar
	 "NONE",//rotate_FULL_QRTR_NONE, //FULL here draws on center= wonky 
	 "QRTR", //rotate caps, FULL for this not accurate: don't use
	  null,//horiz_not_vertical, // null=choose largestlen
	  1, //sketch0_draw1_coltest2_colmulti3
	  null,//OPTIONAL_evenly_placed_OR_null for center, overrides below!
	null	//OPTIONAL_draw_every_steps
	);

	var cols = sketch_line_col_test(o.x, o.y, o.x-10, o.y,
		"z", true, //horiz_not_vertical, 
		true//
		);//get_1_not_multi_pnts, //1 pnt IS somewhat faster!
	//file_log(cols.length);
	for(var i =0; i< cols.length; i+=3){
	  file_log("sketch_line_coldetect" +  cols[i] + " " +cols[i+1] + " " +cols[i+2] + " "); 
	}

		
	
	/*
	sketch_line( o.x + _rmloaded_camera_x, 
		o.y + _rmloaded_camera_y, 
		10+_rmloaded_camera_x,10+_rmloaded_camera_y,
		"FULL",//rotate_FULL_QRTR_NONE,  //str
			//NOTE:keep width/length ODD for gridstr for "FULL"
			// QRTR and NONE work better 
			// 'FULL' joins @ center point, so overshoots by1/2 
		"0a1-+--\n001-+--\n001-+--",  // graphic
		" ", // transparent char
		false,//horiz_not_vertical,// null=choose largestlen
		1,//sketch0_draw1_coltest2_colmulti3,  //bool
		[0,.5,1],//[], // OPTIONAL_drawprcntlist_0to1_or_null 
			// OK, for above: should switch to :
			// draw @ precent OR null. 
			// 0 = first, >= 100% is last. 
			// ... maybe as a list?  
			//
		null,   //OPTIONAL_evenly_placed_OR_null,
		null//OPTIONAL_draw_every_steps // int # of steps OR null
		);
		*/
	/*
	_sketch_line( o.x + _rmloaded_camera_x, 
		o.y + _rmloaded_camera_y, 
		10+_rmloaded_camera_x,10+_rmloaded_camera_y,
		"NONE",//rotate_FULL_QRTR_NONE,  //str
		"   \n X \n   ",  // graphic
		" ", // transparent char
		true,//horiz_not_vertical, // null=choose largestlen
		0,sketch0_draw1_coltest2_colmulti3,  //bool
		false, // OPTIONAL_draw_ONLY_1last_2first //int or null
		null//OPTIONAL_draw_every_steps // int # of steps OR null
		); 
	*/	
	draw("@", o.x + _rmloaded_camera_x, 
		o.y + _rmloaded_camera_y, "");
	draw("@", 10+_rmloaded_camera_x, 10+_rmloaded_camera_y, "");

/*	
	sketch_line( // draw, don't sketch
`+ +
   
+ +`, " ", o.x +_rmloaded_camera_x, o.y+_rmloaded_camera_y, 
			10+_rmloaded_camera_x,10+_rmloaded_camera_y, 
		true, "111111\n101111\n111111", "222",
		3); //setp 
	sketch_line( // draw, don't sketch
"x", " ", o.x +_rmloaded_camera_x, o.y+_rmloaded_camera_y, 
			10+_rmloaded_camera_x,10+_rmloaded_camera_y, 
		true, "111", "222"); 
*/	


	//file_log("aaa" + boobs++);
	//draw_shadows( _rmloaded_camera_x+10, _rmloaded_camera_y );
	
	//draw_shadows(o.x+_rmloaded_camera_x, o.y+_rmloaded_camera_y);
	
	o.light_width =12;
	rmloaded_b_globalThis.ray_light_width(o);
	
	//draw(_sketch_rays_multi_main( o.x, o.y,"0"),0,0,"&");

	rmloaded_draw_overlay("fps :"+(1000/_update_delta),0 ,3, "");
	await rmloaded_b_globalThis.behav_controller_basic_gridmove(o);
	rmloaded_camera_focus(o.x,o.y, 3, 3); //x,y, x/y limit
	//rmloaded_room.objs[rmloaded_room.objs.length-1].dead = true;
    //if(controllers[0].pressed[0]=="RIGHT" //.isdown['RIGHT'];.getch="r"
		//UP,LEFT,RIGHT,DOWN,A/B/C/D/ENTER/ESCAPE 
	//&& rmloaded_col_test_SIMPLE(o.x+1, o.y,"z")==""){o.x+=1;return;}
}
rmloaded_b_globalThis.test_this_script = behavior_test_this_script;
rmloaded_loadroom( testRoom); 

