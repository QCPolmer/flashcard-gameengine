//search z_example files with search_this_file.txt (or use whatever
var testRoom ={
	objs:[ 
	 {x:4, y:10,behavior:"test_this_script",
//"behav_rmloaded_debug_progen", //	,  . @... I think R controls... 
	graphic:"@",ignore_pause:true, draw_1late_2last:1, // 0=hidden
		dead:0 }//dead is optional	
	], 
	objs_large:[
	{x:14, y:10, behavior:"test_rot", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		progen:null},
{x:-14, y:10, behavior:"test_rot", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		progen:null},
{x:1, y:12, behavior:"test_rot_90", graphic:
`0#####    ## #######0
######## :D# ########
######    ## ########
######## :D# ########
######## :D# ########
                     
     TEST  TEST      
                     
######## :D# ########
######    ## ########
######## :D# ########
######    ## ########
0####### :D# #######X
`, colgroup:"z0", ignore_pause:false, 
		draw_1late_2last:1, dead:0,
		progen:null}

	]};


function gen_passages( txtgrid_to_scale, x_size, y_size, getTxt_canvas,
		path_graphic_id, path_thickness){
	
}	
function make_1_passage( getstr, x,y, path_graphic, path_thickness ){

}
//I need a txt-grid erase EDIT: can set overlay or null char to 
//	"X" and paste: " "
//
//
// gridstr_overlay(s_to,	s_from, x, y, overlayChar_or_null)
// var gridstr_scale =function(textblock, size_x, size_y){}
//var gridstr_scale_nearest_neighbor = function(textblock, size_x, size_y){}



function gen_rooms( x_size, y_size, getTxt_canvas, getRandSeed){
	var tmpTxt = gridstr_scale(txtgrid_to_scale, x_size, y_size);
	var tmpGrid = [];

	

	//return {map:tmpTxt };
}
function gen_rooms_test( x_size, y_size, cell_min_x, cell_max_x ){

}

async function behavior_test_rot(o){
	if(o.caught_graphic == undefined){ 
		o.rot_angle = 0;
		//o.caught_graphic = o.graphic+"";
		
		o.caught_graphic = 
		  gridstr_rotation_MAKE_ROTATABLE_BORDER( 
			  gridstr_scale_nearest_neighbor(
				  o.graphic,100,130));

		}
	o.rot_angle +=.02;
	//o.graphic =  gridstr_rotate_90_degrees(//gridstr_rotate(
	// 	o.caught_graphic, o.rot_angle, true);//.01);
	
	o.graphic =  gridstr_rotate( 
		o.caught_graphic, o.rot_angle, " ", .01);
}
rmloaded_b_globalThis.test_rot = behavior_test_rot;

async function behavior_test_rot_90(o){
	if(o.caught_graphic == undefined){ 
		o.rot_angle = 0;
		//o.caught_graphic = o.graphic+"";
		o.caught_graphic = ""+o.graphic;}
	o.rot_angle +=.02;
	o.graphic =  gridstr_rotate_90_degrees(//gridstr_rotate(
	 	o.caught_graphic, o.rot_angle, true);//.01);
	//o.graphic =  gridstr_rotate( 
	//	o.caught_graphic, o.rot_angle," ",  .01);
}
rmloaded_b_globalThis.test_rot_90 = behavior_test_rot_90;

// behaviors can be nested, one in another funct. (same object):behav(o)
async function behavior_test_this_script(o){
	rmloaded_draw_overlay("fps :"+(1000/_update_delta),0 ,3, "");
	await rmloaded_b_globalThis.behav_controller_basic_gridmove(o);
	rmloaded_camera_focus(o.x,o.y, 3, 3); //x,y, x/y limit
	//rmloaded_room.objs[rmloaded_room.objs.length-1].dead = true;
    //if(controllers[0].pressed[0]=="RIGHT" //.isdown['RIGHT'];.getch="r"
		//UP,LEFT,RIGHT,DOWN,A/B/C/D/ENTER/ESCAPE 
	//&& rmloaded_col_test_SIMPLE(o.x+1, o.y,"z")==""){o.x+=1;return;}
}
rmloaded_b_globalThis.test_this_script = behavior_test_this_script;
rmloaded_loadroom( testRoom); 

