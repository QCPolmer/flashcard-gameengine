//file_debug_printf("\n\n test2  test \n\n");

// https://softwareengineering.stackexchange.com/questions/307467/what-are-good-habits-for-designing-command-line-arguments
// ----
// see 'POSIX' system stuff on page... it helps
///////////////////////////////////////////////////

//  file_argument_AUTORUN(); 
//  file_argument_AUTORUN_and_setParams(['paramiters','to','run');
//  file_load_js_cd();  // will be set to the js dir!
//
var main_run_after_script = function(){
	// FOR actual use, with an extra param below
	//
	//file_dir_copy(file_js_cd()+"../../", file_js_cd()+"./_src",
	//	1, ["js$"]);
	file_dir_copy(file_dir_cd(), 
		file_dir_cd()+"html_dist/",
		3, [""], ["cmd$"]);
	file_dir_copy(file_js_cd()+"../../LOAD_1_core_lang_optimized", 
		file_dir_cd()+"html_dist/_src/LOAD_1_core_lang_optimized",
		3, ["js$"], ["m.js$","INJECT_C.js"]);
	file_dir_copy(file_js_cd()+"../../LOAD_2_core_js", 
		file_dir_cd()+"html_dist/_src/LOAD_2_core_js",
		3, ["js$"], ["m.js$","INJECT_C.js"]);
	file_dir_copy(file_js_cd()+"../../COMPILE_THIS", 
		file_dir_cd()+"html_dist/_src/COMPILE_THIS",
		3, ["js$"], ["m.js$","INJECT_C.js"]);

	return;
	
} 


main_run_after_script();
/*
var file_data_eval = async function(){ 
	file_dir_convert_file_to_c_str();
		return;		


}*/


