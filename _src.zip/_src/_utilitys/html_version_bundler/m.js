//file_debug_printf("\n\n test2  test \n\n");

// https://softwareengineering.stackexchange.com/questions/307467/what-are-good-habits-for-designing-command-line-arguments
// ----
// see 'POSIX' system stuff on page... it helps
///////////////////////////////////////////////////

//  file_argument_AUTORUN(); 
//  file_argument_AUTORUN_and_setParams(['paramiters','to','run');
//  file_load_js_cd();  // will be set to the js dir!
//
var main_run_after_script = function(){
	// FOR actual use, with an extra param below
	//
	//file_dir_copy(file_js_cd()+"../../", file_js_cd()+"./_src",
	//	1, ["js$"]);
	//
	//ADDED 5/18/2026
	var tmpSingleFile = main__make_single_file__html_file();


	file_dir_copy(file_dir_cd(), 
		file_dir_cd()+"html_dist/",
		3, [""], ["cmd$"]);
	file_dir_copy(file_js_cd()+"../../LOAD_1_core_lang_optimized", 
		file_dir_cd()+"html_dist/_src/LOAD_1_core_lang_optimized",
		3, ["js$"], ["m.js$","INJECT_C.js"]);
	file_dir_copy(file_js_cd()+"../../LOAD_2_core_js", 
		file_dir_cd()+"html_dist/_src/LOAD_2_core_js",
		3, ["js$"], ["m.js$","INJECT_C.js"]);
	file_dir_copy(file_js_cd()+"../../COMPILE_THIS", 
		file_dir_cd()+"html_dist/_src/COMPILE_THIS",
		3, ["js$"], ["m.js$","INJECT_C.js"]);

	// ADDED 5/18/2026
	file_save(file_dir_cd(), "html_dist/single_file_EXPERIMENTAL.html", 
		tmpSingleFile );

	return;
	
} 

// ADDED 5/18/2026
/*
function __thisFile_eval_can_await( getScriptTooExectute ){
		//__file_load_promise( getFileName){
        return new Promise(function(resolve, reject) {
                var script = document.createElement('script');
                script.onload = function(){resolve(1);};
		script.onerror = function(){
			document.head.removeChild(script);
			resolve(0);};
		script.innerHTML = getScriptTooExectute; 
                document.head.appendChild(script);
        });
}
*/
//
// ADDED 5/18/2026
function main__make_single_file__html_file(){
	//init core-engine load... (order matters...)
	var getFilesList = [
	"../../LOAD_1_core_lang_optimized/file.js",
	"../../LOAD_1_core_lang_optimized/gridstr.js",
	"../../LOAD_1_core_lang_optimized/gridstr_scale.js",
	"../../LOAD_1_core_lang_optimized/draw.js",
	"../../LOAD_1_core_lang_optimized/sketch.js",
	"../../LOAD_1_core_lang_optimized/sketch_3d_CORE.js",
	"../../LOAD_2_core_js/controller.js",
	"../../LOAD_1_core_lang_optimized/update_html_port.js",
	"../../LOAD_1_core_lang_optimized/rmloaded_batch_n_collisions.js",
	"../../LOAD_1_core_lang_optimized/sketch_lines.js",
	"../../LOAD_1_core_lang_optimized/progen_CORE.js",
	"../../LOAD_1_core_lang_optimized/ml_CORE.js",
	"../../LOAD_1_core_lang_optimized/touchscreen_HTML_ONLY.js",
	].map(function(a){ return file_js_cd()+a;});


	getFilesList = getFilesList.concat( [ //order maters
	"txttools.js", "progen.js",  "progen_obj.js", 
	"rmloaded_search.js", "rmloaded.js", "ml.js",   
	"pipe_n_rows.js", "level_editor_loader.js",
	"gui_and_gui_menu.js", "gui_menu_flashcards.js",
	"controller_behaviors.js", "gridstr_rotate.js", "sketch_rays.js", 
	"g.js", "g_rmwarp.js", "g_rmwarp_univ2d.js", "g_convo.js", 
	"sketch_3d.js",
	"rogue.js"].map(function(a){ 
		 return file_js_cd()+"../../LOAD_2_core_js/"+a;}) );


	//var getFilesList = file_dir_search(
	//	file_js_cd()+"../../LOAD_1_core_lang_optimized", 0,
	//	["js$"], ["m.js$","INJECT_C.js"] );
	
	//var getFilesList = getFilesList.concat( file_dir_search(
	//	file_js_cd()+"../../LOAD_2_core_js", 4,
	//	["js$"], ["m.js$","INJECT_C.js"]) );

	getFilesList = getFilesList.concat( file_dir_search(	
		file_js_cd()+"../../COMPILE_THIS", 4,
		["js$"], ["m.js$","INJECT_C.js"]) );

	getFilesList = getFilesList.concat( file_dir_search(	
		file_dir_cd(), 4,
		["js$"], ["m.js$","INJECT_C.js"]) );	   

	var getFiles_text = file_pull_all_data_from_filelist(getFilesList,
		false ); //OPTIONAL_remove_comments_from_js);
			// REMOVING COMMENTS LIKE THIS KILLS 
			// THE async/await. 
			// (remove them below):
	for(var i=0; i< getFiles_text.length; i+=1){
		 getFiles_text[i] =file_scrub_comments( getFiles_text[i]);}
	// to handle initial values...
	var tmpScriptsText = "<script> var _file_check_loaded_js = {};"
		+"var _file_core_js=  '_src/LOAD_2_core_js/' </script>";
	for(var i=0; i< getFilesList.length; i+=1){
		tmpScriptsText = tmpScriptsText + 
			"<script> " 
			+'_file_check_loaded_js[ "'+ 
			  getFilesList[i].split("\\").join("/").split("/")
				.slice(-1)[0]  
			+'"] = true; \n'
			+ getFiles_text[i] + 
			"\n</script>\n\n";   }
	//adding m.js/m_loadLate.js,
	// will load it via eval-ish thing
	tmpScriptsText = tmpScriptsText 
			+ "<script id='m_js_div'>"
			+ file_load( file_dir_cd(), "m.js")
			+ "</script>";
	
	var tmpHTML_Outline = `<html><!DOCTYPE html>
<html> <head></head><body style="background-color:black; color:LightGray; font-weight:bold; font-size:large;">
<div id="_draw_canvas_holder_div" style="text-align: center;">
	<pre id="_draw_canvas_div"> </pre> 
	<div id="_draw_canvas_onscreen_ctrls" style="display:none;"></div>
<button onclick="hide_show_elements('_draw_canvas_onscreen_ctrls')">
	Hide/show touchscreen buttons</button>
<button onclick="fullscreenToggle_for_button(document.getElementById('_draw_canvas_holder_div'),1);">Toggle fullscreenpage</button>---zoom =ctrl+scroll
</div> 
<meta charset="utf-8"/>`+
tmpScriptsText+ ' </body> </html>';

return tmpHTML_Outline;
}



main_run_after_script();
/*
var file_data_eval = async function(){ 
	file_dir_convert_file_to_c_str();
		return;		


}*/


