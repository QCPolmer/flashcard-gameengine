//file_debug_printf("\n\n test2  test \n\n");

// https://softwareengineering.stackexchange.com/questions/307467/what-are-good-habits-for-designing-command-line-arguments
// ----
// see 'POSIX' system stuff on page... it helps
///////////////////////////////////////////////////

//  file_argument_AUTORUN(); 
//  file_argument_AUTORUN_and_setParams(['paramiters','to','run');
//  file_load_js_cd();  // will be set to the js dir!




var main_run_after_script = function(){
	// FOR actual use, with an extra param below
	//
	//file_dir_copy(file_js_cd()+"../../", file_js_cd()+"./_src",
	//	1, ["js$"]);
	var FILE_DOCS_SEPERATOR = "//API_TAG//";

	var tmpfiles=
	file_dir_search( file_js_cd()+"../../LOAD_1_core_lang_optimized",
		3, ["js$", "c$"], ["m.js$"]).concat(
	file_dir_search( file_js_cd()+"../../LOAD_2_core_js",
		3, ["js$", "c$"], ["m.js$"])).concat(
	file_dir_search( file_js_cd()+"../../COMPILE_THIS",
		3, ["js$", "c$"], ["m.js$", "one_js_embeded_file.c"]));

	var tmpScalped_data = "";
	for(var i=0; i< tmpfiles.length; i+=1){
		var tmpfile_data = file_load(  tmpfiles[i], "");
		//file_log_input(tmpfile_data + ":::" + tmpfiles[i]);
		tmpfile_data = tmpfile_data.split(FILE_DOCS_SEPERATOR);
		var tmp_txtblock = "";
		
		for(var j=1; j < tmpfile_data.length; j+=2){
			tmp_txtblock = 
				tmp_txtblock + tmpfile_data[j] + "\n"; }
		
		if(tmp_txtblock!=""){
			tmpScalped_data = tmpScalped_data + 
 "\n ///////////////////////////////////////////////////////////////////////"+ "\n ///////////////////////////////////////////////////////////////////////"+
				"\n /////////////   " + 
				tmpfiles[i].split("/").pop() +
"\n ///////////////////////////////////////////////////////////////////////\n"+
				tmp_txtblock;
	} 	}
	//NOT SAVED YET!
	file_save(file_js_cd(), "../../API.txt", tmpScalped_data);
	return;
	
} 

main_run_after_script();
/*
var file_data_eval = async function(){ 
	file_dir_convert_file_to_c_str();
		return;		


}*/


