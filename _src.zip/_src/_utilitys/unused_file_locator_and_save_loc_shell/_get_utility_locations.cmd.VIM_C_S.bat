c:\Users\Harrison\Desktop\_BACKUP\ACTIVE_LARGE_PROJECTS\_flashcard_gameengine\_src\_utility_locations\_get_utility_locations.cmd gcc.exe

exit 
