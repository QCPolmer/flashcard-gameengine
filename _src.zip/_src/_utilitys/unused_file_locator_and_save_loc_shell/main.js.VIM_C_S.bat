
:; # https://github.com/llamasoft/polyshell
:; # FOR SCRIPTING[sh&bat]: test this crap out IN TERMINAL FIRST!!!
:; # AND 
:; # set ff=   [[if dos]] set ff=unix [[without this, unix glitches]]
:; # EDIT:
:; # this settup is NOT POSIX compliant...
:; # the top code, however, IS... [ the code this comment is in... ]
:; # the program that LOOKS like the one to target is Dash (dash)
:; # in a linux box. 
:; # and for this, I probably should just redirect all the data
:; # up to a centralized file (sh ) which doesn't need to be 
:; # multi-lingual. 
:; # for coding in shell:
:; # use sh ( I think... dash might be more low level ) 
:; # https://www.shellcheck.net/
:; # this is installed locally.
:; # as bash is a subset of posix shell,

echo \" <<'BATCH_SCRIPT' >/dev/null ">NUL "\" \`" <#"
@ECHO OFF
REM =====
REM =====
REM =====
REM ===============================================
REM =====
REM ===== Batch Script Begin ==================
REM =====
REM ===============================================
REM =====


set mypath=%cd%
set my_execute_js=main.js

set "mypath=%mypath:\=/%"
echo "%mypath%"
set compiler_cmds_n_src=/../_utility_locations/interpreter_c_base_params.win.txt
set compiler_cmds="" :: this will fill in later

cd "%mypath%/../../../../../../_src/COMPILE_THIS"
cd "%mypath%/../../../../../_src/COMPILE_THIS"
cd "%mypath%/../../../../_src/COMPILE_THIS"
cd "%mypath%/../../../_src/COMPILE_THIS"
cd "%mypath%/../../_src/COMPILE_THIS"
cd "%mypath%/../_src/COMPILE_THIS"
cd "%mypath%/_src/COMPILE_THIS"

for /f "delims=" %%i in (%cd%%compiler_cmds_n_src%) do ( set compiler_cmds=%%i )
:: run command OR error
( %compiler_cmds% "%mypath%/%my_execute_js%" "%*" ) || (
	echo .
	echo command that failed
	echo %compiler_cmds% "%mypath%/%my_execute_js%" "%*"	
	echo  .
	echo Failed to find %compiler% [the compiler], either install it or add a document labeled '%compiler%.txt' to _src/_utility_locations containing the file location of %compiler%.
)



set /p Input=Enter Text to continue: 


REM =====
REM =====
REM =====
REM ===============================================
REM =====	
REM ====== Batch Script End ======
REM =====
REM ===============================================
GOTO :eof
TYPE CON >NUL
BATCH_SCRIPT
#> | Out-Null


echo \" <<'POWERSHELL_SCRIPT' >/dev/null # " | Out-Null
# ===== PowerShell Script Begin =====
echo "... but also a PowerShell script!"
# ====== PowerShell Script End ======
while ( ! $MyInvocation.MyCommand.Source ) { $input_line = Read-Host }
exit
<#
POWERSHELL_SCRIPT


set +o histexpand 2>/dev/null
# ==========
# ====================================================
# ==========
# ===== Bash Script Begin =============================
# ==========
# ====================================================
# ==========

_cwd="$PWD";
_exec_this_js_file="/main.js";
compiler_cmds_n_src=/../_utility_locations/interpreter_c_base_params.unix.txt
compiler_cmds="" # this will fill in later

cd "$_cwd/../../../../../../_src/COMPILE_THIS";
cd "$_cwd/../../../../../_src/COMPILE_THIS";
cd "$_cwd/../../../../_src/COMPILE_THIS";
cd "$_cwd/../../../_src/COMPILE_THIS";
cd "$_cwd/../../_src/COMPILE_THIS";
cd "$_cwd/../_src/COMPILE_THIS";
cd "$_cwd/_src/COMPILE_THIS";
echo "passing all paramiters via $@, first paramiter is js file to load"; 
echo TRACE:::: ../___duktape_src_ONCE_COMPILED_CAN_OMIT/duktape.c -run one_with_dlls.c $_cwd/$_exec_this_js_file;

compiler_cmds=$(<$PWD$compiler_cmds_n_src)

# run command OR error
($compiler_cmds "$_cwd/$_exec_this_js_file" $@ ) || (
	echo 
	echo ------------ COMMAND THAT FAILED:
	echo	$compiler_cmds "$_cwd/$_exec_this_js_file" $@
	echo
	echo Could not find $_compiler_base [the compiler]! Either install it or add a document labeled [ $_compiler_base.unix.txt ] to _src/_utility_locations containing the file location of $_compiler_base.
	echo
)
exit $?


# ==========
# ====================================================
# ==========
# ====== Bash Script End =======================
# ==========
# ==================================================
# ==========
case $- in *"i"*) cat /dev/stdin >/dev/null ;; esac
exit
#>




