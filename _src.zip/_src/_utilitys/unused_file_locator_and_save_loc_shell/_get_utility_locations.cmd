:; # https://github.com/llamasoft/polyshell
:; # FOR SCRIPTING[sh&bat]: test this crap out IN TERMINAL FIRST!!!
:; # AND 
:; # set ff=   [[if dos]] set ff=unix [[without this, unix glitches]] 


echo \" <<'BATCH_SCRIPT' >/dev/null ">NUL "\" \`" <#"
@ECHO OFF
REM =====
REM =====
REM =====
REM ===============================================
REM =====
REM ===== Batch Script Begin ==================
REM =====
REM ===============================================
REM =====




@echo off
set FILELOC=%~1
set FILE_FINDSEARCH="where %~1"
set THIS_DOC_FILEPATH=%~dp0
set THIS_DOC_FILE_TOGET_DATA_FROM=%THIS_DOC_FILEPATH%%~1.txt    
::::::::::::::::::::::::::::::::::
:::::::::::::::::::::::::::::
:: SETTING FILELOCS (feel free to redefine locations after 'FILELOC='
if exist %THIS_DOC_FILE_TOGET_DATA_FROM%(
	FOR /F %%i IN (%THIS_DOC_FILE_TOGET_DATA_FROM%) do ( 
			set FILELOC=%%i
	)
)
:::::::::::::::::::::::::::::::::::;
:::::::::::::::::::::::::::::::::::;
:: this is a catch-all, for ALL paramites defined above
set LOOKED_FOR_FILE=""
if NOT %FILELOC%=="" (
	if not exist %FILELOC% (
		for /f "delims=" %%i in ('%FILE_FINDSEARCH%') do ( 
			set FILELOC=%%i 
		)
		set LOOKED_FOR_FILE="TRUE"
	)	
)
:: this is in a different section because variables get set 
:: AFTER the loops are all done
if NOT %LOOKED_FOR_FILE%=="" (
	if exist %FILELOC% ( 
		echo %FILELOC% > "%THIS_DOC_FILE_TOGET_DATA_FROM%"
	)
)
if NOT %FILELOC%=="" (
	if exist %FILELOC% (echo %FILELOC%
		exit 0;
	) else (
		echo FILE_NOT_FOUND
		exit 1
	)	) 

REM =====
REM =====
REM =====
REM ===============================================
REM =====	
REM ====== Batch Script End ======
REM =====
REM ===============================================
GOTO :eof
TYPE CON >NUL
BATCH_SCRIPT
#> | Out-Null


echo \" <<'POWERSHELL_SCRIPT' >/dev/null # " | Out-Null
# ===== PowerShell Script Begin =====
echo "... but also a PowerShell script!"
# ====== PowerShell Script End ======
while ( ! $MyInvocation.MyCommand.Source ) { $input_line = Read-Host }
exit
<#
POWERSHELL_SCRIPT


set +o histexpand 2>/dev/null
# ==========
# ====================================================
# ==========
# ===== Bash Script Begin =============================
# ==========
# ====================================================
# ==========

_cwd="$PWD";
_exec_this_js_file="/main.js";

fileloc=$1
file_findsearch="which $1"
#not sure about this
this_doc_filepath=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
this_doc_file_toget_data_from=$this_doc_filepath/$fileloc.unix.txt   

# from https://stackoverflow.com/questions/242538/unix-shell-script-find-out-which-directory-the-script-file-resides
script=$(readlink -f "$0")
scriptpath=$(dirname "$script")



# seeing if file exists, if it does, pull it. 
if [ -f "$this_doc_file_toget_data_from" ]
then 
	fileloc=$(<$this_doc_file_toget_data_from) 
fi ;



looked_for_file=0 
# checking text string


if [ -f "$fileloc" ] 
then
   $()
else
    	fileloc=$($file_findsearch) 
	looked_for_file=1
fi ;



if [ $looked_for_file == 1 ] && [ -f "$fileloc" ] 
then
	echo DIDDIDIDIIDIDDID
	echo $fileloc > $this_doc_file_toget_data_from	
fi ;


if [ -f "$fileloc" ]
then
		$()
else
	echo FILE_NOT_FOUND
	exit 1
fi

echo "$fileloc"
exit 0

# ==========
# ====================================================
# ==========
# ====== Bash Script End =======================
# ==========
# ==================================================
# ==========
case $- in *"i"*) cat /dev/stdin >/dev/null ;; esac
exit
#>



