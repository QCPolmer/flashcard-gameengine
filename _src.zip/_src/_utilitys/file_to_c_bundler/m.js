
//file_debug_printf("\n\n test2  test \n\n");

// https://softwareengineering.stackexchange.com/questions/307467/what-are-good-habits-for-designing-command-line-arguments
// ----
// see 'POSIX' system stuff on page... it helps
///////////////////////////////////////////////////

//  file_argument_AUTORUN(); 
//  file_argument_AUTORUN_and_setParams(['paramiters','to','run');
//  file_load_js_cd();  // will be set to the js dir!



file_load_js( file_js_cd(), "file_arguments.js");



var main_run_after_script = function(){
	// FOR actual use, with an extra param below
	//
	//file_dir_copy(file_js_cd()+"../../", file_js_cd()+"./_src",
	//	1, ["js$"]);
	
	var myDirs_to_bundle = [file_core_js_cd(), file_dir_cd()];
	
	var  myFile_to_inject_between = 
		file_core_js_cd()+"../COMPILE_THIS/one_js_embeded_file.c";
	var MY_TEXT_TO_EMBED_BETWEEN = "//INJECT_C_CODE_FROM_FILE_HERE//";
	
	//added 6/8/2026 - mimizable code function!
	var tmpInject_js_str_compression_funct = null;

	if( file_input("\n\n\n\n"
	    +"\n--------------------------------------"
	    +"\nUse UglifyJS to minimize JS in executable?"
	    +"\n(smaller executable, faster loading, VERY slow compilation)"
	    +"\n '1):yes (else no)\n") == 1 ){
		var tmpDISABLE_MINIFY_JS = false;
	}else{ var tmpDISABLE_MINIFY_JS = true; } 
	
	if( !tmpDISABLE_MINIFY_JS ){
	  file_log("file_to_c_bundler/m.js : using UglifyJS.MyMinify.js");
	   file_load_js_noembed( file_core_js_cd(), 
		"/../_utilitys/UglifyJS.MyMinify.js");
	  tmpInject_js_str_compression_funct = UglifyJS.MyMinify;
	}else{ file_log("file_to_c_bundler/m.js : UglifyJS.MyMinify.js"
	    + "\n---------NOT USING!!!---------");
	}
	
	file_input( "---------------"+ myDirs_to_bundle );

	file_dir_embed_in_c_file(
		myDirs_to_bundle, myFile_to_inject_between,
		MY_TEXT_TO_EMBED_BETWEEN,
		true, // OPTIONAL_remove_comments_from_js
		tmpInject_js_str_compression_funct); 
	file_debug_printf("test");
	file_debug_scanf();
} 

/* OLD
var file_scalpel_data = function( file_name, textblock_to_scalpel_text_between){
	var tmpfileText = file_load(file_name).split(
		textblock_to_insert_text_between);
	if(tmpfileText.length > 2){ return tmpfileText[1]; }
	return "";
}
*/

main_run_after_script();
/*
var file_data_eval = async function(){ 
	file_dir_convert_file_to_c_str();
		return;		


}*/

