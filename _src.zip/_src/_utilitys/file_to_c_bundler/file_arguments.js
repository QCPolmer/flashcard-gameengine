var _file_argument_AUTORUN_functs = [ ];
var file_argument_AUTORUN_addfuncts = function( getFunct ){
	_file_argument_AUTORUN_functs.push(getFunct); }
var file_argument_AUTORUN = function(){
	for(var i =0; i< _file_argument_AUTORUN_functs.length; i+=1){
		_file_argument_AUTORUN_functs[i]();	}	}
var _file_argument_AUTORUN_tmp_params = [];
var file_argument_AUTORUN_and_setParams = function( getParamList ){
	getParamList = getParamList.split(" ");
	getParamList.unshift( file_dir_cd() );
	var file_argument_get_tmp = file_argument_get;
	_file_argument_AUTORUN_tmp_params = getParamList;
	file_argument_get = function(getParam){
		if(getParam<= _file_argument_AUTORUN_tmp_params.length){
			return _file_argument_AUTORUN_tmp_params[getParam];
		}else{ return "";} }
	file_argument_AUTORUN();
	file_argument_get = file_argument_get_tmp; }


// ARGS START WITH '-'
var file_argument_paramsget = function( 
		get_1_char_prefixes_str, get_list_params_to_get ){
	var i =1; // param 0 is filename
	var ret_array = []; var reading_tag = 0;

	while(file_argument_get(i).length != 0){
		if(reading_tag == 1){
		    if( get_1_char_prefixes_str.indexOf(
			    file_argument_get(i)[0]) == -1){
				ret_array.push( file_argument_get(i) );
		    }else{ 
				reading_tag = 0;}	
		}
		if(reading_tag == 0){
		   for( var j=0; j< get_list_params_to_get.length; j+=1){
		     
			//file_debug_printf( "\n"+get_list_params_to_get[j]+ "  "+ file_argument_get(i) +" "+ ((""+file_argument_get(i)) == (""+get_list_params_to_get[j])) +ret_array.length+"\n");
			//file_debug_scanf();

		      if(get_list_params_to_get[j] == file_argument_get(i)){
		  	reading_tag =1;

			if( ret_array.length ==0 ){ 
				ret_array.push( file_argument_get(i));}
			break;
		   } }
		}	
	    i+=1; }
	return ret_array;
}

// recipe: -idir_js ./ -i -o output.js -file_dir_to_c_str 
// requires 'dir'
var file_arguments_get_filelist_from_params = function( ){
	var arg_src_files = 
	    file_argument_paramsget("-", ["-I", "-i", "-input", "--input"]);
	var arg_src_dirs_all_files = 
	    file_argument_paramsget("-", ["-Idir", "-idir" ]);
	var arg_src_dirs_js_only = 
	    file_argument_paramsget("-", ["-Idir_js", "-idir_js" ]);

	//removes original param;
	arg_src_files.shift(); 
	arg_src_dirs_all_files.shift(); arg_src_dirs_js_only.shift();
	

	// adding files abreviation in front of filenames
	for(var i=0; i< arg_src_files; i+=1){
		arg_src_files[i]= file_dir_cd() + arg_src_files[i];}
	// for ALL files in dir
	for(var i =0; i< arg_src_dirs_all_files.length; i+=1){ 
		var tmpfiles =file_dir_search(
			file_dir_cd()+ arg_src_dirs_all_files[i], 0);
		if(tmpfiles != null){ 
			arg_src_files = arg_src_files.concat(tmpfiles); } }
	// for only JS files in dir
	for(var i =0; i< arg_src_dirs_js_only.length; i+=1){ 
	  var tmpfiles =file_dir_search( 
		  file_dir_cd()+arg_src_dirs_js_only[i], 0,["js$"]);
	  
	  if(tmpfiles != null){ 
			arg_src_files = arg_src_files.concat(tmpfiles); } }
	
	

	return arg_src_files;
}
